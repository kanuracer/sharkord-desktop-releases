# Sharkord Desktop Evidence — Live-Debug — v0.3.19

## Purpose

Temporary opt-in live diagnostics for broken macOS voice/video.

## Implemented

- Wails backend method `SendLiveDebugLog` posts sanitized JSON to a configurable HTTP(S) endpoint.
- Backend redacts sensitive keys/values before sending.
- Settings card `Live-Debug` contains enable toggle, endpoint field, new session button, and explicit permission prompt buttons:
  - Mic fragen
  - Kamera fragen
  - Screen fragen
- Voice instrumentation logs:
  - voice join/rejoin
  - mediasoup `Device.load`
  - producer/consumer transport create/connect
  - produce mutation and producer creation
  - consume mutation and remote stream creation
  - mic/camera/screen getUserMedia/getDisplayMedia results/errors

## Collector

Host collector:

```text
http://10.0.0.117:8799/sharkord-live-log
/data/sharkord-live-debug/v0.3.19.ndjson
```

Smoke test:

```text
GET /healthz OK
POST /sharkord-live-log OK
```

## Verification

```text
go test ./... OK
npm test -- --runInBand OK, 41/41
npm run build OK
wails3 build OK
```
