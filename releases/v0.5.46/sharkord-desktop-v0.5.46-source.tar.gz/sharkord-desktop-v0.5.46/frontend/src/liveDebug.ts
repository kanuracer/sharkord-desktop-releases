import * as API from '../bindings/github.com/kanuracer/sharkord-desktop/appservice';

export const DEFAULT_LIVE_DEBUG_ENDPOINT = 'http://10.0.0.117:8799/sharkord-live-log';
export const LIVE_DEBUG_STORAGE_KEY = 'sharkord-desktop:live-debug:v1';

export type DiagnosticLogInfo = { path: string; size: number };

export type LiveDebugSettings = {
  enabled: boolean;
  endpoint: string;
  sessionId: string;
};

function newSessionId() {
  try { return crypto.randomUUID(); }
  catch { return `session-${Date.now()}-${Math.random().toString(36).slice(2)}`; }
}

export function defaultLiveDebugSettings(): LiveDebugSettings {
  return { enabled: false, endpoint: DEFAULT_LIVE_DEBUG_ENDPOINT, sessionId: newSessionId() };
}

export function loadLiveDebugSettings(): LiveDebugSettings {
  const fallback = defaultLiveDebugSettings();
  try {
    const parsed = JSON.parse(localStorage.getItem(LIVE_DEBUG_STORAGE_KEY) || '{}') as Partial<LiveDebugSettings>;
    return {
      enabled: !!parsed.enabled,
      endpoint: parsed.endpoint || fallback.endpoint,
      sessionId: parsed.sessionId || fallback.sessionId
    };
  } catch {
    return fallback;
  }
}

export function saveLiveDebugSettings(settings: LiveDebugSettings) {
  localStorage.setItem(LIVE_DEBUG_STORAGE_KEY, JSON.stringify(settings));
}

export function resetLiveDebugSession(settings: LiveDebugSettings): LiveDebugSettings {
  return { ...settings, sessionId: newSessionId() };
}

export function sendLiveDebug(settings: LiveDebugSettings, event: string, data: Record<string, unknown> = {}, level = 'info', message = '') {
  if (!settings.enabled || !settings.endpoint) return;
  void API.SendLiveDebugLog({
    endpoint: settings.endpoint,
    sessionId: settings.sessionId,
    event,
    level,
    message,
    data,
    at: Date.now()
  }).catch((err) => console.warn('Live-Debug send failed', err));
}

export async function appendDiagnosticLog(event: string, data: Record<string, unknown> = {}, level = 'info', message = '', sessionId = 'desktop'): Promise<DiagnosticLogInfo> {
  return API.AppendDiagnosticLog({
    endpoint: '',
    sessionId,
    event,
    level,
    message,
    data,
    at: Date.now()
  }) as Promise<DiagnosticLogInfo>;
}

export async function getDiagnosticLogInfo(): Promise<DiagnosticLogInfo> {
  return API.GetDiagnosticLogInfo() as Promise<DiagnosticLogInfo>;
}
