import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const voiceSource = readFileSync(new URL('../src/voiceEngine.ts', import.meta.url), 'utf8');
const liveDebugSource = readFileSync(new URL('../src/liveDebug.ts', import.meta.url), 'utf8');
const typesSource = readFileSync(new URL('../src/sharkordTypes.ts', import.meta.url), 'utf8');
const packageJson = readFileSync(new URL('../package.json', import.meta.url), 'utf8');

test('native client removes iframe embedding completely', () => {
  assert.doesNotMatch(appSource, /<iframe/);
  assert.doesNotMatch(appSource, /serverFrame/);
});

test('native client implements Sharkord auth and tRPC join flow', () => {
  assert.match(clientSource, /\/login/);
  assert.match(clientSource, /createTRPCProxyClient/);
  assert.match(clientSource, /createWSClient/);
  assert.match(clientSource, /others\.handshake\.query/);
  assert.match(clientSource, /others\.joinServer\.query/);
});

test('native UI has Discord-like channel and message surfaces', () => {
  assert.match(appSource, /channelSidebar/);
  assert.match(appSource, /messagePane/);
  assert.match(appSource, /messageComposer/);
  assert.match(appSource, /connectPanel/);
});

test('native client can fetch and send messages through tRPC', () => {
  assert.match(clientSource, /messages\.get\.query/);
  assert.match(clientSource, /messages\.send\.mutate/);
});

test('central direct messages show the own user account panel in the DM center', () => {
  assert.match(appSource, /function AccountPanel/);
  assert.match(appSource, /function DirectMessagesSidebar\([^)]*ownUser/);
  assert.match(appSource, /<AccountPanel[\s\S]*ownUser=\{ownUser\}[\s\S]*onOpenOwnProfile=\{onOpenOwnProfile\}/);
  assert.match(appSource, /<DirectMessagesSidebar[\s\S]*ownUser=\{dmOwnUser\}[\s\S]*onOpenOwnProfile=\{\(\) => openOwnProfile\(dmAccountServerId\)\}/);
});

test('central direct messages aggregate every connected server behind the Sharkord logo home button', () => {
  assert.match(typesSource, /isDm\?: boolean/);
  assert.match(typesSource, /publicSettings\?: Partial<SharkordServerSettings>/);
  assert.match(clientSource, /export async function getDirectMessages/);
  assert.match(clientSource, /dms\.get\.query/);
  assert.match(clientSource, /export async function openDirectMessage/);
  assert.match(clientSource, /dms\.open\.mutate/);
  assert.match(clientSource, /dms\.onConversationOpen\.subscribe/);
  assert.match(appSource, /type AppView = 'chat' \| 'settings' \| 'dms'/);
  assert.match(appSource, /type DirectMessageSelection = \{ serverId: string; channelId: number \} \| null/);
  assert.match(appSource, /function DirectMessagesSidebar/);
  assert.match(appSource, /directMessageEntries/);
  assert.match(appSource, /selectedDirectMessage/);
  assert.match(appSource, /onHome=\{openDirectMessagesHome\}/);
  assert.match(appSource, /homeActive=\{activeView === 'dms'\}/);
  assert.match(appSource, /getChannelMessages\(conn, entry\.channel\.id, 50\)/);
  assert.match(appSource, /sendChannelMessage\(conn, targetChannelId, text, files/);
  assert.match(appSource, /sourceMatchesDm = source\?\.view === 'dms' && source\.serverId === dmEntry\.server\.id && source\.channelId === targetChannelId/);
  assert.match(appSource, /messageSourceKey=\{`\$\{activeView\}:/);
  assert.match(appSource, /if \(messageSourceKeyRef\.current !== uploadSourceKey\)/);
  assert.match(appSource, /markChannelAsRead\(conn, entry\.channel\.id\)/);
  assert.match(appSource, /selectedDirectMessageRef\s*=\s*useRef<DirectMessageSelection>/);
  assert.match(appSource, /visibleMessagesSourceRef\s*=\s*useRef<VisibleMessagesSource>/);
  assert.match(appSource, /source\.serverId === eventServerId && source\.channelId === message\.channelId/);
  assert.match(appSource, /visibleMessagesSourceRef\.current = null/);
  assert.match(appSource, /const stillSelected = activeViewRef\.current === 'dms'/);
  assert.match(appSource, /if \(!stillSelected\) return/);
  assert.match(appSource, /function messageActionContext\(message: SharkordMessage\)/);
  assert.match(appSource, /conn: dmEntry\.connection,\s*channelId: dmEntry\.channel\.id,\s*reload: \(\) => \{/);
  assert.match(appSource, /current\?\.view === 'dms' && current\.serverId === dmEntry\.server\.id && current\.channelId === dmEntry\.channel\.id/);
  assert.match(appSource, /editMessage\(ctx\.conn, message\.id, plainText\)/);
  assert.match(appSource, /deleteMessage\(ctx\.conn, message\.id\)/);
  assert.match(appSource, /toggleReaction\(ctx\.conn, message\.id, emoji\)/);
  assert.match(appSource, /openUserProfilePopover\(event, user, activeView === 'dms' \? selectedDirectMessageEntry\?\.server\.id : activeServer\?\.id\)/);
  assert.match(appSource, /const profileServerId = userProfilePopover\?\.serverId \?\? activeServer\?\.id/);
  assert.match(appSource, /connectionsRef\.current\.get\(profileServerId\) \?\? connection/);
  assert.match(appSource, /profilePopoverConnection\?\.join\.publicSettings\?\.directMessagesEnabled/);
  assert.match(appSource, /profilePopoverCanManageUsers/);
  assert.match(appSource, /Direct Message · \$\{entry\.server\.name\}/);
  assert.doesNotMatch(clientSource, /directMessages\.|createDm|createDirectMessage|channels\.createDm/);
});

test('native client keeps saved server connections alive while switching active server', () => {
  assert.match(appSource, /connectionsRef\s*=\s*useRef<Map<string, SharkordConnection>>/);
  assert.match(appSource, /connectSavedServers/);
  assert.match(appSource, /for \(const server of state\.servers\)/);
  assert.match(appSource, /API\.LoadServerCredentials\(server\.id\)/);
  assert.doesNotMatch(appSource, /useEffect\(\(\) => \{[\s\S]*?connectionRef\.current\?\.close\(\); connectionRef\.current = null;[\s\S]*?\}, \[activeServer\?\.id\]\);/);
  assert.match(appSource, /connectionRef\.current = connectionsRef\.current\.get\(activeServer\.id\) \?\? null/);
  assert.match(appSource, /wireSubscriptions\(next, server\.id\)/);
  assert.match(appSource, /const isActiveSubscriptionServer = \(\) => !serverId \|\| serverId === activeServerIdRef\.current/);
});

test('server switching does not close voice engines for other servers', () => {
  assert.match(appSource, /voiceEnginesRef\s*=\s*useRef<Map<string, SharkordVoiceEngine>>/);
  assert.match(appSource, /voiceEngineRef\.current = voiceEnginesRef\.current\.get\(activeServer\.id\) \?\? null/);
  assert.match(appSource, /cleanupServerSession\(serverId/);
  assert.doesNotMatch(appSource, /useEffect\(\(\) => \{[\s\S]*?voiceEngineRef\.current\?\.close\(\); voiceEngineRef\.current = null[\s\S]*?\}, \[activeServer\?\.id\]\);/);
});

test('server switching resets transient overlays instead of stacking old server UI', () => {
  assert.match(appSource, /function resetTransientUiForServerSwitch\(\)/);
  const resetFn = appSource.match(/function resetTransientUiForServerSwitch\(\) \{[\s\S]*?\n  \}/)?.[0] ?? '';
  for (const closeCall of [
    'setContextMenu(null)',
    'setAdminWorkbenchOpen(false)',
    'setPendingChannelDelete(null)',
    'setPendingCategoryDelete(null)',
    'setScreenShareSettingsOpen(false)',
    'setModalOpen(false)'
  ]) assert.match(resetFn, new RegExp(closeCall.replace(/[()]/g, '\\$&')));
  const selectFn = appSource.match(/function selectServer\(serverId: string\) \{[\s\S]*?\n  \}/)?.[0] ?? '';
  assert.match(selectFn, /resetTransientUiForServerSwitch\(\)/);
  const menuFn = appSource.match(/function AdminContextMenu[\s\S]*?function createInviteDraft/)?.[0] ?? '';
  assert.doesNotMatch(menuFn, /contextMenuBackdrop/);
  assert.match(menuFn, /window\.addEventListener\('click'/);
});

test('async message loads are scoped to the active server before mutating visible UI', () => {
  const loadFn = appSource.match(/async function loadMessages\([\s\S]*?\n  \}/)?.[0] ?? '';
  assert.match(loadFn, /const requestServerId = serverIdForConnection\(conn\)/);
  assert.match(loadFn, /isActiveServerRequest\(requestServerId\)/);
  assert.match(loadFn, /snapshotMessagesForServer\(requestServerId/);
  assert.match(appSource, /function serverIdForConnection\(conn: SharkordConnection \| null\)/);
  assert.match(appSource, /function isActiveServerRequest\(serverId: string \| null\)/);
});

test('server switch restores connected server channels and public roles from join data when snapshot is empty', () => {
  const applyFn = appSource.match(/function applyServerSession\(serverId: string\) \{[\s\S]*?\n  \}/)?.[0] ?? '';
  const snapshotFn = appSource.match(/function snapshotFromConnection\(serverId: string, next: SharkordConnection\)[\s\S]*?\n  \}/)?.[0] ?? '';
  assert.match(appSource, /const currentSessionSnapshotRef = useRef<ServerSessionSnapshot \| null>\(null\)/);
  assert.match(appSource, /currentSessionSnapshotRef\.current = \{/);
  assert.match(appSource, /function snapshotFromConnection\(serverId: string, next: SharkordConnection\)/);
  assert.match(appSource, /serverSessionSnapshotsRef\.current\.set\(serverId, snapshotFromConnection\(serverId, next\)\)/);
  assert.doesNotMatch(appSource, /setStatus\(`Verbunden mit \$\{next\.join\.serverName\}`\); playDesktopSound\('server_connected'\);\n\s*snapshotServerSession\(serverId\)/);
  assert.match(typesSource, /roles\?: SharkordRole\[\]/);
  assert.match(snapshotFn, /adminRoles: next\.join\.roles \?\? \[\]/);
  assert.match(applyFn, /const joinChannels = activeConnection\?\.join\.channels \?\? \[\]/);
  assert.match(applyFn, /const joinRoles = activeConnection\?\.join\.roles \?\? \[\]/);
  assert.match(applyFn, /const liveChannelRows = snapshot\?\.liveChannels\?\.length \? snapshot\.liveChannels : joinChannels/);
  assert.match(applyFn, /const roleRows = snapshot\?\.adminRoles\?\.length \? snapshot\.adminRoles : joinRoles/);
  assert.match(applyFn, /setLiveChannels\(liveChannelRows\)/);
  assert.match(applyFn, /setAdminRoles\(roleRows\)/);
  assert.match(applyFn, /const selectedTextChannel = snapshot\?\.selectedChannelId \?\? liveChannelRows\.filter\(isTextChannel\)/);
  assert.match(applyFn, /void loadMessages\(activeConnection, selectedTextChannel\)/);
});

test('native client exposes webclient-equivalent message actions', () => {
  assert.match(clientSource, /messages\.edit\.mutate/);
  assert.match(clientSource, /messages\.delete\.mutate/);
  assert.match(clientSource, /messages\.togglePin\.mutate/);
  assert.match(clientSource, /messages\.toggleReaction\.mutate/);
  assert.match(appSource, /editMessage\(/);
  assert.match(appSource, /deleteMessage\(/);
  assert.match(appSource, /toggleMessagePin\(/);
  assert.match(appSource, /toggleReaction\(/);
});

test('native client implements webclient-like global search for messages and files', () => {
  assert.match(clientSource, /export async function globalSearchMessages/);
  assert.match(clientSource, /messages\.search\.query/);
  assert.match(clientSource, /export async function globalSearchFiles/);
  assert.doesNotMatch(clientSource, /files\.search\.query/);
  assert.match(clientSource, /files:\s*result\.files/);
  assert.match(appSource, /const searchPage = await globalSearchMessages/);
  assert.match(appSource, /const files = searchPage\.files \?\? \[\]/);
  assert.doesNotMatch(appSource, /globalSearchFiles\(connection/);
  assert.match(appSource, /function GlobalSearchDialog/);
  assert.match(appSource, /globalSearchOpen/);
  assert.match(appSource, /Ctrl\+K/);
  assert.match(appSource, /globalSearchResults/);
  assert.match(appSource, /globalFileSearchResults/);
  assert.match(appSource, /onGlobalSearchJump/);
  assert.match(appSource, /globalSearchCursor/);
});

test('global search result click navigates to other channels before closing the dialog', () => {
  const jumpFn = appSource.match(/async function onGlobalSearchJump[\s\S]*?\n  function openServerMenu/)?.[0] ?? '';
  const resultOpenFn = appSource.match(/const openGlobalSearchResult[\s\S]*?\n  const resetGlobalSearch/)?.[0] ?? '';
  assert.match(jumpFn, /const targetChannel = connection\?\.join\.channels\.find\(\(channel\) => channel\.id === channelId\)/);
  assert.match(jumpFn, /visibleMessagesSourceRef\.current = \{ view: 'chat', serverId: targetServerId, channelId \}/);
  assert.match(jumpFn, /setActiveView\('chat'\)/);
  assert.match(jumpFn, /setSelectedChannelId\(channelId\)/);
  assert.doesNotMatch(jumpFn, /const ctx = visibleMessageSourceContext\(channelId\);\s*if \(!ctx\) return/);
  assert.match(resultOpenFn, /const opened = await onGlobalSearchJump\(message\.channelId, message\.id\)/);
  assert.match(resultOpenFn, /if \(opened\) setGlobalSearchOpen\(false\)/);
  assert.doesNotMatch(resultOpenFn, /setGlobalSearchOpen\(false\);\s*onGlobalSearchJump/);
});

test('native client implements welcome profile setup dialog from server welcome flag', () => {
  assert.match(typesSource, /showWelcomeDialog\?: boolean/);
  assert.match(appSource, /WELCOME_PROFILE_SETUP_STORAGE_KEY/);
  assert.match(appSource, /shouldShowWelcomeProfileSetup/);
  assert.match(appSource, /setWelcomeProfileSetupOpen\(shouldShowWelcomeProfileSetup\(next/);
  assert.match(appSource, /function WelcomeProfileSetupDialog/);
  assert.match(appSource, /updateOwnProfile\(connection/);
  assert.match(appSource, /changeOwnAvatar\(connection/);
  assert.match(appSource, /markWelcomeProfileSetupDone/);
  assert.match(appSource, /welcome-profile-setup/);
});

test('native client exposes voice join, leave, state, participant subscriptions and speaking indicator', () => {
  assert.match(clientSource, /voice\.join\.mutate/);
  assert.match(clientSource, /voice\.leave\.mutate/);
  assert.match(clientSource, /voice\.updateState\.mutate/);
  assert.match(clientSource, /voice\.onJoin\.subscribe/);
  assert.match(clientSource, /voice\.onLeave\.subscribe/);
  assert.match(clientSource, /voice\.onUpdateState\.subscribe/);
  assert.match(clientSource, /voice\.onNewProducer\.subscribe/);
  assert.match(clientSource, /voice\.onProducerClosed\.subscribe/);
  assert.match(typesSource, /voiceMap/);
  assert.match(appSource, /voiceUsersByChannelId/);
  assert.match(appSource, /speakingUserIds/);
  assert.match(appSource, /speakingIndicator/);
  assert.match(appSource, /VoiceUserRow/);
  assert.match(appSource, /joinVoiceChannel\(/);
  assert.match(appSource, /toggleMicMuted\(/);
  assert.match(appSource, /toggleSoundMuted\(/);
});

test('voice member drag/drop stays compatible with official Sharkord Docker through capability gating', () => {
  assert.doesNotMatch(clientSource, /moveVoiceMember|onVoiceMoveRequested|voice\.onMoveRequested\.subscribe/);
  assert.doesNotMatch(clientSource, /voice\.moveMember\.mutate|voice\.move\.mutate/);
  assert.match(clientSource, /voiceUserMove:\s*false/);
  assert.match(clientSource, /voice\.moveUser\.mutate/);
  assert.match(appSource, /voiceUserMoveEnabled=\{!!connection\?\.serverCapabilities\.voiceUserMove\}/);
  assert.doesNotMatch(appSource, /moveVoiceMember|canMoveVoiceMembers|onVoiceMoveRequested|joinSelectedVoice\(targetChannel\)/);
  assert.match(appSource, /application\/x-sharkord-voice-user-id/);
  assert.doesNotMatch(appSource, /setVoiceMap\(\(current\) => \{\n\s*const next: VoiceMap = \{ \.\.\.current \};\n\s*const sourceUsers/);
});

test('missing tRPC procedure detection handles dot and comma paths', () => {
  assert.match(clientSource, /path\.replace\('\.', ',\'\)/);
});

test('native client implements real mediasoup voice send and receive audio/video/screen', () => {
  assert.match(packageJson, /"mediasoup-client"/);
  for (const route of [/createProducerTransport\.mutate/, /connectProducerTransport\.mutate/, /createConsumerTransport\.mutate/, /connectConsumerTransport\.mutate/, /voice\.produce\.mutate/, /voice\.consume\.mutate/, /voice\.getProducers\.query/]) assert.match(voiceSource, route);
  assert.match(voiceSource, /new Device\(/);
  assert.match(voiceSource, /navigator\.mediaDevices\.getUserMedia/);
  assert.match(voiceSource, /navigator\.mediaDevices\.getDisplayMedia/);
  for (const kind of ['VIDEO', 'SCREEN', 'SCREEN_AUDIO', 'EXTERNAL_VIDEO']) assert.match(voiceSource, new RegExp(kind));
  assert.match(voiceSource, /startWebcamStream/);
  assert.match(voiceSource, /startScreenShareStream/);
  assert.match(voiceSource, /remoteVideoStreams/);
  assert.match(voiceSource, /REMOTE_VIDEO_KINDS/);
  assert.match(voiceSource, /SCREEN_KIND/);
  assert.match(voiceSource, /EXTERNAL_VIDEO_KIND/);
  assert.match(appSource, /remoteAudioStreams/);
  assert.match(appSource, /remoteVideoStreams/);
  assert.match(appSource, /VoiceGridView/);
  assert.match(appSource, /VoiceUserCard/);
  assert.match(appSource, /<video/);
  assert.match(appSource, /startWebcamStream/);
  assert.match(appSource, /startScreenShareStream/);
  assert.match(appSource, /webcamEnabled/);
  assert.match(appSource, /sharingScreen/);
  assert.doesNotMatch(voiceSource, /await this\.startMicStream\(\);\n\s*this\.onStatus\('Voice verbunden/);
  assert.match(voiceSource, /try \{ await this\.startMicStream\(\); \}/);
});

test('camera and screen do not run against a half initialized voice engine without send transport', () => {
  assert.match(voiceSource, /isReadyToProduce\(\)/);
  assert.match(voiceSource, /return !!this\.producerTransport && !this\.producerTransport\.closed/);
  assert.match(appSource, /setVoiceMediaReady\(true\)/);
  assert.match(appSource, /setVoiceMediaReady\(false\)/);
  assert.match(appSource, /!voiceMediaReady/);
  assert.match(appSource, /Voice-Medien noch nicht bereit/);
  assert.doesNotMatch(appSource, /catch \(mediaError\) \{\n\s*setStatus\(`Voice verbunden · Medien nicht bereit: \$\{cleanError\(mediaError\)\}`\);\n\s*\}/);
});

test('camera and screen rebuild media transports inside the existing joined voice session', () => {
  assert.match(appSource, /voiceRouterRtpCapabilitiesRef/);
  assert.match(appSource, /initVoiceMediaForCurrentChannel/);
  assert.match(appSource, /await initVoiceMediaForCurrentChannel\(currentVoiceChannel, routerRtpCapabilities\)/);
  assert.match(appSource, /Router-Capabilities fehlen/);
  assert.match(appSource, /lastVoiceMediaErrorRef/);
  assert.doesNotMatch(appSource, /await joinSelectedVoice\(currentVoiceChannel\)/);
  assert.doesNotMatch(appSource, /Producer-Transport konnte nicht erstellt werden/);
});

test('macOS Wails WebKit forces mediasoup Safari12 handler when auto-detection fails', () => {
  assert.match(voiceSource, /resolveMediasoupHandlerName/);
  assert.match(voiceSource, /AppleWebKit/);
  assert.match(voiceSource, /Safari12/);
  assert.match(voiceSource, /new Device\(\{ handlerName \}\)/);
  assert.match(voiceSource, /voice.device.create/);
});

test('native client keeps local voice debug markers but removes live debug posting UI', () => {
  assert.doesNotMatch(appSource, /liveDebugSettings|Live-Debug|sendLiveDebug\(/);
  assert.match(liveDebugSource, /SendLiveDebugLog/);
  assert.match(voiceSource, /onDebug/);
  for (const marker of ['voice.init.start', 'voice.transport.producer.create', 'voice.transport.producer.connect', 'voice.produce.start', 'voice.webcam.getUserMedia', 'voice.screen.getDisplayMedia']) assert.match(voiceSource, new RegExp(marker));
  assert.doesNotMatch(appSource + voiceSource, /hunter2|Bearer secret|accessToken/);
});

test('voice speaking indicator follows webclient audio-level behavior without visible input meters', () => {
  assert.doesNotMatch(voiceSource, /onLocalVoiceInput/);
  assert.doesNotMatch(voiceSource, /startLocalInputMeter/);
  assert.doesNotMatch(appSource, /voiceInputMeter|VoiceInputMeter|ownLocalSpeaking|voiceInputInline/);
  assert.match(voiceSource, /onLocalAudioStream/);
  assert.match(appSource, /AudioSpeakingWatcher/);
  assert.match(appSource, /getByteTimeDomainData/);
  assert.match(appSource, /Math\.sqrt\(sum \/ data\.length\)/);
  assert.match(appSource, /normalizedLevel > SPEAKING_THRESHOLD/);
  assert.match(appSource, /speakingUserIds/);
});

test('voice channel view mirrors Sharkord webclient grid cards and controls bar', () => {
  assert.match(appSource, /VoiceGridView/);
  assert.match(appSource, /voiceGrid/);
  assert.match(appSource, /voiceUserCard/);
  assert.match(appSource, /voiceControlsBar/);
  assert.match(appSource, /voiceScreenShareCard/);
  assert.match(appSource, /kind === 'video'/);
  assert.match(appSource, /kind === 'external_video'/);
  assert.match(appSource, /kind === 'screen'/);
  assert.match(appSource, /memberPanelToggle/);
  assert.match(appSource, /Memberliste ausblenden/);
  assert.doesNotMatch(appSource, /Voice Userlist|VoiceMembersPanel/);
  assert.match(appSource, /showOwnVideoPreview/);
  assert.match(appSource, /showOwnScreenPreview/);
  assert.match(appSource, /Eigene Kamera ausblenden/);
  assert.match(appSource, /Eigenen Bildschirm ausblenden/);
  assert.doesNotMatch(appSource, /Voiceinput bereit|Verbunden\. Kamera und Bildschirmfreigabe sind verfügbar\.|voiceChannelOverview|voiceMediaStrip/);
  assert.doesNotMatch(appSource, /Erst Text-Channel auswählen/);
});

test('voice UI treats server-side voice membership as joined and hides debug join copy', () => {
  assert.doesNotMatch(appSource, /Join ruft Sharkord voice\.join/);
  assert.match(appSource, /isSelectedVoiceJoined/);
  assert.match(appSource, /joined=\{isSelectedVoiceJoined\}/);
  assert.match(appSource, /VoiceGridView/);
  assert.doesNotMatch(appSource, /className="voicePill">\{channel\.id === currentVoiceChannelId \? 'Joined' : 'Join'\}/);
});

test('native client exposes webclient-like audio device settings', () => {
  assert.match(voiceSource, /navigator\.mediaDevices\.enumerateDevices/);
  assert.match(voiceSource, /audioinput/);
  assert.match(voiceSource, /audiooutput/);
  assert.match(appSource, /microphoneId/);
  assert.match(appSource, /playbackId/);
  assert.match(voiceSource, /setSinkId/);
  assert.match(appSource, /Mikrofon/);
  assert.match(appSource, /Lautsprecher/);
});

test('native client uses Sharkord logo in rail and empty states', () => {
  assert.match(appSource, /sharkordLogo/);
  assert.match(appSource, /<img className="brandLogo"/);
  assert.match(appSource, /<img className="heroLogo"/);
});

test('native client uses local RNNoise/Speex-style denoise worklet and no brittle RAF gate copy', () => {
  assert.match(packageJson, /@sapphi-red\/web-noise-suppressor/);
  assert.match(appSource, /denoiseEnabled/);
  assert.match(appSource, /Rauschunterdrückung/);
  assert.doesNotMatch(appSource, /Krisp|proprietär/);
  assert.match(voiceSource, /loadRnnoise/);
  assert.match(voiceSource, /RnnoiseWorkletNode/);
  assert.match(voiceSource, /rnnoiseWorkletUrl/);
  assert.match(voiceSource, /rnnoise_simd\.wasm\?url/);
  assert.match(voiceSource, /createDenoisedStream/);
  assert.match(voiceSource, /AudioWorklet/);
  assert.match(voiceSource, /sampleRate:\s*48000/);
  assert.doesNotMatch(voiceSource, /requestAnimationFrame/);
});

test('native client exposes core Sharkord admin APIs', () => {
  for (const route of [
    /others\.getSettings\.query/,
    /others\.updateSettings\.mutate/,
    /categories\.add\.mutate/,
    /categories\.update\.mutate/,
    /categories\.delete\.mutate/,
    /channels\.add\.mutate/,
    /channels\.update\.mutate/,
    /channels\.delete\.mutate/,
    /roles\.getAll\.query/,
    /roles\.add\.mutate/,
    /roles\.update\.mutate/,
    /roles\.delete\.mutate/,
    /roles\.setDefault\.mutate/,
    /users\.getAll\.query/,
    /users\.kick\.mutate/,
    /users\.ban\.mutate/,
    /users\.unban\.mutate/,
    /users\.delete\.mutate/,
    /users\.addRole\.mutate/,
    /users\.removeRole\.mutate/,
    /invites\.getAll\.query/,
    /invites\.add\.mutate/,
    /invites\.delete\.mutate/,
    /emojis\.getAll\.query/,
    /emojis\.update\.mutate/,
    /emojis\.delete\.mutate/
  ]) assert.match(clientSource, route);
});

test('native client subscribes to core webclient realtime events', () => {
  assert.match(clientSource, /messages\.onNew\.subscribe/);
  assert.match(clientSource, /messages\.onUpdate\.subscribe/);
  assert.match(clientSource, /messages\.onDelete\.subscribe/);
  assert.match(clientSource, /messages\.onTyping\.subscribe/);
  assert.match(clientSource, /users\.onJoin\.subscribe/);
  assert.match(clientSource, /users\.onLeave\.subscribe/);
  assert.match(clientSource, /users\.onUpdate\.subscribe/);
  assert.match(clientSource, /channels\.onCreate\.subscribe/);
  assert.match(clientSource, /channels\.onUpdate\.subscribe/);
  assert.match(clientSource, /channels\.onDelete\.subscribe/);
  assert.match(clientSource, /categories\.onCreate\.subscribe/);
  assert.match(clientSource, /categories\.onUpdate\.subscribe/);
  assert.match(clientSource, /categories\.onDelete\.subscribe/);
});

test('native client provides desktop sounds for core actions', () => {
  assert.match(clientSource, /playDesktopSound/);
  assert.match(appSource, /playDesktopSound/);
  assert.match(appSource, /message_received/);
  assert.match(appSource, /own_user_joined_voice_channel/);
  assert.match(appSource, /own_user_muted_mic/);
  assert.match(appSource, /own_user_muted_sound/);
});

test('native client renders signed Sharkord file avatars', () => {
  assert.match(clientSource, /\/public\/\$\{file\.name\}/);
  assert.match(clientSource, /accessToken/);
  assert.match(appSource, /AvatarView/);
  assert.match(appSource, /fileUrl\(/);
});

test('minimal Sharkord DTOs are local and explicit', () => {
  assert.match(typesSource, /export type SharkordChannel/);
  assert.match(typesSource, /export type SharkordMessage/);
  assert.match(typesSource, /export type JoinServerResult/);
});

test('frontend depends on @trpc/client', () => {
  assert.match(packageJson, /"@trpc\/client"/);
});
