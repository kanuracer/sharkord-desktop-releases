import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import ts from 'typescript';

const testDir = dirname(fileURLToPath(import.meta.url));
const projectRoot = join(testDir, '..', '..');
const appSource = readFileSync(join(testDir, '..', 'src', 'App.tsx'), 'utf8');
const cssSource = readFileSync(join(testDir, '..', 'src', 'style.css'), 'utf8');
const voiceSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
const clientSource = readFileSync(join(testDir, '..', 'src', 'sharkordClient.ts'), 'utf8');
const i18nSource = readFileSync(join(testDir, '..', 'src', 'i18n.ts'), 'utf8');
const typesSource = readFileSync(join(testDir, '..', 'src', 'sharkordTypes.ts'), 'utf8');
const serviceSource = [
  'appservice.go',
  'credentials.go',
  'state_store.go',
  'secure_store_other.go',
  'secure_store_windows.go',
  'stream_popout.go'
].map((file) => readFileSync(join(projectRoot, file), 'utf8')).join('\n');
const taskfile = readFileSync(join(projectRoot, 'Taskfile.yml'), 'utf8');
const readmeSource = readFileSync(join(projectRoot, 'README.md'), 'utf8');
const parityMatrixSource = readFileSync(join(projectRoot, 'docs', 'webclient-parity-matrix.md'), 'utf8');
const desktopMvpPlanSource = readFileSync(join(projectRoot, 'docs', 'plans', '2026-06-12-sharkord-desktop-mvp.md'), 'utf8');
const nativeTrpcPlanSource = readFileSync(join(projectRoot, 'docs', 'plans', '2026-06-12-sharkord-desktop-native-trpc.md'), 'utf8');


test('profile edit modal and backdrop use dark themed scrollbars', () => {
  const modalBackdropRule = cssSource.match(/\.modalBackdrop\s*\{[^}]*\}/)?.[0] ?? '';
  const ownProfileDialogRule = cssSource.match(/\.ownProfileDialog\s*\{[^}]*\}/)?.[0] ?? '';
  assert.match(appSource, /className="modalBackdrop ownProfileBackdrop"/);
  assert.match(appSource, /className="ownProfileDialog ownProfilePopup"/);
  assert.match(modalBackdropRule, /scrollbar-color:\s*#3f4650 transparent/);
  assert.match(ownProfileDialogRule, /scrollbar-color:\s*#3f4650 transparent/);
  assert.match(cssSource, /\.ownProfilePopup \*\s*\{[^}]*scrollbar-color:\s*#3f4650 transparent/);
  assert.match(cssSource, /\.ownProfileDialog::-webkit-scrollbar-thumb[\s\S]*background:\s*#3f4650/);
  assert.match(cssSource, /\.ownProfilePopup \*::-webkit-scrollbar-thumb[\s\S]*background:\s*#3f4650/);
});

test('english fallback translations do not corrupt category plurals or English private labels', async () => {
  const js = ts.transpileModule(i18nSource, { compilerOptions: { module: ts.ModuleKind.ES2022, target: ts.ScriptTarget.ES2022 } }).outputText;
  const moduleUrl = `data:text/javascript;charset=utf-8,${encodeURIComponent(js)}`;
  const { tr } = await import(moduleUrl);

  assert.equal(tr('Kategorien', 'en'), 'Categories');
  assert.equal(tr('3 Kategorien', 'en'), '3 Categories');
  assert.equal(tr('Kategorie', 'en'), 'Category');
  assert.equal(tr('Private Voice Channels', 'en'), 'Private Voice Channels');
  assert.equal(tr('PRIVATE VOICE CHANNELS', 'en'), 'PRIVATE VOICE CHANNELS');
  assert.notEqual(tr('Private Voice Channels', 'en'), 'Privatee Voice Channels');
});

test('settings tab owns updates and appearance controls', () => {
  assert.match(appSource, /activeView.*settings|setActiveView\('settings'\)/s);
  assert.match(appSource, /Einstellungen/);
  assert.match(appSource, /Darstellung/);
  assert.match(appSource, /Updates/);
  assert.match(appSource, /SettingsPanel/);
});

test('server settings admin UI uses polished rows, one overview save footer and readable permissions', () => {
  const adminWorkbench = appSource.match(/function AdminWorkbench[\s\S]*?function AdminUserInfoModal/)?.[0] ?? '';
  assert.ok(adminWorkbench, 'AdminWorkbench source not found');

  assert.equal((adminWorkbench.match(/settingsFooter/g) ?? []).length, 3, 'footer is defined once and rendered once per relevant tab');
  assert.match(adminWorkbench, /adminTab === 'general' \? settingsFooter : null/);
  assert.match(appSource, /SERVER_PERMISSION_COPY/);
  assert.match(appSource, /Nachrichten senden/);
  assert.match(appSource, /Channel-Berechtigungen/);
  assert.match(appSource, /permissionToggleText/);
  assert.match(appSource, /className="adminUserMeta"/);
  assert.match(appSource, /adminAccountStatusLabel\(user\)/);
  assert.match(appSource, /function adminAccountStatusLabel\(user: SharkordUser\): string \{ return user\.banned \? tr\('Gebannt'\) : tr\('Aktiv'\); \}/);
  assert.doesNotMatch(appSource, /user\.status \|\| tr\('Aktiv'\)/);
  assert.doesNotMatch(appSource, /setAdminUsers\(users\.filter/);
  assert.match(appSource, /tr\('Rollengewichtung'\)/);
  assert.match(appSource, /function normalizeRoleForSave\(role: SharkordRole\)/);
  assert.match(appSource, /const currentRole = roles\.find\(\(item\) => item\.id === role\.id\) \?\? role/);
  assert.match(appSource, /value=\{normalizeRoleWeight\(role\.weight, role\.id\)\}/);
  assert.match(clientSource, /weight:\s*normalizedRoleWeight\(role\)/);
  assert.doesNotMatch(appSource, /roleWeightSettings/);
  assert.doesNotMatch(appSource, /memberRoleWeights/);

  assert.match(cssSource, /\.settingsInlineForm\s*\{/);
  assert.match(cssSource, /\.permissionToggleText strong\s*\{/);
  assert.match(cssSource, /\.pluginWorkbench \.pluginRow\s*\{[^}]*min-height:\s*104px/s);
  assert.match(cssSource, /\.adminUserMeta\s*\{[^}]*contain:\s*layout paint style/s);
  assert.match(cssSource, /\.adminToolbar button[\s\S]*background:\s*color-mix\(in srgb,var\(--sidebar-bg\),white 4%\)/);
  assert.match(cssSource, /\.adminWorkbenchModal \.paritySprintSettings \.parityGrid\s*\{[^}]*minmax\(220px, 1fr\)/s);
});

test('server setup supports encrypted stored credentials', () => {
  assert.match(appSource, /identity/);
  assert.match(appSource, /password/);
  assert.match(appSource, /SaveServerCredentials/);
  assert.match(appSource, /LoadServerCredentials/);
  assert.match(serviceSource, /SaveServerCredentials/);
  assert.match(serviceSource, /LoadServerCredentials/);
  assert.match(serviceSource, /encryptSecret|protectSecret/);
});


test('server list persists natively across WebView localStorage/profile changes', () => {
  assert.match(appSource, /LoadAppState/);
  assert.match(appSource, /SaveAppState/);
  assert.match(appSource, /nativeStateLoaded/);
  assert.match(appSource, /if \(!nativeStateLoaded\) return/);
  assert.match(appSource, /defaultState/);
  assert.match(appSource, /resolveStartupState/);
  assert.match(appSource, /stripPlaceholderServers/);
  assert.match(appSource, /LEGACY_PLACEHOLDER_HOSTS/);
  assert.match(appSource, /if \(nativeStateLoaded\) saveState\(state\)/);
  assert.match(appSource, /allowEmptyServersSaveRef/);
  assert.match(appSource, /allowEmptyServers/);
  assert.match(serviceSource, /refusing to overwrite existing server list with empty state/);
  assert.match(serviceSource, /backupStateFile/);
  assert.doesNotMatch(appSource, /useState<StoredState>\(\(\) => loadState\(\)\)/);
  assert.match(serviceSource, /SaveAppState/);
  assert.match(serviceSource, /LoadAppState/);
  assert.match(serviceSource, /state\.json/);
});

test('native UI renders all channel classes and members with usernames', () => {
  assert.match(appSource, /MembersPanel/);
  assert.match(appSource, /voiceChannels/);
  assert.match(appSource, /channelGroups/);
  assert.match(appSource, /buildChannelGroups/);
  assert.match(appSource, /usersById/);
  assert.match(appSource, /MessageBubble[^]*usersById/);
});



test('right sidebar stays a real member list in voice mode and is collapsible', () => {
  assert.match(appSource, /membersOpen/);
  assert.match(appSource, /memberPanelToggle/);
  assert.match(appSource, /Memberliste ausblenden/);
  assert.match(appSource, /<MembersPanel users=\{sortedUsers\}/);
  assert.doesNotMatch(appSource, /Voice Userlist|VoiceMembersPanel|voiceMembersOpen/);
  assert.match(cssSource, /\.discordMain\.membersCollapsed\s*\{[^}]*grid-column:\s*3\s*\/\s*5/s);
  assert.match(cssSource, /memberCollapseButton/);
});

test('user join realtime event forces existing offline members back online without app restart', () => {
  const handler = appSource.match(/onUserJoin:\s*\(user\) => \{[^}]*markUserOnline\(user\)[^}]*\}/s)?.[0] ?? '';
  assert.match(handler, /markUserOnline\(user\)/);
  assert.match(appSource, /function markUserOnline\(user: SharkordUser\): SharkordUser \{[^}]*status:\s*'online'/s);
});

test('voice cards expose missing remote webcam or screen streams instead of silent avatar-only tiles', () => {
  assert.match(appSource, /Kamera aktiv · Stream lädt…/);
  assert.match(appSource, /Stream noch nicht empfangen/);
  assert.match(appSource, /pendingScreenUsers/);
  assert.match(cssSource, /voiceMediaHint/);
  assert.match(cssSource, /voiceMediaPending/);
});

test('voice producer events are filtered by live joined channel and own user before consuming', () => {
  assert.match(appSource, /currentVoiceChannelIdRef/);
  assert.match(appSource, /currentVoiceChannelIdRef\.current !== event\.channelId/);
  assert.match(appSource, /event\.remoteId === next\.join\.ownUserId/);
  assert.match(appSource, /return/);
});

test('voice engine queues remote producers that arrive before consumer transport is ready', () => {
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(voiceEngineSource, /pendingRemoteProducers/);
  assert.match(voiceEngineSource, /queuePendingRemoteProducer/);
  assert.match(voiceEngineSource, /drainPendingRemoteProducers/);
  assert.doesNotMatch(voiceEngineSource, /if \(!this\.consumerTransport \|\| !this\.deviceRtpCapabilities\) return;/);
});

test('video tiles explicitly start playback and surface playback failures for remote media', () => {
  assert.match(appSource, /video\.play\(\)/);
  assert.match(appSource, /data-track-state/);
  assert.match(appSource, /videoTileError/);
});


test('server deletion uses an in-app confirm dialog instead of fragile native window.confirm', () => {
  const removeActiveServerFn = appSource.match(/async function removeActiveServer\(\)[\s\S]*?\n  \}/)?.[0] ?? '';
  assert.match(removeActiveServerFn, /setPendingServerRemoval\(activeServer\)/);
  assert.doesNotMatch(removeActiveServerFn, /window\.confirm/);
  assert.match(appSource, /pendingServerRemoval \? <ConfirmServerRemovalDialog/);
  assert.match(appSource, /function ConfirmServerRemovalDialog/);
});

test('server deletion updates UI/state before credential cleanup so native cleanup cannot block removal', () => {
  const confirmServerRemovalFn = appSource.match(/async function confirmServerRemoval\(\)[\s\S]*?\n  \}/)?.[0] ?? '';
  assert.match(confirmServerRemovalFn, /setState\(\(current\) => \{ const servers = current\.servers\.filter\(\(server\) => server\.id !== serverId\)/);
  assert.match(confirmServerRemovalFn, /void API\.DeleteServerCredentials\(serverId\)\.catch/);
  assert.doesNotMatch(confirmServerRemovalFn, /await API\.DeleteServerCredentials\(activeServer\.id\)/);
});

test('remote webcam and screen flags actively refresh producer consumption after missed producer events', () => {
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(voiceEngineSource, /refreshExistingProducers/);
  assert.match(appSource, /refreshRemoteMedia\('voice\.state\.mediaFlag'/);
  assert.match(appSource, /refreshRemoteMedia\('voice\.join\.mediaFlag'/);
  assert.match(appSource, /safeState\.webcamEnabled\s*\|\|\s*safeState\.sharingScreen/);
  assert.match(appSource, /safePatch\.webcamEnabled\s*\|\|\s*safePatch\.sharingScreen/);
  assert.match(appSource, /setTimeout\(\(\) => refreshRemoteMedia/);
});

test('voice recovery resets stale consumer transport and re-syncs remote producers', () => {
  assert.match(voiceSource, /private device\?: Device/);
  assert.match(voiceSource, /async recoverAfterServerMediaReset/);
  assert.match(voiceSource, /resetRemoteConsumers/);
  assert.match(voiceSource, /this\.consumerTransport\?\.close\(\)/);
  assert.match(voiceSource, /await this\.createConsumerTransport\(this\.device\)/);
  assert.match(voiceSource, /await this\.refreshExistingProducers\(\)/);
  const recoverFn = appSource.match(/async function recoverCurrentVoiceMedia\(\)[\s\S]*?\n  \}/)?.[0] ?? '';
  assert.match(recoverFn, /recoverAfterServerMediaReset\(\)/);
  assert.match(recoverFn, /updateVoiceUser\(currentVoiceChannelId, connection\.join\.ownUserId/);
});



test('voice UI keeps stream actions Discord-like in the bottom controls menu', () => {
  assert.match(appSource, /MoreVertical/);
  assert.match(appSource, /voiceOptionsMenuOpen/);
  assert.match(appSource, /voiceControlsMenuButton/);
  assert.match(appSource, /voiceOptionsMenu/);
  assert.match(appSource, /Callmember ausblenden/);
  assert.match(appSource, /hideCallMembers/);
  assert.match(appSource, /Kameras ausblenden/);
  assert.match(appSource, /Bildschirmübertragungen als Popup/);
  assert.match(appSource, /Alle Streams einzeln/);
  assert.doesNotMatch(appSource, /<div className="voiceStreamTools"/);
  assert.match(cssSource, /voiceOptionsMenu/);
  assert.match(cssSource, /voiceControlsMenuButton/);
  assert.doesNotMatch(cssSource, /\.voiceStreamTools\s*\{/);
});

test('voice stream focus is a real toggle and focused layout is visibly different', () => {
  assert.match(appSource, /setFocusedScreenKey\(item\.key === focusedScreenKey \? null : item\.key\)/);
  assert.match(appSource, /aria-pressed=\{item\.watched && item\.key === focusedScreenKey\}/);
  assert.match(appSource, /hasFocusedScreen/);
  assert.match(appSource, /Stream fokussieren/);
  assert.match(cssSource, /\.voiceGrid\.hasFocusedScreen/);
  assert.match(cssSource, /\.voiceGrid\.hasFocusedScreen \.voiceScreenShareCard\.focused/);
});

test('stream popouts use native Wails windows with viewer-owned stream consumption', () => {
  const mainSource = readFileSync(join(projectRoot, 'main.go'), 'utf8');
  assert.match(appSource, /API\.OpenStreamPopoutWindow/);
  assert.match(appSource, /GetStreamPopoutConfig/);
  assert.match(appSource, /initConsumerOnly/);
  assert.match(serviceSource, /OpenStreamPopoutWindow/);
  assert.match(serviceSource, /GetStreamPopoutConfig/);
  assert.match(serviceSource, /app\.Window\.NewWithOptions/);
  assert.match(mainSource, /svc\.app = app/);
  assert.doesNotMatch(appSource, /window\.open\(/);
  assert.doesNotMatch(appSource, /BroadcastChannel|postMessage/);
  assert.doesNotMatch(cssSource, /streamPopupOverlay|streamPopupWindow/);
});



test('stream actions are only in the bottom three-dot menu, not floating on stream tiles', () => {
  const voiceFn = appSource.match(/function VoiceGridView[\s\S]*?function VoiceUserCard/)?.[0] ?? '';
  assert.match(voiceFn, /voiceControlsMenuButton/);
  assert.match(voiceFn, /MoreVertical/);
  assert.match(voiceFn, /Nur Streams anzeigen|Callmember ausblenden/);
  assert.doesNotMatch(voiceFn, /screenShareFocusButton/);
  assert.doesNotMatch(voiceFn, /className="videoPopoutButton"/);
  assert.doesNotMatch(cssSource, /\.screenShareFocusButton/);
});

test('focused stream uses a real single-stream stage instead of keeping call members beside it', () => {
  assert.match(appSource, /visibleScreenCards\s*=\s*focusedScreen \? \[focusedScreen\] : orderedScreenCards/);
  assert.match(appSource, /const participantCards = \(hideCallMembers \|\| focusedScreen\) \? \[\] : visibleVoiceUsers\.flatMap/);
  assert.match(cssSource, /\.voiceGrid\.hasFocusedScreen\s*\{[^}]*grid-template-columns:\s*minmax\(0,1fr\)/s);
  assert.match(cssSource, /\.voiceGrid\.hasFocusedScreen \.voiceScreenShareCard\.focused\s*\{[^}]*height:\s*100%/s);
});

test('stream popout window has its own close button and no in-app fallback CSS', () => {
  assert.match(appSource, /nativeStreamPopout/);
  assert.match(appSource, /aria-label=\{tr\('Popout schließen'\)\}/);
  assert.match(appSource, /window\.close\(\)/);
  assert.doesNotMatch(appSource, /setStreamPopouts|StreamPopupOverlay|function openStreamPopup/);
  assert.doesNotMatch(cssSource, /streamPopupOverlay|streamPopupWindow/);
});

test('left-click user info opens separate profile popover state while right-click keeps context menu', () => {
  assert.match(appSource, /type UserProfilePopoverState/);
  assert.match(appSource, /setUserProfilePopover/);
  assert.match(appSource, /openUserProfilePopover/);
  assert.match(appSource, /onUserProfile=/);
  assert.match(appSource, /UserProfilePopover/);
  assert.match(cssSource, /\.userProfilePopover\b/);
});

test('user profile popover includes official DM action, member-since metadata, and manage-user entry', () => {
  const popoverFn = appSource.match(/function UserProfilePopover[\s\S]*?function SettingsPanel/)?.[0] ?? '';
  assert.match(popoverFn, /onOpenDirectMessage/);
  assert.match(popoverFn, /directMessagesEnabled/);
  assert.match(popoverFn, /memberSince/);
  assert.match(popoverFn, /formatShortDate\(user\.createdAt\)/);
  assert.match(popoverFn, /onManageUser/);
  assert.match(popoverFn, /t\('profile\.popover\.manageUser'\)/);
  assert.match(appSource, /openDirectMessageFromProfile/);
  assert.match(appSource, /openDirectMessage\(conn, user\.id\)/);
  assert.match(appSource, /openUserAdminFromProfile/);
  assert.match(appSource, /userHasServerPermission\(ownUser, adminRoles, \['MANAGE_USERS', 'ADMINISTRATOR'\]\)/);
});

test('desktop admin user detail view has server activity messages links files and storage details', () => {
  assert.match(clientSource, /export async function getUserInfo/);
  assert.match(clientSource, /users\.getInfo\.query\(\{ userId \}\)/);
  assert.match(appSource, /type AdminUserInfoState/);
  assert.match(appSource, /function AdminUserInfoModal/);
  assert.match(appSource, /serverActivityCards/);
  assert.match(appSource, /adminUserFiles/);
  assert.match(appSource, /adminUserMessages/);
  assert.match(appSource, /adminUserLinks/);
  assert.match(appSource, /deleteStoredFile\(connection, file\.id\)/);
  assert.match(appSource, /formatFileSize\(info\.storage\.usedStorage/);
  assert.match(appSource, /setAdminUserInfoState\(\{ userId: user\.id/);
});

test('channel settings checkbox stays inline and does not stretch like a slider', () => {
  assert.match(appSource, /className="channelSettingsGeneral"/);
  assert.match(appSource, /className="checkboxRow"[^>]*><input type="checkbox" checked=\{isPrivate\}/);
  assert.match(cssSource, /\.channelSettingsModal\s*\{[^}]*grid-template-rows:\s*auto auto minmax\(0,1fr\) auto/s);
  assert.match(cssSource, /\.channelSettingsGeneral\s*\{[^}]*align-content:\s*start/s);
  assert.match(cssSource, /\.channelSettingsGeneral \.checkboxRow\s*\{[^}]*grid-template-columns:\s*auto minmax\(0,1fr\)/s);
  assert.match(cssSource, /\.channelSettingsGeneral \.checkboxRow input\[type='checkbox'\]\s*\{[^}]*width:\s*18px/s);
  assert.match(cssSource, /\.channelPermissionsTab\s*\{[^}]*grid-template-columns:\s*260px minmax\(0,1fr\)/s);
  assert.doesNotMatch(cssSource, /\.channelSettingsGeneral input, \.channelSettingsGeneral textarea\s*\{[^}]*input\[type='checkbox'\]/s);
});

test('plugin components use join payloads and live events instead of removed slot query', () => {
  assert.doesNotMatch(clientSource, /plugins\.getSlots|getPluginSlots|isMissingPluginSlotsProcedureError/);
  assert.doesNotMatch(appSource, /getPluginSlots|Plugin-Slots laden/);
  assert.match(typesSource, /pluginIdsWithComponents\?: string\[\]/);
  assert.match(typesSource, /pluginsMetadata\?: SharkordPluginMetadata\[\]/);
  assert.match(typesSource, /commands\?: Record<string, SharkordPluginCommand\[\]>/);
  assert.match(appSource, /connection\.join\.pluginIdsWithComponents \?\? \[\]/);
  assert.match(appSource, /connection\.join\.pluginsMetadata \?\? \[\]/);
  assert.match(appSource, /connection\.join\.commands \?\? \{\}/);
  assert.match(appSource, /onPluginCommandsChange/);
  assert.match(appSource, /onPluginComponentsChange/);
  assert.match(appSource, /onPluginMetadataChange/);
  assert.match(clientSource, /plugins\.onCommandsChange\.subscribe/);
  assert.match(clientSource, /plugins\.onComponentsChange\.subscribe/);
  assert.match(clientSource, /plugins\.onMetadataChange\.subscribe/);
});

test('plugin slash commands expose upstream-style structured argument controls before execute', () => {
  assert.match(appSource, /selectedPluginCommand/);
  assert.match(appSource, /pluginCommandArgValues/);
  assert.match(appSource, /command\.args\?\.length/);
  assert.match(appSource, /pluginCommandBuilder/);
  assert.match(appSource, /pluginCommandArgField/);
  assert.match(appSource, /type=\{arg\.type === 'number' \? 'number' : 'text'\}/);
  assert.match(appSource, /<select[^]*value=\{pluginCommandArgValues\[arg\.name\]/);
  assert.match(appSource, /Pflichtfeld fehlt/);
  assert.match(appSource, /executePluginCommand\(connection, selectedPluginCommand\.pluginId, selectedPluginCommand\.name/);
  assert.match(cssSource, /\.pluginCommandBuilder\b/);
  assert.match(cssSource, /\.pluginCommandArgField\b/);
});

test('streams-only mode renders only real stream cards and no empty placeholder tile', () => {
  assert.match(appSource, /const shouldShowEmptyVoiceCard = !hideCallMembers && !visibleScreenCards\.length && !pendingScreenUsers\.length && !participantCards\.length/);
  assert.match(appSource, /\{shouldShowEmptyVoiceCard \? <div className="voiceEmptyCard"/);
  assert.doesNotMatch(appSource, /participantCards\.length \? participantCards : <div className="voiceEmptyCard"/);
  assert.match(cssSource, /\.voiceGrid\.streamsOnly\s*\{/);
  assert.match(cssSource, /\.voiceGrid\.streamsOnly\.singleStream\s*\{[^}]*grid-template-columns:\s*minmax\(0,1fr\)/s);
});

test('stream video uses contain fit and remote producer close removes stale last frame', () => {
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(cssSource, /\.voiceScreenShareCard \.videoTile video\s*\{[^}]*object-fit:\s*contain/s);
  assert.match(cssSource, /\.videoTile\.screenTile video\s*\{[^}]*object-fit:\s*contain/s);
  assert.match(appSource, /screen=\{true\}/);
  assert.match(voiceEngineSource, /producerclose/);
  assert.match(voiceEngineSource, /consumer\.track\.addEventListener\?\.\('ended', cleanup\)/);
  assert.match(voiceEngineSource, /this\.pendingRemoteProducers\.delete\(key\)/);
});





test('wails stream popout opens a native window and does not depend on window.open', () => {
  assert.match(appSource, /API\.OpenStreamPopoutWindow/);
  assert.match(serviceSource, /OpenStreamPopoutWindow/);
  assert.match(serviceSource, /app\.Window\.NewWithOptions/);
  assert.doesNotMatch(appSource, /window\.open\(/);
  assert.doesNotMatch(appSource, /Popout blockiert/);
});

test('remote screen restart replaces stale consumers and streams instead of returning early', () => {
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(voiceEngineSource, /this\.removeRemoteProducer\(remoteId, kind\);\s*const existingConsumer/);
  assert.doesNotMatch(voiceEngineSource, /if \(existingConsumer && !existingConsumer\.closed\) return;/);
  assert.match(voiceEngineSource, /consumer\.observer\.on\('close'/);
});

test('video tiles reset srcObject before attaching a restarted stream', () => {
  const videoTile = appSource.match(/function VideoTile[\s\S]*?function MembersPanel/)?.[0] ?? '';
  assert.match(videoTile, /video\.pause\(\)/);
  assert.match(videoTile, /video\.srcObject = null/);
  assert.match(videoTile, /video\.load\(\)/);
  assert.match(videoTile, /video\.srcObject = stream/);
});

test('stream popouts do not clone MediaStream objects through BroadcastChannel', () => {
  const voiceFn = appSource.match(/function VoiceGridView[\s\S]*?function VoiceUserCard/)?.[0] ?? '';
  assert.match(appSource, /routerRtpCapabilities: JSON\.stringify\(routerRtpCapabilities\)/);
  assert.match(appSource, /joinResult\.routerRtpCapabilities \?\? JSON\.parse\(config\.routerRtpCapabilities\)/);
  assert.match(appSource, /initConsumerOnly\(routerRtpCapabilities as never\)/);
  assert.doesNotMatch(voiceFn, /BroadcastChannel/);
  assert.doesNotMatch(appSource, /postMessage\(\{ type: 'streams'/);
  assert.doesNotMatch(appSource, /The object can not be cloned/);
});

test('remote screen shares require an explicit watch click before showing live video', () => {
  assert.match(appSource, /watchedScreenKeys/);
  assert.match(appSource, /Stream ansehen/);
  assert.match(appSource, /className="voiceStreamWatchCard"/);
  assert.match(appSource, /setWatchedScreenKeys\(\(current\) => new Set\(current\)\.add\(item\.key\)\)/);
  assert.match(appSource, /item\.watched \? <VideoTile/);
});

test('ended remote screen shares are removed from visible cards and watched focus state', () => {
  assert.match(appSource, /liveRemoteScreenStreams/);
  assert.match(appSource, /normalizeVoiceState\(user\.state\)\.sharingScreen/);
  assert.match(appSource, /setWatchedScreenKeys\(\(current\) =>/);
  assert.match(appSource, /validScreenKeys/);
  assert.match(appSource, /setFocusedScreenKey\(\(current\) => current && validScreenKeys\.has\(current\) \? current : null\)/);
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(voiceEngineSource, /syncRemoteProducerState/);
  assert.match(voiceEngineSource, /this\.pendingRemoteProducers\.delete\(key\)/);
});



test('own screen preview visibility lives in the bottom three-dot menu and persists', () => {
  assert.match(appSource, /loadVoicePreviewSettings/);
  assert.match(appSource, /saveVoicePreviewSettings/);
  assert.match(appSource, /showOwnScreenPreview/);
  assert.match(appSource, /Eigener Bildschirm ausblenden|Eigenen Bildschirm ausblenden/);
  assert.match(appSource, /runVoiceOption\(\(\) => updateVoicePreviewSettings\(\{[\s\S]*showOwnScreenPreview: !showOwnScreenPreview/);
  assert.doesNotMatch(appSource, /<div className="selfPreviewToggles">/);
});

test('native stream popout joins the voice channel before consuming and closes through backend window API', () => {
  assert.match(appSource, /joinVoiceChannel\(connection, config\.channelId/);
  assert.match(appSource, /initConsumerOnly/);
  assert.match(appSource, /consumeProducer\(config\.remoteId/);
  assert.match(appSource, /API\.CloseStreamPopoutWindow\(configId\)/);
  assert.match(serviceSource, /CloseStreamPopoutWindow/);
  assert.match(serviceSource, /streamPopoutWindows/);
  assert.match(serviceSource, /window\.Close\(\)/);
  assert.match(serviceSource, /delete\(s\.streamPopoutConfigs, id\)/);
});


test('remote video tiles attach live streams even while WebRTC track starts muted', () => {
  const videoTile = appSource.match(/function VideoTile[\s\S]*?function MembersPanel/)?.[0] ?? '';
  assert.match(videoTile, /video\.srcObject = stream/);
  assert.doesNotMatch(videoTile, /track\?\.readyState === 'live' && !track\.muted/);
  assert.match(videoTile, /trackState !== 'live' && trackState !== 'muted'/);
});

test('stream audio mute is persisted per server stream user and only mutes stream audio tracks', () => {
  assert.match(appSource, /STREAM_AUDIO_MUTE_STORAGE_KEY/);
  assert.match(appSource, /loadStreamAudioMuteSettings/);
  assert.match(appSource, /saveStreamAudioMuteSettings/);
  assert.match(appSource, /isStreamAudioMuted\(streamAudioMutedUsers, activeServer\.id, item\.remoteId\)/);
  assert.match(appSource, /toggleStreamAudioMute/);
  assert.match(appSource, /Stream-Ton stummschalten|Stream-Ton einschalten/);
  assert.match(appSource, /isStreamAudioKind\(item\.kind\)/);
  assert.match(appSource, /isStreamAudioMuted\(streamAudioMutedUsers, activeServerId, item\.remoteId\)/);
});

test('bottom voice controls expose icon-only camera/screen indicators and can collapse downward', () => {
  const voiceFn = appSource.match(/function VoiceGridView[\s\S]*?function VoiceUserCard/)?.[0] ?? '';
  assert.match(voiceFn, /voiceControlsCollapsed/);
  assert.match(voiceFn, /voiceMediaToggle camera/);
  assert.match(voiceFn, /voiceMediaToggle screen/);
  assert.doesNotMatch(voiceFn, /voiceLiveIndicators|Kamera läuft|Stream läuft/);
  assert.match(voiceFn, /voiceControlsCollapseButton/);
  assert.match(cssSource, /\.voiceControlsDock/);
  assert.match(cssSource, /\.voiceControlsDock\.collapsed/);
  assert.match(cssSource, /\.voiceControlsBar button\.voiceMediaToggle\.active svg/);
});

test('native popout refreshes existing producers and consumes screen audio alongside the target stream', () => {
  const popoutFn = appSource.match(/function StreamPopoutViewer[\s\S]*?export default function App/)?.[0] ?? '';
  assert.match(popoutFn, /refreshExistingProducers\(\)/);
  assert.match(popoutFn, /screen_audio/);
  assert.match(popoutFn, /setStreamAudio/);
  assert.match(popoutFn, /nativeStreamPopoutGrid/);
  assert.match(popoutFn, /streamAudio \? <InlineAudioStream/);
});

test('left voice/user panel follows Discord connected layout', () => {
  assert.match(appSource, /discordVoicePanel/);
  assert.match(appSource, /voicePanelHeader/);
  assert.match(appSource, /voiceQuickActions/);
  assert.match(appSource, /accountPanel/);
  assert.match(appSource, /Sprachchat verbunden/);
  assert.match(cssSource, /\.discordVoicePanel/);
  assert.match(cssSource, /\.voiceQuickActions/);
  assert.match(cssSource, /\.accountPanel/);
  assert.doesNotMatch(appSource, /<div className=\{`voiceStatusBar/);
});

test('admin workbench has compact overview stats and task tabs', () => {
  assert.match(appSource, /adminDashboard/);
  assert.match(appSource, /role="tablist"/);
  assert.match(appSource, /Server-Einstellungen/);
  assert.match(cssSource, /adminPanelHeader/);
  assert.match(cssSource, /adminDashboard/);
  assert.match(cssSource, /adminStatus/);
});

test('discord clone shell replaces card-like chat mockup', () => {
  assert.match(appSource, /discordShell/);
  assert.match(appSource, /guildRail/);
  assert.match(appSource, /channelColumn/);
  assert.match(appSource, /channelTopBar/);
  assert.match(appSource, /messageScroller/);
  assert.match(appSource, /discordMessage/);
  assert.match(appSource, /memberColumn/);
  assert.match(appSource, /userPanel/);
  assert.match(cssSource, /grid-template-columns:\s*72px 260px minmax\(0,1fr\) 240px/);
  assert.match(cssSource, /settingsMode\.appShell\.discordShell\s*\{[^}]*grid-template-columns:\s*72px 260px minmax\(0,1fr\)/s);
  assert.match(cssSource, /\.discordContent\s*\{\s*display:\s*contents;\s*\}/);
  assert.doesNotMatch(cssSource, /\.discordContent\s*\{[^}]*grid-template-columns:\s*260px minmax\(0,1fr\) 240px/s);
  assert.match(cssSource, /border-radius:\s*0/);
});

test('no-server start screen centers hero in main area instead of channel column', () => {
  assert.match(appSource, /noServerShell/);
  assert.match(appSource, /noServersEmptyState/);
  assert.match(cssSource, /\.appShell\.discordShell\.noServerShell\s*\{[^}]*grid-template-columns:\s*72px minmax\(0,1fr\)/s);
  assert.match(cssSource, /\.noServersEmptyState\s*\{[^}]*grid-column:\s*2/s);
  assert.match(cssSource, /\.noServersEmptyState\s*\{[^}]*width:\s*100%/s);
  assert.match(cssSource, /\.welcomeHero\s*\{[^}]*width:\s*min\(560px,\s*100%\)/s);
  assert.doesNotMatch(cssSource, /^\.noServerShell\s*\{\s*grid-template-columns:\s*72px minmax\(0,1fr\)/m);
});

test('no-server start screen keeps settings reachable and appearance controls out of onboarding', () => {
  const noServerFn = appSource.match(/function NoServersEmptyState[\s\S]*?\n}\n/)?.[0] ?? '';
  assert.match(appSource, /onSettings=\{\(\) => setActiveView\(activeView === 'settings' \? 'chat' : 'settings'\)\}/);
  assert.match(appSource, /settingsActive=\{activeView === 'settings'\}/);
  assert.match(appSource, /activeView === 'settings'[\s\S]*<SettingsPanel/);
  assert.match(appSource, /railSettingsButton/);
  assert.match(cssSource, /\.noServerShell \.settingsPanel\.discordSettings\s*\{[^}]*grid-column:\s*2/s);
  assert.doesNotMatch(noServerFn, /themeSwitch|setTheme|ThemeMode|Moon|Sun|Dark|Light/);
});

test('updater uses dedicated release repository feeds', () => {
  assert.match(serviceSource, /raw\.githubusercontent\.com\/kanuracer\/sharkord-desktop-releases/);
  assert.match(serviceSource, /latest\.json/);
  assert.match(serviceSource, /releaseChannelBranches/);
  assert.doesNotMatch(serviceSource, /kanuracer\/sharkord-desktop\/releases\/latest/);
});

test('windows build uses GUI subsystem without console window', () => {
  assert.match(taskfile, /-H windowsgui/);
});
test('macOS updater applies darwin zip in place instead of returning old stub', () => {
  assert.doesNotMatch(serviceSource, /macOS In-Place-Update wird aktiviert/);
  assert.match(serviceSource, /validateDarwinUpdateArchive/);
  assert.match(serviceSource, /currentMacOSAppRoot/);
  assert.match(serviceSource, /apply-update-macos\.sh/);
  assert.match(serviceSource, /\/usr\/bin\/ditto -x -k/);
  assert.match(serviceSource, /\/usr\/bin\/open -n/);
  assert.match(serviceSource, /codesign --verify --deep --strict/);
});


test('uses bundled Sharkord logo as native program icon assets', () => {
  const mainSource = readFileSync(join(projectRoot, 'main.go'), 'utf8');
  assert.match(mainSource, /go:embed frontend\/src\/assets\/sharkord-logo\.png/);
  assert.match(mainSource, /Icon:\s*appIcon/);
  assert.match(taskfile, /wails3 generate icons/);
  assert.match(taskfile, /bash scripts\/generate-windows-syso\.sh/);
  const sysoScript = readFileSync(join(projectRoot, 'scripts/generate-windows-syso.sh'), 'utf8');
  assert.match(sysoScript, /x86_64-w64-mingw32-windres/);
  assert.match(sysoScript, /VERSIONINFO/);
  assert.match(taskfile, /build\/windows\/icon\.ico/);
  assert.match(sysoScript, /wails_windows_amd64\.syso/);
});

test('user-facing settings contain no Krisp/proprietary disclaimer copy', () => {
  assert.doesNotMatch(appSource, /Krisp|proprietär/);
  assert.match(appSource, /Erweiterte Rauschunterdrückung|Rauschunterdrückung/);
});


test('macOS release bundle declares microphone camera and screen capture privacy usage strings', () => {
  const macScript = readFileSync(new URL('../../scripts/build-macos-release.sh', import.meta.url), 'utf8');
  for (const key of ['NSMicrophoneUsageDescription', 'NSCameraUsageDescription', 'NSScreenCaptureUsageDescription']) assert.match(macScript, new RegExp(key));
});

test('voice controls collapse handle is attached to the bar and live state is icon-only', () => {
  assert.match(appSource, /voiceControlsDock/);
  assert.match(appSource, /voiceControlsCollapseButton/);
  assert.doesNotMatch(appSource, /voiceLiveIndicators/);
  assert.doesNotMatch(appSource, /Kamera läuft|Stream läuft/);
  assert.match(appSource, /className=\{`[^`]*voiceMediaToggle[^`]*camera[^`]*\$\{voiceState\.webcamEnabled \? 'active'/);
  assert.match(appSource, /className=\{`[^`]*voiceMediaToggle[^`]*screen[^`]*\$\{voiceState\.sharingScreen \? 'active'/);
  const dockRule = cssSource.match(/\.voiceControlsDock\s*\{[^}]+\}/s)?.[0] || '';
  const handleRule = cssSource.match(/\.voiceControlsCollapseButton\s*\{[^}]+\}/s)?.[0] || '';
  assert.match(dockRule, /gap:\s*0/);
  assert.doesNotMatch(dockRule, /gap:\s*6px|gap:\s*8px/);
  assert.match(handleRule, /margin-bottom:\s*-1px/);
  assert.doesNotMatch(cssSource, /\.voiceLiveIndicators|\.liveIndicator/);
});

test('settings has a real Audio & Video tab with Sharkord device controls from screenshots', () => {
  assert.match(appSource, /type SettingsTab = 'appearance' \| 'updates' \| 'audioVideo'/);
  assert.doesNotMatch(appSource, /type SettingsTab = 'appearance' \| 'updates' \| 'audioVideo' \| 'server'/);
  assert.match(appSource, /Audio & Video/);
  assert.match(appSource, /settingsTab === 'audioVideo'/);
  for (const label of ['Wiedergabe', 'Mikrofon', 'Sprachfilter', 'Sprachisolierung', 'Echounterdrückung', 'Automatische Verstärkung', 'Sprachaktivierung', 'Mikrofon testen', 'Test starten', 'Webcam', 'Webcam-Vorschau starten', 'Eigenes Video spiegeln', 'Simulcast', 'Bildschirmfreigabe', 'Quelle', 'Anwendung / Fenster', 'Maximale Bitrate', 'Eigenes Audio einschränken', 'Lokale Audiowiedergabe unterdrücken']) assert.match(appSource, new RegExp(label));
  assert.match(appSource, /720p/);
  assert.match(appSource, /30 fps/);
  assert.match(appSource, /screenMaxBitrateMbps: 12/);
  assert.match(appSource, /AUDIO_DEVICE_STORAGE_KEY/);
  assert.match(cssSource, /\.avSettingsGrid/);
  assert.match(cssSource, /\.avPreviewBox/);
  assert.match(cssSource, /\.levelMeter/);
});

test('audio video device preferences are persisted and feed webcam screen constraints', () => {
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(voiceEngineSource, /webcamId\?: string/);
  assert.match(voiceEngineSource, /videoResolution/);
  assert.match(voiceEngineSource, /videoFps/);
  assert.match(voiceEngineSource, /screenResolution/);
  assert.match(voiceEngineSource, /screenFps/);
  assert.match(voiceEngineSource, /screenMaxBitrateMbps/);
  assert.match(voiceEngineSource, /noiseGate/);
  assert.match(voiceEngineSource, /this\.settings\.webcamId/);
  assert.match(voiceEngineSource, /mediaSize\(this\.settings\.videoResolution/);
  assert.match(voiceEngineSource, /mediaSize\(this\.settings\.screenResolution/);
  assert.match(voiceEngineSource, /videoGoogleMaxBitrate:\s*this\.settings\.screenMaxBitrateMbps \* 1000/);
});

test('Audio & Video tab is fully German and has real microphone and webcam tests', () => {
  assert.match(appSource, /mikrofonTestStream|webcamTestStream|micTestLevel/);
  assert.match(appSource, /startMicrophoneTest|stopMicrophoneTest|startWebcamPreview|stopWebcamPreview/);
  assert.match(appSource, /getUserMedia\(\{\s*audio:\s*\{/s);
  assert.match(appSource, /new AudioContextCtor\(/);
  assert.match(appSource, /createAnalyser\(/);
  assert.match(appSource, /requestAnimationFrame\(measure/);
  assert.match(appSource, /<VideoTile label=\{tr\('Webcam-Vorschau'\)\} stream=\{webcamTestStream\}/);
  for (const german of ['Wiedergabe', 'Mikrofon', 'Sprachfilter', 'Sprachisolierung', 'Echounterdrückung', 'Automatische Verstärkung', 'Sprachaktivierung', 'Mikrofon testen', 'Test starten', 'Test stoppen', 'Webcam-Vorschau starten', 'Webcam-Vorschau stoppen', 'Eigenes Video spiegeln', 'Bildschirmfreigabe', 'Quelle', 'Anwendung / Fenster', 'Maximale Bitrate', 'Eigenes Audio einschränken', 'Lokale Audiowiedergabe unterdrücken']) assert.match(appSource, new RegExp(german));
  for (const english of ['Playback', 'Noise Suppression', 'Echo Cancellation', 'Automatic gain control', 'Noise Gate', 'Microphone Test', 'Start Video Preview', 'Mirror Own Video', 'Screen Sharing', 'Max Bitrate', 'Restrict Own Audio', 'Suppress Local Audio Playback']) assert.doesNotMatch(appSource, new RegExp(`>${english}<|>${english}|${english}</span>|${english}</label>`));
  assert.doesNotMatch(appSource, />Microphone<|>Microphone|Microphone<\/span>|Microphone<\/label>/);
});

test('webcam and screen share settings support WQHD and 4K constraints', () => {
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(voiceEngineSource, /export type MediaResolution = '480p' \| '720p' \| '1080p' \| '1440p' \| '2160p'/);
  assert.match(voiceEngineSource, /2560, height: 1440/);
  assert.match(voiceEngineSource, /3840, height: 2160/);
  assert.match(appSource, /label: 'WQHD \(1440p\)'/);
  assert.match(appSource, /label: '4K \(2160p\)'/);
});



test('trash actions delete chat messages and channels from the correct places', () => {
  assert.match(appSource, /function onDeleteMessage[\s\S]*?applyDeletedMessageEvent\(ctx\.source\.serverId, message\.channelId, message\.id, ctx\.conn\)/);
  assert.match(appSource, /await deleteMessage\(ctx\.conn, message\.id\)/);
  assert.match(appSource, /function deleteContextChannel[\s\S]*?setContextMenu\(null\)/);
  assert.match(appSource, /function deleteContextChannel[\s\S]*?setLiveChannels\(\(current\) => current\.filter\(\(item\) => item\.id !== channel\.id\)\)/);
  assert.match(appSource, /function deleteContextChannel[\s\S]*?setSelectedChannelId\(\(current\) => current === channel\.id \? null : current\)/);
  assert.doesNotMatch(appSource, /function ChannelList\([\s\S]*?onDeleteChannel/);
  assert.doesNotMatch(appSource, /className="channelDeleteButton"[\s\S]*?<Trash2 size=\{14\}/);
  assert.match(appSource, /Channel löschen/);
  assert.doesNotMatch(appSource, /<UserPlus size=\{14\} className="rowAction" \/>/);
});


test('server settings include webclient general and storage controls', () => {
  const adminFn = appSource.match(/function AdminWorkbench[\s\S]*?function AdminContextMenu/)?.[0] ?? '';
  for (const field of ['onlyAskForPasswordOnFirstJoin', 'allowNewUsers', 'directMessagesEnabled', 'enablePlugins', 'webRtcSimulcastEnabled', 'enableSearch', 'showWelcomeDialog', 'storageUploadEnabled', 'storageFileSharingInDirectMessages', 'storageQuota', 'storageUploadMaxFileSize', 'storageMaxAvatarSize', 'storageMaxBannerSize', 'storageMaxFilesPerMessage', 'storageSpaceQuotaByUser', 'storageOverflowAction', 'storageSignedUrlsEnabled', 'storageSignedUrlsTtlSeconds', 'storageImageOptimizationEnabled', 'storageImageOptimizationQuality']) assert.match(adminFn, new RegExp(field));
  for (const label of ['Server-Informationen', 'Server-Passwort', 'Nur beim ersten Beitritt nach Passwort fragen', 'Neue Benutzer erlauben', 'Direktnachrichten erlauben', 'Plugins aktivieren', 'Suche aktivieren', 'Willkommensdialog anzeigen', 'Speicher', 'Uploads erlauben', 'Dateien in Direktnachrichten erlauben', 'Gesamtes Speicherlimit', 'Maximale Dateigröße', 'Maximale Avatargröße', 'Maximale Bannergröße', 'Maximale Dateien pro Nachricht', 'Speicherlimit pro Benutzer', 'Aktion bei vollem Speicher', 'Alte Dateien löschen', 'Neue Uploads verhindern', 'Signierte URLs', 'Ablauf signierter URLs', 'Bildoptimierung aktivieren', 'Bildqualität']) assert.match(adminFn, new RegExp(label));
  assert.match(typesSource, /storageOverflowAction\?:/);
  assert.match(typesSource, /storageImageOptimizationQuality\?:/);
});


test('server update controls are visually grouped and aligned inside server settings', () => {
  const adminFn = appSource.match(/function AdminWorkbench[\s\S]*?function AdminContextMenu/)?.[0] ?? '';
  assert.match(adminFn, /className="serverUpdatePanel"/);
  assert.match(adminFn, /className="serverTokenForm"/);
  assert.match(adminFn, /className="updateActions"/);
  assert.match(cssSource, /\.serverUpdatePanel\s*\{[\s\S]*display:\s*grid[\s\S]*border-radius:\s*12px/s);
  assert.match(cssSource, /\.serverTokenForm\s*\{[\s\S]*grid-template-columns:\s*minmax\(0,1fr\) auto[\s\S]*align-items:\s*end/s);
  assert.match(cssSource, /\.serverTokenForm button,\s*\.serverUpdatePanel \.updateActions button\s*\{[\s\S]*white-space:\s*nowrap/s);
  assert.match(cssSource, /\.serverUpdatePanel \.updateActions\s*\{[\s\S]*grid-template-columns:\s*repeat\(2, minmax\(0, max-content\)\)/s);
});


test('global settings stay global while server settings live in server dropdown', () => {
  const settingsFn = appSource.match(/function SettingsPanel[\s\S]*?type AdminTab/)?.[0] ?? '';
  const dropdownFn = appSource.match(/function ServerDropdownMenu[\s\S]*?function ChannelSidebar/)?.[0] ?? '';
  assert.doesNotMatch(settingsFn, /settingsTab === 'server'/);
  assert.doesNotMatch(settingsFn, /<button role="tab"[\s\S]*?>Server<\/button>/);
  assert.doesNotMatch(settingsFn, /AdminWorkbench/);
  assert.match(dropdownFn, /Server-Einstellungen/);
  assert.match(appSource, /adminWorkbenchOpen/);
  assert.match(appSource, /<AdminWorkbenchModal/);
});

test('server header menu is anchored dropdown instead of mouse-positioned context menu', () => {
  assert.match(appSource, /type ServerDropdownState = \{ left: number; top: number; width: number \} \| null/);
  assert.doesNotMatch(appSource, /\| \{ kind: 'server'; x: number; y: number \}/);
  const openFn = appSource.match(/function openServerMenu[\s\S]*?\n  \}/)?.[0] ?? '';
  assert.match(openFn, /event\.currentTarget\.getBoundingClientRect\(\)/);
  assert.match(openFn, /setServerDropdown\(/);
  assert.doesNotMatch(openFn, /clientX|clientY|setContextMenu\(\{/)
  const channelSidebarFn = appSource.match(/function ChannelSidebar[\s\S]*?function ConnectPanel/)?.[0] ?? '';
  assert.match(channelSidebarFn, /aria-haspopup="menu"/);
  assert.match(channelSidebarFn, /aria-expanded=\{serverDropdownOpen\}/);
  assert.match(appSource, /<ServerDropdownMenu dropdown=\{serverDropdown\}/);
  const contextFn = appSource.match(/function AdminContextMenu[\s\S]*?function createInviteDraft/)?.[0] ?? '';
  assert.doesNotMatch(contextFn, /menu\.kind === 'server'/);
  assert.match(cssSource, /\.serverDropdownMenu\s*\{[\s\S]*position:\s*fixed/);
  assert.match(cssSource, /\.serverDropdownMenu\s*\{[\s\S]*width:\s*min\(260px,\s*calc\(100vw - 24px\)\)/);
});

test('channel deletion only lives in the channel context menu and closes after action', () => {
  const channelListFn = appSource.match(/function ChannelList[\s\S]*?function ChannelCategory/)?.[0] ?? '';
  const contextFn = appSource.match(/function AdminContextMenu[\s\S]*?function AddServerModal/)?.[0] ?? '';
  assert.doesNotMatch(channelListFn, /channelDeleteButton|onDeleteChannel|deleteChannelClick|<Trash2 size=\{14\}/);
  assert.match(contextFn, /Channel löschen/);
  assert.match(contextFn, /void deleteContextChannel\(menu\.channel\)/);
  assert.match(appSource, /function deleteContextChannel[\s\S]*?setContextMenu\(null\)[\s\S]*?setActionStatus\(tr\('Channel löschen…'\)\)/);
  assert.match(appSource, /function deleteContextChannel[\s\S]*?await deleteChannel\(connection, channel\.id\)/);
  assert.match(appSource, /function deleteContextChannel[\s\S]*?setLiveChannels\(\(current\) => current\.filter\(\(item\) => item\.id !== channel\.id\)\)/);
});

test('message trash deletes without native confirm blocker and exposes failure status', () => {
  const deleteFn = appSource.match(/async function onDeleteMessage[\s\S]*?async function onTogglePin/)?.[0] ?? '';
  assert.doesNotMatch(deleteFn, /window\.confirm/);
  assert.match(deleteFn, /setStatus\(tr\('Nachricht wird gelöscht…'\)\)/);
  assert.match(deleteFn, /applyDeletedMessageEvent\(ctx\.source\.serverId, message\.channelId, message\.id, ctx\.conn\)/);
  assert.match(deleteFn, /await deleteMessage\(ctx\.conn, message\.id\)/);
  assert.match(deleteFn, /await ctx\.reload\(\)/);
  assert.match(deleteFn, /Löschen fehlgeschlagen/);
});

test('message delete controls are permission aware and never shown just because a user is logged in', () => {
  const bubbleFn = appSource.match(/function MessageBubble[\s\S]*?function ThreadPanel/)?.[0] ?? '';
  const messageAreaFn = appSource.match(/function MessageArea[\s\S]*?function PluginSlotRenderer/)?.[0] ?? '';
  assert.match(bubbleFn, /canDelete: boolean/);
  assert.match(bubbleFn, /\{canDelete \? <button type="button" title=\{tr\('Löschen'\)\}/);
  assert.doesNotMatch(bubbleFn, /own \|\| ownUserId \? <button type="button" title=\{tr\('Löschen'\)\}/);
  assert.match(messageAreaFn, /canManageMessages: boolean/);
  assert.match(messageAreaFn, /canDelete=\{message\.userId === ownUserId \|\| canManageMessages\}/);
});

test('remote message deletes purge visible state, cached snapshots, threads, and DM metadata', () => {
  const applyFn = appSource.match(/function applyDeletedMessageEvent[\s\S]*?function setMessagesForEvent/)?.[0] ?? '';
  const wireFn = appSource.match(/function wireSubscriptions[\s\S]*?function setMessagesForEvent/)?.[0] ?? '';
  assert.match(applyFn, /serverSessionSnapshotsRef\.current\.set\(serverId, \{[\s\S]*messages: snapshot\.messages\.filter\(\(message\) => message\.id !== messageId\)/);
  assert.match(applyFn, /setThreadPanel\(\(current\) => current \? \{[\s\S]*messages: current\.messages\.filter\(\(message\) => message\.id !== messageId\)/);
  assert.match(applyFn, /setMessages\(\(current\) => \(matchesChat \|\| matchesDm\) \? current\.filter\(\(message\) => message\.id !== messageId\) : current\)/);
  assert.match(wireFn, /onMessageDelete: \(\{ channelId, messageId \}\) => \{[\s\S]*applyDeletedMessageEvent\(serverId, channelId, messageId, next\)/);
  assert.match(wireFn, /void refreshDirectMessagesForServer\(serverId, next\)/);
});

test('microphone test has adjustable persisted input gain and applies it to meter and voice track', () => {
  const voiceSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(appSource, /microphoneGain: 1/);
  assert.match(appSource, /Mikrofon-Eingangspegel/);
  assert.match(appSource, /min="0" max="2" step="0\.05"/);
  assert.match(appSource, /gainNode\.gain\.value = audioSettings\.microphoneGain/);
  assert.match(voiceSource, /microphoneGain: number/);
  assert.match(voiceSource, /createGainProcessedStream/);
  assert.match(voiceSource, /gain\.gain\.value = this\.settings\.microphoneGain/);
});


test('server settings save action has themed controls sticky footer and local feedback', () => {
  const adminFn = appSource.match(/function AdminWorkbench[\s\S]*?function AdminContextMenu/)?.[0] ?? '';
  assert.match(adminFn, /serverSettingsDirty/);
  assert.match(adminFn, /serverSettingsSaving/);
  assert.match(adminFn, /serverSettingsFeedback/);
  assert.match(adminFn, /className="serverSettingsFooter"/);
  assert.match(adminFn, /className="primaryAction serverSettingsSaveButton"/);
  assert.match(adminFn, /Änderungen gespeichert/);
  assert.match(cssSource, /\.adminSettings select/);
  assert.match(cssSource, /\.serverSettingsFooter\s*\{[\s\S]*position:\s*sticky/);
  assert.match(cssSource, /\.serverSettingsSaveButton/);
});

test('channel delete uses in-app confirmation dialog with visible status and reload', () => {
  const deleteFn = appSource.match(/async function deleteContextChannel[\s\S]*?async function moderateContextUser/)?.[0] ?? '';
  assert.doesNotMatch(deleteFn, /window\.confirm/);
  assert.match(appSource, /pendingChannelDelete/);
  assert.match(appSource, /ConfirmChannelDeleteDialog/);
  assert.match(appSource, /Channel wirklich löschen/);
  assert.match(appSource, /confirmDeleteChannel/);
  assert.match(appSource, /await loadInitialData\(connection\)/);
  assert.match(appSource, /Channel gelöscht/);
  assert.match(appSource, /channelActionStatus/);
});

test('desktop channel and category lists support drag and drop reorder APIs', () => {
  const clientSource = readFileSync(join(testDir, '..', 'src', 'sharkordClient.ts'), 'utf8');
  const channelListFn = appSource.match(/function ChannelList[\s\S]*?function ChannelCategory/)?.[0] ?? '';
  assert.match(clientSource, /reorderChannels\(connection: SharkordConnection, categoryId: number, channelIds: number\[\]/);
  assert.match(clientSource, /connection\.trpc\.channels\.reorder\.mutate\(\{ categoryId, channelIds \}\)/);
  assert.match(clientSource, /reorderCategories\(connection: SharkordConnection, categoryIds: number\[\]/);
  assert.match(clientSource, /connection\.trpc\.categories\.reorder\.mutate\(\{ categoryIds \}\)/);
  assert.match(appSource, /handleChannelDragStart/);
  assert.match(appSource, /handleChannelDrop/);
  assert.match(appSource, /handleCategoryDrop/);
  assert.match(channelListFn, /draggable/);
  assert.match(channelListFn, /dragHandle/);
  assert.match(cssSource, /\.channelRow\.dragOver|\.channelGroupTitle\.dragOver/);
});

test('phase 1 uses upstream detail fetch routes before editing channels and categories', () => {
  const editChannelFn = appSource.match(/async function editContextChannel[\s\S]*?function applyChannelSettingsUpdate/)?.[0] ?? '';
  const editCategoryFn = appSource.match(/async function editContextCategory[\s\S]*?function deleteContextCategory/)?.[0] ?? '';
  const adminFn = appSource.match(/function AdminWorkbench[\s\S]*?function AdminContextMenu/)?.[0] ?? '';
  assert.match(clientSource, /getChannelDetail\(connection: SharkordConnection, channelId: number\)/);
  assert.match(clientSource, /connection\.trpc\.channels\.get\.query\(\{ channelId \}\)/);
  assert.match(clientSource, /getCategoryDetail\(connection: SharkordConnection, categoryId: number\)/);
  assert.match(clientSource, /connection\.trpc\.categories\.get\.query\(\{ categoryId \}\)/);
  assert.match(editChannelFn, /await getChannelDetail\(connection, channel\.id\)/);
  assert.match(editChannelFn, /setChannelSettingsOpen\(freshChannel\)/);
  assert.match(editCategoryFn, /await getCategoryDetail\(connection, category\.id\)/);
  assert.match(editCategoryFn, /prompt\(tr\('Kategorie-Name'\), freshCategory\.name\)/);
  assert.match(adminFn, /await getCategoryDetail\(connection, category\.id\)/);
  assert.match(adminFn, /await getChannelDetail\(connection, channel\.id\)/);
});

test('phase 1 route parity snapshot tracks original and capability-gated routes', () => {
  assert.match(clientSource, /categories\.get\.query/);
  assert.match(clientSource, /channels\.get\.query/);
  assert.match(clientSource, /others\.getUpdate\.query\(\)/);
  assert.match(clientSource, /others\.updateServer\.mutate\(\)/);
  assert.match(clientSource, /others\.useSecretToken\.mutate\(\{\s*token\s*\}\)/);
  assert.match(clientSource, /messages\.getOne\.query\(\{\s*messageId\s*\}\)/);
  assert.match(clientSource, /dms\.delete\.mutate\(\{\s*channelId\s*\}\)/);
});

test('global search dialog uses lighter app surface tokens instead of undefined dark fallbacks', () => {
  const globalSearchCss = cssSource.match(/\.globalSearchBackdrop[\s\S]*?\.globalSearchEmpty\{[^}]*\}/)?.[0] ?? '';
  assert.match(globalSearchCss, /\.globalSearchDialog/);
  assert.doesNotMatch(globalSearchCss, /--surface-elevated|--text-soft/);
  assert.match(globalSearchCss, /\.globalSearchDialog\{[^}]*background:\s*var\(--panel\)/s);
  assert.match(globalSearchCss, /\.globalSearchForm\{[^}]*background:\s*var\(--input-bg\)/s);
  assert.match(globalSearchCss, /\.globalSearchResultRow,\.globalSearchFileRow\{[^}]*background:\s*var\(--surface\)/s);
});

test('current user footer opens editable profile popup without entering server settings', () => {
  const sidebarFn = appSource.match(/function ChannelSidebar[\s\S]*?function ConnectPanel/)?.[0] ?? '';
  const accountPanelFn = appSource.match(/function AccountPanel[\s\S]*?function DirectMessagesSidebar/)?.[0] ?? '';
  assert.match(appSource, /ownProfilePopupOpen/);
  assert.match(sidebarFn, /onOpenOwnProfile/);
  assert.match(sidebarFn, /<AccountPanel/);
  assert.match(accountPanelFn, /className="accountIdentityButton"/);
  assert.match(appSource, /function OwnProfilePopup/);
  assert.match(appSource, /updateOwnProfile\(connection/);
  assert.match(appSource, /changeOwnAvatar\(connection/);
  assert.match(appSource, /changeOwnBanner\(connection/);
  assert.doesNotMatch(sidebarFn, /setAdminWorkbenchOpen\(true\)/);
});
test('server logo management lives in General settings and not Profile settings', () => {
  const ownProfilePopup = appSource.match(/function OwnProfilePopup[\s\S]*?function NotificationParitySettings/)?.[0] ?? '';
  const generalPanel = appSource.match(/adminTab === 'general' \? <div className="adminSettings serverSettingsForm">[\s\S]*?adminTab === 'storage'/)?.[0] ?? '';
  assert.match(ownProfilePopup, /changeOwnAvatar\(connection/);
  assert.doesNotMatch(ownProfilePopup, /logoInputRef|changeServerLogo|profile\.serverLogo|Server-Logo Upload|Logo entfernen/);
  assert.match(generalPanel, /logoInputRef/);
  assert.match(generalPanel, /changeServerLogo\(connection/);
  assert.match(generalPanel, /settings\.logo/);
});

test('official Sharkord Docker build keeps custom voice user move drag/drop capability gated', () => {
  const channelListFn = appSource.match(/function ChannelList[\s\S]*?function ChannelCategory/)?.[0] ?? '';
  const voiceUserRowFn = appSource.match(/function VoiceUserRow[\s\S]*?function MessageArea/)?.[0] ?? '';
  assert.doesNotMatch(clientSource, /moveVoiceMember|voice\.(?:moveMember|move)\.mutate/);
  assert.match(clientSource, /voiceUserMove:\s*false/);
  assert.match(clientSource, /voice\.moveUser\.mutate/);
  assert.match(appSource, /voiceUserMoveEnabled=\{!!connection\?\.serverCapabilities\.voiceUserMove\}/);
  assert.doesNotMatch(appSource, /canMoveVoiceMembers|handleVoiceMemberDragStart|handleVoiceMemberDrop/);
  assert.match(channelListFn, /draggable=\{voiceUserMoveEnabled && voiceUser\.id !== ownUserId\}/);
  assert.match(voiceUserRowFn, /application\/x-sharkord-voice-user-id/);
  assert.doesNotMatch(voiceUserRowFn, /application\/x-sharkord-voice-source-channel-id/);
  assert.match(channelListFn, /onVoiceUserDrop\(channel\)/);
});


test('channel rows keep names left-aligned after drag handles', () => {
  assert.match(appSource, /className="dragHandle" aria-label=\{tr\('Channel verschieben'\)\}/);
  assert.match(cssSource, /\.channelRow,[\s\S]*?grid-template-columns:\s*14px\s+18px\s+minmax\(0,\s*1fr\)\s+auto/);
  assert.match(cssSource, /\.channelRow\s*>\s*span:not\(\.dragHandle\):not\(\.voiceConnectedDot\)[\s\S]*?justify-self:\s*start/);
  assert.match(cssSource, /\.channelRow\s*>\s*span:not\(\.dragHandle\):not\(\.voiceConnectedDot\)[\s\S]*?text-align:\s*left/);
  assert.doesNotMatch(cssSource, /\.channelRow,[^\n]*grid-template-columns:\s*18px\s+minmax\(0,\s*1fr\)\s+auto/);
});


test('desktop sidebar mirrors webclient category structure instead of splitting text and voice groups', () => {
  assert.match(appSource, /const channelGroups = useMemo\(\(\) => buildChannelGroups\(allChannels, categories\)/);
  assert.match(appSource, /function buildChannelGroups\(channels: SharkordChannel\[], categories: SharkordCategory\[]\): ChannelGroup\[]/);
  assert.match(appSource, /categories\.map\(\(category\) => \(\{ id: category\.id, name: category\.name, channels: \[\] as SharkordChannel\[] \}\)\)/);
  assert.doesNotMatch(appSource, /const textGroups = useMemo\(\(\) => groupedChannels/);
  assert.doesNotMatch(appSource, /const voiceGroups = useMemo\(\(\) => groupedChannels/);
  assert.doesNotMatch(appSource, /function groupedChannels\(/);
  assert.match(appSource, /ChannelCategory[\s\S]*?onToggle/);
  assert.match(appSource, /categoryCollapsedIds/);
});

test('voice user avatars use same circular clipped avatar treatment as account and member avatars', () => {
  assert.match(appSource, /<AvatarView user=\{user\} name=\{user\.name \|\| user\.identity \|\| `User \$\{user\.id\}`\} baseUrl=\{baseUrl\} className="voiceUserAvatar"/);
  assert.match(cssSource, /\.userAvatar,\s*\.smallAvatar,\s*\.messageAvatar,\s*\.memberAvatar,\s*\.voiceUserAvatar\s*\{/);
  assert.match(cssSource, /\.voiceUserAvatar\s*\{[^}]*width:\s*18px;[^}]*height:\s*18px/);
});


test('stale server-side voice membership after restart does not masquerade as local joined state', () => {
  assert.match(appSource, /const isSelectedVoiceJoined = selectedVoice \? selectedVoice\.id === currentVoiceChannelId : false/);
  assert.match(appSource, /const serverVoicePresence = useMemo\(\(\) => \{[\s\S]*?return !!voiceMap\[selectedVoice\.id\]\?\.users\?\.\[connection\.join\.ownUserId\]/);
  assert.match(appSource, /serverVoicePresence \? tr\('Server meldet alte Voice-Session · erneut beitreten'\)/);
});

test('voice join recovers from stale server runtime membership by clearing and retrying once', () => {
  assert.match(appSource, /User already in a voice channel/);
  assert.match(appSource, /voice\.join\.staleMembership/);
  assert.match(appSource, /await leaveVoiceChannel\(connection\)\.catch\(\(\) => undefined\)/);
  assert.match(appSource, /const joinResult = await joinVoiceWithStaleRecovery\(channel\)/);
});


test('voice join is guarded against double-clicks and local rate-limit cooldown', () => {
  assert.match(appSource, /const voiceBusyRef = useRef\(false\)/);
  assert.match(appSource, /const voiceJoinCooldownUntilRef = useRef\(0\)/);
  assert.match(appSource, /if \(voiceBusyRef\.current\) return/);
  assert.match(appSource, /voiceBusyRef\.current = true/);
  assert.match(appSource, /voiceBusyRef\.current = false; setVoiceBusy\(false\)/);
  assert.match(appSource, /startVoiceJoinCooldown\(60_000\)/);
  assert.match(appSource, /Voice-Rate-Limit aktiv · bitte/);
  assert.match(appSource, /voiceBusy \|\| voiceJoinCooldownActive/);
});

test('voice join rate-limit errors do not retry immediately', () => {
  assert.match(appSource, /function isRateLimitError\(message: string\): boolean/);
  assert.match(appSource, /isRateLimitError\(message\)/);
  assert.match(appSource, /Voice-Join pausiert: Rate-Limit aktiv/);
  assert.doesNotMatch(appSource, /if \(isRateLimitError\(message\)\)[\s\S]{0,400}return await joinVoiceChannel/);
});


test('category headers expose Discord-like context menu actions for edit and delete', () => {
  assert.match(appSource, /\| \{ kind: 'category'; x: number; y: number; category: SharkordCategory; channelCount: number \}/);
  assert.match(appSource, /onCategoryMenu: \(event: React\.MouseEvent, group: ChannelGroup\) => void/);
  assert.match(appSource, /onContextMenu=\{\(event\) => onCategoryMenu\(event, group\)\}/);
  assert.match(appSource, /menu\.kind === 'category'/);
  assert.match(appSource, /Kategorie bearbeiten/);
  assert.match(appSource, /Kategorie löschen/);
});

test('category deletion uses visible confirmation dialog and updates categories and channels locally', () => {
  assert.match(appSource, /pendingCategoryDelete/);
  assert.match(appSource, /ConfirmCategoryDeleteDialog/);
  assert.match(appSource, /deleteCategory\(connection, category\.id\)/);
  assert.match(appSource, /setLiveCategories\(\(current\) => current\.filter\(\(item\) => item\.id !== category\.id\)\)/);
  assert.match(appSource, /setLiveChannels\(\(current\) => current\.filter\(\(channel\) => channel\.categoryId !== category\.id\)\)/);
  assert.match(appSource, /Diese Kategorie und alle enthaltenen Channels werden gelöscht/);
  assert.doesNotMatch(appSource, /window\.confirm\(`Kategorie/);
});


test('category context menu hint has explicit grid column and stays subtle until hover', () => {
  assert.match(cssSource, /\.channelGroupTitle \{[^}]*grid-template-columns:\s*14px 14px minmax\(0,1fr\) 14px/);
  assert.match(cssSource, /\.categoryTitleText \{[^}]*text-overflow:\s*ellipsis/);
  assert.match(cssSource, /\.categoryMenuHint \{[^}]*opacity:\s*0/);
  assert.match(cssSource, /\.channelGroupTitle:hover \.categoryMenuHint/);
});


test('server dropdown is grouped with server settings as the first action', () => {
  const serverMenuMatch = appSource.match(/function ServerDropdownMenu[\s\S]*?return <div className="serverDropdownMenu"[\s\S]*?<strong>\{tr\('Server'\)\}<\/strong>([\s\S]*?)<\/div>;\n}/);
  assert.ok(serverMenuMatch, 'server dropdown block exists');
  const block = serverMenuMatch[1];
  assert.ok(block.indexOf('Server-Einstellungen') < block.indexOf('Kategorie erstellen'), 'server settings comes before create actions');
  assert.match(block, /contextMenuDivider/);
  assert.match(block, /<small>\{tr\('Erstellen'\)\}<\/small>/);
  assert.match(block, /<small>\{tr\('Verwaltung'\)\}<\/small>/);
  assert.match(block, /<small className="contextMenuInfo">/);
});

test('server storage settings display editable GB values while saving bytes internally', () => {
  assert.match(appSource, /const BYTES_PER_GB = 1024 \* 1024 \* 1024/);
  assert.match(appSource, /function bytesToGbValue\(bytes\?: number \| null\)/);
  assert.match(appSource, /function gbInputToBytes\(value: string\)/);
  for (const field of ['storageQuota', 'storageUploadMaxFileSize', 'storageMaxAvatarSize', 'storageMaxBannerSize', 'storageSpaceQuotaByUser']) {
    assert.match(appSource, new RegExp(`value=\\{bytesToGbValue\\(settings\\.${field}`));
    assert.match(appSource, new RegExp(`${field}: gbInputToBytes\\(event\\.target\\.value\\)`));
  }
  assert.doesNotMatch(appSource, /Bytes, 0 = unbegrenzt/);
  assert.doesNotMatch(appSource, /<small>Bytes<\/small>/);
  assert.match(appSource, /GB, 0 = unbegrenzt/);
});


test('invite deletion sends numeric inviteId and never code to server API', () => {
  assert.match(clientSource, /export async function deleteInvite\(connection: SharkordConnection, inviteId: number\)/);
  assert.match(clientSource, /invites\.delete\.mutate\(\{ inviteId \}\)/);
  assert.doesNotMatch(clientSource, /invites\.delete\.mutate\(\{ code \}\)/);
  assert.match(appSource, /deleteInvite\(connection, invite\.id\)/);
  assert.match(appSource, /if \(invite\.id == null\) throw new Error\(tr\('Einladungs-ID fehlt'\)\)/);
});

test('admin workbench uses compact card lists instead of raw text table rows', () => {
  assert.match(appSource, /className="adminSectionHeader"/);
  assert.match(appSource, /className="adminList adminChannelList"/);
  assert.match(appSource, /className="adminListRow/);
  assert.match(appSource, /className="adminRowActions"/);
  assert.match(appSource, /className="adminBadge/);
  assert.match(appSource, /className="adminPrimaryAction"/);
  assert.doesNotMatch(appSource, /className="adminTable"><button onClick=\{addRole\}>Rolle erstellen<\/button>/);
  assert.doesNotMatch(appSource, /className="adminTable"><button onClick=\{addInvite\}>Invite erstellen<\/button>/);
});

test('admin list styling provides Discord-like cards rows and visible danger buttons', () => {
  assert.match(cssSource, /\.adminSection \{/);
  assert.match(cssSource, /\.adminListRow \{/);
  assert.match(cssSource, /grid-template-columns: minmax\(0,1fr\) auto/);
  assert.match(cssSource, /\.adminRowActions \{/);
  assert.match(cssSource, /\.adminListRow button\.danger/);
  assert.match(cssSource, /\.adminPrimaryAction/);
});


test('admin channel list groups text and voice channels separately', () => {
  assert.match(appSource, /const textAdminChannels = channels\.filter\(\(channel\) => channel\.type !== 'VOICE'\)/);
  assert.match(appSource, /const voiceAdminChannels = channels\.filter\(\(channel\) => channel\.type === 'VOICE'\)/);
  assert.match(appSource, /<div className="adminListTitle">\{tr\('Text-Channels'\)\}<\/div>/);
  assert.match(appSource, /<div className="adminListTitle">\{tr\('Voice-Channels'\)\}<\/div>/);
  assert.match(appSource, /textAdminChannels\.map/);
  assert.match(appSource, /voiceAdminChannels\.map/);
});

test('invite creation mirrors webclient dialog fields instead of instant default invite', () => {
  assert.match(appSource, /function CreateInviteDialog/);
  assert.match(appSource, /tr\('Server-Invite erstellen'\)/);
  assert.match(i18nSource, /'Server-Invite erstellen': 'Create server invite'/);
  assert.match(appSource, /tr\('Erstelle einen neuen Einladungslink, damit Benutzer dem Server beitreten können\.'\)/);
  assert.match(i18nSource, /'Erstelle einen neuen Einladungslink, damit Benutzer dem Server beitreten können\.': 'Create a new invitation link for users to join the server\.'/);
  assert.match(appSource, /\{tr\('Code'\)\}<input/);
  assert.match(appSource, /\{tr\('Maximale Nutzungen'\)\}<small>/);
  assert.match(i18nSource, /'Maximale Nutzungen': 'Max uses'/);
  assert.match(appSource, /tr\('0 bedeutet unbegrenzt\.'\)/);
  assert.match(appSource, /\{tr\('Läuft ab'\)\}<small>/);
  assert.match(appSource, /tr\('Leer lassen für kein Ablaufdatum\.'\)/);
  assert.match(appSource, /\{tr\('Rolle zuweisen'\)\}<small>/);
  assert.match(i18nSource, /'Rolle zuweisen': 'Assign role'/);
  assert.match(appSource, /tr\('Beitretende Benutzer erhalten diese Rolle\.'\)/);
  assert.match(appSource, /roleId: inviteDraft\.roleId === 'default' \? undefined : Number\(inviteDraft\.roleId\)/);
  assert.match(appSource, /expiresAt: inviteDraft\.expiresAt \? new Date\(inviteDraft\.expiresAt\)\.getTime\(\) : null/);
  assert.doesNotMatch(appSource, /const addInvite = \(\) => runAdmin\('Invite erstellen', async \(\) => \{ await createInvite\(connection, \{ maxUses: 0, expiresAt: null \}\)/);
});

test('invite dialog styling matches modal form pattern and remains viewport safe', () => {
  assert.match(cssSource, /\.inviteCreateDialog/);
  assert.match(cssSource, /\.inviteCreateDialog textarea|\.inviteCreateDialog select|\.inviteCreateDialog input/);
  assert.match(cssSource, /max-height: min\(720px,calc\(100vh - 48px\)\)/);
  assert.match(cssSource, /\.inviteCreateActions/);
});


test('server settings tabs mirror webclient structure except profile/updates and keep desktop max-files UX', () => {
  const adminFn = appSource.match(/function AdminWorkbench[\s\S]*?function AdminContextMenu/)?.[0] ?? '';
  for (const label of ["general: tr\\('Übersicht'\\)", "roles: tr\\('Rollen'\\)", "emojis: tr\\('Emojis'\\)", "storage: tr\\('Speicher'\\)", "users: tr\\('Benutzer'\\)", "security: tr\\('IP-Sicherheit'\\)", "invites: tr\\('Einladungen'\\)", "plugins: tr\\('Plugins'\\)", "parity: tr\\('Parität'\\)"]) assert.match(adminFn, new RegExp(label));
  assert.doesNotMatch(adminFn, /profile:\s*tr\('Profil'\)|adminTab === 'profile'|<ProfileParitySettings|\['general','profile'/);
  assert.doesNotMatch(adminFn, />Updates</);
  assert.match(appSource, /type AdminTab = 'general' \| 'roles' \| 'emojis' \| 'storage' \| 'users' \| 'security' \| 'invites' \| 'plugins' \| 'parity';/);
  assert.match(adminFn, /adminTab === 'storage'/);
  assert.match(adminFn, /Maximale Dateien pro Nachricht/);
});

test('signed url ttl is edited in minutes with presets while saving seconds to server', () => {
  assert.match(appSource, /ttlSecondsToMinutesValue/);
  assert.match(appSource, /minutesInputToTtlSeconds/);
  assert.match(appSource, /Signed URL TTL/);
  assert.match(appSource, /1 Minute|15 Minuten|60 Minuten|24 Stunden/);
  assert.doesNotMatch(appSource, /Signed URL TTL<small>Sekunden/);
});

test('roles parity includes permissions and storage quota override editor', () => {
  assert.match(appSource, /SERVER_PERMISSION_OPTIONS/);
  assert.match(appSource, /toggleRolePermission/);
  assert.match(appSource, /Rollen-Berechtigungen/);
  assert.match(appSource, /Speicherlimit-Override/);
  assert.match(appSource, /storageQuotaOverrideEnabled/);
  assert.match(appSource, /storageSpaceQuota/);
  assert.match(appSource, /MANAGE_PLUGINS/);
});

test('emoji parity includes upload workflow and real webclient upload plus emojis.add API', () => {
  assert.match(clientSource, /uploadEmoji/);
  assert.match(clientSource, /`\$\{connection\.baseUrl\}\/upload`/);
  assert.match(clientSource, /emojis\.add\.mutate/);
  assert.match(appSource, /emojiFileInputRef/);
  assert.match(appSource, /Emoji hochladen/);
  assert.match(appSource, /handleEmojiUpload/);
});

test('users parity includes search, roles, created date, last login and status badges', () => {
  assert.match(appSource, /userSearch/);
  assert.match(appSource, /filteredAdminUsers/);
  assert.match(appSource, /Rollen:/);
  assert.match(appSource, /tr\('Erstellt'\)/);
  assert.match(appSource, /tr\('Letzter Login'\)/);
  assert.match(appSource, /tr\('Status'\)/);
});

test('invite list parity includes search copy role creator created status and delete', () => {
  assert.match(appSource, /inviteSearch/);
  assert.match(appSource, /copyInviteCode/);
  assert.match(appSource, /tr\('Rolle'\)/);
  assert.match(appSource, /tr\('Ersteller'\)/);
  assert.match(appSource, /tr\('Erstellt'\)/);
  assert.match(appSource, /tr\('Status'\)/);
  assert.match(appSource, /Einladung kopieren/);
});

test('plugins parity includes installed marketplace logs commands settings and backend routes', () => {
  assert.match(typesSource, /SharkordPluginInfo/);
  assert.match(typesSource, /SharkordMarketplaceEntry/);
  assert.match(clientSource, /getPlugins/);
  assert.match(clientSource, /togglePlugin/);
  assert.match(clientSource, /removePlugin/);
  assert.match(clientSource, /installPlugin/);
  assert.match(clientSource, /updatePlugin/);
  assert.match(appSource, /pluginSubTab/);
  for (const label of ['Installed','Marketplace','Logs','Commands','Settings']) assert.match(appSource, new RegExp(label));
});

test('plugin component parity exposes typed wrappers and native render surfaces', () => {
  assert.match(typesSource, /PluginSlotId\s*=\s*'topbar' \| 'chat-actions' \| 'connect' \| 'content-wrapper'/);
  assert.match(typesSource, /SharkordPluginSlotRender|PluginSlotItem/);
  for (const field of ['pluginId', 'slot', 'label', 'title', 'description', 'icon', 'actionName', 'payload', 'enabled', 'order', 'component', 'componentSlot', 'componentIndex']) assert.match(typesSource, new RegExp(`${field}\\??:`));
  assert.match(clientSource, /processPluginComponents/);
  assert.match(clientSource, /executePluginSlotAction/);
  assert.match(clientSource, /plugin-bundle/);
  assert.match(clientSource, /CLIENT_PLUGIN_ENTRY_FILE = 'client\/index\.js'/);
  assert.match(clientSource, /plugins\.executeAction\.mutate\(\{[\s\S]*pluginId[\s\S]*actionName[\s\S]*payload[\s\S]*slot[\s\S]*context/);
  assert.match(appSource, /function PluginSlotRenderer/);
  for (const slot of ['topbar', 'chat-actions', 'connect', 'content-wrapper']) assert.match(appSource, new RegExp(`slot=\\{['\"]${slot}['\"]\\}|slot: ['\"]${slot}['\"]`));
  assert.match(appSource, /pluginSlotRenderer/);
  assert.match(appSource, /pluginSlotButton/);
  assert.match(cssSource, /\.pluginSlotRenderer/);
  assert.match(cssSource, /\.pluginSlotButton/);
  assert.doesNotMatch(appSource, /<iframe\b|<webview\b/i);
});

test('installed plugin admin panel lists component slot visibility from join component bundles', () => {
  const adminFn = appSource.match(/function AdminWorkbench[\s\S]*?function AdminContextMenu/)?.[0] ?? '';
  assert.match(adminFn, /pluginSlots/);
  assert.match(adminFn, /processPluginComponents/);
  assert.match(adminFn, /connection\.join\.pluginIdsWithComponents \?\? \[\]/);
  assert.match(adminFn, /Slot visibility|Slot-Sichtbarkeit|Slots/);
  assert.match(adminFn, /pluginSlotList/);
  assert.match(adminFn, /pluginSlotAdminSection/);
});

test('server settings removes internal webclient-structure explainer copy', () => {
  assert.doesNotMatch(appSource, /Webclient-nahe Struktur: General, Roles, Emojis, Storage, Users, Invites, Plugins/);
  assert.doesNotMatch(appSource, /Updates bewusst nicht enthalten/);
  assert.doesNotMatch(appSource, /Alltagsaktionen bleiben in Server-, Channel- und User-Kontextmenüs/);
});

test('storage tab includes webclient-like disk usage overview cards and progress', () => {
  assert.match(appSource, /storageOverviewMetrics/);
  for (const label of ['Gesamtspeicher', 'Freier Speicher', 'System belegt', 'Sharkord belegt', 'Speicherbelegung']) assert.match(appSource, new RegExp(`tr\\('${label}'\\)`));
  for (const pair of [
    ["'Gesamtspeicher'", "'Total space'"],
    ["'Freier Speicher'", "'Available space'"],
    ["'System belegt'", "'System used'"],
    ["'Sharkord belegt'", "'Sharkord used'"],
    ["'Speicherbelegung'", "'Disk usage'"]
  ]) assert.match(i18nSource, new RegExp(`${pair[0]}: ${pair[1]}`));
  assert.match(appSource, /storageUsagePercent/);
  assert.match(cssSource, /\.storageOverviewGrid/);
  assert.match(cssSource, /\.storageUsageBar/);
});

test('admin header and plugin segmented buttons use unified secondary button styling', () => {
  const adminFn = appSource.match(/function AdminWorkbench[\s\S]*?function AdminContextMenu/)?.[0] ?? '';
  assert.match(adminFn, /className="adminSecondaryAction"[\s\S]*?>\{tr\('Neu laden'\)\}</);
  assert.match(adminFn, /className=\{`adminSegmentButton \$\{pluginSubTab === 'installed' \? 'selected' : ''\}`\}/);
  assert.match(adminFn, /className=\{`adminSegmentButton \$\{pluginSubTab === 'marketplace' \? 'selected' : ''\}`\}/);
  assert.doesNotMatch(adminFn, /<button className=\{pluginSubTab === 'installed' \? 'selected' : ''\}/);
  assert.match(cssSource, /\.adminSecondaryAction/);
  assert.match(cssSource, /\.adminSegmentedControl/);
  assert.match(cssSource, /\.adminSegmentButton\.selected/);
});



test('global settings expose import export tab for portable desktop transfer', () => {
  assert.match(appSource, /type SettingsTab = 'appearance' \| 'updates' \| 'audioVideo' \| 'notifications' \| 'importExport'/);
  assert.match(appSource, />Import\/Export<|Import\/Export/);
  assert.match(appSource, /settingsTab === 'importExport'/);
  assert.match(appSource, /ImportExportSettings/);
  assert.match(appSource, /openSettingsImportFile/);
  assert.match(appSource, /ReadSettingsImportJSON/);
});

test('settings export contains portable state audio and stream mute settings but no credentials', () => {
  assert.match(appSource, /createSettingsExport/);
  assert.match(appSource, /kind: 'sharkord-desktop-settings-export'/);
  assert.match(appSource, /state/);
  assert.match(appSource, /audioSettings/);
  assert.match(appSource, /streamAudioMuted/);
  assert.match(appSource, /AUDIO_DEVICE_STORAGE_KEY/);
  assert.match(appSource, /STREAM_AUDIO_MUTE_STORAGE_KEY/);
  assert.doesNotMatch(appSource.match(/function createSettingsExport[\s\S]*?\n}\n/)?.[0] ?? '', /password|serverPassword|LoadServerCredentials|SaveServerCredentials/);
});

test('settings import validates schema, saves native state and applies imported audio settings', () => {
  assert.match(appSource, /parseSettingsImport/);
  assert.match(appSource, /Ungültige Import-Datei/);
  assert.match(appSource, /API\.SaveAppState/);
  assert.match(appSource, /saveState\(nextState\)/);
  assert.match(appSource, /setAudioSettings\(nextAudioSettings\)/);
  assert.match(appSource, /localStorage\.setItem\(STREAM_AUDIO_MUTE_STORAGE_KEY/);
  assert.match(appSource, /window\.confirm\(/);
});

test('import export panel has compact card styling and no horizontal overflow traps', () => {
  assert.match(cssSource, /\.importExportSettings/);
  assert.match(cssSource, /\.importExportGrid/);
  assert.match(cssSource, /\.importExportActions/);
  assert.match(cssSource, /\.importExportSummary/);
  assert.match(cssSource, /\.settingsContent \{[^}]*max-width:\s*900px/);
  assert.match(cssSource, /grid-template-columns:\s*repeat\(2,minmax\(0,1fr\)\)/);
  assert.match(cssSource, /\.importExportGrid \{ grid-template-columns: minmax\(0,1fr\); \}/);
});

test('import export action buttons share one clean settings button system', () => {
  const importExportFn = appSource.slice(appSource.indexOf('function ImportExportSettings'), appSource.indexOf('type AdminTab'));
  assert.doesNotMatch(importExportFn, /className="primaryAction"/);
  assert.doesNotMatch(importExportFn, /className="secondary"/);
  assert.match(importExportFn, /className="settingsTransferButton primary"/);
  assert.match(importExportFn, /className="settingsTransferButton secondary"/);
  assert.match(cssSource, /\.settingsTransferButton\s*\{/);
  assert.match(cssSource, /\.settingsTransferButton\.primary/);
  assert.match(cssSource, /\.settingsTransferButton\.secondary/);
  assert.match(cssSource, /min-height:\s*40px/);
  assert.match(cssSource, /width:\s*100%/);
  assert.match(cssSource, /border-radius:\s*8px/);
});



test('text composer uses real action buttons and no fake gift icon', () => {
  const messageArea = appSource.match(/function MessageArea[\s\S]*?function AudioSpeakingWatcher/)?.[0] ?? '';
  assert.doesNotMatch(messageArea, /<Gift\b/);
  assert.doesNotMatch(messageArea, /<div className="composerTools"><Gift/);
  assert.match(messageArea, /aria-label=\{tr\('Datei anhängen'\)\}/);
  assert.match(messageArea, /aria-label=\{tr\('Bild anhängen'\)\}/);
  assert.match(messageArea, /aria-label=\{tr\('Emoji einfügen'\)\}/);
  assert.match(messageArea, /className="composerToolButton"/);
  assert.match(messageArea, /onClick=\{openFilePicker\}/);
  assert.match(messageArea, /onClick=\{openImagePicker\}/);
  assert.match(messageArea, /setEmojiPickerOpen/);
});

test('text composer uploads attachments and sends their file ids', () => {
  const clientSource = readFileSync(join(testDir, '..', 'src', 'sharkordClient.ts'), 'utf8');
  assert.match(clientSource, /export async function uploadTemporaryFile/);
  assert.match(clientSource, /fetch\(`\$\{connection\.baseUrl\}\/upload`/);
  assert.match(clientSource, /'x-token': await connection\.getFreshToken\(\)/);
  assert.match(clientSource, /'x-file-name': safeName/);
  assert.match(clientSource, /'x-file-type': file\.type \|\| 'application\/octet-stream'/);
  assert.match(clientSource, /export async function sendChannelMessage\(connection: SharkordConnection, channelId: number, plainText: string, files: SharkordTempFile\[\] = \[\]\)/);
  assert.match(clientSource, /files: files\.map\(\(file\) => file\.id\)/);
  assert.match(appSource, /sendMessage\(event, attachments\)/);
  assert.match(appSource, /setAttachments\(\[\]\)/);
});



test('emoji picker has enough room and never clips its grid', () => {
  assert.match(cssSource, /\.composerEmojiMenu\s*\{[^}]*min-width:\s*260px/);
  assert.match(cssSource, /\.composerEmojiMenu\s*\{[^}]*overflow:\s*hidden/);
  assert.match(cssSource, /\.composerEmojiMenu button\s*\{[^}]*width:\s*42px/);
  assert.match(cssSource, /\.composerEmojiMenu button\s*\{[^}]*height:\s*42px/);
});

test('text chat header tools are real controls and search filters messages', () => {
  const messageArea = appSource.match(/function MessageArea[\s\S]*?function AudioSpeakingWatcher/)?.[0] ?? '';
  assert.doesNotMatch(messageArea, /<Bell size=\{18\} \/><PinIcon \/><button/);
  assert.match(messageArea, /aria-label=\{tr\('Benachrichtigungen umschalten'\)\}/);
  assert.match(messageArea, /aria-label=\{tr\('Nur Erwähnungen anzeigen'\)\}/);
  assert.match(messageArea, /aria-label=\{tr\('Speicher öffnen'\)\}/);
  assert.match(messageArea, /aria-label=\{tr\('Hilfe anzeigen'\)\}/);
  assert.match(messageArea, /value=\{messageSearch\}/);
  assert.match(messageArea, /setMessageSearch/);
  assert.match(messageArea, /visibleMessages/);
  assert.match(messageArea, /mentionsOnly/);
  assert.match(messageArea, /storageOpen/);
});

test('composer supports at mention suggestions and insertion', () => {
  const messageArea = appSource.match(/function MessageArea[\s\S]*?function AudioSpeakingWatcher/)?.[0] ?? '';
  assert.match(messageArea, /mentionSuggestions/);
  assert.match(messageArea, /insertMention/);
  assert.match(messageArea, /composerMentionMenu/);
  assert.match(messageArea, /@\$\{displayUserName\(user\)\}/);
  assert.match(cssSource, /\.composerMentionMenu\s*\{/);
  assert.match(cssSource, /\.composerMentionMenu button\s*\{/);
});


test('text chat header replaces inbox with user storage browser', () => {
  const clientSource = readFileSync(join(testDir, '..', 'src', 'sharkordClient.ts'), 'utf8');
  const messageArea = appSource.match(/function MessageArea[\s\S]*?function AudioSpeakingWatcher/)?.[0] ?? '';
  assert.doesNotMatch(appSource, /\bInbox\b/);
  assert.match(appSource, /\bHardDrive\b/);
  assert.match(messageArea, /aria-label=\{tr\('Speicher öffnen'\)\}/);
  assert.match(messageArea, /setStorageOpen\(true\)/);
  assert.match(messageArea, /Meine Dateien/);
  assert.match(clientSource, /export async function getOwnStorageFiles/);
  assert.match(clientSource, /connection\.trpc\.users\.getInfo\.query\(\{ userId: connection\.join\.ownUserId \}\)/);
  assert.match(clientSource, /export async function deleteStoredFile/);
  assert.match(clientSource, /connection\.trpc\.files\.delete\.mutate\(\{ fileId \}\)/);
});

test('user storage browser can search open and delete uploaded media', () => {
  const messageArea = appSource.match(/function MessageArea[\s\S]*?function AudioSpeakingWatcher/)?.[0] ?? '';
  assert.match(messageArea, /storageFiles/);
  assert.match(messageArea, /storageQuery/);
  assert.match(messageArea, /filteredStorageFiles/);
  assert.match(messageArea, /Datei öffnen/);
  assert.match(messageArea, /Datei löschen/);
  assert.match(messageArea, /deleteStoredFile\(connection, file\.id\)/);
  assert.match(cssSource, /\.userStorageModal\s*\{[^}]*width:\s*min\(680px,calc\(100vw - 48px\)\)/);
  assert.match(cssSource, /\.userStorageGrid\s*\{[^}]*grid-template-columns:\s*repeat\(auto-fill,minmax\(200px,1fr\)\)/);
  assert.match(cssSource, /\.userStorageFileCard\s*\{/);
});


test('server rail uses configured server logo before initials fallback', () => {
  const typeSource = readFileSync(join(testDir, '..', 'src', 'types.ts'), 'utf8');
  const storageSource = readFileSync(join(testDir, '..', 'src', 'storage.ts'), 'utf8');
  const rail = appSource.match(/function ServerRail[\s\S]*?function ConnectPanel/)?.[0] ?? '';
  assert.match(typeSource, /logo\?:\s*SharkordFile \| null/);
  assert.match(storageSource, /logo:\s*input\.logo/);
  assert.match(appSource, /logo:\s*info\.logo/);
  assert.match(appSource, /logo:\s*candidate\.logo/);
  assert.match(rail, /server\.logo/);
  assert.match(rail, /className="serverLogo"/);
  assert.match(rail, /fileUrl\(server\.url, server\.logo\)/);
  assert.match(rail, /initials\(server\.name\)/);
  assert.match(cssSource, /\.serverButton, \.guildButton\s*\{[^}]*padding:\s*0/);
  assert.match(cssSource, /\.serverLogo\s*\{/);
});

test('settings export uses native save dialog and optional user data instead of browser download', () => {
  assert.match(appSource, /includeUserData/);
  assert.match(appSource, /Nutzerdaten einschließen/);
  assert.match(appSource, /saveSettingsExportFile\(filename\)/);
  assert.match(appSource, /WriteSettingsExportJSON\(savedPath, JSON\.stringify\(payload, null, 2\), withUserData\)/);
  assert.doesNotMatch(appSource, /URL\.createObjectURL\(/);
  assert.doesNotMatch(appSource, /document\.createElement\('a'\)/);
  assert.match(serviceSource, /WriteSettingsExportJSON/);
  assert.doesNotMatch(serviceSource, /Dialog\.SaveFile\(\)/);
  assert.doesNotMatch(serviceSource, /PromptForSingleSelection\(\)/);
  assert.match(serviceSource, /os\.WriteFile\(target, \[\]byte\(exportJSON\), 0600\)/);
  assert.match(serviceSource, /credentialsByServerId/);
  assert.match(serviceSource, /LoadServerCredentials\(server\.ID\)/);
});

test('settings import restores optional exported user credentials after explicit confirmation', () => {
  assert.match(appSource, /credentialsByServerId\?: Record<string, ServerCredentials>/);
  assert.match(appSource, /Object\.entries\(imported\.credentialsByServerId \?\? \{\}\)/);
  assert.match(appSource, /API\.SaveServerCredentials\(serverId, creds\)/);
  assert.match(appSource, /Nutzerdaten\/Zugangsdaten/);
});



test('macos settings export uses frontend-attached Wails save dialog before backend write', () => {
  assert.match(appSource, /saveSettingsExportFile\(filename\)/);
  assert.match(appSource, /API\.WriteSettingsExportJSON\(savedPath, JSON\.stringify\(payload, null, 2\), withUserData\)/);
  assert.doesNotMatch(appSource, /API\.ExportSettingsJSON\(filename, JSON\.stringify\(payload, null, 2\), includeUserData\)/);
  assert.match(serviceSource, /WriteSettingsExportJSON/);
  const writeFn = serviceSource.match(/func \(s \*AppService\) WriteSettingsExportJSON[\s\S]*?\n}/)?.[0] ?? '';
  assert.match(writeFn, /os\.WriteFile\(target/);
  assert.doesNotMatch(writeFn, /Dialog\.SaveFile|PromptForSingleSelection|SaveFileDialogOptions/);
});


test('macos settings import uses native open dialog and backend JSON reader instead of browser file input text', () => {
  const importExportFn = appSource.slice(appSource.indexOf('function ImportExportSettings'), appSource.indexOf('type AdminTab'));
  assert.match(appSource, /async function openSettingsImportFile\(\)/);
  assert.match(appSource, /Dialogs\.OpenFile\(\{[\s\S]*Title:\s*tr\('Sharkord Einstellungen importieren'\)[\s\S]*CanChooseFiles:\s*true[\s\S]*AllowsMultipleSelection:\s*false[\s\S]*Filters:\s*\[\{ DisplayName:\s*tr\('JSON-Dateien'\), Pattern:\s*'\*\.json' \}\]/);
  assert.match(appSource, /API\.ReadSettingsImportJSON\(importPath\)/);
  assert.doesNotMatch(appSource, /await file\.text\(\)/);
  assert.match(importExportFn, /onClick=\{\(\) => void onImport\(\)\}/);
  assert.doesNotMatch(importExportFn, /type="file"|settingsImportFile|importFileRef|onImportFile/);
  assert.match(serviceSource, /ReadSettingsImportJSON/);
  assert.match(serviceSource, /maxSettingsImportBytes/);
  assert.match(serviceSource, /json\.Valid/);
});


test('settings import confirmation uses Wails question dialog instead of browser confirm', () => {
  const importSettingsFn = appSource.match(/const importSettingsFile = async \(\) => \{[\s\S]*?\n  \};/)?.[0] ?? '';
  assert.match(appSource, /async function confirmSettingsImport\(message: string, title = tr\('Import bestätigen'\), confirmLabel = tr\('Importieren'\)\)/);
  assert.match(appSource, /Dialogs\.Question\(\{[\s\S]*Title:\s*title[\s\S]*Buttons:\s*\[/);
  assert.match(importSettingsFn, /await confirmSettingsImport\(/);
  assert.doesNotMatch(importSettingsFn, /window\.confirm/);
  assert.match(importSettingsFn, /Import: keine Datei ausgewählt/);
});


test('user data export warning is in-app and does not cancel macos save dialog through window.confirm', () => {
  assert.match(appSource, /exportUserDataConfirmOpen/);
  assert.match(appSource, /confirmExportWithUserData/);
  const exportFn = appSource.match(/const exportSettings = async \(\) => \{[\s\S]*?\n  \};/)?.[0] ?? '';
  assert.match(exportFn, /setExportUserDataConfirmOpen\(true\)/);
  assert.doesNotMatch(exportFn, /window\.confirm/);
  assert.match(appSource, /Nutzerdaten wirklich exportieren\?/);
  assert.match(appSource, /Fortfahren und Speicherort wählen/);
});


test('audio video settings can unlock full Windows media device lists after permission grant', () => {
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(voiceEngineSource, /requestMediaDeviceAccess/);
  assert.match(voiceEngineSource, /refreshMediaDeviceLists/);
  assert.match(voiceEngineSource, /getUserMedia\(\{\s*audio:\s*true,\s*video:\s*false\s*\}\)/s);
  assert.match(voiceEngineSource, /getUserMedia\(\{\s*audio:\s*false,\s*video:\s*true\s*\}\)/s);
  assert.match(appSource, /autoUnlockMediaDeviceLists/);
  assert.match(appSource, /refreshMediaDeviceLists\(\)/);
  assert.match(appSource, /startMikrofonTest[^]*refreshMediaDeviceLists\(\)/);
  assert.match(appSource, /startWebcamPreview[^]*refreshMediaDeviceLists\(\)/);
  assert.match(appSource, /Geräte aktualisieren/);
});


test('windows webview grants microphone and camera permissions for device enumeration', () => {
  const mainSource = readFileSync(join(projectRoot, 'main.go'), 'utf8');
  assert.match(mainSource, /Windows:\s*application\.WindowsWindow\{/s);
  assert.match(mainSource, /CoreWebView2PermissionKindMicrophone/);
  assert.match(mainSource, /CoreWebView2PermissionKindCamera/);
  assert.match(mainSource, /CoreWebView2PermissionStateAllow/);
});


test('audio video device lists auto-unlock and do not require manual refresh', () => {
  assert.match(appSource, /autoUnlockMediaDeviceLists/);
  assert.match(appSource, /settingsTab !== 'audioVideo'\) return;\n\s*void autoUnlockMediaDeviceLists\(\)/);
  assert.doesNotMatch(appSource, /Mediengeräte freischalten/);
});

test('audio video selects keep chosen concrete device ids and ignore blank duplicate defaults', () => {
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(voiceEngineSource, /normalizeMediaDevices/);
  assert.match(voiceEngineSource, /!device\.deviceId \|\| device\.deviceId === 'default'/);
  assert.doesNotMatch(appSource, /value=\{device\.deviceId \|\| 'default'\}/);
  assert.match(appSource, /<option key=\{device\.deviceId\} value=\{device\.deviceId\}>/);
  assert.match(appSource, /ensureAudioSettingStillSelectable/);
});

test('voice speaking watcher resumes audio context and uses robust time-domain level', () => {
  const watcher = appSource.match(/function AudioSpeakingWatcher[\s\S]*?\n}\n\nfunction VoiceGridView/)?.[0] ?? '';
  assert.match(watcher, /context\.resume\(\)/);
  assert.match(watcher, /getByteTimeDomainData/);
  assert.match(watcher, /centered = value - 128/);
  assert.match(watcher, /SPEAKING_THRESHOLD/);
});


test('windows microphone test resumes audio context before measuring input level', () => {
  const micTest = appSource.match(/const startMikrofonTest =[\s\S]*?setMediaTestStatus\(tr\('Mikrofon-Test läuft'\)\);\n  }, \[audioSettings, refreshMediaDeviceLists, stopMikrofonTest\]\);/)?.[0] ?? '';
  assert.match(micTest, /new AudioContextCtor\(\)/);
  assert.match(micTest, /await context\.resume\(\)/);
  assert.match(micTest, /getByteTimeDomainData/);
  assert.match(micTest, /centered = value - 128/);
});

test('voice microphone uplink uses processed isolation when enabled and keeps raw fallback available', () => {
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  const startMic = voiceEngineSource.match(/async startMicStream\(\)[\s\S]*?track\.onended = \(\) => this\.stopMicStream\(\);\n  }/)?.[0] ?? '';
  assert.match(startMic, /const rawTrack = stream\.getAudioTracks\(\)\[0\]/);
  assert.match(startMic, /const track = processedStream\.getAudioTracks\(\)\[0\] \?\? rawTrack/);
  assert.match(startMic, /producingRawFallback/);
  assert.match(startMic, /this\.callbacks\.onLocalAudioStream\(new MediaStream\(\[track\]\)\)/);
});


test('screen and webcam producers pass configured fps into mediasoup encodings', () => {
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(voiceEngineSource, /this\.videoProducer = await this\.producerTransport\.produce\(\{ track, encodings: \[\{ maxFramerate: videoFps \}\]/);
  assert.match(voiceEngineSource, /this\.screenProducer = await this\.producerTransport\.produce\(\{[\s\S]*encodings: \[\{ maxBitrate: this\.settings\.screenMaxBitrateMbps \* 1000 \* 1000, maxFramerate: screenFps \}\]/);
  assert.match(voiceEngineSource, /requestedFps: screenFps/);
  assert.match(voiceEngineSource, /trackSettings: videoTrack\.getSettings\?\.\(\) \?\? \{\}/);
});

test('windows microphone uplink prefers processed isolation track but falls back to raw captured track', () => {
  const voiceEngineSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  const startMic = voiceEngineSource.match(/async startMicStream\(\)[\s\S]*?track\.onended = \(\) => this\.stopMicStream\(\);\n  }/)?.[0] ?? '';
  assert.match(startMic, /const track = processedStream\.getAudioTracks\(\)\[0\] \?\? rawTrack/);
  assert.match(startMic, /producingRawFallback = track === rawTrack/);
  assert.match(startMic, /processedAudioTracks/);
});


test('audio settings expose voice isolation without Krisp/vendor copy', () => {
  const appSource = readFileSync(join(testDir, '..', 'src', 'App.tsx'), 'utf8');
  const voiceSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(appSource, />\{tr\('Sprachisolierung'\)\}<\/option>/);
  assert.doesNotMatch(appSource, /Starke Sprachisolierung/);
  assert.doesNotMatch(appSource, /Krisp|proprietär|proprietary/i);
  assert.match(appSource, /voiceIsolationEnabled: true/);
  assert.match(appSource, /event\.target\.value === 'voiceIsolation'/);
  assert.match(voiceSource, /createVoiceIsolatedStream/);
  assert.match(voiceSource, /VoiceGateWorkletNode|voiceGateWorkletUrl/);
});

test('strong voice isolation is used for the transmitted microphone track', () => {
  const voiceSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  const startMic = voiceSource.match(/async startMicStream\(\)[\s\S]*?track\.onended = \(\) => this\.stopMicStream\(\);\n  }/)?.[0] ?? '';
  assert.match(startMic, /const processedStream = this\.settings\.voiceIsolationEnabled/);
  assert.match(startMic, /const track = processedStream\.getAudioTracks\(\)\[0\] \?\? rawTrack/);
  assert.doesNotMatch(startMic, /const track = rawTrack;\n    const producingRawFallback = true/);
  assert.match(startMic, /voiceIsolationEnabled/);
});

test('screen share uses motion hint and higher gaming bitrate range for 1080p60', () => {
  const appSource = readFileSync(join(testDir, '..', 'src', 'App.tsx'), 'utf8');
  const voiceSource = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  assert.match(appSource, /screenMaxBitrateMbps: 12/);
  assert.match(appSource, /max="30"/);
  assert.match(appSource, /Gaming 1080p60/);
  assert.match(voiceSource, /videoTrack\.contentHint = this\.settings\.screenContentHint/);
  assert.match(appSource, /screenContentHint: 'motion'/);
  assert.match(voiceSource, /maxBitrate: this\.settings\.screenMaxBitrateMbps \* 1000 \* 1000/);
});


test('screen share start flow exposes quality options before opening picker', () => {
  const appSource = readFileSync(join(testDir, '..', 'src', 'App.tsx'), 'utf8');
  assert.match(appSource, /screenShareSettingsOpen/);
  assert.match(appSource, /function ScreenShareSettingsDialog/);
  assert.match(appSource, /Bildschirm teilen vorbereiten/);
  assert.match(appSource, /onConfirm=\{startScreenShareWithCurrentSettings\}/);
  assert.match(appSource, /Auflösung[\s\S]*Bildrate[\s\S]*Codec[\s\S]*Optimierung/);
  assert.match(appSource, /Maximale Bitrate/);
  assert.match(appSource, /Teilen starten/);
});

test('strong voice isolation gate keeps speech tails instead of hard cutting syllables', () => {
  const workletSource = readFileSync(join(testDir, '..', 'src', 'audioWorklets', 'voiceGateProcessor.js'), 'utf8');
  assert.match(workletSource, /holdMs/);
  assert.match(workletSource, /holdFrames/);
  assert.match(workletSource, /this\.holdFramesRemaining/);
  assert.match(workletSource, /target = active \? 1 : this\.floor/);
  assert.match(voiceSource, /voiceGateParamsForIntensity/);
  assert.match(voiceSource, /threshold: .*intensity/);
  assert.match(voiceSource, /floor: .*intensity/);
  assert.match(voiceSource, /holdMs: .*intensity/);
  assert.match(voiceSource, /release: .*intensity/);
});


test('screen share preflight dialog uses polished Discord-like dark controls and uncluttered bitrate layout', () => {
  assert.match(appSource, /screenShareSettingsDialog/);
  assert.match(appSource, /screenShareField/);
  assert.match(appSource, /screenShareBitrateBlock/);
  assert.match(appSource, /screenShareHint/);
  assert.match(appSource, /screenShareToggleList/);
  const dialogSource = appSource.match(/function ScreenShareSettingsDialog[\s\S]*?function InlineAudioStream/)?.[0] ?? '';
  assert.doesNotMatch(dialogSource, /<label>Auflösung<select/);
  assert.match(cssSource, /\.screenShareSettingsDialog select\s*\{[^}]*background:\s*var\(--input-bg\)/s);
  assert.match(cssSource, /\.screenShareField\s*\{[^}]*display:\s*grid/s);
  assert.match(cssSource, /\.screenShareBitrateMain\s*\{[^}]*grid-template-columns:\s*minmax\(0,\s*1fr\)\s+auto/s);
  assert.match(cssSource, /\.screenShareHint\s*\{[^}]*grid-column:\s*1\s*\/\s*-1/s);
  assert.match(cssSource, /\.screenShareSettingsDialog \.primaryAction\s*\{[^}]*background:\s*var\(--accent\)/s);
});

test('user context menu exposes persistent per-user voice volume slider like Discord', () => {
  assert.match(appSource, /UserVolumeSettings/);
  assert.match(appSource, /loadUserVolumeSettings/);
  assert.match(appSource, /saveUserVolumeSettings/);
  assert.match(appSource, /userVolumeKey\(activeServerId, item\.remoteId\)/);
  assert.match(appSource, /Benutzerlautstärke/);
  assert.match(appSource, /className="userVolumeSlider"/);
  assert.match(appSource, /type="range" min=\{0\} max=\{200\}/);
  assert.match(appSource, /volume=\{userVolumes\[userVolumeKey\(activeServerId, item\.remoteId\)\] \?\? 100\}/);
  assert.match(cssSource, /\.userVolumeControl\s*\{/);
  assert.match(cssSource, /\.userVolumeSlider\s*\{/);
});


test('menus and screen share modal use defined opaque surface variables', () => {
  assert.match(cssSource, /:root\[data-theme='dark'\][\s\S]*--panel:/);
  assert.match(cssSource, /:root\[data-theme='dark'\][\s\S]*--surface:/);
  assert.match(cssSource, /:root\[data-theme='light'\][\s\S]*--panel:/);
  assert.match(cssSource, /:root\[data-theme='light'\][\s\S]*--surface:/);
  assert.match(cssSource, /\.screenShareSettingsDialog\s*\{[\s\S]*background:\s*var\(--panel\)/);
  assert.match(cssSource, /\.serverContextMenu,\s*\.adminContextMenu,\s*\.serverDropdownMenu\s*\{[\s\S]*background:\s*var\(--panel\)/);
  assert.doesNotMatch(cssSource, /background:\s*rgba\([^)]*,\s*0\.[0-8]\)/i);
});

test('screen share can request and produce system audio explicitly', () => {
  assert.match(appSource, /includeScreenAudio: true/);
  assert.match(appSource, /Systemaudio übertragen/);
  assert.match(appSource, /Im Windows-Picker muss „Audio teilen“ aktiviert sein/);
  assert.match(appSource, /includeScreenAudio/);
  assert.match(voiceSource, /this\.settings\.includeScreenAudio \? \{/);
  assert.match(voiceSource, /systemAudio:\s*'include'/);
  assert.match(voiceSource, /windowAudio:\s*'system'/);
  assert.match(voiceSource, /SCREEN_AUDIO_KIND/);
  assert.match(voiceSource, /voice\.screen\.audio\.missing/);
});

test('voice isolation exposes intensity control and maps to gate parameters', () => {
  assert.match(appSource, /voiceIsolationIntensity: 60/);
  assert.match(appSource, /Sprachfilter-Stärke/);
  assert.match(appSource, /Sanfter = weniger abgeschnitten/);
  assert.match(voiceSource, /voiceIsolationIntensity/);
  assert.match(voiceSource, /voiceGateParamsForIntensity/);
  assert.match(voiceSource, /threshold: .*intensity/);
  assert.match(voiceSource, /holdMs: .*intensity/);
  assert.match(voiceSource, /floor: .*intensity/);
  assert.match(voiceSource, /processorOptions: voiceGateParamsForIntensity/);
});


test('screen share preflight offers application window source mode but does not promise unsupported picker tabs', () => {
  assert.match(appSource, /screenSourceMode: 'window'/);
  assert.match(appSource, /Quelle/);
  assert.match(appSource, /Anwendung \/ Fenster/);
  assert.match(appSource, /War Thunder.*Randloses Fenster/s);
  assert.match(voiceSource, /displaySurface:\s*this\.settings\.screenSourceMode === 'window' \? 'window' : 'monitor'/);
  assert.match(voiceSource, /monitorTypeSurfaces:\s*this\.settings\.screenSourceMode === 'window' \? 'exclude' : 'include'/);
});

test('voice isolation is labeled simply and strong wording is gone', () => {
  assert.match(appSource, />\{tr\('Sprachisolierung'\)\}<\/option>/);
  assert.doesNotMatch(appSource, /Starke Sprachisolierung/);
});

test('live debug sender UI is removed from settings and App no longer posts live debug logs', () => {
  assert.doesNotMatch(appSource, /Live-Debug/);
  assert.doesNotMatch(appSource, /liveDebugSettings/);
  assert.doesNotMatch(appSource, /sendLiveDebug/);
  assert.doesNotMatch(appSource, /Voice\/WebRTC Logs an Hermes-Host senden/);
});

test('screen share settings do not duplicate the Systemaudio toggle', () => {
  const matches = appSource.match(/Systemaudio übertragen/g) ?? [];
  assert.equal(matches.length, 2, 'one global Audio & Video toggle and one pre-share toggle');
});

test('parity sprint exposes server logo profile password notification plugin pin reaction readstate quality external and popout features', () => {
  const app = readFileSync(join(testDir, '..', 'src', 'App.tsx'), 'utf8');
  const client = readFileSync(join(testDir, '..', 'src', 'sharkordClient.ts'), 'utf8');
  const types = readFileSync(join(testDir, '..', 'src', 'sharkordTypes.ts'), 'utf8');
  const voice = readFileSync(join(testDir, '..', 'src', 'voiceEngine.ts'), 'utf8');
  const css = readFileSync(join(testDir, '..', 'src', 'style.css'), 'utf8');

  for (const marker of ['changeServerLogo', 'changeOwnAvatar', 'changeOwnBanner', 'updateOwnProfile', 'updateOwnPassword', 'requestDesktopNotificationPermission']) {
    assert.ok(client.includes(marker), `${marker} missing in desktop client`);
  }
  for (const marker of ['getPinnedMessages', 'getMessagePageAround', 'markChannelAsRead', 'setConsumerQuality', 'getPluginCommands', 'executePluginCommand', 'executePluginAction', 'getPluginLogs', 'getPluginSettings', 'updatePluginSetting']) {
    assert.ok(client.includes(marker), `${marker} missing in desktop client`);
  }
  for (const marker of ['onReadStateUpdate', 'onReadStateDelta', 'onVoiceAddExternalStream', 'onVoiceUpdateExternalStream', 'onVoiceRemoveExternalStream', 'onPluginLog']) {
    assert.ok(client.includes(marker), `${marker} subscription missing`);
  }
  for (const marker of ['SharkordExternalStream', 'SharkordReadState', 'SharkordPluginCommand', 'SharkordPluginLog', 'SharkordPluginSetting', 'StreamQualitySetting']) {
    assert.ok(types.includes(marker), `${marker} type missing`);
  }
  for (const marker of ['Server-Logo', 'Profil', 'Avatar', 'Banner', 'Passwort ändern', 'Benachrichtigungen', 'Plugin-Befehle', 'Plugin-Logs', 'Plugin-Einstellungen', 'Angepinnte Nachrichten', 'Springen', 'Emoji auswählen', 'Ungelesen', 'Qualität', 'Externe Streams', 'Popout']) {
    assert.ok(app.includes(marker), `${marker} UI missing`);
  }
  for (const marker of ['pinnedMessagesPopover', 'emojiPickerPopover', 'unreadBadge', 'pluginLogsDialog', 'pluginSettingsDialog', 'floatingPopoutCard', 'externalStreamCard', 'notificationSettings']) {
    assert.ok(css.includes(marker), `${marker} CSS missing`);
  }
  assert.match(app, /localStorage\.setItem\([^)]*recent-emojis/);
  assert.match(app, /Notification\.requestPermission/);
  assert.match(voice, /setConsumerQuality/);
});



test('desktop has an i18n system for parity/settings strings instead of only hard-coded German labels', () => {
  const i18n = readFileSync(join(testDir, '..', 'src', 'i18n.ts'), 'utf8');
  const app = readFileSync(join(testDir, '..', 'src', 'App.tsx'), 'utf8');
  assert.match(i18n, /export function t/);
  assert.match(i18n, /export function setLocale/);
  assert.match(i18n, /sharkord-desktop:locale:v2/);
  assert.match(app, /type Locale/);
  assert.match(app, /t\('profile\.avatarBanner'\)/);
  assert.match(app, /t\('profile\.passwordChange'\)/);
  assert.match(app, /t\('parity\.pluginCommands'/);
});


test('new settings parity panels use Discord-like themed controls instead of raw browser/admin UI', () => {
  const app = readFileSync(join(testDir, '..', 'src', 'App.tsx'), 'utf8');
  const css = readFileSync(join(testDir, '..', 'src', 'style.css'), 'utf8');
  assert.match(app, /className="settingsSelect languageSelect"/);
  assert.match(app, /className="settingsControlRow themeControlRow"/);
  assert.match(app, /className="[^"]*settingsFormGrid[^"]*profileFormGrid[^"]*"/);
  assert.match(app, /className="settingsActionButton primary"/);
  assert.match(app, /className="settingsActionButton secondary"/);
  assert.match(app, /className="settingsActionButton danger"/);
  assert.match(app, /className="settingsInput"/);
  assert.match(app, /className="settingsTextarea"/);
  assert.match(app, /className="settingsColorControl"/);
  assert.match(app, /className="settingsSelect qualitySelect"/);
  assert.doesNotMatch(app, /<label>Plugin-ID<input/);
  assert.doesNotMatch(app, /<label>Remote-ID<input/);
  assert.doesNotMatch(app, /<label>Bannerfarbe<input type="color"/);
  for (const marker of ['.settingsInput', '.settingsSelect', '.settingsTextarea', '.settingsActionButton', '.parityActionCard', '.settingsControlRow', '.settingsColorControl']) {
    assert.ok(css.includes(marker), `${marker} CSS missing`);
  }
  assert.doesNotMatch(css, /background:\s*white/i);
});


test('profile editing lives only in the account footer popup, not in server settings', () => {
  const app = readFileSync(join(testDir, '..', 'src', 'App.tsx'), 'utf8');
  assert.match(app, /type SettingsTab = 'appearance' \| 'updates' \| 'audioVideo' \| 'notifications' \| 'importExport'/);
  assert.doesNotMatch(app, /type SettingsTab =[^;]*(?:'profile'|'parity')/);
  const settingsPanel = app.slice(app.indexOf('function SettingsPanel'), app.indexOf('type AdminTab'));
  assert.doesNotMatch(settingsPanel, /setSettingsTab\('profile'\)|settingsTab === 'profile'/);
  assert.match(app, /type AdminTab = 'general' \| 'roles' \| 'emojis' \| 'storage' \| 'users' \| 'security' \| 'invites' \| 'plugins' \| 'parity';/);
  assert.doesNotMatch(app, /type AdminTab =[^;]*'profile'/);
  assert.doesNotMatch(app, /function ProfileParitySettings/);
  const adminWorkbench = app.slice(app.indexOf('function AdminWorkbench'), app.indexOf('function AdminContextMenu'));
  assert.doesNotMatch(adminWorkbench, /profile:\s*tr\('Profil'\)|adminTab === 'profile'|<ProfileParitySettings/);
  assert.match(adminWorkbench, /parity:\s*tr\('Parität'\)/);
  assert.match(adminWorkbench, /adminTab === 'parity'/);
  assert.match(adminWorkbench, /<ParitySprintSettings/);
  assert.match(app, /className="accountIdentityButton"[^>]*onClick=\{onOpenOwnProfile\}/);
  assert.match(app, /function OwnProfilePopup/);
  assert.match(app, /className="ownProfileDialog ownProfilePopup"/);
});

test('own profile popup has polished modal CSS and does not clip avatar or show raw close button', () => {
  const app = readFileSync(join(testDir, '..', 'src', 'App.tsx'), 'utf8');
  const css = readFileSync(join(testDir, '..', 'src', 'style.css'), 'utf8');
  assert.match(app, /<button type="button" className="modalCloseButton" onClick=\{onClose\} aria-label=\{tr\('Schließen'\)\}>×<\/button>/);
  assert.match(app, /<div className="ownProfilePreview"/);
  assert.match(css, /\.ownProfileDialog\s*\{[^}]*width:\s*min\(980px, calc\(100vw - 32px\)\)/s);
  assert.match(css, /\.ownProfilePopup header \.modalCloseButton\s*\{[^}]*background:\s*var\(--surface\)/s);
  assert.match(css, /\.ownProfilePreview\s*\{[^}]*overflow:\s*hidden/s);
  assert.match(css, /\.ownProfilePreview \.profileSetupAvatar, \.ownProfilePreview \.ownProfileAvatar\s*\{[^}]*width:\s*80px/s);
  assert.match(css, /\.ownProfileGrid\s*\{[^}]*grid-template-columns:\s*repeat\(3, minmax\(0, 1fr\)\)/s);
  assert.match(css, /\.ownProfileGrid \.parityActionCard\s*\{[^}]*min-height:\s*100%/s);
  assert.match(css, /\.ownProfilePopup \.settingsActionButton:disabled, \.ownProfilePopup \.settingsActionButton\.primary:disabled\s*\{[^}]*color:\s*var\(--muted\)/s);
  assert.match(app, /useState\(user\?\.bannerColor \|\| '#5865f2'\)/);
  assert.match(app, /const bannerSrc = bannerPreviewUrl \|\| \(baseUrl \? fileUrl\(baseUrl, user\?\.banner\) : ''\)/);
  assert.match(app, /<div className="welcomeProfileBanner">\{bannerSrc \? <img src=\{bannerSrc\} alt="" \/> : null\}<\/div>/);
  assert.match(app, /onSaved\(\{ name: trimmedName, bio: trimmedBio, bannerColor, statusOverride: statusOverride \|\| null, statusMessage: trimmedStatusMessage \|\| null \}\)/);
  assert.match(clientSource, /updateOwnProfile\(connection:\s*SharkordConnection,\s*input:\s*\{\s*name:\s*string;\s*bannerColor:\s*string;\s*bio\?:\s*string;\s*statusOverride\?:\s*string \| null;\s*statusMessage\?:\s*string \| null\s*\}\)/);
  assert.match(app, /updateOwnProfile\(connection, \{ name: trimmedName, bio: trimmedBio, bannerColor, statusOverride: statusOverride \|\| null, statusMessage: trimmedStatusMessage \|\| null \}\)/);
  assert.match(app, /if \(input\.bannerColor !== undefined\) next\.bannerColor = input\.bannerColor/);
  assert.match(css, /\.ownProfilePreview \.welcomeProfileBanner img\s*\{[^}]*object-fit:\s*cover/s);
  assert.match(css, /\.ownProfilePreview > span\s*\{[^}]*white-space:\s*pre-wrap/s);
});


test('P0 pinned messages popover buttons are dark themed and not raw browser controls', () => {
  assert.match(cssSource, /\.pinnedMessagesPopover header button\s*,\s*\.pinnedMessageRow button\s*\{/s);
  const pinnedButtonCss = cssSource.match(/\.pinnedMessagesPopover header button\s*,\s*\.pinnedMessageRow button\s*\{[\s\S]*?\}/)?.[0] ?? '';
  assert.match(pinnedButtonCss, /background:\s*var\(--input-bg\)/);
  assert.match(pinnedButtonCss, /color:\s*var\(--text\)/);
  assert.match(pinnedButtonCss, /border:\s*0/);
  assert.match(pinnedButtonCss, /border-radius:\s*(?:7|8)px/);
  assert.doesNotMatch(pinnedButtonCss, /outset|rgb\(233,\s*233,\s*237\)|background:\s*buttonface/i);
  assert.match(cssSource, /\.pinnedMessagesPopover header button:hover\s*,\s*\.pinnedMessageRow button:hover\s*\{[\s\S]*background:\s*var\(--hover\)/s);
  assert.match(cssSource, /\.pinnedMessagesPopover\s*\{[^}]*right:\s*16px/s);
  assert.match(cssSource, /\.pinnedMessagesPopover\s*\{[^}]*width:\s*min\(420px, calc\(100% - 32px\)\)/s);
});

test('P0 desktop sends typing notifications while composing messages', () => {
  assert.match(clientSource, /export async function signalTyping\(connection: SharkordConnection, channelId: number\)/);
  assert.match(clientSource, /messages\.signalTyping\.mutate\(\{ channelId \}\)/);
  assert.match(appSource, /signalTyping/);
  assert.match(appSource, /lastTypingSignalRef/);
  assert.match(appSource, /function notifyTyping\(\)/);
  assert.match(appSource, /onChange=\{\(event\) => \{ setComposer\(event\.target\.value\); notifyTyping\(\); \}\}/);
});

test('P0 pinned messages trigger avoids native title tooltip over the open popover', () => {
  assert.match(appSource, /aria-label=\{tr\('Angepinnte Nachrichten'\)\}/);
  assert.doesNotMatch(appSource, /title="Angepinnte Nachrichten"/);
});

test('P0 removing composer attachments deletes temporary server files', () => {
  assert.match(clientSource, /export async function deleteTemporaryFile\(connection: SharkordConnection, fileId: SharkordTempFile\['id'\]\)/);
  assert.match(clientSource, /files\.deleteTemporary\.mutate\(\{ fileId: String\(fileId\) \}\)/);
  assert.match(appSource, /deleteTemporaryFile/);
  assert.match(appSource, /async function removeAttachment\(file: SharkordTempFile\)/);
  assert.match(appSource, /await deleteTemporaryFile\(connection, file\.id\)/);
  assert.doesNotMatch(appSource, /const removeAttachment = \(id: SharkordTempFile\['id'\]\) => setAttachments/);
});

test('emoji picker title owns a full grid row and cannot overlap emoji buttons', () => {
  assert.match(appSource, /className="emojiPickerTitle">\{tr\('Emoji auswählen'\)\}<\/strong>\{emojiChoices\.map/);
  assert.match(cssSource, /\.composerEmojiMenu\s*\{[^}]*grid-template-columns:\s*repeat\(5,\s*42px\)/s);
  assert.match(cssSource, /\.emojiPickerTitle\s*\{[^}]*grid-column:\s*1\s*\/\s*-1/s);
  assert.match(cssSource, /\.emojiPickerTitle\s*\{[^}]*white-space:\s*nowrap/s);
  assert.match(cssSource, /\.emojiPickerTitle\s*\{[^}]*width:\s*100%/s);
  assert.match(cssSource, /\.composerEmojiMenu button\s*\{[^}]*font-size:\s*22px/s);
});

test('server settings user delete sends the webclient-compatible wipe flag', () => {
  assert.match(clientSource, /moderateUser\([^)]*options:\s*\{\s*reason\?:\s*string;\s*wipe\?:\s*boolean\s*\}\s*=\s*\{\s*\}/s);
  assert.match(clientSource, /users\.delete\.mutate\(\{ userId, wipe:\s*!!options\.wipe \}\)/);
  assert.match(appSource, /if \(action === 'delete'\) \{[^]*const wipe = window\.confirm\([^]*Daten dieses Benutzers[^]*moderateUser\(connection, action, user\.id, \{ wipe \}\)/s);
  assert.doesNotMatch(appSource, /moderateUser\(connection, action, user\.id, prompt\('Grund optional'\) \|\| undefined\)/);
});

test('users admin and member context menus never target Sharkord deleted-user placeholder', () => {
  assert.match(clientSource, /DELETED_USER_IDENTITY_AND_NAME\s*=\s*'__deleted_user__'/);
  assert.match(clientSource, /function isDeletedUserPlaceholder/);
  assert.match(clientSource, /getAdminUsers[\s\S]*filter\(\(user\) => !isDeletedUserPlaceholder\(user\)\)/);
  assert.match(appSource, /sortedUsers[\s\S]*filter\(\(user\) => !isDeletedUserPlaceholder\(user\)\)/);
  assert.match(appSource, /openUserMenu[\s\S]*isDeletedUserPlaceholder\(user\)[\s\S]*return/);
  assert.match(appSource, /moderateAdminUser[\s\S]*isDeletedUserPlaceholder\(user\)[\s\S]*return/);
  assert.match(appSource, /filteredAdminUsers[\s\S]*!isDeletedUserPlaceholder\(user\)/);
});

test('users admin panel has dedicated compact themed CSS instead of cramped generic list styling', () => {
  assert.match(appSource, /className="adminList adminUsersList"/);
  assert.match(appSource, /className="adminListRow adminUserRow"/);
  assert.match(appSource, /className="adminRowActions adminUserActions"/);
  assert.match(appSource, /className="adminUserRoles"/);
  assert.match(cssSource, /\.adminUsersList,\s*\n\.adminSearch \+ \.adminUsersList\s*\{[^}]*max-height:\s*none/s);
  assert.match(cssSource, /\.adminUsersList,\s*\n\.adminSearch \+ \.adminUsersList\s*\{[^}]*overflow:\s*visible/s);
  assert.match(cssSource, /\.adminUserRow\s*\{[^}]*display:\s*grid/s);
  assert.match(cssSource, /\.adminUserRow\s*\{[^}]*grid-template-columns:\s*minmax\(0,1fr\)/s);
  assert.doesNotMatch(cssSource, /\.adminUserRow\s*\{[^}]*grid-template-columns:\s*minmax\(0,1fr\)\s+minmax\(240px,auto\)/s);
  assert.match(cssSource, /\.adminUserRow\s*\{[^}]*overflow:\s*visible/s);
  assert.match(cssSource, /\.adminUserMain\s*\{[^}]*min-width:\s*0/s);
  assert.match(cssSource, /\.adminUserActions\s*\{[^}]*display:\s*grid/s);
  assert.match(cssSource, /\.adminUserActions\s*\{[^}]*grid-template-columns:\s*repeat\(3,minmax\(68px,1fr\)\)/s);
  assert.match(cssSource, /\.adminUserActions\s*\{[^}]*justify-self:\s*end/s);
  assert.match(cssSource, /\.adminUserActions\s*\{[^}]*max-width:\s*280px/s);
  assert.match(cssSource, /\.adminUserActions button\s*\{[^}]*min-width:\s*0/s);
  assert.match(cssSource, /\.adminRowMain\s*>\s*strong\s*\{/);
  assert.match(cssSource, /\.adminUserRoles\s*\{[^}]*grid-template-columns:\s*auto\s+minmax\(0,1fr\)/s);
  assert.match(cssSource, /\.adminUserRoles\s*\{[^}]*overflow:\s*visible/s);
  assert.match(cssSource, /\.adminUserMain \.roleChipWrap\s*\{[^}]*display:\s*flex/s);
  assert.match(cssSource, /\.adminUserMain \.roleChipWrap\s*\{[^}]*flex-wrap:\s*wrap/s);
  assert.match(cssSource, /\.adminUserMain \.roleChipWrap\s*\{[^}]*overflow:\s*visible/s);
  assert.match(cssSource, /\.adminUserMain \.roleChip\s*\{[^}]*min-height:\s*28px/s);
  assert.match(cssSource, /\.adminUserMain \.roleChip\s*\{[^}]*flex:\s*0\s+0\s+auto/s);
});

test('users admin list keeps rows max-content height so wrapped role chips and actions do not get vertically clipped', () => {
  assert.match(cssSource, /\.adminUsersList,\s*\n\.adminSearch \+ \.adminUsersList\s*\{[^}]*grid-auto-rows:\s*max-content/s);
  assert.match(cssSource, /\.adminUsersList,\s*\n\.adminSearch \+ \.adminUsersList\s*\{[^}]*align-items:\s*start/s);
});

test('server settings general checkboxes stay inline and english password phrase translates atomically', () => {
  assert.match(appSource, /onlyAskForPasswordOnFirstJoin/s);
  assert.match(appSource, /tr\('Nur beim ersten Beitritt nach Passwort fragen'\)/);
  assert.match(cssSource, /\.adminSettingsGroup \.checkboxRow\s*\{[^}]*display:\s*grid/s);
  assert.match(cssSource, /\.adminSettingsGroup \.checkboxRow\s*\{[^}]*grid-template-columns:\s*auto\s+minmax\(0,1fr\)/s);
  assert.match(cssSource, /\.adminSettingsGroup \.checkboxRow input\s*\{[^}]*width:\s*16px/s);
  const fullPhraseIndex = i18nSource.indexOf("[/Nur beim ersten Beitritt nach Passwort fragen/g, 'Ask for password only on first join']");
  const genericPasswordIndex = i18nSource.indexOf("[/Passwort/g, 'Password']");
  assert.ok(fullPhraseIndex >= 0, 'missing full first-join password phrase translation');
  assert.ok(genericPasswordIndex >= 0, 'missing generic password translation');
  assert.ok(fullPhraseIndex < genericPasswordIndex, 'full first-join phrase must translate before generic Passwort -> Password replacement');
  assert.doesNotMatch(i18nSource, /Nur beim ersten Beitritt nach Password fragen/);
});

test('server settings and role checkbox edits are not reset by parent rerenders', () => {
  assert.match(appSource, /const syncLiveUsersFromAdminRows = useCallback\(\(nextUsers: SharkordUser\[\]\) => \{/);
  const adminWorkbenchCall = appSource.match(/<AdminWorkbench[\s\S]*?realtimeEvent=\{adminRealtimeEvent\} \/>/)?.[0] ?? '';
  assert.ok(adminWorkbenchCall, 'AdminWorkbench call not found');
  assert.match(adminWorkbenchCall, /onUsersChanged=\{syncLiveUsersFromAdminRows\}/);

  const adminWorkbenchSource = appSource.match(/function AdminWorkbench[\s\S]*?function AdminUserInfoModal/)?.[0] ?? '';
  assert.match(adminWorkbenchSource, /updateServerSettings\(\{ onlyAskForPasswordOnFirstJoin: event\.target\.checked \}\)/);
  assert.match(adminWorkbenchSource, /patchRole\(role, \{ storageQuotaOverrideEnabled: event\.target\.checked \}\)/);
  assert.match(adminWorkbenchSource, /patchRole\(role, \{ mentionable: event\.target\.checked \}\)/);
  assert.match(adminWorkbenchSource, /toggleRolePermission\(role, permission\)/);
});

test('server admin screenshots contain no German fallback leaks in English locale', () => {
  const adminWorkbench = appSource.slice(appSource.indexOf('function AdminWorkbench'), appSource.indexOf('function AdminContextMenu'));
  const parityPanel = appSource.slice(appSource.indexOf('function ParitySprintSettings'), appSource.indexOf('function ExportUserDataConfirmDialog'));
  for (const phrase of [
    'Aktuell:',
    'Beschreibung',
    'Server-Passwort',
    'Nur beim ersten Beitritt nach Passwort fragen',
    'Willkommensdialog anzeigen',
    'Aktion bei vollem Speicher',
    'Neue Uploads verhindern',
    'Alte Dateien löschen',
    'Signierte URLs aktivieren',
    'Ablauf signierter URLs',
    'Minuten',
    'Stunden',
    'Bildoptimierung aktivieren',
    'Bildqualität',
    'Als Standard',
    'Popout-Architektur nutzt native Stream-Popout-Fenster und Floating-Popout statt Browser-window.open.',
    'Wert'
  ]) {
    assert.ok(i18nSource.includes(phrase), `i18n missing German source phrase: ${phrase}`);
  }
  for (const english of [
    'Current:',
    'Description',
    'Server password',
    'Ask for password only on first join',
    'Show welcome dialog',
    'Action when storage is full',
    'Prevent new uploads',
    'Delete old files',
    'Enable signed URLs',
    'Signed URL TTL',
    'minutes',
    'hours',
    'Enable image optimization',
    'Image quality',
    'Set as default',
    'Popout architecture uses native stream popout windows and floating popouts instead of browser window.open.',
    'Value'
  ]) {
    assert.ok(i18nSource.includes(english), `i18n missing English phrase: ${english}`);
  }
  for (const bareGerman of [
    />Willkommensdialog anzeigen</,
    />Aktion bei vollem Speicher</,
    />Neue Uploads verhindern</,
    />Alte Dateien löschen</,
    />Signierte URLs aktivieren</,
    />Bildoptimierung aktivieren</,
    />Als Standard</,
    />Marketplace leer oder nicht erreichbar\.</
  ]) {
    assert.doesNotMatch(adminWorkbench, bareGerman);
  }
  assert.doesNotMatch(parityPanel, />Popout-Architektur nutzt native/);
  assert.match(parityPanel, /tr\('Popout-Architektur nutzt native Stream-Popout-Fenster und Floating-Popout statt Browser-window\.open\.'\)/);
  assert.match(appSource, /tr\(`Aktuell:/);
  assert.match(appSource, /tr\('Willkommensdialog anzeigen'\)/);
  assert.match(appSource, /tr\('Aktion bei vollem Speicher'\)/);
  assert.match(appSource, /tr\('Als Standard'\)/);
});

test('admin modal scrollbars remain themed and constrained inside viewport', () => {
  assert.match(cssSource, /\.adminWorkbenchModal\s*\{[^}]*box-sizing:\s*border-box/s);
  assert.match(cssSource, /\.adminWorkbenchModal\s*\{[^}]*overflow-x:\s*hidden/s);
  assert.match(cssSource, /\.adminWorkbenchModal\s*\{[^}]*scrollbar-width:\s*thin/s);
  assert.match(cssSource, /\.adminWorkbenchModal\s*\{[^}]*scrollbar-color:/s);
  assert.match(cssSource, /\.adminWorkbenchModal::\-webkit-scrollbar\s*\{/);
  assert.match(cssSource, /\.adminListRow\s*\{[^}]*min-width:\s*0/s);
});

test('settings scrollbars and audio range helper copy stay dark and aligned', () => {
  assert.match(cssSource, /\.settingsPanel\.discordSettings\s*\{[^}]*scrollbar-width:\s*thin/s);
  assert.match(cssSource, /\.settingsPanel\.discordSettings\s*\{[^}]*scrollbar-color:\s*#3f4650 transparent/s);
  assert.match(cssSource, /\.settingsPanel\.discordSettings::\-webkit-scrollbar-thumb\s*\{[^}]*background:\s*#3f4650/s);
  assert.match(cssSource, /\.rangeRow small\s*\{[^}]*grid-column:\s*1\s*\/\s*-1/s);
  assert.match(cssSource, /\.audioVideoSettings \.rangeRow input\[type='range'\]\s*\{[^}]*width:\s*100%/s);
  assert.match(appSource, /className="rangeRow voiceIsolationIntensityRow"/);
});

test('right member context menu clamps to the viewport instead of clipping offscreen', () => {
  assert.match(appSource, /const contextMenuWidth = menu\.kind === 'user' \? 300 : 240/);
  assert.match(appSource, /Math\.min\(menu\.x, window\.innerWidth - contextMenuWidth - contextMenuMargin\)/);
  assert.match(appSource, /maxHeight:\s*'calc\(100vh - 24px\)'/);
  assert.match(appSource, /overflowY:\s*'auto'/);
  assert.doesNotMatch(appSource, /const style = \{ left: menu\.x, top: menu\.y \}/);
});

test('left-clicking users opens a separate profile popover without replacing right-click admin menus', () => {
  assert.match(appSource, /type UserProfilePopoverState = \{ x: number; y: number; user: SharkordUser; serverId\?: string \} \| null/);
  assert.match(appSource, /const \[userProfilePopover, setUserProfilePopover\] = useState<UserProfilePopoverState>\(null\)/);
  assert.match(appSource, /function openUserProfilePopover\(event: React\.MouseEvent, user: SharkordUser, serverId = activeServer\?\.id\)/);
  assert.match(appSource, /setUserProfilePopover\(\{ x: event\.clientX, y: event\.clientY, user, serverId \}\)/);
  assert.match(appSource, /setContextMenu\(null\)/);
  assert.match(appSource, /<UserProfilePopover popover=\{userProfilePopover\}/);
  assert.match(appSource, /onUserProfile=\{openUserProfilePopover\}/);
  assert.match(appSource, /onClick=\{\(event\) => onUserProfile\(event, user\)\}/);
  assert.match(appSource, /onContextMenu=\{\(event\) => onUserMenu\(event, user\)\}/);
  assert.match(appSource, /onClick=\{\(event\) => authorUser \? onUserProfile\(event, authorUser\) : undefined\}/);
  assert.match(appSource, /function VoiceUserCard\(\{[^}]*onUserProfile/);
  assert.match(appSource, /<VoiceUserCard[^>]+onUserProfile=\{onUserProfile\}/);
  assert.match(appSource, /className=\{`voiceUserCard[^`]+`\} onClick=\{\(event\) => onUserProfile\(event, user\)\} onContextMenu=\{\(event\) => onUserMenu\(event, user\)\}/);
  assert.match(appSource, /function UserProfilePopover\(/);
  assert.match(appSource, /const profilePopoverWidth = 320/);
  assert.match(appSource, /Math\.min\(popover\.x, window\.innerWidth - profilePopoverWidth - profilePopoverMargin\)/);
  assert.match(appSource, /AvatarView user=\{user\}/);
  assert.match(appSource, /user\.bannerColor \|\| '#5865f2'/);
  assert.match(appSource, /user\.bio \|\| t\('profile\.popover\.noBio'\)/);
  assert.match(cssSource, /\.userProfilePopoverBackdrop/);
  assert.match(cssSource, /\.userProfilePopover\s*\{/);
  assert.match(cssSource, /\.userProfileBanner/);
  assert.match(cssSource, /\.userProfileBio/);
});

test('english locale routes common settings and admin labels through phrase translations', () => {
  assert.match(i18nSource, /export function tr\(/);
  for (const phrase of ['Darstellung', 'Prüfen', 'Inplace installieren', 'Geräte aktualisieren', 'Wiedergabe', 'Mikrofon', 'Sprachfilter', 'Test starten', 'Server-Logo Upload', 'Nutzerdaten einschließen', 'Server-Einstellungen', 'Löschen', 'Benutzerlautstärke', 'Noch kein Server hinterlegt. Füge deinen eigenen Sharkord-Server hinzu und speichere optional Credentials für Auto-Connect.', 'Server hinzufügen', 'Sharkord-Server hinzufügen']) {
    assert.match(appSource, new RegExp(`tr\\('${phrase.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&')}`));
  }
  for (const english of ['Appearance', 'Check', 'Install in place', 'Refresh devices', 'Playback', 'Microphone', 'Voice filter', 'Start test', 'Upload server logo', 'Include user data', 'Server settings', 'Delete', 'User volume', 'No server saved yet', 'Add server', 'Add Sharkord server']) {
    assert.match(i18nSource, new RegExp(english.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&')));
  }
});


test('english locale fallback does not recursively translate Profile text', () => {
  assert.match(i18nSource, /Profil bearbeiten/g);
  assert.match(i18nSource, /Profil-Setup übersprungen/g);
  assert.match(i18nSource, /\[\/\\bProfil\\b\/g, 'Profile'\]/);
  assert.doesNotMatch(i18nSource, /\[\/Profil\/g, 'Profile'\]/);
});

test('english locale applies a visible phrase translation safety net to unwrapped UI chrome', () => {
  assert.match(appSource, /installVisiblePhraseTranslator/);
  assert.match(appSource, /translateVisiblePhrases/);
  assert.match(i18nSource, /export function translateVisiblePhrases/);
  assert.match(i18nSource, /export function installVisiblePhraseTranslator/);
  assert.match(i18nSource, /MutationObserver/);
  assert.match(i18nSource, /SHOW_TEXT/);
  assert.match(i18nSource, /aria-label/);
  assert.match(i18nSource, /requestAnimationFrame/);
  assert.match(i18nSource, /mutation\.addedNodes\.forEach\(schedule\)/);
  assert.doesNotMatch(i18nSource, /queueMicrotask\(run\)/);
  assert.doesNotMatch(i18nSource, /characterData:\s*true/);
  assert.doesNotMatch(i18nSource, /new MutationObserver\(schedule\)/);
  for (const [german, english] of [
    ['Mit Sharkord verbinden', 'Connect to Sharkord'],
    ['Nicht verbunden', 'Not connected'],
    ['Voice getrennt', 'Voice disconnected'],
    ['Willkommen bei Sharkord Desktop', 'Welcome to Sharkord Desktop'],
    ['Passwort', 'Password'],
    ['Server-Passwort optional', 'Optional server password'],
    ['Einstellungen', 'Settings'],
    ['Server löschen', 'Delete server'],
    ['State konnte nicht gespeichert werden:', 'State could not be saved:']
  ]) {
    assert.match(i18nSource, new RegExp(german.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
    assert.match(i18nSource, new RegExp(english.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  }
});

test('auto-connect has an in-flight guard so startup effects cannot double-login the same server', () => {
  assert.match(appSource, /connectingServerIdsRef/);
  assert.match(appSource, /connectionsRef\.current\.has\(server\.id\) \|\| connectingServerIdsRef\.current\.has\(server\.id\)/);
  assert.match(appSource, /connectingServerIdsRef\.current\.add\(server\.id\)/);
  assert.match(appSource, /connectingServerIdsRef\.current\.delete\(server\.id\)/);
  assert.match(appSource, /Verbindung läuft bereits/);
});


test('category drag and drop carries drag data and shows a real drop target', () => {
  assert.match(appSource, /onCategoryDragStart:\s*\(event: React\.DragEvent, group: ChannelGroup\) => void/);
  assert.match(appSource, /event\.dataTransfer\.setData\('application\/x-sharkord-category-id', String\(group\.id\)\)/);
  assert.match(appSource, /event\.dataTransfer\.effectAllowed = 'move'/);
  assert.match(appSource, /setDragOverCategoryId\(group\.id\)/);
  assert.match(appSource, /aria-label=\{tr\('Kategorie verschieben'\)\}/);
  assert.match(cssSource, /\.categoryDragHandle/);
  assert.match(cssSource, /\.channelGroupTitle\.dragOver::after/);
});

test('english locale covers dynamic German status and native dialog phrases', () => {
  assert.match(i18nSource, /const STORAGE_KEY = 'sharkord-desktop:locale:v2'/);
  assert.match(i18nSource, /return stored === 'en' \|\| stored === 'de' \? stored : 'en'/);
  assert.match(i18nSource, /catch \{\s*return 'en';\s*\}/);
  assert.match(i18nSource, /fallbackEnReplacements/);
  for (const [german, english] of [
    ['wirklich entfernen', 'Really remove server'],
    ['wirklich löschen', 'Really delete file'],
    ['Daten dieses Benutzers endgültig löschen', 'Permanently delete this user'],
    ['Voice-Join blockiert: Server hält noch eine alte Voice-Session', 'Voice join blocked'],
    ['werden hochgeladen', 'file(s) uploading'],
    ['angepinnte Nachricht', 'pinned message(s)'],
    ['Callmember sind ausgeblendet', 'Call members are hidden'],
    ['Sharkord Einstellungen exportieren', 'Export Sharkord settings'],
    ['JSON-Dateien', 'JSON files'],
    ['Mein Sharkord', 'My Sharkord'],
    ['Simulcast ist auf diesem Server deaktiviert', 'Simulcast is disabled on this server.'],
    ['Diese Screen-Sharing-Einstellungen sind best effort', 'These screen-sharing settings are best effort'],
    ['Import ersetzt die lokale Serverliste und globale Einstellungen', 'Import replaces the local server list and global settings.'],
    ['Geräteliste aktualisiert', 'Device list updated'],
    ['Geräte aktualisiert', 'Devices refreshed'],
    ['Mediengeräte automatisch erkennen', 'Detect media devices automatically'],
    ['Verbindung läuft bereits', 'Connection already in progress'],
    ['Kategorie erstellen', 'Create category'],
    ['Stream-Producer werden gesucht', 'Searching stream producers'],
    ['Popout schließen', 'Close popout'],
    ['Server wirklich entfernen', 'Really remove server'],
    ['Server entfernen', 'Remove server'],
    ['wird aus dieser Desktop-App entfernt. Der Server selbst und seine Daten bleiben online.', 'will be removed from this desktop app. The server itself and its data stay online.']
  ]) {
    assert.ok(i18nSource.includes(german), `missing German source phrase: ${german}`);
    assert.ok(i18nSource.includes(english), `missing English phrase: ${english}`);
  }
  for (const appPattern of [
    /function ConfirmServerRemovalDialog/,
    /window\.confirm\(tr\(`Datei/,
    /Title:\s*tr\('Sharkord Einstellungen exportieren'\)/,
    /ButtonText:\s*tr\('Exportieren'\)/,
    /<option value="de">\{locale === 'en' \? 'German' : 'Deutsch'\}<\/option>/,
    /placeholder=\{tr\('Mein Sharkord'\)\}/,
    /tr\('Import ersetzt die lokale Serverliste und globale Einstellungen\. Enthaltene Nutzerdaten\/Zugangsdaten/,
    /toLocaleString\(getLocale\(\) === 'en' \? 'en-US' : 'de-DE'/,
    /toLocaleDateString\(getLocale\(\) === 'en' \? 'en-US' : 'de-DE'/
  ]) assert.match(appSource, appPattern);
});

test('reported English locale profile dm and search chrome come from i18n keys', () => {
  for (const key of [
    'profile.popover.memberSince',
    'profile.popover.sendMessage',
    'profile.popover.manageUser',
    'profile.popover.noBio',
    'profile.edit.title',
    'profile.edit.description',
    'dm.sidebar.title',
    'dm.sidebar.center',
    'dm.sidebar.searchPlaceholder',
    'search.global.title',
    'search.global.description'
  ]) assert.match(i18nSource, new RegExp(`'${key}'`));
  for (const english of [
    'Member since',
    'Send message',
    'Manage users',
    'No bio set',
    'Edit profile',
    'Change name, bio, avatar, banner and password.',
    'Direct messages',
    'DM center',
    'Search user or start DM',
    'Global search',
    'Search messages and files server-wide'
  ]) assert.match(i18nSource, new RegExp(english.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  for (const hardcoded of ['Globale Suche', 'DM-Zentrale', 'Mitglied seit', 'Nachricht senden', 'Benutzer verwalten', 'Keine Bio gesetzt', 'Name, Bio, Avatar, Banner und Passwort ändern.', 'User suchen oder DM starten']) {
    const escaped = hardcoded.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    assert.doesNotMatch(appSource, new RegExp(`\\b(?:tr|t)\\(['\"\`]${escaped}`));
  }
});

test('rich text composer sends on Enter and inserts newline only with Shift Enter', () => {
  assert.match(appSource, /event\.key === 'Enter'/);
  assert.match(appSource, /!event\.shiftKey/);
  assert.match(appSource, /event\.preventDefault\(\)/);
  assert.match(appSource, /event\.currentTarget\.closest\('form'\)\?\.requestSubmit\(\)/);
  assert.match(appSource, /aria-multiline="true"/);
});

test('channel permission override types model role and user targets', () => {
  assert.match(typesSource, /export type ChannelPermissionTarget\s*=\s*'role'\s*\|\s*'user'/);
  assert.match(typesSource, /export type ChannelPermissionOverride\s*=\s*\{/);
  assert.match(typesSource, /targetType:\s*ChannelPermissionTarget/);
  assert.match(typesSource, /targetId:\s*number/);
  assert.match(typesSource, /allow:\s*string\[\]/);
  assert.match(typesSource, /deny:\s*string\[\]/);
});

test('channel permission override client wrappers call the expected trpc channel paths', () => {
  assert.match(clientSource, /getChannelPermissions\(connection:\s*SharkordConnection,\s*channelId:\s*number\)/);
  assert.match(clientSource, /connection\.trpc\.channels\.getPermissions\.mutate\(\{\s*channelId\s*\}\)/);
  assert.doesNotMatch(clientSource, /connection\.trpc\.channels\.getPermissions\.query\(\{\s*channelId\s*\}\)/);
  assert.match(clientSource, /if \(isMissingTrpcProcedureError\(error, 'channels\.getPermissions'\)\) return \[\]/);
  assert.match(clientSource, /updateChannelPermissions\(connection:\s*SharkordConnection,\s*channelId:\s*number,\s*targetType:\s*ChannelPermissionTarget,\s*targetId:\s*number,\s*allow:\s*string\[\],\s*deny:\s*string\[\]\)/);
  assert.match(clientSource, /const targetPayload = channelPermissionTargetPayload\(targetType, targetId\);/);
  assert.match(clientSource, /connection\.trpc\.channels\.updatePermissions\.mutate\(\{\s*channelId,\s*\.\.\.targetPayload,\s*permissions:\s*normalizeChannelPermissionNames\(allow\)\s*\}\)/);
  assert.match(clientSource, /if \(isMissingTrpcProcedureError\(error, 'channels\.updatePermissions'\)\) throw new Error\(tr\('Server unterstützt Channel-Berechtigungs-Overrides noch nicht\.'\)\)/);
  assert.match(clientSource, /deleteChannelPermissions\(connection:\s*SharkordConnection,\s*channelId:\s*number,\s*targetType:\s*ChannelPermissionTarget,\s*targetId:\s*number\)/);
  assert.match(clientSource, /connection\.trpc\.channels\.deletePermissions\.mutate\(\{\s*channelId,\s*\.\.\.targetPayload\s*\}\)/);
  assert.match(clientSource, /if \(isMissingTrpcProcedureError\(error, 'channels\.deletePermissions'\)\) throw new Error\(tr\('Server unterstützt Channel-Berechtigungs-Overrides noch nicht\.'\)\)/);
  assert.match(clientSource, /tr\('Channel-Berechtigungen laden fehlgeschlagen'\)/);
  assert.match(clientSource, /tr\('Channel-Berechtigungen speichern fehlgeschlagen'\)/);
  assert.match(clientSource, /tr\('Channel-Berechtigungen löschen fehlgeschlagen'\)/);
});

test('channel settings modal replaces prompt-only edit with general and permission tabs', () => {
  assert.match(appSource, /ChannelSettingsModal/);
  assert.match(appSource, /channelSettingsModal/);
  assert.match(appSource, /channelPermissionsTab/);
  assert.match(appSource, /permissionOverrideGrid/);
  assert.match(appSource, /permissionTriState/);
  assert.match(appSource, /data-permission-state=\{permissionState/);
  assert.match(appSource, /data-target-type=\{selectedTarget\.targetType\}/);
  assert.match(appSource, /MANAGE_CHANNEL_PERMISSIONS/);
  assert.match(appSource, /MANAGE_CHANNELS/);
  assert.match(appSource, /ADMINISTRATOR/);
  assert.match(appSource, /public channels.*default role.*SEND_MESSAGES|öffentlichen Channels.*Default-Rolle.*SEND_MESSAGES/i);
  assert.match(cssSource, /\.channelSettingsModal\b/);
  assert.match(cssSource, /\.channelSettingsModal\s*\{[^}]*grid-template-rows:\s*auto auto minmax\(0,1fr\) auto/s);
  assert.match(cssSource, /\.channelPermissionsTab\s*\{[^}]*grid-template-columns:\s*260px minmax\(0,1fr\)/s);
  assert.match(cssSource, /\.permissionEditorPanel\s*\{[^}]*scrollbar-gutter:\s*stable/s);
  assert.match(cssSource, /\.permissionTriState button\.active\s*\{[^}]*background:\s*var\(--accent\)/s);
  assert.match(cssSource, /\.channelSettingsModal \.contextActionStatus\s*\{[^}]*overflow-wrap:\s*anywhere/s);
  assert.match(cssSource, /\.channelPermissionsTab\b/);
  assert.match(cssSource, /\.permissionOverrideGrid\b/);
  const editContextChannel = appSource.match(/function editContextChannel[\s\S]*?\n  \}/)?.[0] ?? '';
  assert.match(editContextChannel, /setChannelSettingsOpen\(/);
  assert.doesNotMatch(editContextChannel, /prompt\(/);
});

test('threads and replies have API parity with parentMessageId without breaking legacy send callers', () => {
  assert.match(typesSource, /parentMessageId\?:\s*number/);
  assert.match(typesSource, /parentMessage\?:\s*SharkordMessage/);
  assert.match(clientSource, /export async function getThreadMessages\(/);
  assert.match(clientSource, /getChannelMessages\([^)]*parentMessageId/);
  assert.match(clientSource, /messages\.get\.query\(\{[^}]*parentMessageId/s);
  assert.match(clientSource, /sendChannelMessage\([^)]*files:\s*SharkordTempFile\[\]\s*=\s*\[\][^)]*options/s);
  assert.match(clientSource, /parentMessageId:\s*options\.parentMessageId/);
  assert.match(clientSource, /signalTyping\([^)]*parentMessageId/);
  assert.match(clientSource, /signalTyping\.mutate\(\{[^}]*parentMessageId/s);
  assert.match(appSource, /threadPanel/);
  assert.match(appSource, /replyTarget/);
  assert.match(appSource, /onReply=\{setReplyTarget\}/);
  assert.match(appSource, /onOpenThread=\{openThreadPanel\}/);
  assert.match(appSource, /sendChannelMessage\(conn, targetChannelId, text, files, \{ parentMessageId: replyTarget\?\.id \}\)/);
});

test('reply submits target the message channel instead of the currently selected chat', () => {
  assert.match(appSource, /const targetChannelId = replyTarget\?\.channelId \?\? selectedChannelId/);
  assert.match(appSource, /sendChannelMessage\(conn, targetChannelId, text, files, \{ parentMessageId: replyTarget\?\.id \}\)/);
  assert.match(appSource, /await loadMessages\(conn, targetChannelId\)/);
  assert.match(appSource, /getThreadMessages\(ctx\.conn, parent\.channelId, parent\.id, 50\)/);
  assert.match(appSource, /sendChannelMessage\(ctx\.conn, parent\.channelId, plainText\.trim\(\), files, \{ parentMessageId: parent\.id \}\)/);
  assert.doesNotMatch(appSource, /sendChannelMessage\(connection, selectedChannelId, text, files, \{ parentMessageId: replyTarget\?\.id \}\)/);
});

test('unread counts trust server read-state events and do not double increment on message events', () => {
  const subscriptionBlock = appSource.match(/function wireSubscriptions[\s\S]*?\n  \}/)?.[0] ?? '';
  const newMessageHandler = subscriptionBlock.match(/onMessageNew:\s*\(message\) => \{[\s\S]*?\},\n\s*onMessageUpdate/)?.[0] ?? '';
  assert.match(subscriptionBlock, /onReadStateDelta/);
  assert.match(subscriptionBlock, /onReadStateUpdate/);
  assert.match(newMessageHandler, /setMessagesForEvent\(message, 'new', serverId\)/);
  assert.doesNotMatch(newMessageHandler, /setReadStates/);
});

test('DM conversation hiding opens an in-app confirmation before calling the real route', () => {
  const requestDeleteBlock = appSource.match(/function deleteDirectMessageConversation[\s\S]*?async function confirmDeleteDirectMessageConversation/)?.[0] ?? '';
  const confirmDeleteBlock = appSource.match(/async function confirmDeleteDirectMessageConversation[\s\S]*?\n  \}/)?.[0] ?? '';
  const dmSidebarRender = appSource.match(/<DirectMessagesSidebar[\s\S]*?status=\{status\} \/>/)?.[0] ?? '';
  assert.match(appSource, /pendingDirectMessageDelete/);
  assert.match(appSource, /function ConfirmDirectMessageDeleteDialog/);
  assert.match(appSource, /<ConfirmDirectMessageDeleteDialog entry=\{pendingDirectMessageDelete\}/);
  assert.match(requestDeleteBlock, /setPendingDirectMessageDelete\(entry\)/);
  assert.doesNotMatch(requestDeleteBlock, /window\.confirm/);
  assert.match(confirmDeleteBlock, /hideDirectMessage\(entry\.connection, entry\.channel\.id\)/);
  assert.match(confirmDeleteBlock, /setDirectMessagesByServer/);
  assert.match(dmSidebarRender, /onDelete=\{\(entry\) => void deleteDirectMessageConversation\(entry\)\}/);
});

test('voice participant drag/drop is enabled only behind Kanuracer voiceUserMove capability', () => {
  assert.doesNotMatch(appSource, /function hasDragType\(event: React\.DragEvent, type: string\)/);
  assert.doesNotMatch(appSource, /readDraggedVoiceMember\(event\?\.dataTransfer\)/);
  assert.doesNotMatch(appSource, /onVoiceMemberDrop:\s*\(channel: SharkordChannel, event\?: React\.DragEvent\) => void/);
  assert.doesNotMatch(appSource, /onVoiceMemberDrop\(channel, event\)/);
  assert.match(appSource, /className="voiceUserList"/);
  assert.match(appSource, /voiceUserMoveEnabled=\{!!connection\?\.serverCapabilities\.voiceUserMove\}/);
  assert.match(appSource, /application\/x-sharkord-voice-user-id/);
  assert.doesNotMatch(appSource, /application\/x-sharkord-voice-source-channel-id/);
});

test('chat UI exposes thread panel, reply controls, and rich composer affordances', () => {
  assert.match(appSource, /function ThreadPanel\(/);
  assert.match(appSource, /className="threadPanel"/);
  assert.match(appSource, /className="replyPreview"/);
  assert.match(appSource, /message\.replyCount/);
  assert.match(appSource, /title=\{tr\('Antworten'\)\}/);
  assert.match(appSource, /title=\{tr\('Thread öffnen'\)\}/);
  assert.match(appSource, /contentEditable/);
  assert.match(appSource, /richComposerToolbar/);
  assert.match(appSource, /formatComposer\('bold'\)/);
  assert.match(appSource, /formatComposer\('italic'\)/);
  assert.match(appSource, /formatComposer\('code'\)/);
  assert.match(appSource, /pluginCommandMenu/);
  assert.match(appSource, /event\.key === 'ArrowUp'/);
  assert.match(appSource, /lastOwnMessage/);
  assert.match(appSource, /setComposer\(textFromHtml\(lastOwnMessage\.content\)\)/);
});

test('source files contain no unwrapped German display strings outside i18n helpers', () => {
  const files = [];
  const visit = (dir) => {
    for (const name of readdirSync(dir)) {
      const path = join(dir, name);
      const stat = statSync(path);
      if (stat.isDirectory()) visit(path);
      else if (/\.(?:ts|tsx|js|jsx)$/.test(name) && name !== 'i18n.ts') files.push(path);
    }
  };
  visit(join(testDir, '..', 'src'));
  for (const name of readdirSync(projectRoot)) if (/\.go$/.test(name) && !/_test\.go$/.test(name)) files.push(join(projectRoot, name));

  const germanDisplayPattern = /[ÄÖÜäöüß]|\b(?:Abbrechen|Abgelaufen|Aktiv|Aktuelles|Alle|Anfang|Anhang|Angepinnte|Anwendung|Auflösung|Ausführen|Bearbeiten|Bereit|Benachrichtigungen|Benutzer|Beitreten|Bildschirm|Callmember|Darstellung|Datei|Dateien|Direktnachrichten|Einstellungen|Entfernen|Erstellen|Fehler|Fortfahren|Freigabe|Gerät|Geräte|Hinzufügen|Kamera|Kategorie|Kein|Keine|Kopieren|Lade|Löschen|Mikrofon|Nachricht|Nachrichten|Nicht|Nutzerdaten|Passwort|Profil|Prüfen|Rolle|Rollen|Speicher|Speichern|Sprache|Sprach|Stumm|Suche|Suchen|Teilen|Teilnehmer|Trennen|Ungelesen|Unbekannt|Verbinden|Verbunden|Verlassen|Willkommen|Wirklich|Zugangsdaten|Änderung|Änderungen|Öffnen|Übertrage|abgebrochen|aktivieren|ausblenden|beendet|bearbeitet|einschalten|einklappen|fehlgeschlagen|fehlt|geladen|gespeichert|gelöscht|hochgeladen|konnte|läuft|löschen|nicht|nötig|öffnen|speichern|stummschalten|ungültig|verfügbar|verbinden|verbunden|wird)\b/i;
  const stringLiteralPattern = /(['"`])((?:\\[\s\S]|(?!\1)[\s\S])*?)\1/g;
  const allowedExact = new Set(['de', 'de-DE', 'Deutsch', 'German', 'VOICE', 'voice', 'sharkord-desktop:voice-preview:v1']);
  const allowedRaw = new Set(['(?i)(password|passwort|token|secret|authorization|cookie|credential|session)']);
  const issues = [];

  for (const file of files) {
    const source = readFileSync(file, 'utf8');
    for (const match of source.matchAll(stringLiteralPattern)) {
      const literal = match[2];
      if (allowedExact.has(literal) || allowedRaw.has(literal)) continue;
      if (!germanDisplayPattern.test(literal)) continue;
      const before = source.slice(Math.max(0, match.index - 25), match.index);
      if (/(?:\btr|\bt)\s*\(\s*$/.test(before)) continue;
      const stripped = literal.replace(/\$\{\s*(?:tr|t)\s*\([^}]*\)\s*\}/g, '');
      if (!germanDisplayPattern.test(stripped)) continue;
      const line = source.slice(0, match.index).split('\n').length;
      issues.push(`${file.replace(projectRoot + '/', '')}:${line}: ${literal.slice(0, 120)}`);
    }
  }

  assert.deepEqual(issues, []);
});


test('German channel permission override states are localized', () => {
  const channelSettingsModal = appSource.slice(
    appSource.indexOf('function ChannelSettingsModal'),
    appSource.indexOf('function OwnProfilePopup')
  );
  for (const label of ['Vererben', 'Erlauben', 'Verweigern']) {
    assert.match(channelSettingsModal, new RegExp(`tr\\('${label}'\\)`));
    assert.match(i18nSource, new RegExp(label));
  }
  for (const stale of ['Inherit', 'Allow', 'Deny']) {
    assert.doesNotMatch(channelSettingsModal, new RegExp(`tr\\('${stale}'\\)`));
  }
});

test('visible translatable app copy uses Sharkord or neutral wording instead of Discord branding', () => {
  const visibleDiscordTrCalls = appSource.match(/\btr\(\s*(["'`])(?:(?!\1)[\s\S])*?\bDiscord\b[\s\S]*?\1\s*\)/g) ?? [];
  assert.deepEqual(visibleDiscordTrCalls, []);
  for (const forbidden of ['Discord-Clone Shell mit Sharkord-Branding.', 'wie in Discord', 'Discord-style shell', 'like Discord']) {
    assert.doesNotMatch(i18nSource, new RegExp(forbidden.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  }
  assert.match(appSource, /Native Desktop-Shell mit Sharkord-Branding\./);
  assert.match(appSource, /Server wählen, Login speichern, dann zwischen Servern, Channels und Members arbeiten — ohne iframe\./);
});

test('current public docs avoid Discord branding outside archived evidence', () => {
  for (const [name, source] of [
    ['README.md', readmeSource],
    ['docs/webclient-parity-matrix.md', parityMatrixSource],
    ['docs/plans/2026-06-12-sharkord-desktop-mvp.md', desktopMvpPlanSource],
    ['docs/plans/2026-06-12-sharkord-desktop-native-trpc.md', nativeTrpcPlanSource]
  ]) {
    assert.doesNotMatch(source, /\bDiscord\b/i, `${name} still contains Discord branding`);
  }
});

test('DM conversation hiding keeps one real hide button on every server and gates only the action', () => {
  assert.match(clientSource, /trpc\.dms\.hide\.mutate\(\{\s*channelId\s*\}\)/);
  assert.match(appSource, /deleteDirectMessageConversation/);
  assert.match(appSource, /hideDirectMessage\(entry\.connection, entry\.channel\.id\)/);
  assert.match(appSource, /onDelete=\{\(entry\) => void deleteDirectMessageConversation\(entry\)\}/);
  assert.match(appSource, /Direktnachricht mit \$\{displayUserName\(entry\.user\)\} ausblenden/);
  assert.match(appSource, /className="dmConversationDeleteButton"/);
  assert.match(appSource, /serverCapabilities\.directMessageHide/);
  assert.doesNotMatch(appSource, /className="capabilityUnsupportedHint"/);
  assert.doesNotMatch(appSource, /<span className="capabilityUnsupportedHint"/);
  assert.match(cssSource, /\.dmConversationDeleteButton\b/);
});

test('unsupported DM hide opens an in-app unsupported dialog instead of rendering a sidebar label', () => {
  const requestDeleteBlock = appSource.match(/function deleteDirectMessageConversation[\s\S]*?async function confirmDeleteDirectMessageConversation/)?.[0] ?? '';
  assert.match(appSource, /pendingUnsupportedDirectMessageDelete/);
  assert.match(appSource, /function UnsupportedDirectMessageDeleteDialog/);
  assert.match(appSource, /<UnsupportedDirectMessageDeleteDialog entry=\{pendingUnsupportedDirectMessageDelete\}/);
  assert.match(requestDeleteBlock, /if \(!entry\.connection\.serverCapabilities\.directMessageHide\)/);
  assert.match(requestDeleteBlock, /setPendingUnsupportedDirectMessageDelete\(entry\)/);
  assert.doesNotMatch(requestDeleteBlock, /hideDirectMessage\(entry\.connection, entry\.channel\.id\)/);
  assert.match(appSource, /Diese Funktion wird von diesem Server nicht unterstützt\./);
  assert.doesNotMatch(appSource, />\{tr\('DM-Löschen nicht unterstützt'\)\}<\/small>/);
  assert.doesNotMatch(appSource, /capabilityUnsupportedHint/);
  assert.match(cssSource, /\.dmConversationDeleteButton \{[^}]*width: 28px;[^}]*height: 32px;[^}]*display: grid;[^}]*place-items: center;[^}]*opacity: 0;/s);
  assert.match(cssSource, /\.dmConversationShell:hover \.dmConversationDeleteButton, \.dmConversationDeleteButton:focus-visible \{ opacity: 1; \}/);
});

test('reported English locale screenshots translate DM delete storage server update and voice move copy', () => {
  for (const [german, english] of [
    ['Direktnachricht ausblenden nicht unterstützt', 'Direct message hiding not supported'],
    ['Direktnachricht wirklich ausblenden?', 'Really hide direct message?'],
    ['Die Direktnachricht mit', 'The direct message with'],
    ['wird aus deiner Liste ausgeblendet. Nachrichten bleiben auf dem Server; die Unterhaltung erscheint wieder bei einer neuen Gegen-Nachricht.', 'will be hidden from your list. Messages stay on the server; the conversation appears again when the other person sends a new message.'],
    ['Diese Funktion wird von diesem Server nicht unterstützt.', 'This feature is not supported by this server.'],
    ['kann die Direktnachricht mit', 'cannot hide the direct message with'],
    ['nicht über die Desktop-App aus der Liste ausblenden.', 'from the list via the desktop app.'],
    ['Herunterladen', 'Download'],
    ['URL kopieren', 'Copy URL'],
    ['Server-Modus', 'Server mode'],
    ['Kanuracer: Desktop-Erweiterungen verfügbar.', 'Kanuracer: desktop extensions available.'],
    ['Server-Update prüfen', 'Check server update'],
    ['Server aktualisieren', 'Update server'],
    ['Token anwenden', 'Apply token'],
    ['kein Update', 'no update'],
    ['Emoji · Erstellt:', 'Emoji · Created:'],
    ['Rollback: Wenn das Update nicht startet', 'Rollback: If the update does not start']
  ]) {
    assert.ok(i18nSource.includes(german), `missing German source phrase: ${german}`);
    assert.ok(i18nSource.includes(english), `missing English phrase: ${english}`);
  }
  const currentVersionIndex = i18nSource.indexOf("[/Aktuell: (.+) · (.+): (.+)/g, 'Current: $1 · $2: $3']");
  const genericDeleteIndex = i18nSource.indexOf("[/löschen/g, 'delete']");
  const dmDeleteIndex = i18nSource.indexOf("[/Direktnachricht mit (.+) ausblenden/g, 'Hide direct message with $1']");
  const voiceMoveIndex = i18nSource.indexOf("[/(.+) verschoben nach (.+)/g, '$1 moved to $2']");
  assert.ok(currentVersionIndex >= 0, 'missing dynamic current-version translation');
  assert.ok(dmDeleteIndex >= 0, 'missing dynamic DM delete translation');
  assert.ok(voiceMoveIndex >= 0, 'missing dynamic voice-move translation');
  assert.ok(dmDeleteIndex < genericDeleteIndex, 'DM delete phrase must translate before generic löschen -> delete replacement');
  assert.doesNotMatch(i18nSource, /Direktnachricht delete/);
});

async function loadI18nModuleForRegression() {
  const output = ts.transpileModule(i18nSource, {
    compilerOptions: { module: ts.ModuleKind.ES2022, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX }
  }).outputText;
  return import(`data:text/javascript;charset=utf-8,${encodeURIComponent(output)}`);
}

const englishGermanLeakPattern = /[ÄÖÜäöüß]|\b(?:Abbrechen|Abgelaufen|Aktuell|Alle|Anfang|Anhang|Angepinnte|Antwort|Ausgewählte|Bearbeiten|Benachrichtigung|Benutzer|Berechtigungen|Bildschirm|Datei|Dateien|Direktnachricht|Direktnachrichten|Einladung|Einstellungen|Entfernen|Erstellt|Fehler|Farbe|Fortfahren|Gelöschter|Gerät|Geräte|Hinzufügen|Installiere|Kategorie|Kein|Keine|Lade|Lädt|Letzter|Löschen|Nachricht|Nachrichten|Nicht|Nutzerdaten|Passwort|Privat|Profil|Prüfen|Registrierungen|Release-Kanal|Rolle|Rollen|Schließen|Speicher|Speichern|Suche|Suchbegriff|Suchtreffer|Treffer|Unbekannt|Verbindung|Verwendet|Willkommen|Zugangsdaten|Änderung|Änderungen|Öffnet|Übertrage|angehängt|ausführen|deaktiviert|eingeben|fehlgeschlagen|gefunden|geladen|gelöscht|gespeichert|hochgeladen|kein|keine|konnte|laden|läuft|löschen|nicht|öffentlichen|schließen|speichern|unterstützt|verfügbar|verschoben|wird|wurden)\b/i;

function collectProductionTrLiterals() {
  const files = [];
  const visit = (dir) => {
    for (const name of readdirSync(dir)) {
      const path = join(dir, name);
      const stat = statSync(path);
      if (stat.isDirectory()) visit(path);
      else if (/\.(?:ts|tsx)$/.test(name) && name !== 'i18n.ts') files.push(path);
    }
  };
  visit(join(testDir, '..', 'src'));
  const phrases = [];
  for (const file of files) {
    const source = readFileSync(file, 'utf8');
    const sf = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, file.endsWith('.tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS);
    const lineOf = (node) => sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1;
    const templateText = (node) => {
      if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) return node.text;
      if (!ts.isTemplateExpression(node)) return null;
      let text = node.head.text;
      node.templateSpans.forEach((span, index) => { text += `VALUE${index + 1}${span.literal.text}`; });
      return text;
    };
    const visitNode = (node) => {
      if (ts.isCallExpression(node) && node.expression.getText(sf) === 'tr' && node.arguments.length) {
        const phrase = templateText(node.arguments[0]);
        if (phrase && englishGermanLeakPattern.test(phrase)) phrases.push({ file: file.replace(projectRoot + '/', ''), line: lineOf(node.arguments[0]), phrase });
      }
      ts.forEachChild(node, visitNode);
    };
    visitNode(sf);
  }
  return phrases;
}

test('english locale translates every production tr literal without German leaks', async () => {
  const i18n = await loadI18nModuleForRegression();
  const leaks = collectProductionTrLiterals().map(({ file, line, phrase }) => {
    const translated = i18n.tr(phrase, 'en');
    return englishGermanLeakPattern.test(translated) ? `${file}:${line}: ${phrase} => ${translated}` : null;
  }).filter(Boolean);
  assert.deepEqual(leaks, []);
});

test('english server update no-update status renders fully English', async () => {
  const i18n = await loadI18nModuleForRegression();
  const rendered = `${i18n.tr('Server', 'en')}: 0.0.22 → 0.0.22 · ${i18n.tr('kein Update', 'en')}`;
  assert.equal(rendered, 'Server: 0.0.22 → 0.0.22 · no update');
});

test('websocket reconnects reuse the joined token while uploads can refresh REST auth', () => {
  assert.match(clientSource, /const TOKEN_REFRESH_AFTER_MS\s*=\s*8 \* 60 \* 1000/);
  assert.match(clientSource, /async function refreshAuthTokenIfStale\(force = false\)/);
  assert.match(clientSource, /if \(!force && Date\.now\(\) - tokenIssuedAt < TOKEN_REFRESH_AFTER_MS\) return token/);
  assert.match(clientSource, /token = await refreshToken\(\)/);
  assert.match(clientSource, /const websocketToken = token/);
  assert.match(clientSource, /connectionParams: \(\) => \(\{ token: websocketToken \}\)/);
  assert.doesNotMatch(clientSource, /connectionParams: async \(\) => \(\{ token: await refreshAuthTokenIfStale\(\) \}\)/);
  assert.match(clientSource, /get token\(\) \{ return token; \}/);
  assert.match(clientSource, /getFreshToken: \(\) => refreshAuthTokenIfStale\(\)/);
  assert.match(clientSource, /'x-token': await connection\.getFreshToken\(\)/);
});

test('protected websocket subscription auth failures trigger full loginAndJoin reconnect', () => {
  assert.match(appSource, /realtimeAuthReconnectServerIdsRef/);
  assert.match(appSource, /function isAuthenticationError\(message: string\)/);
  assert.match(appSource, /must be authenticated\|unauthorized\|unauthenticated\|not authenticated/);
  assert.match(appSource, /async function reconnectServerAfterRealtimeAuthFailure/);
  assert.match(appSource, /cleanupServerSession\(serverId, false\);\s*const next = await loginAndJoin\(\{ serverUrl: server\.url, \.\.\.reconnectAuth \}\)/s);
  assert.match(appSource, /wireSubscriptions\(next, serverId\)/);
  assert.match(appSource, /onError: \(label, err\) => \{\s*if \(!isActiveSubscriptionServer\(\)\) return;\s*void reconnectServerAfterRealtimeAuthFailure\(serverId, next, label, err\)/s);
});

test('desktop role editor marks local-only role changes dirty until saved and refreshes clean realtime roles', () => {
  assert.match(appSource, /dirtyRoleIds/);
  assert.match(appSource, /setDirtyRoleIds\(\(current\) => new Set\(current\)\.add\(role\.id\)\)/);
  assert.match(appSource, /Ungespeichert/);
  assert.match(appSource, /await updateRole\(connection, normalizeRoleForSave\(currentRole\)\)/);
  assert.match(appSource, /next\.delete\(role\.id\)/);
  assert.match(appSource, /if \(dirtyRoleIds\.size === 0\)[^]*getRoles\(connection\)/);
  assert.match(appSource, /lokale ungespeicherte Änderungen behalten/);
});

test('native members panel uses join roles and no longer shows the channel-access checkbox', () => {
  const panelFn = appSource.match(/function MembersPanel[\s\S]*?function MemberGroup/)?.[0] ?? '';
  const groupsFn = appSource.match(/function groupMembersByAssignedRole[\s\S]*?function credsToAuth/)?.[0] ?? '';
  assert.match(panelFn, /groupMembersByPresenceAndRole\(panelUsers, roles, ownUserId\)/);
  assert.doesNotMatch(panelFn, /memberAccessFilter|setMemberAccessFilter|channelAccessFilterSupported|Nur Channel-Zugriff/);
  assert.doesNotMatch(appSource, /const \[memberAccessFilter, setMemberAccessFilter\]/);
  assert.match(appSource, /setMemberPanelUserIds\(new Set\(rows\.map\(\(user\) => user\.id\)\)\)/);
  assert.doesNotMatch(appSource, /getAccessibleMembers\(connection, selectedChannel\.id, !memberAccessFilter\)/);
  assert.match(groupsFn, /if \(!roles\.length\) return \[singleMemberGroup\(users\)\]/);
  assert.match(groupsFn, /const hasAnyKnownRoleAssignment = users\.some/);
  assert.match(groupsFn, /if \(!defaultRole && !hasAnyKnownRoleAssignment\) return \[singleMemberGroup\(users\)\]/);
});

test('member sidebar keeps only channel-access ids and renders live user objects for realtime status/join freshness', () => {
  const source = appSource;
  assert.match(source, /const \[memberPanelUserIds, setMemberPanelUserIds\] = useState<Set<number> \| null>/, 'member panel must cache ids, not stale SharkordUser snapshots');
  assert.doesNotMatch(source, /useState<SharkordUser\[\] \| null>\(null\)/, 'member panel must not store stale user snapshots');
  assert.match(source, /setMemberPanelUserIds\(new Set\(rows\.map\(\(user\) => user\.id\)\)\)/, 'getAccessibleMembers should only update allowed ids');
  assert.match(source, /sortedUsers\.filter\(\(user\) => memberPanelUserIds\.has\(user\.id\)\)/, 'display users must come from live sortedUsers');
  assert.match(source, /liveUserRoleSignature/, 'channel member access must refetch when role assignments change');
});

test('member sidebar groups online users by role then collapses offline into one unsorted section', () => {
  const source = appSource;
  const groupingFn = source.match(/function groupMembersByPresenceAndRole[\s\S]*?function credsToAuth/)?.[0] ?? '';
  assert.match(groupingFn, /const onlineUsers = users\.filter/, 'online users must be separated first');
  assert.match(groupingFn, /groupMembersByAssignedRole\(onlineUsers, roles\)/, 'only online users should be grouped by role');
  assert.match(groupingFn, /const offlineUsers = users\.filter/, 'offline users must be separated');
  assert.match(groupingFn, /key:\s*'offline'/, 'offline must be one plain group');
  assert.match(groupingFn, /title:\s*tr\('Offline'\)/, 'offline group title must not include role name');
  assert.doesNotMatch(groupingFn, /groupMembersByAssignedRole\(offlineUsers/, 'offline users must not be role-sorted/grouped');
  assert.match(source, /groupMembersByPresenceAndRole\(panelUsers, roles, ownUserId\)/, 'MembersPanel must use status-first grouping');
});

test('admin role changes in settings are synced back to live users and context menu roles', () => {
  const source = appSource;
  assert.match(source, /syncLiveUsersFromAdminRows/, 'settings user role edits must update live user cache');
  assert.match(source, /onUsersChanged=\{syncLiveUsersFromAdminRows\}/, 'AdminWorkbench must notify App when admin user rows refresh');
  assert.match(source, /usersById=\{usersById\}/, 'AdminContextMenu must receive live users map');
  assert.match(source, /currentMenuUser = menu\?\.kind === 'user' \? usersById\.get\(menu\.user\.id\) \?\? menu\.user : null/, 'context menu must resolve fresh user before rendering roles');
  assert.match(source, /toggleUserRole\(currentMenuUser, role\)/, 'role toggles must use fresh current menu user');
});

