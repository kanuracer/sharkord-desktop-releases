package main

import (
	"strings"
	"testing"
)

func TestLiveDebugLogRedactsSensitiveValues(t *testing.T) {
	entry := LiveDebugLogEntry{
		Endpoint:  "http://127.0.0.1:8799/sharkord-live-log",
		SessionID: "session-1",
		Event:     "voice.produce.error",
		Level:     "error",
		Message:   "failed with password hunter2 and token abc123",
		Data: map[string]any{
			"password":      "hunter2",
			"accessToken":   "abc123",
			"authorization": "Bearer secret",
			"safe":          "kept",
		},
	}
	clean := sanitizeLiveDebugEntry(entry)
	raw := liveDebugJSONForTest(clean)
	for _, forbidden := range []string{"hunter2", "abc123", "Bearer secret"} {
		if strings.Contains(raw, forbidden) {
			t.Fatalf("live debug payload leaked secret %q in %s", forbidden, raw)
		}
	}
	if !strings.Contains(raw, "[REDACTED]") || !strings.Contains(raw, "kept") {
		t.Fatalf("expected redacted secrets and safe data in %s", raw)
	}
}

func TestLiveDebugEndpointValidation(t *testing.T) {
	for _, endpoint := range []string{"", "file:///tmp/x", "ftp://example.invalid/x", "http://127.0.0.1:8799/log", "https://logs.example.invalid/log"} {
		err := validateLiveDebugEndpoint(endpoint)
		if endpoint == "http://127.0.0.1:8799/log" || endpoint == "https://logs.example.invalid/log" {
			if err != nil {
				t.Fatalf("expected %s to be accepted: %v", endpoint, err)
			}
			continue
		}
		if err == nil {
			t.Fatalf("expected %s to be rejected", endpoint)
		}
	}
}
