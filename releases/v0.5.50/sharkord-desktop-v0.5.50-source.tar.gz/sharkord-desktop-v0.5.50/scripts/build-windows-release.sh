#!/usr/bin/env bash
set -euo pipefail

VERSION="${1:-${SHARKORD_VERSION:-0.5.50}}"
OUTDIR="${2:-$PWD/bin}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ASSET="$OUTDIR/sharkord-desktop-${VERSION}-windows-amd64.exe"

export CGO_ENABLED=1
export CC="${CC:-x86_64-w64-mingw32-gcc}"

cd "$ROOT"
mkdir -p "$OUTDIR"
./scripts/generate-windows-syso.sh "$VERSION"
wails3 generate bindings -ts ./...
npm --prefix frontend install
npm --prefix frontend run build
GOOS=windows GOARCH=amd64 go build \
  -tags production \
  -trimpath \
  -buildvcs=false \
  -ldflags="-w -s -H windowsgui -X main.appVersion=${VERSION}" \
  -o "$ASSET"

file "$ASSET"
if file "$ASSET" | grep -qi 'console'; then
  echo "WINDOWS_GUI_SUBSYSTEM_CHECK_FAILED: built Console/CUI executable" >&2
  exit 1
fi
if command -v x86_64-w64-mingw32-objdump >/dev/null; then
  x86_64-w64-mingw32-objdump -x "$ASSET" | grep -i 'Subsystem.*Windows GUI' >/dev/null
fi
sha256sum "$ASSET"
echo "WINDOWS_RELEASE_OK VERSION=$VERSION ASSET=$ASSET"
