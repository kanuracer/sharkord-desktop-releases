# Sharkord Desktop

Cross-platform native desktop client for [Sharkord](https://github.com/sharkord/sharkord), built with the same stack direction as `ssh-vault2`.

## Stack

- Wails v3 + Go backend
- React 19 + TypeScript + Vite frontend
- `@trpc/client` WebSocket transport for Sharkord
- GitHub Releases updater with in-place install flow via `kanuracer/sharkord-desktop-releases`
- Settings tab for desktop updates/appearance; server owner/update actions live in per-server settings
- Encrypted per-server credentials in backend storage (Windows DPAPI, Linux/macOS AES-GCM)
- Window position/size persistence like ssh-vault2
- No Electron, no iframe, no embedded browser shell around Sharkord
- Node test runner for lightweight regression tests

## Current 0.5.46

### Added

- Adds Server Settings > Security controls for Kanuracer server IP allow/block rules and security events.

### Fixed

- Fixes role weighting saves in Server Settings > Roles by sending normalized weights from the current local role state.
- Keeps upgraded servers compatible when older databases are missing role weight metadata.

## Current 0.5.14

### Added

- Adds two-factor authentication login support for Sharkord servers that require TOTP codes.
- Adds remembered-device app password storage after a successful TOTP login so Desktop can reconnect without storing one-time codes.
- Adds profile security controls to review and revoke remembered Desktop app passwords.

### Fixed

- Keeps TOTP codes out of saved credentials while preserving secure auto-login through revocable app passwords.

## Current 0.5.13

### Fixed

- Preserves unsaved local role and permission edits while realtime role updates arrive, so in-progress Admin changes no longer get overwritten before saving.
- Includes the English fallback fixes from 0.5.12, including corrected `Private Voice Channels` and `3 Categories` text.

### Improvements

- Keeps the stable and beta update feeds aligned on the verified 0.5.13 desktop build for Linux, Windows, and macOS arm64.

## Current 0.5.12

### Fixed

- Fixes English locale text corruption such as `Privatee Voice Channels`.
- Fixes mixed German/English plural text such as `3 Categoryn`; English now renders `3 Categories`.

## Current 0.5.11

### Fixed

- Completes English and German i18n coverage for dynamic app text, dialogs, Admin settings, server update status, storage, DM deletion, and voice move/status surfaces.
- Routes previously raw role and emoji Admin strings through the i18n system.

## Current 0.5.10

### Fixed

- Completes English locale coverage for update/settings, server update, direct-message delete, storage, and voice move UI surfaces.
- Prevents mixed German/English copy in English mode for reported labels and action messages.

## Current 0.5.9

### Fixed

- Updates live member presence immediately when a user comes online while the desktop app is already open.
- Marks `users.onJoin` realtime events as online so the desktop matches webclient presence behavior without a restart.

## Current 0.5.8

### Fixed

- Keeps the DM delete button visible on every connected server.
- Shows an in-app unsupported-feature dialog when the selected server does not support DM conversation deletion.

## Current 0.5.7

### Added

- Adds a command palette with Ctrl/Cmd+K for quick app actions and navigation.
- Adds an attachment lightbox for images and shared storage previews.
- Adds a notification center plus appearance/accessibility controls for compact mode, reduced motion, high contrast, and font size.

### Fixed

- Localizes the new appearance and command-palette UI in English.
- Keeps beta update verification copy focused on checksum/feed status and safe rollback/manual install guidance.

## Current 0.5.3

### Fixed

- Replaces the server-removal browser confirm prompt with a visible in-app confirmation dialog.
- Keeps removal state updates ahead of credential cleanup so the trash action cannot be blocked by native storage errors.

## Current 0.5.2

### Fixed

- Keeps WebSocket reconnects on the same server-joined token so protected realtime subscriptions stay authenticated after idle reconnects.
- Prevents `categories.onDelete: You must be authenticated to perform this action.` from reappearing when the WebSocket reconnects without re-running `joinServer`.

## Current 0.5.1

### Fixed

- Recovers from protected realtime subscription auth failures by performing a full `loginAndJoin` reconnect and resubscribing.
- Keeps the active channel selected after the reconnect so `categories.onDelete` and similar idle subscription errors self-heal.

## Current 0.5.0

### Added

- Detects original Sharkord vs Kanuracer server capabilities after login.
- Hides fork-only Desktop actions on original servers instead of showing unsupported controls.
- Enables DM deletion, owner-token, and server self-update UI only when the connected server advertises support.

## Current 0.4.20

### Fixed

- Refreshes the Sharkord auth token before WebSocket reconnects after idle time so realtime subscriptions do not fail with `You must be auth`.
- Uses fresh auth for uploads after long-running sessions.

## Current 0.4.19

### Fixed

- Moves the Server-Owner-Token and server self-update controls out of global desktop updates and into per-server settings.

## Current 0.4.16

### Fixed

- Keeps settings import moving after file selection by replacing browser confirm prompts with native Wails confirmation dialogs.
- Shows a distinct “no file selected” status only when the import dialog is actually cancelled.

## Current 0.4.14

### Fixed

- Restores settings import on macOS by using the native file picker and backend JSON reader.
- Rejects invalid or oversized settings import files before applying them.

## Current 0.4.13

### Fixed

- Adds structured plugin slash-command argument controls before command execution.
- Validates required plugin command arguments before calling the server.

### Improvements

- Keeps plugin command execution aligned with upstream Sharkord WebUI composer behavior for typed text, number, and boolean args.

## Current 0.4.12

### Fixed

- Fixed mixed-language desktop labels in Settings, Admin, Invite, Storage, and profile surfaces.

### Improvements

- Improved English locale coverage for common Admin and settings labels.
- Improved i18n regression coverage so UI chrome stays routed through translation helpers.

## Current 0.4.11

- Replaces the server header context menu with an anchored dropdown under the server name.
- Keeps channel, category, and user right-click context menus separate from server actions.
- Adds regression coverage for dropdown anchoring, grouping, and opaque menu styling.
- Stable channel stays unchanged; this build is published to the Beta update channel.

## Current 0.4.10

- Fixes English locale leaks in profile, direct-message, and global-search UI chrome.
- Sends rich-composer messages with Enter while preserving Shift+Enter for new lines.
- Adds regression coverage for reported i18n leaks and composer send behavior.
- Stable channel stays unchanged; this build is published to the Beta update channel.

## Current 0.4.0

- Adds stable/beta update channels via branch-specific release feeds.
- Checks for updates at startup and shows a visible update CTA.
- Shows channel, available version, asset, and changelog in Settings → Updates.
- Localizes channel permission override states in German.
- Cleans visible Sharkord branding copy.

## Current 0.3.95

- Fixes Voice user drag/drop moves between voice channels from the native desktop sidebar.
- Keeps profile editing in the account footer; server logo management stays in server settings.
- Fixes Global Search/profile popup surface styling and account footer overflow.
- Fixes English fallback translation recursion that could turn profile text into `Profileeeee...`.
- Release artifacts are published through `kanuracer/sharkord-desktop-releases`.

## Current 0.3.94

- Adds Global Search via Ctrl/Cmd+K for server-wide message and file search.
- Adds Welcome/Profile Setup onboarding when the server requests first-run profile completion.
- Keeps both new dialogs dark themed and viewport-safe.
- Release artifacts are published through `kanuracer/sharkord-desktop-releases`.

## Current 0.3.18

- Same user-facing voice media rebuild fix as 0.3.16/0.3.17.
- Skips the macOS-only app-root updater test on non-darwin OSes so Windows release verification can run `go test ./...` cleanly.
- macOS asset was not included for this release.

## Current 0.3.17

- Same user-facing voice media rebuild fix as 0.3.16.
- Makes the macOS updater path test portable so Windows release verification can run `go test ./...` cleanly.

## Current 0.3.16

- Fixes camera/screen media rebuild after a failed initial voice media setup:
  - Stores router RTP capabilities from the successful `voice.join`.
  - Rebuilds mediasoup send/receive transports inside the existing joined voice session.
  - Avoids calling `voice.join` again for the same channel, which Sharkord rejects because the user is already in voice.
  - Preserves the real mediasoup/tRPC error instead of overwriting it with a generic Producer-Transport status.

## Current 0.3.15

- Fixes camera/screen failures after voice join:
  - Adds a producer-transport readiness check before media actions.
  - Discards half-initialized voice engines instead of keeping an engine without send transport.
  - Camera/screen clicks retry media-transport setup once when voice membership exists but media transport is not ready.
  - Replaces internal `Producer transport fehlt` user failure with a clear media-setup status.
- Fixes fresh release builds:
  - Generates Wails app bindings before Linux/Windows frontend builds.
  - Regenerates Windows SYSO before Windows `go build`.
  - Uses 4-component Windows manifest/resource versions for release builds.
  - macOS release script honors output dir argument.

## Current 0.3.14

- Fixes camera/screen failures after voice join:
  - Adds a producer-transport readiness check before media actions.
  - Discards half-initialized voice engines instead of keeping an engine without send transport.
  - Camera/screen clicks retry media-transport setup once when voice membership exists but media transport is not ready.
  - Replaces internal `Producer transport fehlt` user failure with a clear media-setup status.
- Fixes fresh release builds:
  - Generates Wails app bindings before Linux/Windows frontend builds.
  - Regenerates Windows SYSO before Windows `go build`, preserving ProductVersion.
  - macOS release script honors output dir argument.

## Current 0.3.13

- Superseded before release assets: source tag only; release build caught Windows ProductVersion and macOS output-dir issues.

## Current 0.3.12

- Superseded before release assets: source tag only; release build caught missing generated bindings in fresh archives.

## Current 0.3.11

- Enables macOS in-place updates:
  - Removes the old darwin stub that returned `macOS In-Place-Update wird aktiviert...`.
  - Validates darwin `.zip` release assets before applying.
  - Replaces the running `.app` bundle after exit and restarts via `open -n`.
  - Important: macOS `v0.3.10` cannot self-update to this fix because the updater bug is in `v0.3.10`; install `v0.3.11` manually once.

## Current 0.3.10

- Fixes macOS voice/media state mismatch:
  - A successful server-side `voice.join` immediately marks the selected voice channel as joined.
  - Microphone capture errors are non-fatal; camera/screen sharing can still use the mediasoup transport.
  - Voice panel no longer shows internal `voice.join` debug copy.
  - Voice channel rows no longer show green `Join`/`Joined` pills; connected channel uses a subtle icon.
  - macOS release bundle now includes microphone, camera, and screen-capture privacy usage strings.

## Current 0.3.9

- Fixes no-server onboarding UX:
  - Settings gear is available in the server rail before any server is added.
  - Settings can open with `activeServer=null`.
  - Light/Dark switch was removed from the start page and stays in Settings → Darstellung.
  - Rail Settings hover no longer looks like the active state.

## Current 0.3.8

- Fixes the no-server start screen layout regression:
  - Empty state now spans the main area to the right of the server rail.
  - Hero/content is centered in that main area, not squeezed into the old 260px channel column.
  - Regression test locks the geometry.

## Current 0.3.7

- Adds core webclient media parity:
  - Webcam publishing via `getUserMedia` + mediasoup `video` producer.
  - Screen sharing via `getDisplayMedia` + mediasoup `screen` producer.
  - Optional screen audio via `screen_audio` producer.
  - Remote media consumers for `video`, `screen`, and `external_video`.
  - Local and remote video tiles in the Voice view.
- Replaces brittle RMS gate with local WASM denoise:
  - RNNoise AudioWorklet first.
  - Speex AudioWorklet fallback.
  - Keeps browser echo/noise/AGC toggles.
  - Removes old threshold/gate UI copy.
- Uses the Sharkord logo as native program icon:
  - Wails runtime icon via embedded PNG.
  - Windows `.ico` + `wails_windows_amd64.syso` resource.
  - macOS `.icns` generated for future Mac build.

## Current 0.3.6

- Uses the generated Sharkord logo as a real bundled frontend asset:
  - `frontend/src/assets/sharkord-logo.png` optimized to 256×256 (~71 KB).
  - Rendered in the server rail brand button.
  - Rendered in welcome/empty hero states.
- Added first-generation voice cleanup settings. Superseded by 0.3.7 local WASM denoise.

## Current 0.3.5

- Fixes desktop shell layout regression from hidden remote-audio grid child:
  - Server rail, channel sidebar, chat/settings, and members are explicit grid columns.
  - `RemoteAudioStreams` is fixed zero-size and no longer consumes a grid slot.
  - Regression test locks the shell geometry.

## Current 0.3.4

- Adds real Webclient-style voice audio transport:
  - `mediasoup-client` Device setup from `voice.join` router RTP capabilities.
  - Producer transport create/connect/produce for microphone audio.
  - Consumer transport create/connect/consume for remote audio producers.
  - Remote `<audio>` elements use MediaStream tracks and playback device routing.
  - Producer open/close events start/stop remote audio consumers and speaking indicators.
- Adds Webclient-style audio device settings:
  - Microphone select via `navigator.mediaDevices.enumerateDevices()` / `getUserMedia` deviceId.
  - Speaker select via `HTMLAudioElement.setSinkId` where supported.
  - Echo cancellation, noise suppression, auto gain control toggles.

## Current 0.3.3

- Replaces the temporary Settings Admin Center with context-menu admin UX:
  - Server header click/right-click opens a compact server context menu.
  - Channel rows support right-click context actions.
  - Member and voice-user rows support right-click user actions.
  - User roles are assigned/removed from the user context menu, not a Settings page.
  - Settings now only contains appearance, updates, server account/status.
- Keeps native admin tRPC coverage from 0.3.2; actions are moved to the normal server/channel/user interaction surfaces.

## Current 0.3.2

- Native Admin Center added under Settings:
  - Server settings get/update (`others.getSettings`, `others.updateSettings`).
  - Category create/update/delete.
  - Channel create/update/delete.
  - Role list/create/update/delete/default.
  - User moderation: kick/ban/unban/delete and role assign/remove.
  - Invite list/create/delete.
  - Emoji list/update/delete.
- Voice producer subscriptions added:
  - `voice.onNewProducer` / `voice.onProducerClosed` mark active audio/speaking users in the voice list.
  - Note: true audio-level speaking meters still require full mediasoup audio pipeline.

## Current 0.3.1

- Webclient parity pass:
  - Removed bundled demo server and demo wording; app starts in empty onboarding.
  - Renders voice participants below voice channels via `voiceMap` and `voice.onJoin/onLeave/onUpdateState`.
  - Subscribes to core live webclient events for messages, users, channels, and categories.
  - Adds lightweight desktop sounds for messages, connect/disconnect, voice join/leave, mute/deafen.

## Current 0.3.0

- Webclient-parity sprint:
  - Auto-Connect option when adding servers.
  - Direct server delete button in server header.
  - Bottom-left mic/deafen state toggles.
  - Server-side voice join/leave/update-state via Sharkord `voice.*` tRPC routes.
  - Signed avatar file URLs rendered for user panel, members, and messages.
  - Message hover actions for edit/delete/pin/reaction.
- Hotfix: server setup credentials no longer fail for legacy/URL-like server IDs (`ungültige Server-ID`).
- Real Sharkord-native desktop shell:
  - far-left guild/server rail
  - channel column with server header
  - text + voice channel groups
  - top channel bar
  - row-based message feed with avatars/usernames/timestamps
  - right Members sidebar
  - bottom-left voice/user controls
  - bottom composer with action icons
- Add multiple Sharkord servers by URL.
- Switch between servers.
- Dark mode and light mode.
- Server list/theme persist locally.
- Native Sharkord connection flow:
  - `GET /info`
  - `POST /login`
  - tRPC WebSocket with JWT connection params
  - `others.handshake`
  - `others.joinServer`
  - `messages.get`
  - `messages.send`
- Native channel sidebar.
- Native message pane with wrapped long messages.
- No iframe.
- No Electron webview.

## Development

```bash
cd frontend
npm install
npm test
npm run build
cd ..
go build ./...
go run github.com/wailsapp/wails/v3/cmd/wails3@v3.0.0-alpha.95 build
```

## Verification snapshot

```text
npm test: 33/33 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
browser core media/settings visual QA: OK
browser banned denoise disclaimer check: OK
browser overflowX: 0
Windows npm test: 33/33 pass
Windows npm run build: OK
Windows go test ./...: OK
Windows Wails build: OK
Windows PE subsystem: 2 (GUI, no CMD console)
Windows PE resources: OK (.rsrc present, icon/version/manifest verified locally)
window position persistence: OK
```

Live smoke was performed against `https://demo.sharkord.com` with a throwaway demo identity. Messages were loaded from the README channel. Sending was not performed against the public demo to avoid spam.

## GitHub updater

The app checks branch-specific public release feeds:

```text
https://raw.githubusercontent.com/kanuracer/sharkord-desktop-releases/main/latest.json
https://raw.githubusercontent.com/kanuracer/sharkord-desktop-releases/beta/latest.json
```

Release repo is public, so normal update checks do not need a token. No GitHub token is embedded in the binary. Stable uses `main`; beta uses `beta`. Old clients using GitHub Releases `/latest` should only receive approved stable releases.

For private/future protected checks, launch with:

```text
SHARKORD_DESKTOP_GITHUB_TOKEN=<token>
```

Supported update asset shapes:

```text
sharkord-desktop-<version>-windows-amd64.exe
sharkord-desktop-<version>-linux-amd64.tar.gz
sharkord-desktop-<version>-darwin-arm64.zip
```

## Packaging target

- Linux: local Wails build creates `bin/sharkord-desktop`.
- Windows: Win11 testclient build creates `C:\Users\hermes\sharkord-desktop\bin\sharkord-desktop.exe`.
- macOS: build on MacBook when reachable.

## Next work

1. Add native subscriptions for realtime message updates.
2. Add full voice/WebRTC join flow.
3. Add DM view.
4. Add file upload/download surfaces.
5. Add user profiles/context menus and member popovers.
6. Add notification/toast system.
7. Build macOS artifact when MacBook is reachable.
