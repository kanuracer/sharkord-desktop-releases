package main

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
)

type ServerCredentials struct {
	Identity       string `json:"identity"`
	Password       string `json:"password"`
	AppPassword    string `json:"appPassword"`
	ServerPassword string `json:"serverPassword"`
	Invite         string `json:"invite"`
}

type storedCredentialBlob struct {
	Data string `json:"data"`
}

func credentialsPath() (string, error) {
	dir, err := configDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(dir, "credentials.json"), nil
}

func readCredentialStore() (map[string]storedCredentialBlob, error) {
	path, err := credentialsPath()
	if err != nil {
		return nil, err
	}
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return map[string]storedCredentialBlob{}, nil
	}
	if err != nil {
		return nil, err
	}
	var store map[string]storedCredentialBlob
	if err := json.Unmarshal(cleanJSONBytes(b), &store); err != nil {
		return nil, err
	}
	if store == nil {
		store = map[string]storedCredentialBlob{}
	}
	return store, nil
}

func writeCredentialStore(store map[string]storedCredentialBlob) error {
	path, err := credentialsPath()
	if err != nil {
		return err
	}
	b, err := json.MarshalIndent(store, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0600)
}

func credentialStoreKey(serverID string) (string, error) {
	serverID = strings.TrimSpace(serverID)
	if serverID == "" {
		return "", errors.New("invalid server ID")
	}
	if !strings.ContainsAny(serverID, `/\\\x00`) {
		return serverID, nil
	}
	return "id_" + base64.RawURLEncoding.EncodeToString([]byte(serverID)), nil
}

func (s *AppService) SaveServerCredentials(serverID string, creds ServerCredentials) error {
	key, err := credentialStoreKey(serverID)
	if err != nil {
		return err
	}
	payload, err := json.Marshal(creds)
	if err != nil {
		return err
	}
	protected, err := encryptSecret(payload)
	if err != nil {
		return err
	}
	store, err := readCredentialStore()
	if err != nil {
		return err
	}
	store[key] = storedCredentialBlob{Data: base64.StdEncoding.EncodeToString(protected)}
	return writeCredentialStore(store)
}

func (s *AppService) LoadServerCredentials(serverID string) (ServerCredentials, error) {
	var creds ServerCredentials
	key, err := credentialStoreKey(serverID)
	if err != nil {
		return creds, err
	}
	store, err := readCredentialStore()
	if err != nil {
		return creds, err
	}
	blob, ok := store[key]
	if !ok || strings.TrimSpace(blob.Data) == "" {
		return creds, nil
	}
	protected, err := base64.StdEncoding.DecodeString(blob.Data)
	if err != nil {
		return creds, err
	}
	plain, err := decryptSecret(protected)
	if err != nil {
		return creds, err
	}
	if err := json.Unmarshal(plain, &creds); err != nil {
		return creds, err
	}
	return creds, nil
}

func (s *AppService) DeleteServerCredentials(serverID string) error {
	key, err := credentialStoreKey(serverID)
	if err != nil {
		return err
	}
	store, err := readCredentialStore()
	if err != nil {
		return err
	}
	delete(store, key)
	return writeCredentialStore(store)
}
