package main

import (
	"os"
	"strings"
	"testing"
)

func TestEncryptedCredentialStoreRoundTrip(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", tmp)
	t.Setenv("APPDATA", tmp)
	svc := NewAppService()
	want := ServerCredentials{Identity: "paul", Password: "super-secret-pass", ServerPassword: "server-secret"}
	if err := svc.SaveServerCredentials("server-1", want); err != nil {
		t.Fatalf("save credentials: %v", err)
	}
	got, err := svc.LoadServerCredentials("server-1")
	if err != nil {
		t.Fatalf("load credentials: %v", err)
	}
	if got != want {
		t.Fatalf("credentials mismatch: got %#v want %#v", got, want)
	}
	path, err := credentialsPath()
	if err != nil {
		t.Fatalf("credentials path: %v", err)
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read store: %v", err)
	}
	for _, forbidden := range []string{want.Identity, want.Password, want.ServerPassword} {
		if strings.Contains(string(raw), forbidden) {
			t.Fatalf("credential store contains plaintext %q: %s", forbidden, string(raw))
		}
	}
	if err := svc.DeleteServerCredentials("server-1"); err != nil {
		t.Fatalf("delete credentials: %v", err)
	}
	empty, err := svc.LoadServerCredentials("server-1")
	if err != nil {
		t.Fatalf("load deleted credentials: %v", err)
	}
	if empty != (ServerCredentials{}) {
		t.Fatalf("expected empty credentials after delete, got %#v", empty)
	}
}

func TestCredentialStoreAcceptsLegacyURLLikeServerIDs(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", tmp)
	t.Setenv("APPDATA", tmp)
	svc := NewAppService()
	legacyID := "https://sharkord.example.tld/server?id=42"
	want := ServerCredentials{Identity: "paul", Password: "pw", ServerPassword: "server"}
	if err := svc.SaveServerCredentials(legacyID, want); err != nil {
		t.Fatalf("legacy/url-like server id should be normalized, got error: %v", err)
	}
	got, err := svc.LoadServerCredentials(legacyID)
	if err != nil {
		t.Fatalf("load legacy/url-like id: %v", err)
	}
	if got != want {
		t.Fatalf("credentials mismatch: got %#v want %#v", got, want)
	}
	if err := svc.DeleteServerCredentials(legacyID); err != nil {
		t.Fatalf("delete legacy/url-like id: %v", err)
	}
}
