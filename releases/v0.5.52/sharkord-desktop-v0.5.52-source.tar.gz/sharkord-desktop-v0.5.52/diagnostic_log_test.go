package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestDiagnosticLogAppendRedactsAndRotatesLocally(t *testing.T) {
	dir := t.TempDir()
	oldConfigDir := diagnosticConfigDirForTest
	diagnosticConfigDirForTest = dir
	defer func() { diagnosticConfigDirForTest = oldConfigDir }()

	entry := LiveDebugLogEntry{
		SessionID: "voice-session-1",
		Event:     "voice.join.error",
		Level:     "error",
		Message:   "failed with password hunter2 and token abc123",
		Data: map[string]any{
			"channelId":      123,
			"accessToken":    "abc123",
			"authorization":  "Bearer secret",
			"messageContent": "private message body",
		},
	}
	info, err := AppendDiagnosticLogEntry(entry)
	if err != nil {
		t.Fatalf("append diagnostic log: %v", err)
	}
	if !strings.HasSuffix(info.Path, filepath.Join("logs", "diagnostic.ndjson")) {
		t.Fatalf("unexpected log path %q", info.Path)
	}
	raw, err := os.ReadFile(info.Path)
	if err != nil {
		t.Fatalf("read log: %v", err)
	}
	for _, forbidden := range []string{"hunter2", "abc123", "Bearer secret", "private message body"} {
		if strings.Contains(string(raw), forbidden) {
			t.Fatalf("diagnostic log leaked %q in %s", forbidden, raw)
		}
	}
	if !strings.Contains(string(raw), "[REDACTED]") || !strings.Contains(string(raw), "voice.join.error") {
		t.Fatalf("expected redacted diagnostic event in %s", raw)
	}
	var decoded LiveDebugLogEntry
	if err := json.Unmarshal([]byte(strings.TrimSpace(string(raw))), &decoded); err != nil {
		t.Fatalf("log line is not valid json: %v", err)
	}
}

func TestDiagnosticLogInfoUsesConfigLogsDirectory(t *testing.T) {
	dir := t.TempDir()
	oldConfigDir := diagnosticConfigDirForTest
	diagnosticConfigDirForTest = dir
	defer func() { diagnosticConfigDirForTest = oldConfigDir }()
	info, err := DiagnosticLogInfoForTest()
	if err != nil {
		t.Fatalf("diagnostic info: %v", err)
	}
	want := filepath.Join(dir, "logs", "diagnostic.ndjson")
	if info.Path != want {
		t.Fatalf("path mismatch: got %q want %q", info.Path, want)
	}
}
