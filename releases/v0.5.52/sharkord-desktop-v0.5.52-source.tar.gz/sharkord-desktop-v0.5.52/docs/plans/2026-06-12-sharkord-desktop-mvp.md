# Sharkord Desktop MVP Implementation Plan

> **For Hermes:** Use subagent-driven-development skill to implement this plan task-by-task.

**Goal:** Build a Sharkord-native cross-platform desktop client with server rail, server switching, and dark/light themes.

**Architecture:** Match `ssh-vault2` stack: Wails v3 Go app shell + React/TypeScript/Vite frontend. MVP stores server list locally and embeds selected Sharkord instance in an iframe. If framing is blocked by target server headers, phase 2 replaces iframe with native tRPC views.

**Tech Stack:** Wails v3, Go 1.25, React 19, TypeScript 6, Vite 8, `@wailsio/runtime`.

---

## Preflight

- Upstream `sharkord/sharkord`: cloned, branch `development`, commit `d8def12`.
- Desktop repo `kanuracer/sharkord-desktop`: cloned; repo was empty before scaffold.
- Requested stack correction: use same stack as `ssh-vault2`, not Electron.
- ssh-vault2 stack verified: Wails v3 + Go backend + React/TypeScript/Vite frontend.
- Windows test client reachable on SSH/RDP.
- MacBook candidates currently unreachable; macOS build skipped until reachable.
- Wiki token not found in default secret lookup; private Wiki update needs token/path confirmation.

## Acceptance criteria

- App uses Wails/Go + React/Vite.
- Left rail lists configured Sharkord servers.
- Clicking server changes active frame.
- Add-server modal normalizes URL.
- Theme toggle changes dark/light mode.
- State persists across restarts.
- `npm run build` passes in frontend.
- `go build ./...` passes after frontend build.
- Linux/Windows Wails package builds in later step.
- macOS package builds only on reachable MacBook.
- Private Wiki page documents plan, todos, done work, and blockers.

## Tasks

### Task 1: Wails scaffold

**Files:** `go.mod`, `main.go`, `appservice.go`, `frontend/*`

- Create Wails app shell using `github.com/wailsapp/wails/v3/pkg/application`.
- Embed `frontend/dist`.
- Add minimal `AppService` for future URL probing/normalization.
- Verify `go build ./...`.

### Task 2: React server rail

**Files:** `frontend/src/App.tsx`, `frontend/src/style.css`, `frontend/src/types.ts`

- Render fixed left server rail.
- Add default demo entry.
- Persist server list in localStorage.
- Switch active server by click.

### Task 3: Add/remove server

**Files:** `frontend/src/App.tsx`, `frontend/src/storage.ts`

- Add modal.
- Validate URL.
- Fallback `https://` if user enters plain host.
- Remove custom active server.

### Task 4: Theme support

**Files:** `frontend/src/App.tsx`, `frontend/src/style.css`

- Add dark/light state.
- Apply `document.documentElement.dataset.theme`.
- Persist in localStorage.

### Task 5: Sharkord embedding

**Files:** `frontend/src/App.tsx`

- MVP: iframe with sandbox for selected server URL.
- Verify target servers do not send frame-blocking headers.
- If blocked: switch to native tRPC client implementation.

### Task 6: Tests/build

Commands:

```bash
cd frontend
npm test
npm run build
cd ..
go build ./...
```

### Task 7: Windows QA

- Build or copy to Win11 test client.
- Start app.
- Screenshot dark mode, light mode, add modal, server switch.
- Check no clipping/overflow.

### Task 8: macOS build

- Probe MacBook SSH.
- If reachable: build Wails macOS artifact there.
- If unreachable: keep skipped status documented.

### Task 9: Private Wiki

Suggested path: `projekte/sharkord-desktop`.

- Publish this plan + todo + completed work.
- Verify API readback markers.
- Verify unauthenticated access returns 403.

## Open decisions

- Confirm if iframe-based MVP is acceptable, or if phase 1 must be native tRPC screens.
- Confirm private Wiki path if not `projekte/sharkord-desktop`.
- Confirm which Sharkord server URLs should be preloaded besides demo.
