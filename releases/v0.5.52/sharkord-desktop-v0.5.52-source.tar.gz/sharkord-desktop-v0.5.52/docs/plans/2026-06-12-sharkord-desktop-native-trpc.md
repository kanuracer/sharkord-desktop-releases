# Sharkord Desktop Native tRPC Implementation Plan

> **For Hermes:** Use subagent-driven-development skill to implement this plan task-by-task.

**Goal:** Build a clean Sharkord-native desktop client for Sharkord without iframe/webview embedding.

**Architecture:** Wails v3 hosts a React/TypeScript/Vite frontend. The frontend speaks Sharkord directly: HTTP `/info` and `/login`, then tRPC over WebSocket using the JWT token as `connectionParams`. UI state stays desktop-owned and renders native server rail, channel sidebar, and message pane.

**Tech Stack:** Wails v3, Go 1.25, React 19, TypeScript 6, Vite 8, `@trpc/client`.

---

## Decision

User explicitly chose native Sharkord-tRPC UI and accepted the extra work. iframe path is abandoned.

## Preflight facts

- Upstream Sharkord uses Bun/React/tRPC/Mediasoup.
- Client reference: `apps/client/src/lib/trpc.ts`.
- Auth reference: `apps/server/src/http/login.ts`.
- Join flow reference: `apps/client/src/features/server/actions.ts`.
- Message routes:
  - `messages.get.query({ channelId, limit })`
  - `messages.send.mutate({ channelId, content, files: [] })`
- Demo server `/info` works and allows free join.

## Implemented now

- Removed iframe path from app source.
- Added `frontend/src/sharkordClient.ts`.
- Added `frontend/src/sharkordTypes.ts`.
- Added native login/join/message API flow.
- Added native connect panel.
- Added native channel sidebar.
- Added native message pane and composer.
- Added source regression tests ensuring no iframe/webview and tRPC routes exist.
- Fixed long-message wrapping after screenshot QA.

## Verified

```text
npm test: 9/9 pass
npm run build: OK
go build ./...: OK
wails3 build: OK
```

Live browser QA:

- Native UI loads server info from `https://demo.sharkord.com`.
- Login succeeds with throwaway identity.
- `others.handshake` and `others.joinServer` succeed.
- Channels load: README, Discussions, Tech Support, Releases.
- README messages load via `messages.get`.
- Long messages wrap after CSS fix.
- No iframe/webview in source or visible UI.

## Not done yet

- Message send not live-tested on public demo to avoid spam.
- Realtime subscriptions not wired.
- Category grouping is not rendered yet; text channels shown flat.
- DMs not rendered yet.
- Voice not implemented.
- File uploads not implemented.
- Windows/macOS packaging not done in this phase.

## Next tasks

### Task 1: Realtime subscriptions

- Implement tRPC subscriptions for `messages.onNew`, `messages.onUpdate`, `messages.onDelete`.
- Deduplicate message IDs.
- Keep active channel message list updated.
- Add source tests for subscription route names.

### Task 2: Category grouping

- Render `join.categories` sorted by position.
- Show channels under categories sorted by position.
- Keep uncategorized channels in separate group.

### Task 3: Account/session storage

- Persist per-server identity and optional token if user chooses.
- Never persist password by default.
- Add logout/forget session.

### Task 4: Send message QA on private/test server

- Use own Sharkord test instance, not public demo.
- Send test message.
- Verify it appears after reload and via `messages.get`.

### Task 5: Windows build + QA

- Build on Win11 test client.
- Launch packaged app.
- Screenshot dark/light, login, channels, messages.
- Verify no clipped content.

### Task 6: Wiki maintenance

- Update private Wiki after each phase.
- Include tests, screenshots, blockers, and next work.
