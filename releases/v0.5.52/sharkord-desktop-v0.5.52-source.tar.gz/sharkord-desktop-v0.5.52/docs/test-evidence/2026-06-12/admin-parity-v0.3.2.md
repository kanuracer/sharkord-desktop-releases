# Sharkord Desktop Evidence — Admin Parity — v0.3.2

## Scope

User reported: all admin functions missing.

Implemented native desktop admin center under Settings.

## Admin APIs mapped from Sharkord server routers

- Server settings:
  - `others.getSettings.query`
  - `others.updateSettings.mutate`
- Categories:
  - `categories.add.mutate`
  - `categories.update.mutate`
  - `categories.delete.mutate`
- Channels:
  - `channels.add.mutate`
  - `channels.update.mutate`
  - `channels.delete.mutate`
- Roles:
  - `roles.getAll.query`
  - `roles.add.mutate`
  - `roles.update.mutate`
  - `roles.delete.mutate`
  - `roles.setDefault.mutate`
- Users:
  - `users.getAll.query`
  - `users.kick.mutate`
  - `users.ban.mutate`
  - `users.unban.mutate`
  - `users.delete.mutate`
  - `users.addRole.mutate`
  - `users.removeRole.mutate`
- Invites:
  - `invites.getAll.query`
  - `invites.add.mutate`
  - `invites.delete.mutate`
- Emojis:
  - `emojis.getAll.query`
  - `emojis.update.mutate`
  - `emojis.delete.mutate`

## UI added

Settings -> Admin panel with tabs:

- overview
- Settings
- Channels
- Roles
- Users
- Invites
- Emojis

## Speaking indicator

- Added `voice.onNewProducer.subscribe` and `voice.onProducerClosed.subscribe`.
- Audio producer marks user row with `.speaking` / `.speakingIndicator`.
- Note: this indicates active audio producer. True audio-level meter still needs full mediasoup audio pipeline and stats/level sampling.

## Local verification

```text
npm test: 27/27 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
```

## Browser visual QA

- Admin panel visible in Settings.
- Admin tabs visible: overview, Settings, Channels, Roles, Users, Invites, Emojis.
- No right-edge clipping after settings grid fix.
- Bottom content reachable by scrolling.

Screenshots:

- /root/.hermes/browser_screenshots/browser_screenshot_f6d7eff8.png
- /root/.hermes/browser_screenshots/browser_screenshot_907ce72a.png

## Windows verification

```text
WINDOWS_ADMIN_PARITY_OK
PE_SUBSYSTEM=2
VERSION="version": "0.3.2",
```
