# Sharkord Desktop Evidence — Complaint Fixes — 2026-06-12

## User complaints addressed

1. Server setup needs credentials immediately.
   - Add Server modal now includes Identity, Passwort, optional Server-Passwort.
   - Credentials are not stored in `localStorage`.
   - Backend API stores credentials encrypted:
     - Windows: DPAPI (`CryptProtectData` / `CryptUnprotectData`)
     - Linux/macOS: AES-GCM with a local 0600 key under app config.

2. Updates and appearance belong in settings.
   - Added `Einstellungen` tab.
   - Moved GitHub updater controls and theme controls into settings.
   - Chat header no longer has update panel/theme controls.

3. Only `general`/one channel visible.
   - Channel list now renders text + voice channel groups.
   - Channel type normalization handles Sharkord DTOs robustly.
   - Demo verification shows 4 text channels and 2 voice channels.

4. Missing usernames.
   - Message author rendering now uses `join.users` map as fallback.
   - Added right-side Members panel.
   - Demo verification shows message author `bruxo` and 10,989 member rows.

5. CMD window with WebView2 log.
   - Windows build now uses `-ldflags="-w -s -H windowsgui"`.
   - Windows PE subsystem verified as `2` (GUI), not console.
   - RDP screenshot shows Sharkord Desktop with no separate CMD/console window.

## Local verification

```text
go test ./...                                              OK
wails3 generate bindings                                  OK
npm test                                                   16/16 PASS
npm run build                                              OK
go build ./...                                             OK
wails3 build                                               OK
Linux binary SHA256                                        98d7b3446e7ce7c7755868478d7936851e8eb14e225a0cebbc22e016bdcfb244
Linux binary size                                          10343440
```

## Browser UI smoke

Settings DOM:

```json
{
  "settings": true,
  "updateInSettings": true,
  "updateOutsideSettings": false,
  "overflow": false
}
```

Add server modal DOM:

```json
{
  "hasModal": true,
  "clipped": false,
  "fields": ["Anzeigename", "Server-URL", "Identity", "Passwort", "Server-Passwort optional"]
}
```

Demo connection DOM:

```json
{
  "textChannels": ["⭐ README ⭐", "Releases", "Discussions", "Tech Support"],
  "voiceChannels": ["General Voice", "General Voice 2"],
  "authors": ["bruxo", "bruxo", "bruxo", "bruxo", "bruxo"],
  "membersCount": 10989,
  "overflow": false
}
```

Settings screenshot:

```text
/root/.hermes/browser_screenshots/browser_screenshot_3ae6c9d6.png
```

## Windows 11 testclient verification

Host: `10.0.0.115`

Final verification:

```text
npm test                                                   16/16 PASS
npm run build                                              OK
go test ./...                                             OK
go build -tags production -trimpath -buildvcs=false -ldflags="-w -s -H windowsgui" OK
EXE                                                       C:\Users\hermes\sharkord-desktop\bin\sharkord-desktop.exe
SIZE                                                      10723840
SHA256                                                    56223B504CCF5D6382DD25E68E17E53D872B62941641996B40998249F1D61A87
PE_SUBSYSTEM                                              2
go test ./... -run TestEncryptedCredentialStoreRoundTrip  OK
WINDOWS_FINAL_OK
```

Windows RDP screenshot — no CMD/console window visible:

```text
docs/test-evidence/2026-06-12/windows-rdp-no-cmd-settings-credentials.png
```

## Notes

- The first Windows script run still logged the expected `frontend/dist` embed failure because it ran `go test` before building the frontend. The final verification script fixed order and passed.
- Browser screenshot tool cropped the centered modal visually on ultra-wide viewport, but DOM geometry showed no real clipping (`clipped=false`, all fields present). CSS was hardened with modal `max-height`, `overflow:auto`, and viewport-safe width.
