# Sharkord Desktop Evidence — Discord-like Admin Context UX — v0.3.3

## User correction

Admin actions should not live in a generic Admin panel. They should behave like Discord:

- server actions from the server header menu
- channel actions from right-clicking a channel row
- user moderation/roles from right-clicking a user

## Changes

- Removed Settings Admin panel/tab from UI.
- Added `AdminContextMenu` overlay.
- Added context menu state:
  - server
  - channel
  - user
- Server header click/right-click opens server menu.
- Channel rows have `onContextMenu` actions.
- Member rows and voice-user rows have `onContextMenu` actions.
- User role assignment/removal is now in user context menu via `roleMenuItem`.

## Verified locally

```text
npm test: 27/27 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
```

## Browser QA

- Server context menu visible as compact overlay.
- Menu includes:
  - Kategorie erstellen
  - Text-Channel erstellen
  - Voice-Channel erstellen
  - Invite erstellen
  - Rollen aktualisieren
- Settings page has no Admin tab/panel.
- Settings page says admin actions live in Discord-like server/channel/user context menus.
- No clipping in menu/settings screenshots.

Screenshots:

- /root/.hermes/browser_screenshots/browser_screenshot_6c0a31df.png
- /root/.hermes/browser_screenshots/browser_screenshot_5009b03a.png

## Windows verification

```text
WINDOWS_CONTEXT_ADMIN_OK
PE_SUBSYSTEM=2
VERSION="version": "0.3.3",
```
