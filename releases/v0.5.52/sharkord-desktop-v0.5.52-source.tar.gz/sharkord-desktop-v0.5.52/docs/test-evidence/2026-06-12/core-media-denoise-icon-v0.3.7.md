# Sharkord Desktop Evidence — Core Media + Denoise + Icon — v0.3.7

## Request

- Add missing webclient core media features: webcam and screen share.
- Use Sharkord logo as program icon.
- Remove old denoise disclaimer text from visible settings.
- Replace brittle noise gate with stronger local denoise.

## Implemented

- Webcam producer:
  - `navigator.mediaDevices.getUserMedia({ video: ... })`
  - mediasoup `produce(... appData.kind='video')`
  - local preview tile
  - `voice.updateState({ webcamEnabled })`

- Screen share producer:
  - `navigator.mediaDevices.getDisplayMedia(...)`
  - mediasoup `produce(... appData.kind='screen')`
  - optional screen audio producer as `screen_audio`
  - local screen preview tile
  - `voice.updateState({ sharingScreen })`

- Remote media consumers:
  - audio: `audio`, `screen_audio`, `external_audio`
  - video: `video`, `screen`, `external_video`
  - remote video tiles in voice preview

- Local denoise:
  - `@sapphi-red/web-noise-suppressor`
  - RNNoise WASM AudioWorklet first
  - Speex WASM fallback
  - no requestAnimationFrame RMS gate copy

- Program icon:
  - `build/appicon.png`
  - `build/windows/icon.ico`
  - `build/darwin/icons.icns`
  - `wails_windows_amd64.syso`
  - runtime Wails `Icon: appIcon`

## Linux verification

```text
npm test: 33/33 pass
npm run build: OK
vite bundles rnnoise/speex worklets + wasm
Go test ./...: OK
go build ./...: OK
wails3 build: OK
```

## Browser verification

```text
hasKrisp=false
hasAdvancedNoise=true
hasCameraButton=true
hasScreenButton=true
hasAdminTab=false
overflowX=0
settingsVisible=true
userPanelButtons=5
```

## Windows verification

```text
WINDOWS_CORE_MEDIA_ICON_OK
PE_SUBSYSTEM=2
RESOURCE_RVA=45260800
RESOURCE_SIZE=1404
VERSION=0.3.7
```

Local PE resource parse of Windows EXE:

```text
PE32+ executable for MS Windows 6.01 (GUI), x86-64
Resource Directory [.rsrc]
ID 0x000003 RT_ICON
ID 0x00000e RT_GROUP_ICON
ID 0x000010 RT_VERSION
ID 0x000018 RT_MANIFEST
```

## macOS verification

```text
MACBOOK_UNREACHABLE
macOS build skipped until MacBook is reachable.
```
