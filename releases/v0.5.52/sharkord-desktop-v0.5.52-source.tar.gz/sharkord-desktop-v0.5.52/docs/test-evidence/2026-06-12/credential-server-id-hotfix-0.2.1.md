# Sharkord Desktop Evidence — Credential Server-ID Hotfix 0.2.1 — 2026-06-12

## User-visible bug

When adding a server with stored credentials, the app could show:

```json
{"message":"ungültige Server-ID","cause":{},"kind":"RuntimeError"}
```

## Root cause

The backend credential store rejected server IDs containing path separators (`/`, `\\`) or NUL. New generated UUID IDs are safe, but legacy/local states or URL-like IDs can contain slashes (for example old server IDs derived from `https://host`). `SaveServerCredentials(server.id, ...)` then failed before the server was saved.

## Fix

- Added `credentialStoreKey(serverID)`.
- Empty server IDs still fail.
- Safe IDs remain unchanged, preserving existing credentials.
- Unsafe/legacy URL-like IDs are deterministically encoded with `base64.RawURLEncoding` and prefix `id_`.
- Save/Load/Delete all use the same normalized key.

## Regression

```text
TestCredentialStoreAcceptsLegacyURLLikeServerIDs
```

Test case:

```text
https://sharkord.example.tld/server?id=42
```

Result:

```text
SaveServerCredentials OK
LoadServerCredentials OK
DeleteServerCredentials OK
```

## Local verification

```text
npm test                              18/18 PASS
npm run build                         OK
go test ./...                         OK
wails3 generate bindings              OK
go build ./...                        OK
wails3 build                          OK
```

Linux asset:

```text
sharkord-desktop-0.2.1-linux-amd64.tar.gz
size=4214453
sha256=4c2864b57d7db0029a98f8f283989a492efc19d8d98aa3d5bb061070c8b6ed21
```

## Windows 11 testclient verification

Host: `10.0.0.115`

```text
npm test                              18/18 PASS
npm run build                         OK
go test ./...                         OK
go test ./... -run TestCredentialStoreAcceptsLegacyURLLikeServerIDs -count=1 OK
go build -H windowsgui                OK
PE_SUBSYSTEM                          2
WINDOWS_021_CREDENTIAL_ID_FIX_OK
```

Windows asset:

```text
sharkord-desktop-0.2.1-windows-amd64.exe
size=10735104
sha256=256be8b7312ecd83f696e948d96610f7e2c5027fc313b7575da04c74b899b783
```
