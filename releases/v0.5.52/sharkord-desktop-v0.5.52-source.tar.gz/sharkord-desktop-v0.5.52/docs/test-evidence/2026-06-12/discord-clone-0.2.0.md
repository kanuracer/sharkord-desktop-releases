# Sharkord Desktop Evidence — Discord Clone Shell 0.2.0 — 2026-06-12

## Scope

User feedback: previous UI was not a real Discord experience. This pass replaces the card-like native client shell with a Discord-style desktop layout.

## Implemented

- Real Discord-like app shell:
  - far-left guild/server rail
  - channel column with server header
  - text + voice channel groups
  - Discord-like top channel bar
  - row-based message feed with avatars, usernames, timestamps
  - right Members sidebar with sticky `Members` header
  - bottom-left voice status + user/mute/deafen/settings controls
  - bottom composer with plus/action icons
- Settings remain separate from chat.
- Updater now uses dedicated release repository:
  - `https://github.com/kanuracer/sharkord-desktop-releases`
  - API: `https://api.github.com/repos/kanuracer/sharkord-desktop-releases/releases/latest`
- Version bumped to `0.2.0`.

## Browser visual QA

Connected against `https://demo.sharkord.com` with test identity.

DOM geometry:

```json
{
  "overflow": false,
  "shell": true,
  "guildRail": true,
  "channelColumn": true,
  "channelTopBar": true,
  "messageRows": 7,
  "memberHeader": "Members",
  "memberRows": 10992,
  "userPanel": true,
  "voiceStatusBar": true,
  "cols": "260px 1348px 240px"
}
```

Visual QA screenshot used temporary browser zoom only to fit the whole ultra-wide viewport into the screenshot crop. Code layout unchanged.

Screenshot:

```text
docs/test-evidence/2026-06-12/browser-discord-clone-0.2.0.png
```

Verified visually:

- guild rail visible
- channel column visible
- top channel bar visible
- message rows with avatars visible
- right Members sidebar visible
- bottom-left user/voice controls visible
- no obvious horizontal clipping

## Local Linux verification

```text
go test ./...                         OK
wails3 generate bindings              OK
npm test                              18/18 PASS
npm run build                         OK
go build ./...                        OK
wails3 build                          OK
Linux binary SHA256                   dfcacf5de2c5c4c5430526e799c1d393209cc778d4dfab77f5683cc94fff2fa6
Linux binary size                     10355728
```

## Windows 11 testclient verification

Host: `10.0.0.115`

```text
wails3 generate bindings              OK
npm install                           OK
npm test                              18/18 PASS
npm run build                         OK
go test ./...                         OK
go build -H windowsgui                OK
PE_SUBSYSTEM                          2
DPAPI credential roundtrip             OK
WINDOWS_DISCORD_FINAL_OK
```

Windows asset:

```text
C:\Users\hermes\sharkord-desktop\bin\sharkord-desktop.exe
SIZE=10735104
SHA256=9DA4FCFAF0DC54A231038D5E115EF8C7D169A056FD728658AA7DA7C974F61640
PE_SUBSYSTEM=2
```

Windows RDP screenshot:

```text
docs/test-evidence/2026-06-12/windows-rdp-discord-clone-0.2.0-front.png
```

Verified visually:

- Sharkord Desktop foreground
- Discord-style shell visible
- right Members sidebar visible
- no overlapping `ssh-vault2`
- no CMD console window

## Release assets

Release repo: `kanuracer/sharkord-desktop-releases`

```text
sharkord-desktop-0.2.0-linux-amd64.tar.gz
size=4214739
sha256=44af7e2add6f28f13b278754395d819c2676861a1e465e9b90b78ce21192428c

sharkord-desktop-0.2.0-windows-amd64.exe
size=10735104
sha256=9da4fcfaf0dc54a231038d5e115ef8c7d169a056fd728658aa7da7c974f61640
```
