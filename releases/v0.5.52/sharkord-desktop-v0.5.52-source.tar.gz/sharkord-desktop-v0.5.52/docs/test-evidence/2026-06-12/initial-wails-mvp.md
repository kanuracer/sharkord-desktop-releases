# Sharkord Desktop Evidence — 2026-06-12

## Build/Test

Commands executed:

```text
cd frontend && npm test
cd frontend && npm run build
go build ./...
go run github.com/wailsapp/wails/v3/cmd/wails3@v3.0.0-alpha.95 build
```

Results:

```text
node --test: 3/3 pass
Vite build: OK
Go build: OK
Wails3 build: OK
Linux binary: bin/sharkord-desktop
Binary type: ELF 64-bit x86-64
Binary size: 10129456 bytes
```

## Browser UI QA

Dev URL: `http://127.0.0.1:5173`

Checked:

- Dark theme shell renders.
- Light theme shell renders.
- Left server rail visible.
- Active Sharkord Demo server visible.
- Add-server modal opens.
- Modal fields/buttons visible.
- Modal not clipped.
- DOM shell overflow check: `documentElement.scrollWidth === innerWidth`, topbar/actions/frame bounds within viewport.

Screenshots captured by Hermes browser tool:

```text
/root/.hermes/browser_screenshots/browser_screenshot_a255c3bf.png
/root/.hermes/browser_screenshots/browser_screenshot_a6f4fd7b.png
/root/.hermes/browser_screenshots/browser_screenshot_2afcb6e2.png
/root/.hermes/browser_screenshots/browser_screenshot_bb95e685.png
```

Note: Vision flagged a clipped top-right control, but DOM measurement showed Sharkord Desktop shell had no horizontal overflow. The visible clipping appears to be inside/near the embedded Sharkord demo frame, not the shell controls.

## Wiki

Private Wiki page created:

```text
projekte/sharkord-desktop
```

API verification:

```text
id: 143
isPrivate: true
isPublished: true
markers: OK
content length: 7450
```

Unauthenticated access:

```text
403 https://wiki.kanuracer.eu/de/projekte/sharkord-desktop
403 https://wiki.kanuracer.eu/projekte/sharkord-desktop
```
