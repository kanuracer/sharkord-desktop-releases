# Sharkord Desktop Evidence — Layout Hotfix — v0.3.5

## User report

Attached screenshot showed the app layout shifted:

- Members panel appeared below/left instead of as right column.
- Chat composer appeared too high.
- Large empty right/bottom area.

## Root cause

`RemoteAudioStreams` was rendered as a direct grid child between `MessageArea` and `MembersPanel` after the voice-audio work. It consumed the 4th grid slot. `MembersPanel` became the next grid item and was auto-placed into a new row.

## Fix

- App shell now uses direct columns:
  - server rail
  - channel sidebar
  - chat/settings
  - members
- `RemoteAudioStreams` removed from layout flow with fixed zero-size positioning.
- Explicit grid columns pinned:
  - `serverRail` → 1
  - `channelColumn` → 2
  - `discordMain/settings` → 3
  - `membersPanel` → 4
- Regression test updated to prevent the old nested `discordContent` grid from returning.

## Browser geometry evidence

```text
viewport: 1920x930
serverRail: left=0 right=72 height=930
channelColumn: left=72 right=332 height=930
discordMain: left=332 right=1680 height=930
membersPanel: left=1680 right=1920 height=930
composer: top=862 bottom=930
remoteAudioStreams: position=fixed, width=0, height=0
horizontal overflow: 0
okMembersRight: true
okComposerBottom: true
```

## Local verification

```text
npm test: 29/29 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
```

## Windows verification

```text
WINDOWS_LAYOUT_HOTFIX_OK
PE_SUBSYSTEM=2
VERSION="version": "0.3.5",
```

## Logo

Logo preview exists at:

```text
docs/test-evidence/2026-06-12/sharkord-logo-preview.png
```

Description: neon blue-to-purple chat bubble outline with a stylized shark fin inside on a dark navy background.
