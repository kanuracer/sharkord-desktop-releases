# Sharkord Desktop Evidence — Logo + Noise Gate — v0.3.6

## Requested

- Use the generated Sharkord logo in the app.
- Add Discord/Krisp-like audio cleanup such as noise gate.

## Clarification

Krisp itself is proprietary and not bundled. Implemented:

- Browser/WebRTC `noiseSuppression`, `echoCancellation`, `autoGainControl` remain available.
- New local Discord-like Noise Gate before mediasoup `produce`.
- dB threshold slider persisted in audio settings.

## Implementation

Logo:

- Source preview remains: `docs/test-evidence/2026-06-12/sharkord-logo-preview.png`.
- Optimized app asset: `frontend/src/assets/sharkord-logo.png` (256x256, ~71 KB).
- Used in server rail brand mark and welcome/empty hero.

Noise Gate:

- Settings keys:
  - `noiseGateEnabled`
  - `noiseGateThreshold`
- Settings UI:
  - `Noise Gate` checkbox
  - `Schwellwert` dB slider (`-80` to `-20`)
- Voice pipeline:
  - `getUserMedia` raw mic stream
  - `AudioContext.createMediaStreamSource`
  - `AnalyserNode` RMS/dB measurement
  - `GainNode` opens/closes gate via `setTargetAtTime`
  - `createMediaStreamDestination`
  - gated track sent into mediasoup `producerTransport.produce`
  - cleanup closes AudioContext and animation frame on leave/rejoin

## Browser visual QA

```text
logos: 1 in connected/settings shell
settingsText includes Noise Gate + Schwellwert: true
noiseGateChecked: true
range text: Schwellwert -50 dB
settings horizontal overflow: 0
hasAdmin: false
```

Screenshot evidence: `/root/.hermes/browser_screenshots/browser_screenshot_963c9e75.png`

## Local verification

```text
npm test: 31/31 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
```

## Windows verification

```text
WINDOWS_LOGO_NOISE_OK
PE_SUBSYSTEM=2
VERSION="version": "0.3.6",
LOGO_BYTES=71214
```
