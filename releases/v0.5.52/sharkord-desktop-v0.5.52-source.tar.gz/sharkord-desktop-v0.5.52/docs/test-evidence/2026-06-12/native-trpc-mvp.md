# Sharkord Desktop Evidence — Native tRPC MVP — 2026-06-12

## Build/Test

Commands executed:

```text
cd frontend && npm test
cd frontend && npm run build
go build ./...
go run github.com/wailsapp/wails/v3/cmd/wails3@v3.0.0-alpha.95 build
```

Results:

```text
node --test: 9/9 pass
Vite build: OK
Go build: OK
Wails3 build: OK
Linux binary: bin/sharkord-desktop
Binary type: ELF 64-bit x86-64
Binary size: 10166320 bytes
```

## Native tRPC live smoke

Target:

```text
https://demo.sharkord.com
```

Verified:

- `GET /info` loaded Demo server name/description.
- Native login form rendered.
- Throwaway demo identity logged in successfully.
- tRPC WebSocket connected with JWT connection params.
- `others.handshake.query()` passed.
- `others.joinServer.query()` passed.
- Channels loaded: README, Discussions, Tech Support, Releases.
- `messages.get.query()` loaded README messages.
- Message send route exists in code: `messages.send.mutate()`.

Not performed:

- Live send on public demo, to avoid spam.

## Browser UI QA

Dev URL: `http://127.0.0.1:5173`

Checked:

- No iframe/webview source or visible embedded webpage.
- Native Discord-like left server rail.
- Native channel sidebar.
- Native message pane.
- Dark theme.
- Connected/online status.
- Long message wrapping after CSS fix.
- DOM overflow proof: `documentElement.scrollWidth === innerWidth`, message bubbles within viewport.

Screenshots captured by Hermes browser tool:

```text
/root/.hermes/browser_screenshots/browser_screenshot_0fb7f7ed.png
/root/.hermes/browser_screenshots/browser_screenshot_7de8b32f.png
/root/.hermes/browser_screenshots/browser_screenshot_42f88e35.png
```

Final screenshot verdict:

```text
Connected native Sharkord UI: PASS
Long messages wrap inside pane: PASS
No visible right-side text clipping/overflow: PASS
```

## Current limitations

- Realtime subscriptions not wired yet.
- Channel categories not grouped yet.
- DMs not rendered yet.
- Voice/file upload not implemented yet.
- Windows/macOS packaging still pending.
