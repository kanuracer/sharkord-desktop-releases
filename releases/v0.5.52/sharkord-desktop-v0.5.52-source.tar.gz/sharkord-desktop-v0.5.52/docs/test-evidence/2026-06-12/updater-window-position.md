# Sharkord Desktop Evidence — Updater + Window Position — 2026-06-12

## Scope

Implemented and tested:

- GitHub Release updater backend
- In-place update installer skeleton/flow
- Frontend update panel
- Wails-generated TypeScript bindings
- Window position/size persistence like ssh-vault2
- Windows testclient build and GUI launch through active RDP session

## GitHub updater implementation

Backend methods:

```text
Info()
GitHubRelease()
InstallUpdate(asset)
```

Release endpoint:

```text
https://api.github.com/repos/kanuracer/sharkord-desktop-releases/releases/latest
```

Private repo support:

```text
SHARKORD_DESKTOP_GITHUB_TOKEN
```

No token is embedded in the binary.

Current GitHub state observed:

```text
app repo: kanuracer/sharkord-desktop
app repo latest release: v0.1.1 (stale; do not use for updater)
release repo: kanuracer/sharkord-desktop-releases
release repo latest release: v0.3.4
release_assets:
  - SHA256SUMS.txt
  - sharkord-desktop-0.3.4-linux-amd64.tar.gz
  - sharkord-desktop-0.3.4-windows-amd64.exe
anonymous latest release: HTTP 404 if repo/token access is private
```

Expected without token while release repo remains private:

```text
Update-Check fehlgeschlagen: GitHub Release HTTP 404
```

Expected with `SHARKORD_DESKTOP_GITHUB_TOKEN`:

```text
Aktuell: 0.3.4 · GitHub: 0.3.4
```

## Linux/local gates

```text
go test ./...                         OK
wails3 generate bindings              OK
npm test                              12/12 PASS
npm run build                         OK
go build ./...                        OK
wails3 build                          OK
bin/sharkord-desktop                  ELF x86-64
binary-size=10327056
```

## Windows gates

Host:

```text
10.0.0.115
RDP 3389: open
SSH 22: open
RDP session: active
```

Toolchain:

```text
git version 2.54.0.windows.1
node v24.16.0
npm 11.13.0
go version go1.26.4 windows/amd64
```

Windows build/test:

```text
npm install                           OK
npm test                              12/12 PASS
npm run build                         OK
go test ./...                         OK
go build ./...                        OK
wails3 build                          OK
```

Windows artifact:

```text
C:\Users\hermes\sharkord-desktop\bin\sharkord-desktop.exe
SIZE=10704896
SHA256=2A187F2CE64B64C4CD6562C521F37630384FB3B5809925C05B09E28605DCD440
```

## GUI/RDP QA

A real RDP session was opened via FreeRDP/Xvfb to avoid the previous non-interactive WebView2 crash.

Session:

```text
hermes rdp-tcp#1 Aktiv
```

Launch method:

```text
Interactive Scheduled Task: SharkordDesktopSmoke
```

Process result:

```text
sharkord-desktop Responding=True
```

Screenshots:

```text
docs/test-evidence/2026-06-12/windows-rdp-updater-launch.png
docs/test-evidence/2026-06-12/windows-rdp-window-restore.png
```

Visual verification:

- native Sharkord Desktop window visible
- GitHub Updater panel visible
- no crash dialog
- dark mode visible
- native tRPC UI still present

## Window position persistence

Prefs file observed:

```text
C:\Users\hermes\AppData\Roaming\sharkord-desktop\window.json
```

Content after close:

```json
{
  "x": 0,
  "y": 16,
  "width": 1280,
  "height": 820,
  "valid": true
}
```

Relaunch screenshot showed app restored near the saved top-left position and no crash dialog.

## Notes

- Updater uses GitHub Releases, not iframe/browser update logic.
- Private repo means anonymous GitHub update checks return 404. For private update checks, launch with `SHARKORD_DESKTOP_GITHUB_TOKEN` or make releases public via a public release repo.
- `InstallUpdate` validates asset platform/name/size/version and starts a detached OS-specific in-place replacement script.
