# Sharkord Desktop Evidence — Webclient Parity Sprint 0.3.0 — 2026-06-12

## User-reported gaps

- Voicechannel beitreten did nothing.
- Bottom-left mute/deafen buttons did not work.
- Profile images/avatars were not rendered.
- Message edit/delete and webclient actions were missing.
- Connections were not established automatically.
- Servers could not be deleted directly.

## Implemented in 0.3.0

### Server management

- Added `autoConnect?: boolean` to stored servers.
- Add-server modal now has an auto-connect checkbox.
- Stored credentials + auto-connect now trigger `loginAndJoin()` automatically on server selection/start.
- Direct server delete button is visible in the server header, not only deep in settings.
- Deleting a server also deletes stored credentials via `DeleteServerCredentials()`.

### Voice

- Voice channel click now calls real Sharkord `voice.join.mutate({ channelId, state })`.
- Voice leave calls `voice.leave.mutate()`.
- Bottom-left mic/deafen buttons now maintain state and call `voice.updateState.mutate()` when joined.
- UI status shows joined voice channel and provides disconnect control.

Note: this is server-side voice presence/state join. Full audio transport still needs Mediasoup client device/producer/consumer flow.

### Messages

- Added client wrappers for:
  - `messages.edit.mutate`
  - `messages.delete.mutate`
  - `messages.togglePin.mutate`
  - `messages.toggleReaction.mutate`
- Message rows now show hover actions:
  - react 👍
  - pin/unpin
  - edit own/editable messages
  - delete
- Inline edit field saves through Sharkord edit route and reloads messages.

### Avatars

- Added `SharkordFile` DTO.
- Users now support `avatar: SharkordFile | null`.
- Added signed file URL builder matching webclient helper:
  - `${baseUrl}/public/${file.name}`
  - optional `?accessToken=...&expires=...`
- User panel, members list and message rows render avatar images with initials fallback.

## Automated verification

### Frontend/Linux

```text
npm test: 22/22 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
```

Linux binary:

```text
bin/sharkord-desktop
sha256=ab6bfc80a7027f95e37e063e43dcee046e156c0bea05da730bf5b2f389640a90
size=10368016
```

### Browser visual QA

- Auto marker visible in server header.
- Direct server delete button visible next to header.
- Auto-connect checkbox visible and checked in add-server modal.
- Bottom-left mic/deafen toggles switched to red/toggled state.

Screenshots:

- Auto-connect modal: browser state verified in snapshot.
- Delete + Auto + toggled bottom controls: `/root/.hermes/browser_screenshots/browser_screenshot_b86c6d21.png`

### Windows 11 testclient

```text
npm test: 22/22 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
go build -ldflags='-H windowsgui': OK
PE_SUBSYSTEM=2
WINDOWS_030_FEATURES_OK
```

Windows artifact:

```text
sharkord-desktop-0.3.0-windows-amd64.exe
sha256=9abde1aa2df6bb8e94c9e57ff0ba069dac75135624edc707fb0fa4d67f7abe1c
size=20666368
```

## Release assets prepared

```text
sharkord-desktop-0.3.0-linux-amd64.tar.gz
sha256=4c076164bb6541d588c62be84493dd871663f0ab3cf94d8bd6c1a2bfdad2e5e8
size=4217479

sharkord-desktop-0.3.0-windows-amd64.exe
sha256=9abde1aa2df6bb8e94c9e57ff0ba069dac75135624edc707fb0fa4d67f7abe1c
size=20666368
```

## Remaining true webclient-parity work

- Full Mediasoup audio/WebRTC transport:
  - `Device.load(routerRtpCapabilities)`
  - `voice.createProducerTransport`
  - `voice.connectProducerTransport`
  - `getUserMedia({ audio: true })`
  - `producerTransport.produce`
  - remote `getProducers`/`consume`/consumer transports/audio elements
- Full reactions/emoji picker, threads/replies, attachments/files, permissions-aware action hiding.
