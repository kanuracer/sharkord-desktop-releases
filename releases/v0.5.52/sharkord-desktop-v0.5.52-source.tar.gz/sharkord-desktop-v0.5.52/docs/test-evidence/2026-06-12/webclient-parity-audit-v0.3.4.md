# Sharkord Desktop — Webclient Parity Audit — v0.3.4

## Trigger

User reported native desktop voice did not actually transmit audio and audio-device settings were missing. User also requested all Webclient functionality be brought into the desktop client.

## Root cause

Desktop v0.3.3 implemented only voice presence/state:

- `voice.join`
- `voice.leave`
- `voice.updateState`
- participant events
- producer open/close speaking indicator

It did **not** implement the Webclient mediasoup audio pipeline:

- no `mediasoup-client` Device
- no producer transport
- no microphone `getUserMedia`
- no `voice.produce`
- no consumer transport
- no `voice.consume`
- no remote audio playback
- no device enumeration / speaker routing

## Implemented in v0.3.4

### Voice transport

Desktop now includes `frontend/src/voiceEngine.ts`:

- Creates `mediasoup-client` `Device` from `voice.join` router RTP capabilities.
- Creates producer transport via `voice.createProducerTransport`.
- Connects producer transport via `voice.connectProducerTransport`.
- Captures microphone via `navigator.mediaDevices.getUserMedia`.
- Produces microphone audio via `voice.produce` with appData kind `audio`.
- Creates consumer transport via `voice.createConsumerTransport`.
- Connects consumer transport via `voice.connectConsumerTransport`.
- Loads existing producers via `voice.getProducers`.
- Consumes remote audio/screen-audio/external-audio via `voice.consume`.
- Emits remote `MediaStream`s and renders hidden `<audio>` elements in React.
- Cleans up producers, consumers, tracks, streams, and transports on leave/server switch.

### Audio devices

Settings now includes `Audiogeräte`:

- Microphone select from `enumerateDevices()` `audioinput`.
- Speaker select from `enumerateDevices()` `audiooutput`.
- Playback routing via `HTMLAudioElement.setSinkId` where supported.
- Echo Cancellation toggle.
- Noise Suppression toggle.
- Auto Gain Control toggle.
- Settings persisted in localStorage key `sharkord-desktop:audio-devices:v1`.

### Events

Desktop consumes Webclient-equivalent voice events:

- `voice.onJoin`
- `voice.onLeave`
- `voice.onUpdateState`
- `voice.onNewProducer`
- `voice.onProducerClosed`

`onNewProducer` now starts consumers for remote audio instead of only setting the speaking indicator.

## Verified parity areas already present before/with v0.3.4

| Area | Desktop status |
| --- | --- |
| Server rail / switch servers | Implemented |
| Dark/light mode | Implemented |
| Login / stored credentials | Implemented |
| tRPC WebSocket Sharkord auth/join | Implemented |
| Text channels/messages | Implemented |
| Message send | Implemented |
| Message edit/delete/pin/reaction | Basic implemented |
| Channels/categories realtime events | Implemented |
| User realtime events | Implemented |
| Voice presence + mute/deafen | Implemented |
| Voice real audio send/receive | Implemented in v0.3.4 |
| Audio device settings | Implemented in v0.3.4 |
| Admin actions | Discord-like context menus |
| Roles on user | User context menu |
| Invites | Server context menu create |

## Remaining Webclient-heavy areas from audit

These are the large Webclient modules still not fully rebuilt in native desktop UI:

- File/message attachments upload and preview parity.
- Rich TipTap composer parity: mentions, commands, markdown/rich editing, drafts.
- Threads and thread sidebar.
- Full pinned-message popover/search dialogs.
- Full user profile/settings screens: avatar/banner upload, password, notification prefs.
- Full server settings screens: logo upload, storage metrics, plugins, marketplace.
- Full channel/category settings overlays including permission overrides.
- Full emoji manager upload/update flows.
- Full moderation view/sheets and server activity pages.
- Webcam/screen-share/external stream video UI parity.
- Volume-per-user controls / microphone test meter from Webclient.

## Verification

Linux local:

```text
npm test: 29/29 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
```

Browser visual QA:

```text
Audiogeräte settings: visible
Mikrofon select: visible
Lautsprecher select: visible
Echo Cancellation: visible
Noise Suppression: visible
Auto Gain Control: visible
No Admin panel: OK
No update-button clipping: OK
```

Windows verification:

```text
WINDOWS_VOICE_AUDIO_OK
PE_SUBSYSTEM=2
VERSION="version": "0.3.4",
```
