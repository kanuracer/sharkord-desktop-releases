# Sharkord Desktop Evidence — Webclient Parity Pass — 2026-06-12

## User issue

- Voice join worked, but the joined user was not shown below the voice channel.
- The desktop client still missed core live webclient behavior.
- Bundled demo server should be removed.
- Desktop sounds were missing.
- New logo requested as preview only, not built in yet.

## Implemented

### Removed demo server

- Removed bundled initial server behavior.
- App now starts with empty onboarding state:
  - no prefilled server
  - no demo URL
  - no visible demo wording
  - add-server flow remains available from rail and empty state

### Voice presence / participant rendering

- Added `voiceMap` DTO support from `others.joinServer`.
- Added local `voiceUsersByChannelId` derived view.
- Added visible `VoiceUserRow` below each voice channel.
- Shows:
  - avatar
  - display name
  - `(du)` marker for own user
  - mic/deafen icons
  - webcam/screen flags when present

### Realtime subscriptions added

Desktop now wires Sharkord webclient-style tRPC subscriptions:

- `voice.onJoin`
- `voice.onLeave`
- `voice.onUpdateState`
- `messages.onNew`
- `messages.onUpdate`
- `messages.onDelete`
- `messages.onTyping`
- `users.onJoin`
- `users.onLeave`
- `users.onUpdate`
- `channels.onCreate`
- `channels.onUpdate`
- `channels.onDelete`
- `categories.onCreate`
- `categories.onUpdate`
- `categories.onDelete`

### Message/live behavior

- Incoming messages update active channel without manual reload.
- Updated/deleted messages are applied live for the open channel.
- Typing indicator added.
- User/channel/category changes update local UI stores.

### Sounds

Added lightweight desktop SFX via Web Audio oscillator, no external assets required:

- `message_received`
- `message_sent`
- `server_connected`
- `server_disconnected`
- `own_user_joined_voice_channel`
- `own_user_left_voice_channel`
- `own_user_muted_mic`
- `own_user_unmuted_mic`
- `own_user_muted_sound`
- `own_user_unmuted_sound`
- `remote_user_joined_voice_channel`
- `remote_user_left_voice_channel`

### Logo preview

Generated preview only. Not integrated into app assets.

- `docs/test-evidence/2026-06-12/sharkord-logo-preview.png`

## Verification

### Linux / local

```text
npm test: 25/25 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
```

### Browser visual QA

```text
No-server onboarding visible
No demo server wording visible
Add-server modal visible
Auto-connect checkbox checked by default
Modal top/bottom visible after CSS fix
No obvious layout issue
```

Screenshot:

- `browser_screenshot_a507fd76.png`

### Windows 11 test client

```text
npm test: 25/25 pass
npm run build: OK
go test ./...: OK
wails3 install/build: OK
bin/sharkord-desktop.exe PE_SUBSYSTEM=2
WINDOWS_WAILS_BIN_GUI_OK
```

Note: plain `go build ./...` can leave a root `sharkord-desktop.exe` with PE subsystem 3. The Wails production binary is `bin/sharkord-desktop.exe` and correctly uses subsystem 2.

## Remaining known gaps

Full audio media transport is still separate work:

- mediasoup-client Device
- producer/consumer transports
- microphone `getUserMedia`
- remote audio playback
- reconnect/cleanup behavior for media streams

This pass fixes presence/state visibility and core live webclient subscriptions, not full voice audio streaming.
