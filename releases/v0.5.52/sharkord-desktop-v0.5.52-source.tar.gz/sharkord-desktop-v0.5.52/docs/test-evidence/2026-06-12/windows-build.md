# Sharkord Desktop Windows Build Evidence — 2026-06-12

Host:

```text
HERMES-TEST / 10.0.0.115
User: hermes
```

Toolchain installed/verified:

```text
git version 2.54.0.windows.1
go version go1.26.4 windows/amd64
node v24.16.0
npm 11.13.0
WebView2 Runtime 149.0.4022.62
```

Source transfer:

- GitHub clone failed because Windows testclient has no GitHub creds for private repo.
- Source was copied from Linux via `tar.gz` over SSH/SCP.

Build/test commands run on Windows:

```text
npm install
npm test
npm run build
go build ./...
go run github.com/wailsapp/wails/v3/cmd/wails3@v3.0.0-alpha.95 build
```

Results:

```text
npm install: OK
npm test: 9/9 pass
npm run build: OK
go build ./...: OK
wails3 build: OK after adding windows:build task
```

Artifact:

```text
C:\Users\hermes\sharkord-desktop\bin\sharkord-desktop.exe
Size: 10596864 bytes
```

Launch smoke:

Attempted via SSH/PowerShell while RDP session was disconnected.

Result:

```text
exit=1
fatal: GetCursorPos failed
```

Diagnosis:

- WebView2 runtime is installed.
- No Application EventLog crash entry found.
- `quser` showed `hermes` session ID 6 as disconnected (`Getr.`).
- Wails/WebView UI cannot start correctly in this non-interactive/disconnected desktop state.

Next Windows QA:

1. Connect via RDP to `10.0.0.115` as `hermes`.
2. Launch `C:\Users\hermes\sharkord-desktop\bin\sharkord-desktop.exe` inside the active desktop session.
3. Verify dark/light, native login, channels, messages.
4. Capture screenshot evidence.
