# Sharkord Desktop Evidence — Local voice diagnostics — v0.3.19

## Purpose

Historical evidence for temporary voice/video diagnostics. Remote live-debug HTTP posting and the private collector endpoint have since been removed from the app.

## Current status

- Desktop keeps only local, redacted diagnostic logging in the app config logs directory.
- No private collector URL is stored here.
- No app code should expose a remote diagnostic-posting method or default endpoint.

## Verification at the time

```text
go test ./... OK
npm test -- --runInBand OK, 41/41
npm run build OK
wails3 build OK
```
