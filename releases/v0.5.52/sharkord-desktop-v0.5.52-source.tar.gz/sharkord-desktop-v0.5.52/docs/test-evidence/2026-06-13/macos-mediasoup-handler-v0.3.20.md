# Sharkord Desktop Evidence — macOS mediasoup WebKit handler — v0.3.20

## LiveLog root cause

Session: `254c2770-7dcd-4e56-b33c-d9a2cf48593b`

Observed sequence:

```text
media.permission.preflight.ok microphone audioTracks=1
media.permission.preflight.ok camera videoTracks=1
media.permission.preflight.ok screen videoTracks=1
voice.join.start channelId=3
voice.join.ok hasRouterRtpCapabilities=true
voice.init.start
voice.media.initForChannel.error: device not supported
```

Conclusion:

- macOS permissions are OK.
- Server `voice.join` succeeds.
- Failure happens before producer/consumer transports.
- `mediasoup-client` auto-detection fails in Wails macOS WebKit because the embedded user-agent can be AppleWebKit without normal Safari markers.

## Fix

`frontend/src/voiceEngine.ts` now resolves Apple WebKit on Apple platforms to mediasoup handler `Safari12` and creates:

```ts
new Device({ handlerName })
```

Non-Apple/non-WebKit remains auto-detected.

## Regression

Added frontend source regression:

```text
macOS Wails WebKit forces mediasoup Safari12 handler when auto-detection fails
```

## Verification

```text
npm test -- --runInBand: 42/42 pass
npm run build: OK
go test ./...: OK
wails3 build: OK
```

