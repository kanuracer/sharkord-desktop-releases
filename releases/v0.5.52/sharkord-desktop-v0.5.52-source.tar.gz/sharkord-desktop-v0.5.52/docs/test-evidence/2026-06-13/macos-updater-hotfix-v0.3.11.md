# Sharkord Desktop Evidence — macOS Updater Hotfix — v0.3.11

## User report

macOS in-app update failed with:

```text
Installation fehlgeschlagen: {"message":"macOS In-Place-Update wird aktiviert, sobald macOS-Build-Artefakte vorliegen", ...}
```

## Root cause

The release had darwin `.zip` artifacts, and asset selection already accepted them, but `AppService.InstallUpdate` still had a hard-coded `runtime.GOOS == "darwin"` stub returning that error before any apply script ran.

Important consequence: installed `v0.3.10` cannot update itself to this fix on macOS because the broken updater code is what handles the click. The `v0.3.11` macOS app must be installed manually once; future macOS in-place updates then use the implemented updater.

## Fix

- Added `validateDarwinUpdateArchive()` for `.zip` assets:
  - rejects unsafe paths/path traversal
  - rejects symlinks
  - requires exactly one `.app`
  - requires one `.app/Contents/MacOS/sharkord-desktop` binary
- Added `currentMacOSAppRoot()` to locate the running `.app` bundle from executable path.
- Replaced darwin stub with detached `apply-update-macos.sh`:
  - waits for app process to exit
  - verifies SHA256 again
  - extracts with `/usr/bin/ditto -x -k`
  - verifies codesign on extracted `.app`
  - backs up current `.app`
  - swaps app bundle
  - restarts via `/usr/bin/open -n`
  - restores backup on move failure
- Added regression test ensuring old stub string cannot return.
- Added Go tests for valid/invalid macOS updater ZIPs and `.app` root detection.

## Gates

Initial gates:

```text
go test ./...: OK
npm test: 38/38 pass
npm run build: OK
```

Full release gates before source tag:

```text
go test ./...: OK
npm test: 38/38 pass
npm run build: OK
go build ./...: OK
wails3 build: OK
```
