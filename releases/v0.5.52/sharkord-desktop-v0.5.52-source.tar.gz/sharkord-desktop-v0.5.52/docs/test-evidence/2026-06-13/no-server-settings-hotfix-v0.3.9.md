# Sharkord Desktop Evidence — No-server Settings Hotfix — v0.3.9

## Problem

User reported:

- Without any server configured, Settings were not reachable.
- Light/Dark mode control was shown on the start/onboarding page.

## Fix

- Added a Settings gear to the left server rail for the no-server state.
- No-server shell now renders `SettingsPanel` when the gear is active, even with `activeServer=null`.
- Removed the Light/Dark theme switch from `NoServersEmptyState`.
- Appearance/theme controls remain inside Settings → Darstellung.
- Separated rail settings hover from active styling so hover does not look like an active settings state.

## Browser QA

Start page after fix:

```text
hasHero: true
startHasThemeSwitch: false
hasSettingsButton: true
buttons: ["Server hinzufügen", "Einstellungen", "Server hinzufügen"]
empty: 72..1536 width=1464
hero center: 804
main center: 804
deltaHeroVsMain: 0
overflowX: 0
settings button class: "railSettingsButton "
settings hover background: rgb(53, 55, 60)
```

Settings without server after click:

```text
hasSettings: true
hasAppearance: true
hasThemeSwitch: true
startHasThemeSwitch: false
settings: 72..1536 width=1464
overflowX: 0
buttons: ["Server hinzufügen", "Einstellungen", "Darstellung", "Updates", "Server", "Dark", "Light", "Prüfen", "Inplace installieren"]
```

Screenshot after Settings click:

```text
/root/.hermes/browser_screenshots/browser_screenshot_d822b8e8.png
```

Screenshot after returning to start:

```text
/root/.hermes/browser_screenshots/browser_screenshot_16e6f0e3.png
```

## Gates

```text
npm test: 35/35 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
```
