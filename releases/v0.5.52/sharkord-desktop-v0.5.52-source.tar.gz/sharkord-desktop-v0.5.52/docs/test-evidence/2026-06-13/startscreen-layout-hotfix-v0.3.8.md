# Sharkord Desktop Evidence — Startscreen Layout Hotfix — v0.3.8

## Problem

User reported the no-server start screen looked distorted in `Bildschirmfoto_2026-06-13_um_02.18.34.png`.

Live DOM before the fix showed the empty state was rendered in the old 260px channel column instead of the main area:

```text
viewport: 1536x771
rail: 0..72
empty: 72..332 width=260
hero center: 202
expected main center: 804
deltaHeroVsMain: -602
overflowX: 0
```

## Root cause

`.appShell.discordShell` had higher specificity than `.noServerShell`, so the 4-column Discord grid stayed active:

```css
grid-template-columns: 72px 260px minmax(0,1fr) 240px
```

`NoServersEmptyState` then fell into grid column 2, the 260px channel/sidebar column.

## Fix

- Changed selector to `.appShell.discordShell.noServerShell` so the no-server layout wins.
- Pinned `.noServersEmptyState` to `grid-column: 2` and `width: 100%`.
- Changed `.welcomeHero` to `width: min(560px, 100%)` so the paragraph is not squeezed.
- Added regression test: `no-server start screen centers hero in main area instead of channel column`.

## Browser QA after fix

```text
viewport: 1536x771
rail: 0..72
empty: 72..1536 width=1464
hero: 524..1084 width=560
paragraph: 548..1060 width=512
expectedMainCenter: 804
deltaHeroVsMain: 0
overflowX: 0
emptyCoversMain: true
```

Visual screenshot after fix:

```text
/root/.hermes/browser_screenshots/browser_screenshot_24b0ab2d.png
```

## Gates

```text
npm test: 34/34 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
```
