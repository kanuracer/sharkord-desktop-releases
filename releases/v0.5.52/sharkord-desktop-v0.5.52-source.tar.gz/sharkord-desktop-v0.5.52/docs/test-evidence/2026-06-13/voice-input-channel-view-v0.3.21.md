# Sharkord Desktop Evidence — Voice input indicator + web-style voice channel view — v0.3.21

## User report

- macOS voice now connects.
- Missing visible voice input indicator on macOS.
- Voice channel main view should be closer to the web version instead of a large call-tile takeover.

## Fix

### Local voice input indicator

`frontend/src/voiceEngine.ts`

- Added `onLocalVoiceInput` callback.
- Added `startLocalInputMeter()` using Web Audio `AnalyserNode#getByteTimeDomainData` on the processed mic stream.
- Emits `{ level, speaking }` every 120ms.
- Resets meter to level `0` on mic stop, voice leave, voice media rebuild, and server switch.
- Uses local mic signal, so it works even if the Sharkord server does not echo own speaking events back to the client.

`frontend/src/App.tsx` / `frontend/src/style.css`

- Added `localVoiceInput` state.
- Added `VoiceInputMeter` component.
- Shows active input in:
  - bottom-left user panel,
  - own user row in the voice-channel participant list,
  - main voice-channel overview.
- Speaking state adds a green ring to the own avatar and a green meter fill.

### Web-style channel view

- Voice main pane now renders `voiceChannelOverview` with centered mic icon, channel title, joined status, camera button, and screen-share button.
- Video/screen previews remain available but are moved into a compact `voiceMediaStrip`, avoiding the huge full-call tile takeover seen in the macOS screenshot.
- Text composer remains visible with `Erst Text-Channel auswählen...`, matching the web version's channel context behavior.

## Regression tests added

```text
native client shows a local voice input indicator even when the server does not echo own speaking events
voice channel view matches the web-style channel overview instead of a full-call tile takeover
```

## Verification

Linux build host:

```text
frontend npm test -- --runInBand: 44/44 pass
frontend npm run build: OK
Go test ./...: OK
Linux binary: ELF 64-bit x86-64, stripped
Windows binary: PE32+ GUI x86-64
```

macOS build host:

```text
macOS 26.5.1 arm64
wails3 v3.0.0-alpha.96
frontend tests: 44/44 pass
frontend build: OK
go test ./...: OK
codesign --verify --deep --strict: OK
Mach-O 64-bit executable arm64
Info.plist CFBundleShortVersionString: 0.3.21
MACOS_RELEASE_OK VERSION=0.3.21 ARCH=arm64
```

## Release assets

```text
sharkord-desktop-0.3.21-linux-amd64.tar.gz
sharkord-desktop-0.3.21-windows-amd64.exe
sharkord-desktop-0.3.21-darwin-arm64.zip
SHA256SUMS.txt
```

## Notes

- macOS linker warns that some object files were built for newer macOS versions than the deployment target. Build and codesign still completed successfully.
- No live visual QA screenshot was captured from the packaged app in this run; verification is source/regression/build/codesign based.
