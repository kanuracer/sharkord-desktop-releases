# Sharkord Desktop Evidence — Voice/Media macOS Hotfix — v0.3.10

## User report

macOS screenshot showed:

- User was visibly listed in `General Voice`.
- Center pane still said `Voice beitreten` / `Voice bereit`.
- Debug copy `Join ruft Sharkord voice.join` was visible.
- Camera and screen buttons were visible but had no useful effect.

## Root cause

`voice.join` could succeed server-side, then `SharkordVoiceEngine.init()` failed during microphone capture (`device no...`). The catch path treated the whole join as failed and never set `currentVoiceChannelId`, so UI stayed in pre-join state while server membership already showed the user in the channel.

macOS release bundle also lacked privacy usage strings for microphone/camera/screen capture, making media prompts/capture fragile.

## Fix

- Server-side `voice.join` success now immediately marks the local user as joined.
- Microphone capture failure is non-fatal: voice remains connected and camera/screen can still initialize through mediasoup transports.
- Media setup failure is reported as `Voice verbunden · Medien nicht bereit`, not as voice join failure.
- Center voice panel uses `isSelectedVoiceJoined`, including server-side voice membership.
- Removed user-facing debug string `Join ruft Sharkord voice.join`.
- Removed green Join/Joined pills from voice channel rows; connected channel gets a small icon only.
- Added repo macOS release script with `NSMicrophoneUsageDescription`, `NSCameraUsageDescription`, `NSScreenCaptureUsageDescription`.

## Regression tests

```text
npm test: 37/37 pass
```

Added tests:

- fatal mic startup cannot break voice joined state
- server-side voice membership renders joined UI
- no debug `voice.join` copy
- no Discord-breaking Join pill
- macOS bundle declares mic/camera/screen privacy keys

## Build gates

```text
npm test: 37/37 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
```

Cross-platform release gates pending after source tag.
