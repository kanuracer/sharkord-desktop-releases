# Sharkord Desktop Evidence — Voice Media Rebuild Hotfix — v0.3.17

## User report

```text
Voice-Medien noch nicht bereit · Producer-Transport konnte nicht erstellt werden
video weiterhin nicht funktionsfähig
```

## Root cause

After initial media setup failed, the user remained joined on the Sharkord server. Camera/screen retry called `joinSelectedVoice(currentVoiceChannel)`, which called `voice.join` again for the same channel. Sharkord rejects that state with `User already in a voice channel`. The app then overwrote the real error with the generic Producer-Transport message.

## Fix

- Store `routerRtpCapabilities` returned by the successful `voice.join`.
- Add `initVoiceMediaForCurrentChannel()` for transport-only rebuilds.
- `prepareVoiceMediaIfNeeded()` now rebuilds mediasoup transports using existing voice membership instead of rejoining.
- Preserve actual media setup errors in `lastVoiceMediaErrorRef` and show them in status.
- Clear cached voice media state on server disconnect/leave.
- Make macOS updater app-root test portable so Windows release verification can run full Go tests.

## Verification

```text
npm test -- --runInBand: 40/40 pass
go test ./...: OK on Linux and Windows
npm run build: OK
wails3 build: OK on Linux
Windows release build: OK, PE subsystem=2
```
