# Sharkord Desktop Evidence — Voice Producer Transport Hotfix — v0.3.14

## User report

macOS reported after joining voice:

```text
Kamera fehlgeschlagen: Producer transport fehlt
Bildschirmfreigabe fehlgeschlagen: Producer transport fehlt
```

## Root cause

The app marked the user as joined after `voice.join`, but kept a `SharkordVoiceEngine` instance even when mediasoup init failed before the send/producer transport existed. Camera/screen buttons then called `startWebcamStream()` / `startScreenShareStream()` on that half-initialized engine.

Release packaging also needed fixes found before upload:

- Fresh git archives need Wails app bindings generated before frontend builds.
- Windows fresh build needs `wails_windows_amd64.syso` regenerated before `go build`, otherwise ProductVersion is empty.
- macOS release script needed to honor its output directory argument.

## Fix

- Added `SharkordVoiceEngine.isReadyToProduce()`.
- Added `voiceMediaReady` app state.
- Join sets media ready only after send transport exists.
- Failed media init closes/discards the half-initialized engine.
- Camera/screen clicks no longer hit a missing producer transport.
- If media transport is not ready while voice membership exists, the click attempts one media-transport rebuild via `joinSelectedVoice(currentVoiceChannel)` and continues only when send transport exists.
- If rebuild still fails, status becomes user-facing:

```text
Voice-Medien noch nicht bereit · Producer-Transport konnte nicht erstellt werden
```

## Regression

```text
camera and screen do not run against a half initialized voice engine without send transport: RED before fix, GREEN after fix
```

## Gates

```text
npm test: 39/39 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
fresh archive Linux build: pending
fresh archive Windows build: pending
fresh archive macOS build: pending
```
