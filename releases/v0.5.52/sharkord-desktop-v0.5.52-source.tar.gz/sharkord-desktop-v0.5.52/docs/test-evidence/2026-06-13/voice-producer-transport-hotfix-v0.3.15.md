# Sharkord Desktop Evidence — Voice Producer Transport Hotfix — v0.3.15

## User report

```text
Kamera fehlgeschlagen: Producer transport fehlt
Bildschirmfreigabe fehlgeschlagen: Producer transport fehlt
```

## Root cause

The app marked the user as joined after `voice.join`, but could keep a `SharkordVoiceEngine` instance even when mediasoup init failed before the send/producer transport existed. Camera/screen buttons then called produce methods on that half-initialized engine.

## Fix

- Added `SharkordVoiceEngine.isReadyToProduce()`.
- Added `voiceMediaReady` app state.
- Join sets media ready only after send transport exists.
- Failed media init closes/discards the half-initialized engine.
- Camera/screen clicks no longer hit missing producer transport directly.
- If voice membership exists but media transport is missing, camera/screen click attempts one media-transport rebuild and continues only when send transport exists.
- User-facing fallback status:

```text
Voice-Medien noch nicht bereit · Producer-Transport konnte nicht erstellt werden
```

## Release packaging fixes included

- Fresh git archive builds generate Wails app bindings before frontend build.
- Windows fresh builds regenerate SYSO before `go build`.
- Windows manifest/resource versions use 4-component form (`0.3.15.0`).
- macOS release script honors output dir argument.

## Gates

```text
npm test: 39/39 pass
npm run build: OK
go test ./...: OK
go build ./...: OK
wails3 build: OK
```

## Notes

`v0.3.12`/`v0.3.13`/`v0.3.14` were superseded during release verification before final asset publication. Final public release is `v0.3.15`.
