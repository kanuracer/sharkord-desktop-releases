## Parity-Audit Desktop vs Webclient — aktualisiert 2026-06-19

Quelle/Stand:

- Desktop: `kanuracer/sharkord-desktop` v0.5.0-Arbeitsstand.
- Webclient/Server: `sharkord/sharkord` `d8def12`, Version `0.0.22`.
- Sharkord-Fork: zusätzliche `dms.delete`-Route geprüft.
- Methode: Code-Scan von Desktop `frontend/src/sharkordClient.ts`, `frontend/src/App.tsx`, `frontend/src/i18n.ts`, `frontend/src/voiceEngine.ts` gegen Webclient `apps/client/src` und Server-Router `apps/server/src/routers`.

### Kurzfazit

Phase-1 Core/WebUI-Parität ist umgesetzt. Desktop deckt alle 124 Original-Server-Routen des geprüften upstream Stands und alle 125 Routen des geprüften Fork-Stands über native Wrapper oder UI-Flows ab. Größere Produktbereiche wie Rich-Composer-Feinschliff, Renderer-Details, Plugin-Slot-Tiefe und native Capture-Optimierung können weiter wachsen, blockieren Phase 1 aber nicht mehr.

| Bereich | Aktueller Desktop-Status | Webclient-Iststand / Delta | Prio |
|---|---:|---|---:|
| Server-Rail / Serverwechsel | umgesetzt | Serverwechsel, Auto-Connect, Invite-Link-Normalisierung und persistierte Verbindungen vorhanden | niedrig |
| Channel-Sidebar + Kategorien | umgesetzt | Kategorien/Text/Voice, Collapse, Context-Menüs und Drag&Drop-Reorder vorhanden | niedrig |
| Textnachrichten Basis | umgesetzt | Laden/Senden/Edit/Delete, Zielseiten-Laden, Typing, Pins, Reactions vorhanden | niedrig |
| Uploads / Attachments | weitgehend umgesetzt | Temporäre Uploads, File-IDs beim Senden, Storage-Browser und Cleanup-Pfade vorhanden; Preview-UX kann wachsen | mittel |
| Direct Messages | umgesetzt | DM-Liste, User-Suche, `dms.open`, `dms.get`, DM-Unreads und `dms.delete`-Kontrolle vorhanden | niedrig |
| Replies / Threads | umgesetzt | Reply-Auswahl, Thread-Panel, Thread-Compose, Thread-Events und `messages.getThread`-Route vorhanden | niedrig |
| Suche | umgesetzt | Globale Message/File-Suche mit Jump-to-message vorhanden | niedrig |
| Channel Permissions | umgesetzt | Rollen/User-Overrides mit Allow/Deny/Delete über offizielle Routen vorhanden | niedrig |
| Rich Composer | weitgehend umgesetzt | Rich-Text-Serialisierung, Mentions, Emoji-Picker, Attachments, Replies und Slash/Plugin-Command-Anbindung vorhanden; TipTap-Detailparität kann wachsen | mittel |
| Message Rendering | weitgehend umgesetzt | Safe Rich Tokens, Mentions, Links, Embeds/Media/File Cards, Reactions und Reply-Kontext vorhanden; Renderer-Overrides können wachsen | mittel |
| Pins | umgesetzt | `getPinnedMessages`-Popover + Jump-to-message und Pin toggle vorhanden | niedrig |
| Reactions | umgesetzt | Reaction-Emoji wählbar, Recent-Emojis persistent, Custom Emoji-Reactions werden getoggelt | niedrig |
| Readstate / Unreads | umgesetzt | `channels.markAsRead`, Readstate-Events und Sidebar-/DM-Unread-Badges vorhanden | niedrig |
| User-Profil | umgesetzt | Avatar/Banner/Profil über Desktop-Profilpopup angebunden | niedrig |
| Passwort ändern | umgesetzt | `users.updatePassword` angebunden | niedrig |
| Notifications | umgesetzt | Desktop/Browser-Permission und lokale Regeln für All/Mentions/DMs/Replies vorhanden | niedrig |
| i18n | weitgehend umgesetzt | Locale-Persistenz, Sprachwahl, harte Display-String-Guards und Phrase-Safety-Net vorhanden | mittel |
| Member/User Popover | umgesetzt | Profil-Popover, Kontextmenüs, Mod-Actions, Rollen, Voice-Lautstärke und deleted-user Guards vorhanden | niedrig |
| Rollenverwaltung | umgesetzt | CRUD/default/user-role assign/permissions/storage quota vorhanden | niedrig |
| Invites | umgesetzt | CRUD inkl. MaxUses/Expiry/Role/Copy/Suche vorhanden | niedrig |
| Emojis | umgesetzt | List/update/delete/upload und Composer/Reaction-Nutzung vorhanden | niedrig |
| Server Settings / Storage | umgesetzt | General/Storage/Admin-Panels, Logo-Manager, TTL/Quota/Disk-Metrics vorhanden | niedrig |
| Server-Owner-Token / Server-Update | umgesetzt | `others.useSecretToken`, `others.getUpdate`, `others.updateServer` als Desktop-Updatepanel-Kontrollen vorhanden | niedrig |
| Plugin-Verwaltung | weitgehend umgesetzt | Marketplace/install/toggle/remove/update, Commands/Actions/Logs/Settings/Components/Metadata vorhanden; tiefe Plugin-UI kann wachsen | mittel |
| Voice Audio/Video/Screen | weitgehend umgesetzt | mediasoup Audio, Webcam, Screen, Systemaudio-Hints, per-user Volume, Consumer Quality und Popouts vorhanden | mittel |
| External Streams | umgesetzt | External-Stream-Events werden in State gespiegelt und angezeigt | niedrig |
| Screen-Share Hinweisleiste | Desktop-spezifisches Delta | Chromium/WebView2 Capture-Leiste bleibt; echte Entfernung braucht native Capture-Pipeline | mittel |
| 1080p60 Gaming-FPS | teilweise | FPS/Bitrate/ContentHint gesetzt; Live-FPS unter starker Bewegung bleibt abhängig von WebView2/Capture/Encoder | hoch |
| Popout Video | umgesetzt | Native Stream-Popout-Architektur und Wails-Popouts vorhanden | niedrig |

### Router-Coverage Iststand

Automatischer Router-Scan:

- Original upstream: 124 Routen, Desktop refs: 125, fehlend: keine.
- Sharkord-Fork: 125 Routen, Desktop refs: 125, fehlend: keine.
- Fork-Delta: `dms.delete` ist angebunden und im DM-Sidebar verfügbar.

Neu/promoted in diesem Abschluss:

- `messages.getOne`
- `messages.getThread`
- `dms.delete`
- `others.useSecretToken`
- `others.getUpdate`
- `others.updateServer`

### Sinnvolle nächste Reihenfolge nach Phase 1

1. UX-Polish für Rich Composer und Renderer-Details.
2. Plugin-Komponenten tiefer als native Panels abbilden.
3. Native Capture-/Encoder-Optimierung für stabilere 1080p60-Gaming-Capture.
4. Weitere i18n-Politur alter Admin-/Status-Phrasen.
