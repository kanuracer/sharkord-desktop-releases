class VoiceGateProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const opts = options?.processorOptions || {};
    this.threshold = typeof opts.threshold === 'number' ? opts.threshold : 0.006;
    this.floor = typeof opts.floor === 'number' ? opts.floor : 0.10;
    this.attack = typeof opts.attack === 'number' ? opts.attack : 0.60;
    this.release = typeof opts.release === 'number' ? opts.release : 0.025;
    this.holdMs = typeof opts.holdMs === 'number' ? opts.holdMs : 320;
    this.frameMs = 128 / sampleRate * 1000;
    this.holdFrames = Math.max(1, Math.round(this.holdMs / this.frameMs));
    this.holdFramesRemaining = 0;
    this.gain = this.floor;
  }

  process(inputs, outputs) {
    const input = inputs[0] || [];
    const output = outputs[0] || [];
    if (!input.length || !output.length) return true;
    let sum = 0;
    let samples = 0;
    for (const channel of input) {
      for (let i = 0; i < channel.length; i += 1) {
        sum += channel[i] * channel[i];
        samples += 1;
      }
    }
    const rms = samples ? Math.sqrt(sum / samples) : 0;
    if (rms >= this.threshold) this.holdFramesRemaining = this.holdFrames;
    else this.holdFramesRemaining = Math.max(0, this.holdFramesRemaining - 1);
    const active = rms >= this.threshold || this.holdFramesRemaining > 0;
    const target = active ? 1 : this.floor;
    const step = target > this.gain ? this.attack : this.release;
    this.gain += (target - this.gain) * step;
    for (let c = 0; c < output.length; c += 1) {
      const source = input[c] || input[0];
      const dest = output[c];
      for (let i = 0; i < dest.length; i += 1) dest[i] = (source?.[i] || 0) * this.gain;
    }
    return true;
  }
}

registerProcessor('voice-gate-processor', VoiceGateProcessor);
