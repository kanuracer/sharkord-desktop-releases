import * as API from '../bindings/github.com/kanuracer/sharkord-desktop/appservice';

export type DiagnosticLogInfo = { path: string; size: number };

export async function appendDiagnosticLog(event: string, data: Record<string, unknown> = {}, level = 'info', message = '', sessionId = 'desktop'): Promise<DiagnosticLogInfo> {
  return API.AppendDiagnosticLog({
    sessionId,
    event,
    level,
    message,
    data,
    at: Date.now()
  }) as Promise<DiagnosticLogInfo>;
}

export async function getDiagnosticLogInfo(): Promise<DiagnosticLogInfo> {
  return API.GetDiagnosticLogInfo() as Promise<DiagnosticLogInfo>;
}
