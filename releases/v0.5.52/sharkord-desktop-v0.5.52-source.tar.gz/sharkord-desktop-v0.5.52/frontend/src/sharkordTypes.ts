import type { ComponentType } from 'react';

export type SharkordFile = {
  id: number;
  name: string;
  originalName?: string;
  type?: string;
  mimeType?: string;
  extension?: string;
  size?: number;
  userId?: number;
  createdAt?: number;
  updatedAt?: number | null;
  _accessToken?: string;
  _accessTokenExpiresAt?: number;
};

export type SharkordServerInfo = {
  serverId: string;
  version: string;
  name: string;
  description?: string;
  allowNewUsers: boolean;
  logo?: SharkordFile | null;
};

export type SharkordCategory = {
  id: number;
  name: string;
  position: number;
};

export type SharkordChannel = {
  id: number;
  name: string;
  type: 'TEXT' | 'VOICE' | string;
  categoryId?: number | null;
  position: number;
  isDm?: boolean;
  private?: boolean;
  topic?: string | null;
};

export type ChannelPermissionTarget = 'role' | 'user';

export type ChannelPermissionOverride = {
  targetType: ChannelPermissionTarget;
  targetId: number;
  allow: string[];
  deny: string[];
};

export type SharkordUser = {
  id: number;
  name: string;
  identity?: string;
  avatar?: SharkordFile | null;
  banner?: SharkordFile | null;
  bannerColor?: string | null;
  status?: string;
  statusOverride?: string | null;
  statusMessage?: string | null;
  roleIds?: number[];
  banned?: boolean;
  banReason?: string | null;
  createdAt?: number;
  lastLoginAt?: number;
  bio?: string | null;
};

export type SharkordRole = {
  id: number;
  name: string;
  color: string;
  permissions?: string[];
  isDefault?: boolean;
  isPersistent?: boolean;
  storageQuotaOverrideEnabled?: boolean;
  storageSpaceQuota?: number;
  weight?: number;
  mentionable?: boolean;
};

export type SharkordInvite = {
  id?: number;
  code: string;
  creatorId?: number;
  roleId?: number | null;
  role?: Pick<SharkordRole, 'id' | 'name' | 'color'> | null;
  creator?: SharkordUser;
  maxUses?: number | null;
  uses?: number;
  expiresAt?: number | null;
  createdAt?: number;
};

export type SharkordEmoji = {
  id: number;
  name: string;
  file?: SharkordFile | null;
  createdAt?: number;
};

export type SharkordStorageOverflowAction = 'DELETE_OLD_FILES' | 'PREVENT_UPLOADS' | string;

export type SharkordDiskMetrics = {
  totalSpace: number;
  freeSpace: number;
  usedSpace: number;
  sharkordUsedSpace: number;
};

export type SharkordServerSettings = {
  name: string;
  description?: string | null;
  password?: string | null;
  onlyAskForPasswordOnFirstJoin?: boolean;
  allowNewUsers?: boolean;
  directMessagesEnabled?: boolean;
  enablePlugins?: boolean;
  webRtcSimulcastEnabled?: boolean;
  enableSearch?: boolean;
  showWelcomeDialog?: boolean;
  storageUploadEnabled?: boolean;
  storageFileSharingInDirectMessages?: boolean;
  storageQuota?: number;
  storageUploadMaxFileSize?: number;
  storageMaxAvatarSize?: number;
  storageMaxBannerSize?: number;
  storageMaxFilesPerMessage?: number;
  storageSpaceQuotaByUser?: number;
  storageOverflowAction?: SharkordStorageOverflowAction;
  storageSignedUrlsEnabled?: boolean;
  storageSignedUrlsTtlSeconds?: number;
  storageImageOptimizationEnabled?: boolean;
  storageImageOptimizationQuality?: number;
  retentionCleanupEnabled?: boolean;
  messageRetentionDays?: number;
  mediaRetentionDays?: number;
  logo?: SharkordFile | null;
};

export type SharkordStorageSettingsResponse = {
  storageSettings: Partial<SharkordServerSettings>;
  diskMetrics?: SharkordDiskMetrics;
};

export type VoiceProducerEvent = {
  channelId: number;
  remoteId: number;
  kind: 'audio' | 'video' | 'screen' | string;
};

export type VoiceState = {
  micMuted: boolean;
  soundMuted: boolean;
  webcamEnabled?: boolean;
  sharingScreen?: boolean;
};

export type VoiceMap = Record<number, { users: Record<number, VoiceState> }>;

export type VoiceUser = SharkordUser & {
  state: VoiceState;
};

export type SharkordMessageReaction = {
  emoji: string;
  count?: number;
  reacted?: boolean;
  file?: SharkordFile | null;
};

export type SharkordMessage = {
  id: number;
  channelId: number;
  userId: number;
  content: string;
  parentMessageId?: number | null;
  createdAt: number;
  updatedAt?: number | null;
  editedAt?: number | null;
  editable?: boolean;
  pinned?: boolean;
  reactions?: SharkordMessageReaction[];
  files?: SharkordFile[];
  user?: SharkordUser;
  author?: SharkordUser;
  parentMessage?: SharkordMessage;
  replyCount?: number;
  mentionedRoleIds?: number[];
  mentionedUserIds?: number[];
};

export type ThreadInboxItem = {
  channelId: number;
  parentMessageId: number;
  parentMessage: SharkordMessage;
  latestReply: SharkordMessage;
  replyCount: number;
  unreadReplyCount: number;
};

export type ThreadInboxResponse = {
  items: ThreadInboxItem[];
  totalUnreadReplies: number;
};

export type UnreadThreadItem = ThreadInboxItem;

export type DirectMessageConversation = {
  channelId: number;
  userId: number;
  unreadCount: number;
  lastMessageAt: number;
};

export type SharkordUserInfo = {
  user: SharkordUser;
  logins?: Array<{ id?: number; userId?: number; createdAt?: number; ip?: string; loc?: string | null }>;
  files?: SharkordFile[];
  messages?: SharkordMessage[];
  storage?: { userId?: number; fileCount?: number; usedStorage?: number; quota?: number };
};

export type JoinServerResult = {
  categories: SharkordCategory[];
  channels: SharkordChannel[];
  users: SharkordUser[];
  roles?: SharkordRole[];
  serverId: string;
  serverName: string;
  ownUserId: number;
  publicSettings?: Partial<SharkordServerSettings>;
  voiceMap?: VoiceMap;
  externalStreamsMap?: unknown;
  readStates?: Record<number, number>;
  showWelcomeDialog?: boolean;
  commands?: Record<string, SharkordPluginCommand[]>;
  pluginIdsWithComponents?: string[];
  pluginsMetadata?: SharkordPluginMetadata[];
};

export type MessagePage = {
  messages: SharkordMessage[];
  nextCursor: number | null;
};

export type GlobalSearchMessageResult = SharkordMessage & {
  channel?: SharkordChannel;
  excerpt?: string;
};

export type GlobalSearchMessagePage = {
  messages: GlobalSearchMessageResult[];
  files?: GlobalSearchFileResult[];
  nextCursor: number | string | null;
};

export type GlobalSearchFileResult = SharkordFile & {
  channelId?: number | null;
  messageId?: number | null;
  user?: SharkordUser;
  message?: SharkordMessage;
};

export type GlobalSearchFilePage = {
  files: GlobalSearchFileResult[];
  nextCursor: number | string | null;
};

export type NativeSharkordSession = {
  baseUrl: string;
  token: string;
  join: JoinServerResult;
};


export type SharkordTempFile = {
  id: string | number;
  name?: string;
  originalName?: string;
  size?: number;
  type?: string;
};

export type SharkordPluginInfo = {
  id: string;
  name: string;
  description?: string;
  version?: string;
  author?: string;
  homepage?: string;
  logo?: string;
  enabled?: boolean;
  loadError?: string | null;
};

export type SharkordMarketplacePlugin = {
  id: string;
  name: string;
  description: string;
  author: string;
  logo?: string;
  homepage?: string;
  tags?: string[];
  categories?: string[];
  verified?: boolean;
  screenshots?: string[];
};

export type SharkordMarketplaceVersion = {
  version: string;
  downloadUrl?: string;
  checksum?: string;
  sdkVersion?: number | string;
  size?: number;
  timestamp?: number;
};

export type SharkordMarketplaceEntry = {
  plugin: SharkordMarketplacePlugin;
  versions: SharkordMarketplaceVersion[];
};

export type SharkordReadState = { channelId: number; count?: number; delta?: number };
export type StreamQualitySetting = { mode: 'auto' } | { mode: 'layer'; spatialLayer: number };
export type SharkordExternalStream = {
  title: string;
  key: string;
  pluginId: string;
  avatarUrl?: string;
  bannerUrl?: string;
  tracks?: { audio?: boolean; video?: boolean };
};
export type SharkordPluginCommandArg = { name: string; type?: 'string' | 'number' | 'boolean' | string; description?: string; required?: boolean; default?: string | number | boolean };
export type SharkordPluginCommand = { pluginId?: string; name: string; description?: string; args?: SharkordPluginCommandArg[] };
export type SharkordPluginLog = { pluginId?: string; level?: string; message?: string; timestamp?: number; data?: unknown };
export type SharkordPluginSetting = { key: string; type?: 'string' | 'number' | 'boolean' | string; label?: string; description?: string; value?: string | number | boolean; defaultValue?: string | number | boolean };
export type PluginSlotId = 'topbar' | 'chat-actions' | 'connect' | 'content-wrapper';
export type SharkordOfficialPluginSlotId = 'connect_screen' | 'home_screen' | 'chat_actions' | 'topbar_right' | 'full_screen';
export type SharkordPluginMetadata = { pluginId: string; name: string; description?: string; avatarUrl?: string };
export type SharkordPluginSlotRender = {
  pluginId: string;
  slot: PluginSlotId;
  label?: string;
  title?: string;
  description?: string;
  icon?: string;
  actionName?: string;
  payload?: unknown;
  enabled?: boolean;
  order?: number;
  component?: ComponentType;
  componentSlot?: SharkordOfficialPluginSlotId;
  componentIndex?: number;
};
export type PluginSlotItem = SharkordPluginSlotRender;
