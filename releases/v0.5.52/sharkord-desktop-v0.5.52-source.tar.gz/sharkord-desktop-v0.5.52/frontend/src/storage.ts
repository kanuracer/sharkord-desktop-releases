import type { ReleaseChannel, SharkordServer, StoredState, ThemeMode } from './types';

const STORAGE_KEY = 'sharkord-desktop:v1';
export const defaultState: StoredState = { theme: 'dark', activeServerId: null, servers: [], releaseChannel: 'stable' };

export function normalizeUrl(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) throw new Error('URL missing');
  const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  const parsed = new URL(withProtocol);
  parsed.hash = '';
  return parsed.toString().replace(/\/$/, '');
}

export function initials(name: string): string {
  const value = name.trim();
  if (!value) return 'SK';
  return value.split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase() ?? '').join('') || 'SK';
}

export function createServer(input: { name: string; url: string; autoConnect?: boolean; logo?: SharkordServer['logo'] }): SharkordServer {
  const url = normalizeUrl(input.url);
  const name = input.name.trim() || new URL(url).hostname;
  return { id: crypto.randomUUID(), name, url, color: colorFor(name + url), lastOpenedAt: Date.now(), autoConnect: !!input.autoConnect, logo: input.logo ?? null };
}

export function normalizeReleaseChannel(raw: unknown): ReleaseChannel {
  return raw === 'beta' ? 'beta' : 'stable';
}

export function loadState(storage: Storage = window.localStorage): StoredState {
  const raw = storage.getItem(STORAGE_KEY);
  if (!raw) return defaultState;
  try {
    const parsed = JSON.parse(raw) as StoredState;
    const servers = Array.isArray(parsed.servers)
      ? parsed.servers.map((server) => ({ ...server, autoConnect: !!server.autoConnect, logo: server.logo ?? null }))
      : [];
    const theme: ThemeMode = parsed.theme === 'light' ? 'light' : 'dark';
    const activeServerId = servers.some((server) => server.id === parsed.activeServerId)
      ? parsed.activeServerId
      : (servers[0]?.id ?? null);
    return { theme, servers, activeServerId, releaseChannel: normalizeReleaseChannel(parsed.releaseChannel) };
  } catch {
    return defaultState;
  }
}

export function saveState(state: StoredState, storage: Storage = window.localStorage) {
  storage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function colorFor(seed: string): string {
  const colors = ['#5865f2', '#22c55e', '#f97316', '#ec4899', '#06b6d4', '#a855f7'];
  const idx = [...seed].reduce((sum, c) => sum + c.charCodeAt(0), 0) % colors.length;
  return colors[idx];
}
