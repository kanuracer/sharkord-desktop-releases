export type ThemeMode = 'dark' | 'light';
export type ReleaseChannel = 'stable' | 'beta';

import type { SharkordFile } from './sharkordTypes';

export type SharkordServer = {
  id: string;
  name: string;
  url: string;
  color: string;
  lastOpenedAt: number;
  autoConnect?: boolean;
  logo?: SharkordFile | null;
};

export type StoredState = {
  theme: ThemeMode;
  activeServerId: string | null;
  servers: SharkordServer[];
  releaseChannel?: ReleaseChannel;
  allowEmptyServers?: boolean;
};
