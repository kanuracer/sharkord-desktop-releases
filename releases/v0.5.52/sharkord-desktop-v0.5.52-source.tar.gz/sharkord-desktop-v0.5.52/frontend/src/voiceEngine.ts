import { loadRnnoise, RnnoiseWorkletNode, loadSpeex, SpeexWorkletNode } from '@sapphi-red/web-noise-suppressor';
import { tr } from './i18n';
import rnnoiseWorkletUrl from '@sapphi-red/web-noise-suppressor/rnnoiseWorklet.js?url';
import rnnoiseWasmUrl from '@sapphi-red/web-noise-suppressor/rnnoise.wasm?url';
import rnnoiseSimdWasmUrl from '@sapphi-red/web-noise-suppressor/rnnoise_simd.wasm?url';
import speexWorkletUrl from '@sapphi-red/web-noise-suppressor/speexWorklet.js?url';
import speexWasmUrl from '@sapphi-red/web-noise-suppressor/speex.wasm?url';
import voiceGateWorkletUrl from './audioWorklets/voiceGateProcessor.js?url';
import { Device } from 'mediasoup-client';
import type { AppData, Consumer, Producer, ProducerCodecOptions, RtpCapabilities, RtpParameters, Transport } from 'mediasoup-client/types';
import type { SharkordConnection } from './sharkordClient';

export type StreamKind = 'audio' | 'video' | 'screen' | 'screen_audio' | 'external_video' | 'external_audio';
export type MediaResolution = '480p' | '720p' | '1080p' | '1440p' | '2160p';
export type AudioDeviceSettings = {
  microphoneId?: string;
  playbackId?: string;
  webcamId?: string;
  echoCancellation: boolean;
  noiseSuppression: boolean;
  autoGainControl: boolean;
  microphoneGain: number;
  denoiseEnabled: boolean;
  voiceIsolationEnabled: boolean;
  noiseGate: boolean;
  videoResolution: MediaResolution;
  videoFps: number;
  mirrorOwnVideo: boolean;
  simulcastEnabled: boolean;
  screenResolution: MediaResolution;
  screenFps: number;
  screenCodec: 'auto' | 'vp8' | 'h264';
  screenContentHint: 'detail' | 'motion';
  screenSourceMode: 'window' | 'screen';
  screenMaxBitrateMbps: number;
  restrictOwnAudio: boolean;
  suppressLocalAudioPlayback: boolean;
  includeScreenAudio: boolean;
  voiceIsolationIntensity: number;
};
export type RemoteMediaStream = {
  remoteId: number;
  kind: StreamKind;
  stream: MediaStream;
};
export type RemoteAudioStream = RemoteMediaStream;
export type RemoteVideoStream = RemoteMediaStream;

export type VoiceEngineCallbacks = {
  onRemoteAudioStreams: (streams: RemoteAudioStream[]) => void;
  onRemoteVideoStreams: (streams: RemoteVideoStream[]) => void;
  onLocalAudioStream: (stream: MediaStream | null) => void;
  onLocalVideoStream: (stream: MediaStream | null) => void;
  onLocalScreenStream: (stream: MediaStream | null) => void;
  onStatus: (status: string) => void;
  onDebug?: (event: string, data?: Record<string, unknown>, level?: string, message?: string) => void;
  onLocalMediaEnded?: (kind: 'video' | 'screen') => void;
};

type StatusCallback = (status: string) => void;
type MediasoupHandlerName = 'Safari12';

export function resolveMediasoupHandlerName(userAgent = globalThis.navigator?.userAgent ?? '', platform = globalThis.navigator?.platform ?? ''): MediasoupHandlerName | undefined {
  const isAppleWebKit = /AppleWebKit\/\d+/i.test(userAgent);
  const isApplePlatform = /(Macintosh|Mac OS X|iPhone|iPad|iPod)/i.test(userAgent) || /(Mac|iPhone|iPad|iPod)/i.test(platform);
  const isExplicitNonSafariEngine = /(Chrome|Chromium|CriOS|Edg|OPR|Firefox|FxiOS)/i.test(userAgent);
  if (isAppleWebKit && isApplePlatform && !isExplicitNonSafariEngine) return 'Safari12';
  return undefined;
}

const AUDIO_KIND: StreamKind = 'audio';
const VIDEO_KIND: StreamKind = 'video';
const SCREEN_KIND: StreamKind = 'screen';
const SCREEN_AUDIO_KIND: StreamKind = 'screen_audio';
const EXTERNAL_VIDEO_KIND: StreamKind = 'external_video';
const EXTERNAL_AUDIO_KIND: StreamKind = 'external_audio';
export const AUDIO_OPUS_CODEC_MIME_TYPE = 'audio/opus';
export const SHARKORD_AUDIO_OPUS_PRODUCER_CODEC_OPTIONS = {
  opusFec: true,
  opusDtx: false,
  opusMaxPlaybackRate: 48000,
  opusMaxAverageBitrate: 128000
} satisfies ProducerCodecOptions;
const REMOTE_AUDIO_KINDS = new Set<StreamKind>([AUDIO_KIND, SCREEN_AUDIO_KIND, EXTERNAL_AUDIO_KIND]);
const REMOTE_VIDEO_KINDS = new Set<StreamKind>([VIDEO_KIND, SCREEN_KIND, EXTERNAL_VIDEO_KIND]);
const REMOTE_KINDS = new Set<StreamKind>([...REMOTE_AUDIO_KINDS, ...REMOTE_VIDEO_KINDS]);

export type AudioCodecNegotiationSummary = {
  kind: StreamKind;
  expectedAudioCodec: typeof AUDIO_OPUS_CODEC_MIME_TYPE;
  codecMimeTypes: string[];
  negotiatedAudioCodec: string;
  audioCodecNegotiated: boolean;
};

export function summarizeAudioCodecNegotiation(kind: StreamKind, rtpParameters: RtpParameters): AudioCodecNegotiationSummary | undefined {
  if (!REMOTE_AUDIO_KINDS.has(kind)) return undefined;
  const codecMimeTypes = rtpParameters.codecs.map((codec) => codec.mimeType.toLowerCase());
  const negotiatedAudioCodec = codecMimeTypes.find((mimeType) => mimeType.startsWith('audio/')) ?? 'missing';
  return {
    kind,
    expectedAudioCodec: AUDIO_OPUS_CODEC_MIME_TYPE,
    codecMimeTypes,
    negotiatedAudioCodec,
    audioCodecNegotiated: negotiatedAudioCodec === AUDIO_OPUS_CODEC_MIME_TYPE
  };
}

function mediaSize(resolution: MediaResolution) {
  if (resolution === '480p') return { width: 854, height: 480 };
  if (resolution === '1080p') return { width: 1920, height: 1080 };
  if (resolution === '1440p') return { width: 2560, height: 1440 };
  if (resolution === '2160p') return { width: 3840, height: 2160 };
  return { width: 1280, height: 720 };
}
function clampFps(value: number | undefined, fallback = 30) { return Math.max(5, Math.min(60, Number(value || fallback))); }

function clampVoiceIsolationIntensity(value: number | undefined) { return Math.max(0, Math.min(100, Number.isFinite(value) ? Number(value) : 60)); }
function voiceGateParamsForIntensity(value: number | undefined) {
  const intensity = clampVoiceIsolationIntensity(value) / 100;
  return {
    threshold: Number((0.004 + intensity * 0.012).toFixed(4)),
    floor: Number((0.18 - intensity * 0.15).toFixed(3)),
    attack: 0.60,
    release: Number((0.018 + intensity * 0.040).toFixed(3)),
    holdMs: Math.round(420 - intensity * 180)
  };
}

export class SharkordVoiceEngine {
  private connection: SharkordConnection;
  private device?: Device;
  private producerTransport?: Transport<AppData>;
  private consumerTransport?: Transport<AppData>;
  private audioProducer?: Producer<AppData>;
  private videoProducer?: Producer<AppData>;
  private screenProducer?: Producer<AppData>;
  private screenAudioProducer?: Producer<AppData>;
  private consumers = new Map<string, Consumer<AppData>>();
  private pendingRemoteProducers = new Map<string, { remoteId: number; kind: StreamKind }>();
  private consumingRemoteProducers = new Set<string>();
  private remoteAudioStreams = new Map<string, RemoteAudioStream>();
  private remoteVideoStreams = new Map<string, RemoteVideoStream>();
  private deviceRtpCapabilities?: RtpCapabilities;
  private localAudioStream?: MediaStream;
  private rawAudioStream?: MediaStream;
  private localVideoStream?: MediaStream;
  private localScreenStream?: MediaStream;
  private cleanupDenoise?: () => void;
  private cleanupGain?: () => void;
  private cleanupVoiceGate?: () => void;
  private callbacks: VoiceEngineCallbacks;
  private onStatus: StatusCallback;
  private settings: AudioDeviceSettings;

  constructor(connection: SharkordConnection, settings: AudioDeviceSettings, callbacks: VoiceEngineCallbacks) {
    this.connection = connection;
    this.settings = settings;
    this.callbacks = callbacks;
    this.onStatus = callbacks.onStatus;
  }

  private debug(event: string, data: Record<string, unknown> = {}, level = 'info', message = '') {
    this.callbacks.onDebug?.(event, data, level, message);
  }

  private debugAudioProducerCodec(kind: StreamKind, producer: Producer<AppData>) {
    const codecSummary = summarizeAudioCodecNegotiation(kind, producer.rtpParameters);
    if (!codecSummary) return;
    const level = codecSummary.audioCodecNegotiated ? 'info' : 'warn';
    const message = codecSummary.audioCodecNegotiated
      ? `Audio codec negotiated: ${codecSummary.negotiatedAudioCodec}`
      : `Expected audio/opus but negotiated ${codecSummary.negotiatedAudioCodec}`;
    this.debug('voice.produce.codec', { producerId: producer.id, ...codecSummary }, level, message);
  }

  updateSettings(settings: AudioDeviceSettings) {
    this.settings = settings;
  }

  async hotSwapMicrophone(settings: AudioDeviceSettings = this.settings) {
    this.settings = settings;
    if (!this.audioProducer || this.audioProducer.closed) {
      await this.startMicStream();
      return;
    }
    const hasSpecificMic = !!settings.microphoneId && settings.microphoneId !== 'default';
    this.debug('voice.deviceHotSwap.mic.start', { microphoneId: settings.microphoneId ?? 'default' });
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        deviceId: hasSpecificMic ? { exact: settings.microphoneId } : undefined,
        echoCancellation: settings.echoCancellation,
        noiseSuppression: settings.noiseSuppression,
        autoGainControl: settings.autoGainControl,
        channelCount: 1,
        sampleRate: { ideal: 48000 }
      },
      video: false
    });
    const rawTrack = stream.getAudioTracks()[0];
    if (!rawTrack) {
      stream.getTracks().forEach((item) => item.stop());
      throw new Error(tr('Kein Mikrofon-Audio-Track erhalten'));
    }
    await rawTrack.applyConstraints?.({ echoCancellation: settings.echoCancellation, noiseSuppression: settings.noiseSuppression, autoGainControl: settings.autoGainControl }).catch(() => undefined);
    const processedStream = settings.voiceIsolationEnabled
      ? await this.createVoiceIsolatedStream(stream)
      : settings.denoiseEnabled
        ? await this.createDenoisedStream(stream)
        : this.createGainProcessedStream(stream);
    const track = processedStream.getAudioTracks()[0] ?? rawTrack;
    await this.audioProducer.replaceTrack({ track });
    this.localAudioStream?.getTracks().forEach((item) => item.stop());
    if (this.rawAudioStream !== this.localAudioStream) this.rawAudioStream?.getTracks().forEach((item) => item.stop());
    this.rawAudioStream = stream;
    this.localAudioStream = new MediaStream([track]);
    this.callbacks.onLocalAudioStream(new MediaStream([track]));
    track.onended = () => this.stopMicStream();
    this.debug('voice.deviceHotSwap.mic.ok', { microphoneId: settings.microphoneId ?? 'default', trackReadyState: track.readyState });
  }

  async hotSwapWebcam(settings: AudioDeviceSettings = this.settings) {
    this.settings = settings;
    if (!this.videoProducer || this.videoProducer.closed) {
      await this.startWebcamStream();
      return;
    }
    const videoSize = mediaSize(settings.videoResolution);
    const videoFps = clampFps(settings.videoFps, 30);
    const hasSpecificWebcam = !!settings.webcamId && settings.webcamId !== 'default';
    this.debug('voice.deviceHotSwap.webcam.start', { webcamId: settings.webcamId ?? 'default', videoResolution: settings.videoResolution, videoFps });
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        deviceId: hasSpecificWebcam ? { exact: settings.webcamId } : undefined,
        width: { ideal: videoSize.width },
        height: { ideal: videoSize.height },
        frameRate: { ideal: videoFps, max: videoFps }
      }
    });
    const track = stream.getVideoTracks()[0];
    if (!track) {
      stream.getTracks().forEach((item) => item.stop());
      throw new Error(tr('Keine Webcam-Video-Spur erhalten'));
    }
    await track.applyConstraints?.({ width: { ideal: videoSize.width }, height: { ideal: videoSize.height }, frameRate: { ideal: videoFps, max: videoFps } }).catch(() => undefined);
    await this.videoProducer.replaceTrack({ track });
    this.localVideoStream?.getTracks().forEach((item) => item.stop());
    this.localVideoStream = stream;
    this.callbacks.onLocalVideoStream(stream);
    track.onended = () => {
      this.stopWebcamStream();
      this.callbacks.onLocalMediaEnded?.('video');
    };
    this.debug('voice.deviceHotSwap.webcam.ok', { webcamId: settings.webcamId ?? 'default', trackReadyState: track.readyState });
  }

  async setConsumerQuality(remoteId: number, kind: 'video' | 'screen' | 'external_video', quality: { mode: 'auto' } | { mode: 'layer'; spatialLayer: number }) {
    await this.connection.trpc.voice.setConsumerQuality.mutate({ remoteId, kind, quality });
  }

  isReadyToProduce() {
    return !!this.producerTransport && !this.producerTransport.closed;
  }

  async init(routerRtpCapabilities: RtpCapabilities) {
    this.debug('voice.init.start', { hasRouterRtpCapabilities: !!routerRtpCapabilities });
    this.onStatus(tr('Voice: mediasoup initialized...'));
    this.cleanupMediaOnly();
    const handlerName = resolveMediasoupHandlerName();
    this.debug('voice.device.create', { handlerName: handlerName ?? 'auto', userAgent: globalThis.navigator?.userAgent ?? '', platform: globalThis.navigator?.platform ?? '' });
    const device = handlerName ? new Device({ handlerName }) : new Device();
    this.device = device;
    try {
      await device.load({ routerRtpCapabilities });
      this.debug('voice.device.load.ok');
    } catch (error) {
      this.debug('voice.device.load.error', { error: cleanError(error) }, 'error', cleanError(error));
      throw error;
    }
    const loaded = device as Device & { rtpCapabilities?: RtpCapabilities; recvRtpCapabilities?: RtpCapabilities };
    this.deviceRtpCapabilities = loaded.recvRtpCapabilities ?? loaded.rtpCapabilities;
    if (!this.deviceRtpCapabilities) throw new Error(tr('Keine RTP Capabilities vom mediasoup Device'));
    await this.createProducerTransport(device);
    await this.createConsumerTransport(device);
    await this.refreshExistingProducers();
    try { await this.startMicStream(); }
    catch (error) { this.debug('voice.mic.start.error', { error: cleanError(error) }, 'warn', cleanError(error)); this.onStatus(tr(`Voice verbunden · Mikrofon nicht verfügbar: ${cleanError(error)}`)); return; }
    this.debug('voice.init.ready', { readyToProduce: this.isReadyToProduce() });
    this.onStatus(tr('Voice verbunden · Audio/Video bereit'));
  }

  async initConsumerOnly(routerRtpCapabilities: RtpCapabilities) {
    this.debug('voice.consumerOnly.init.start', { hasRouterRtpCapabilities: !!routerRtpCapabilities });
    this.cleanupMediaOnly();
    const handlerName = resolveMediasoupHandlerName();
    const device = handlerName ? new Device({ handlerName }) : new Device();
    this.device = device;
    await device.load({ routerRtpCapabilities });
    const loaded = device as Device & { rtpCapabilities?: RtpCapabilities; recvRtpCapabilities?: RtpCapabilities };
    this.deviceRtpCapabilities = loaded.recvRtpCapabilities ?? loaded.rtpCapabilities;
    if (!this.deviceRtpCapabilities) throw new Error(tr('Keine RTP Capabilities vom mediasoup Device'));
    await this.createConsumerTransport(device);
    this.debug('voice.consumerOnly.init.ready', { hasConsumerTransport: !!this.consumerTransport });
  }

  async startMicStream() {
    if (!this.producerTransport) throw new Error(tr('Producer transport fehlt'));
    this.debug('voice.mic.getUserMedia.start', { microphoneId: this.settings.microphoneId ?? 'default', echoCancellation: this.settings.echoCancellation, noiseSuppression: this.settings.noiseSuppression, autoGainControl: this.settings.autoGainControl, denoiseEnabled: this.settings.denoiseEnabled, voiceIsolationEnabled: this.settings.voiceIsolationEnabled, noiseGate: this.settings.noiseGate });
    this.stopMicStream();
    const hasSpecificMic = !!this.settings.microphoneId && this.settings.microphoneId !== 'default';
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        deviceId: hasSpecificMic ? { exact: this.settings.microphoneId } : undefined,
        echoCancellation: this.settings.echoCancellation,
        noiseSuppression: this.settings.noiseSuppression,
        autoGainControl: this.settings.autoGainControl,
        channelCount: 1,
        sampleRate: { ideal: 48000 }
      },
      video: false
    });
    const rawTrack = stream.getAudioTracks()[0];
    if (!rawTrack) {
      stream.getTracks().forEach((item) => item.stop());
      throw new Error(tr('Kein Mikrofon-Audio-Track erhalten'));
    }
    const processedStream = this.settings.voiceIsolationEnabled
      ? await this.createVoiceIsolatedStream(stream)
      : this.settings.denoiseEnabled
        ? await this.createDenoisedStream(stream)
        : this.createGainProcessedStream(stream);
    const processedAudioTracks = processedStream.getAudioTracks().length;
    const track = processedStream.getAudioTracks()[0] ?? rawTrack;
    const producingRawFallback = track === rawTrack;
    const outboundStream = new MediaStream([track]);
    this.debug('voice.mic.getUserMedia.ok', { rawAudioTracks: stream.getAudioTracks().length, processedAudioTracks, microphoneGain: this.settings.microphoneGain, voiceIsolationEnabled: this.settings.voiceIsolationEnabled, producingRawFallback, rawTrackSettings: rawTrack.getSettings?.() ?? {}, processedTrackSettings: track.getSettings?.() ?? {} });
    this.rawAudioStream = stream;
    this.localAudioStream = outboundStream;
    this.callbacks.onLocalAudioStream(new MediaStream([track]));
    this.debug('voice.produce.start', { kind: AUDIO_KIND, trackReadyState: track.readyState, trackMuted: track.muted, producingRawFallback });
    this.audioProducer = await this.producerTransport.produce({
      track,
      codecOptions: {
        ...SHARKORD_AUDIO_OPUS_PRODUCER_CODEC_OPTIONS,
        opusStereo: false
      },
      appData: { kind: AUDIO_KIND }
    });
    this.audioProducer.on('@close', () => {
      void this.connection.trpc.voice.closeProducer.mutate({ kind: AUDIO_KIND }).catch(() => undefined);
    });
    this.debugAudioProducerCodec(AUDIO_KIND, this.audioProducer);
    this.debug('voice.produce.ok', { kind: AUDIO_KIND, producerId: this.audioProducer.id });
    track.onended = () => this.stopMicStream();
  }

  async startWebcamStream() {
    if (!this.producerTransport) throw new Error(tr('Producer transport fehlt'));
    const videoSize = mediaSize(this.settings.videoResolution);
    const videoFps = clampFps(this.settings.videoFps, 30);
    const hasSpecificWebcam = !!this.settings.webcamId && this.settings.webcamId !== 'default';
    this.debug('voice.webcam.getUserMedia.start', { webcamId: this.settings.webcamId ?? 'default', videoResolution: this.settings.videoResolution, videoFps });
    this.stopWebcamStream();
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        deviceId: hasSpecificWebcam ? { exact: this.settings.webcamId } : undefined,
        width: { ideal: videoSize.width },
        height: { ideal: videoSize.height },
        frameRate: { ideal: videoFps, max: videoFps }
      }
    });
    const track = stream.getVideoTracks()[0];
    this.debug('voice.webcam.getUserMedia.ok', { videoTracks: stream.getVideoTracks().length, label: track?.label || '', readyState: track?.readyState || '', trackSettings: track?.getSettings?.() ?? {} });
    if (!track) {
      stream.getTracks().forEach((item) => item.stop());
      throw new Error(tr('Keine Webcam-Video-Spur erhalten'));
    }
    this.localVideoStream = stream;
    this.callbacks.onLocalVideoStream(stream);
    this.debug('voice.produce.start', { kind: VIDEO_KIND, trackReadyState: track.readyState, trackMuted: track.muted, requestedFps: videoFps, trackSettings: track.getSettings?.() ?? {} });
    this.videoProducer = await this.producerTransport.produce({ track, encodings: [{ maxFramerate: videoFps }], appData: { kind: VIDEO_KIND } });
    this.videoProducer.on('@close', () => {
      void this.connection.trpc.voice.closeProducer.mutate({ kind: VIDEO_KIND }).catch(() => undefined);
    });
    this.debug('voice.produce.ok', { kind: VIDEO_KIND, producerId: this.videoProducer.id });
    track.onended = () => {
      this.stopWebcamStream();
      this.callbacks.onLocalMediaEnded?.('video');
    };
  }

  stopWebcamStream() {
    if (this.videoProducer && !this.videoProducer.closed) this.videoProducer.close();
    this.videoProducer = undefined;
    this.localVideoStream?.getTracks().forEach((track) => track.stop());
    this.localVideoStream = undefined;
    this.callbacks.onLocalVideoStream(null);
  }

  async startScreenShareStream() {
    if (!this.producerTransport) throw new Error(tr('Producer transport fehlt'));
    if (!navigator.mediaDevices.getDisplayMedia) throw new Error(tr('Bildschirmfreigabe nicht verfügbar'));
    const screenSize = mediaSize(this.settings.screenResolution);
    const screenFps = clampFps(this.settings.screenFps, 30);
    this.debug('voice.screen.getDisplayMedia.start', { hasGetDisplayMedia: !!navigator.mediaDevices.getDisplayMedia, screenResolution: this.settings.screenResolution, screenFps, screenCodec: this.settings.screenCodec, screenContentHint: this.settings.screenContentHint, screenSourceMode: this.settings.screenSourceMode, restrictOwnAudio: this.settings.restrictOwnAudio, suppressLocalAudioPlayback: this.settings.suppressLocalAudioPlayback });
    this.stopScreenShareStream();
    const screenAudioConstraints = this.settings.includeScreenAudio ? {
      echoCancellation: false,
      noiseSuppression: false,
      autoGainControl: false,
      channelCount: 2,
      sampleRate: 48000,
      suppressLocalAudioPlayback: this.settings.suppressLocalAudioPlayback,
      systemAudio: 'include',
      windowAudio: 'system'
    } : false;
    const stream = await navigator.mediaDevices.getDisplayMedia({
      video: { width: { ideal: screenSize.width }, height: { ideal: screenSize.height }, frameRate: { ideal: screenFps, max: screenFps }, displaySurface: this.settings.screenSourceMode === 'window' ? 'window' : 'monitor' },
      audio: screenAudioConstraints,
      monitorTypeSurfaces: this.settings.screenSourceMode === 'window' ? 'exclude' : 'include',
      selfBrowserSurface: 'exclude',
      surfaceSwitching: 'include'
    } as DisplayMediaStreamOptions & { video: MediaTrackConstraints & { displaySurface?: 'window' | 'monitor' }; audio: false | (MediaTrackConstraints & { suppressLocalAudioPlayback?: boolean; systemAudio?: 'include' | 'exclude'; windowAudio?: 'system' | 'window' | 'exclude' }); monitorTypeSurfaces?: 'include' | 'exclude'; selfBrowserSurface?: 'include' | 'exclude'; surfaceSwitching?: 'include' | 'exclude'; systemAudio?: 'include' | 'exclude'; windowAudio?: 'system' | 'window' | 'exclude' });
    const videoTrack = stream.getVideoTracks()[0];
    this.debug('voice.screen.getDisplayMedia.ok', { videoTracks: stream.getVideoTracks().length, audioTracks: stream.getAudioTracks().length, label: videoTrack?.label || '', readyState: videoTrack?.readyState || '', trackSettings: videoTrack?.getSettings?.() ?? {} });
    if (videoTrack) videoTrack.contentHint = this.settings.screenContentHint;
    if (!videoTrack) {
      stream.getTracks().forEach((item) => item.stop());
      throw new Error(tr('Keine Bildschirm-Video-Spur erhalten'));
    }
    this.localScreenStream = stream;
    this.callbacks.onLocalScreenStream(new MediaStream([videoTrack]));
    this.debug('voice.produce.start', { kind: SCREEN_KIND, trackReadyState: videoTrack.readyState, trackMuted: videoTrack.muted, requestedFps: screenFps, requestedMaxBitrateMbps: this.settings.screenMaxBitrateMbps, trackSettings: videoTrack.getSettings?.() ?? {}, screenContentHint: videoTrack.contentHint });
    this.screenProducer = await this.producerTransport.produce({
      track: videoTrack,
      encodings: [{ maxBitrate: this.settings.screenMaxBitrateMbps * 1000 * 1000, maxFramerate: screenFps }],
      codecOptions: { videoGoogleStartBitrate: Math.min(2500, this.settings.screenMaxBitrateMbps * 1000), videoGoogleMaxBitrate: this.settings.screenMaxBitrateMbps * 1000, videoGoogleMinBitrate: 800 },
      appData: { kind: SCREEN_KIND }
    });
    this.screenProducer.on('@close', () => {
      void this.connection.trpc.voice.closeProducer.mutate({ kind: SCREEN_KIND }).catch(() => undefined);
    });
    this.debug('voice.produce.ok', { kind: SCREEN_KIND, producerId: this.screenProducer.id });
    const audioTrack = stream.getAudioTracks()[0];
    if (!audioTrack && this.settings.includeScreenAudio) this.debug('voice.screen.audio.missing', { includeScreenAudio: this.settings.includeScreenAudio }, 'warn', tr('Kein Systemaudio-Track erhalten. Im Picker muss Audio teilen aktiviert sein und die Plattform muss Systemaudio erlauben.'));
    if (audioTrack) {
      this.debug('voice.produce.start', { kind: SCREEN_AUDIO_KIND, trackReadyState: audioTrack.readyState, trackMuted: audioTrack.muted });
      this.screenAudioProducer = await this.producerTransport.produce({
        track: audioTrack,
        codecOptions: { ...SHARKORD_AUDIO_OPUS_PRODUCER_CODEC_OPTIONS, opusStereo: true },
        appData: { kind: SCREEN_AUDIO_KIND }
      });
      this.screenAudioProducer.on('@close', () => {
        void this.connection.trpc.voice.closeProducer.mutate({ kind: SCREEN_AUDIO_KIND }).catch(() => undefined);
      });
      this.debugAudioProducerCodec(SCREEN_AUDIO_KIND, this.screenAudioProducer);
      this.debug('voice.produce.ok', { kind: SCREEN_AUDIO_KIND, producerId: this.screenAudioProducer.id });
    }
    videoTrack.onended = () => {
      this.stopScreenShareStream();
      this.callbacks.onLocalMediaEnded?.('screen');
    };
  }

  stopScreenShareStream() {
    if (this.screenProducer && !this.screenProducer.closed) this.screenProducer.close();
    if (this.screenAudioProducer && !this.screenAudioProducer.closed) this.screenAudioProducer.close();
    this.screenProducer = undefined;
    this.screenAudioProducer = undefined;
    this.localScreenStream?.getTracks().forEach((track) => track.stop());
    this.localScreenStream = undefined;
    this.callbacks.onLocalScreenStream(null);
  }

  setMicMuted(muted: boolean) {
    this.localAudioStream?.getAudioTracks().forEach((track) => { track.enabled = !muted; });
  }

  setSoundMuted(muted: boolean) {
    if (muted) this.callbacks.onRemoteAudioStreams([]);
    else this.emitRemoteAudioStreams();
  }

  async consumeProducer(remoteId: number, kind: StreamKind) {
    if (!REMOTE_KINDS.has(kind)) return;
    const key = `${remoteId}:${kind}`;
    if (this.consumers.has(key) || this.remoteAudioStreams.has(key) || this.remoteVideoStreams.has(key) || this.pendingRemoteProducers.has(key)) this.removeRemoteProducer(remoteId, kind);
    const existingConsumer = this.consumers.get(key);
    if (existingConsumer?.closed) this.consumers.delete(key);
    if (!this.consumerTransport || !this.deviceRtpCapabilities) {
      this.queuePendingRemoteProducer(remoteId, kind);
      return;
    }
    if (this.consumingRemoteProducers.has(key)) return;
    this.consumingRemoteProducers.add(key);
    this.debug('voice.consume.start', { remoteId, kind });
    try {
      const result = await this.connection.trpc.voice.consume.mutate({
        kind,
        remoteId,
        rtpCapabilities: this.deviceRtpCapabilities
      });
      const consumer = await this.consumerTransport.consume({
        id: result.consumerId,
        producerId: result.producerId,
        kind: mediasoupKind(kind),
        rtpParameters: result.consumerRtpParameters
      });
      this.pendingRemoteProducers.delete(key);
      this.consumers.set(key, consumer);
      const stream = new MediaStream([consumer.track]);
      if (REMOTE_AUDIO_KINDS.has(kind)) this.remoteAudioStreams.set(key, { remoteId, kind, stream });
      if (REMOTE_VIDEO_KINDS.has(kind)) this.remoteVideoStreams.set(key, { remoteId, kind, stream });
      this.debug('voice.consume.ok', { remoteId, kind, consumerId: result.consumerId, producerId: result.producerId, trackReadyState: consumer.track.readyState, trackMuted: consumer.track.muted });
      const cleanup = () => this.removeRemoteProducer(remoteId, kind);
      consumer.on('transportclose', cleanup);
      (consumer as unknown as { on(event: 'producerclose', listener: () => void): void }).on('producerclose', cleanup);
      consumer.on('trackended', cleanup);
      consumer.on('@close', cleanup);
      consumer.observer.on('close', cleanup);
      consumer.track.addEventListener?.('ended', cleanup);
      consumer.track.onunmute = () => this.debug('voice.consume.track.unmute', { remoteId, kind, readyState: consumer.track.readyState });
      consumer.track.onmute = () => this.debug('voice.consume.track.mute', { remoteId, kind, readyState: consumer.track.readyState });
      this.emitRemoteAudioStreams();
      this.emitRemoteVideoStreams();
    } finally {
      this.consumingRemoteProducers.delete(key);
    }
  }

  private queuePendingRemoteProducer(remoteId: number, kind: StreamKind) {
    const key = `${remoteId}:${kind}`;
    this.pendingRemoteProducers.set(key, { remoteId, kind });
    this.debug('voice.consume.queued', { remoteId, kind, hasConsumerTransport: !!this.consumerTransport, hasRtpCapabilities: !!this.deviceRtpCapabilities }, 'warn', 'Remote Producer wartet auf Consumer-Transport');
  }

  private async drainPendingRemoteProducers() {
    const pending = [...this.pendingRemoteProducers.values()];
    if (!pending.length) return;
    this.debug('voice.consume.drain.start', { count: pending.length });
    await Promise.all(pending.map((item) => this.consumeProducer(item.remoteId, item.kind).catch((error) => this.debug('voice.consume.drain.error', { remoteId: item.remoteId, kind: item.kind, error: cleanError(error) }, 'error', cleanError(error)))));
    this.debug('voice.consume.drain.done', { remaining: this.pendingRemoteProducers.size });
  }

  removeRemoteProducer(remoteId: number, kind: StreamKind) {
    const key = `${remoteId}:${kind}`;
    this.pendingRemoteProducers.delete(key);
    this.consumingRemoteProducers.delete(key);
    const consumer = this.consumers.get(key);
    this.consumers.delete(key);
    if (consumer && !consumer.closed) consumer.close();
    this.remoteAudioStreams.get(key)?.stream.getTracks().forEach((track) => track.stop());
    this.remoteVideoStreams.get(key)?.stream.getTracks().forEach((track) => track.stop());
    this.remoteAudioStreams.delete(key);
    this.remoteVideoStreams.delete(key);
    this.emitRemoteAudioStreams();
    this.emitRemoteVideoStreams();
  }

  private resetRemoteConsumers() {
    this.consumerTransport?.close();
    this.consumerTransport = undefined;
    this.pendingRemoteProducers.clear();
    this.consumingRemoteProducers.clear();
    for (const consumer of this.consumers.values()) if (!consumer.closed) consumer.close();
    this.consumers.clear();
    for (const stream of this.remoteAudioStreams.values()) stream.stream.getTracks().forEach((track) => track.stop());
    for (const stream of this.remoteVideoStreams.values()) stream.stream.getTracks().forEach((track) => track.stop());
    this.remoteAudioStreams.clear();
    this.remoteVideoStreams.clear();
    this.emitRemoteAudioStreams();
    this.emitRemoteVideoStreams();
  }

  async recoverAfterServerMediaReset() {
    if (!this.device) throw new Error(tr('Voice-Medien noch nicht bereit'));
    this.debug('voice.recovery.remote.start');
    this.resetRemoteConsumers();
    await this.createConsumerTransport(this.device);
    await this.refreshExistingProducers();
    this.debug('voice.recovery.remote.done');
  }

  removeRemoteAudio(remoteId: number, kind: StreamKind) {
    this.removeRemoteProducer(remoteId, kind);
  }

  removeRemoteUser(remoteId: number) {
    for (const key of [...this.remoteAudioStreams.keys(), ...this.remoteVideoStreams.keys()]) {
      if (key.startsWith(`${remoteId}:`)) {
        const [, kind] = key.split(':') as [string, StreamKind];
        this.removeRemoteProducer(remoteId, kind);
      }
    }
  }

  close() {
    this.cleanupMediaOnly();
    this.producerTransport?.close();
    this.consumerTransport?.close();
    this.producerTransport = undefined;
    this.consumerTransport = undefined;
    this.deviceRtpCapabilities = undefined;
    this.device = undefined;
    this.callbacks.onRemoteAudioStreams([]);
    this.callbacks.onRemoteVideoStreams([]);
    this.callbacks.onLocalAudioStream(null);
    this.callbacks.onLocalVideoStream(null);
    this.callbacks.onLocalScreenStream(null);
  }

  private async createProducerTransport(device: Device) {
    this.debug('voice.transport.producer.create.start');
    const params = await this.connection.trpc.voice.createProducerTransport.mutate();
    this.producerTransport = device.createSendTransport(params);
    this.debug('voice.transport.producer.create.ok', { id: params.id, iceCandidates: params.iceCandidates?.length ?? 0, iceParameters: !!params.iceParameters, dtlsParameters: !!params.dtlsParameters });
    this.producerTransport.on('connect', async ({ dtlsParameters }, callback, errback) => {
      this.debug('voice.transport.producer.connect.start', { hasDtlsParameters: !!dtlsParameters });
      try {
        await this.connection.trpc.voice.connectProducerTransport.mutate({ dtlsParameters });
        this.debug('voice.transport.producer.connect.ok');
        callback();
      } catch (error) { this.debug('voice.transport.producer.connect.error', { error: cleanError(error) }, 'error', cleanError(error)); errback(error as Error); }
    });
    this.producerTransport.on('produce', async ({ rtpParameters, appData }, callback, errback) => {
      try {
        const { kind, qualityLayers } = appData as { kind: StreamKind; qualityLayers?: { spatialLayer: number; label: string }[] };
        this.debug('voice.transport.producer.produce.mutate.start', { kind, transportId: this.producerTransport?.id ?? '', hasRtpParameters: !!rtpParameters, qualityLayers: qualityLayers?.length ?? 0 });
        const producerId = await this.connection.trpc.voice.produce.mutate({
          transportId: this.producerTransport?.id ?? '',
          kind,
          rtpParameters,
          qualityLayers
        });
        this.debug('voice.transport.producer.produce.mutate.ok', { kind, producerId });
        callback({ id: producerId });
      } catch (error) { this.debug('voice.transport.producer.produce.mutate.error', { error: cleanError(error) }, 'error', cleanError(error)); errback(error as Error); }
    });
  }

  private async createConsumerTransport(device: Device) {
    this.debug('voice.transport.consumer.create.start');
    const params = await this.connection.trpc.voice.createConsumerTransport.mutate();
    this.consumerTransport = device.createRecvTransport(params);
    this.debug('voice.transport.consumer.create.ok', { id: params.id, iceCandidates: params.iceCandidates?.length ?? 0, iceParameters: !!params.iceParameters, dtlsParameters: !!params.dtlsParameters });
    this.consumerTransport.on('connect', async ({ dtlsParameters }, callback, errback) => {
      this.debug('voice.transport.consumer.connect.start', { hasDtlsParameters: !!dtlsParameters });
      try {
        await this.connection.trpc.voice.connectConsumerTransport.mutate({ dtlsParameters });
        this.debug('voice.transport.consumer.connect.ok');
        callback();
      } catch (error) { this.debug('voice.transport.consumer.connect.error', { error: cleanError(error) }, 'error', cleanError(error)); errback(error as Error); }
    });
  }

  async refreshExistingProducers() {
    if (!this.consumerTransport || !this.deviceRtpCapabilities) {
      this.debug('voice.consume.refresh.skipped', { hasConsumerTransport: !!this.consumerTransport, hasRtpCapabilities: !!this.deviceRtpCapabilities }, 'warn', 'Remote Producer Refresh wartet auf Medien-Transport');
      return;
    }
    this.debug('voice.consume.refresh.start');
    await this.consumeExistingProducers();
    await this.drainPendingRemoteProducers();
    this.debug('voice.consume.refresh.done', { audioStreams: this.remoteAudioStreams.size, videoStreams: this.remoteVideoStreams.size });
  }

  private syncRemoteProducerState(activeKeys: Set<string>) {
    for (const key of [...this.consumers.keys(), ...this.remoteAudioStreams.keys(), ...this.remoteVideoStreams.keys(), ...this.pendingRemoteProducers.keys()]) {
      if (!activeKeys.has(key)) {
        const [remoteId, kind] = key.split(':') as [string, StreamKind];
        this.removeRemoteProducer(Number(remoteId), kind);
      }
    }
  }

  private async consumeExistingProducers() {
    const producers = await this.connection.trpc.voice.getProducers.query();
    this.syncRemoteProducerState(new Set([
      ...(producers.remoteAudioIds ?? []).map((remoteId: number) => `${remoteId}:${AUDIO_KIND}`),
      ...(producers.remoteVideoIds ?? []).map((remoteId: number) => `${remoteId}:${VIDEO_KIND}`),
      ...(producers.remoteScreenIds ?? []).map((remoteId: number) => `${remoteId}:${SCREEN_KIND}`),
      ...(producers.remoteScreenAudioIds ?? []).map((remoteId: number) => `${remoteId}:${SCREEN_AUDIO_KIND}`),
      ...(producers.remoteExternalStreamIds ?? []).flatMap((remoteId: number) => [`${remoteId}:${EXTERNAL_AUDIO_KIND}`, `${remoteId}:${EXTERNAL_VIDEO_KIND}`])
    ]));
    this.debug('voice.consume.existing.producers', {
      remoteAudioIds: producers.remoteAudioIds?.length ?? 0,
      remoteVideoIds: producers.remoteVideoIds?.length ?? 0,
      remoteScreenIds: producers.remoteScreenIds?.length ?? 0,
      remoteScreenAudioIds: producers.remoteScreenAudioIds?.length ?? 0,
      remoteExternalStreamIds: producers.remoteExternalStreamIds?.length ?? 0
    });
    const tasks: Array<Promise<void>> = [
      ...(producers.remoteAudioIds ?? []).map((remoteId: number) => this.consumeProducer(remoteId, AUDIO_KIND)),
      ...(producers.remoteVideoIds ?? []).map((remoteId: number) => this.consumeProducer(remoteId, VIDEO_KIND)),
      ...(producers.remoteScreenIds ?? []).map((remoteId: number) => this.consumeProducer(remoteId, SCREEN_KIND)),
      ...(producers.remoteScreenAudioIds ?? []).map((remoteId: number) => this.consumeProducer(remoteId, SCREEN_AUDIO_KIND)),
      ...(producers.remoteExternalStreamIds ?? []).flatMap((remoteId: number) => [this.consumeProducer(remoteId, EXTERNAL_AUDIO_KIND), this.consumeProducer(remoteId, EXTERNAL_VIDEO_KIND)])
    ];
    await Promise.all(tasks.map((task) => task.catch((error) => this.onStatus(`Remote Stream: ${cleanError(error)}`))));
  }

  private stopMicStream() {
    if (this.audioProducer && !this.audioProducer.closed) this.audioProducer.close();
    this.audioProducer = undefined;
    this.callbacks.onLocalAudioStream(null);
    this.cleanupGain?.();
    this.cleanupGain = undefined;
    this.cleanupDenoise?.();
    this.cleanupDenoise = undefined;
    this.cleanupVoiceGate?.();
    this.cleanupVoiceGate = undefined;
    this.localAudioStream?.getTracks().forEach((track) => track.stop());
    if (this.rawAudioStream !== this.localAudioStream) this.rawAudioStream?.getTracks().forEach((track) => track.stop());
    this.localAudioStream = undefined;
    this.rawAudioStream = undefined;
  }



  private createGainProcessedStream(input: MediaStream): MediaStream {
    const gainValue = Number.isFinite(this.settings.microphoneGain) ? Math.max(0, Math.min(2, this.settings.microphoneGain)) : 1;
    if (Math.abs(gainValue - 1) < 0.001) return input;
    const AudioContextCtor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextCtor) return input;
    const context = new AudioContextCtor({ sampleRate: 48000 });
    void context.resume().catch(() => undefined);
    const source = context.createMediaStreamSource(input);
    const gain = context.createGain();
    const destination = context.createMediaStreamDestination();
    gain.gain.value = this.settings.microphoneGain;
    source.connect(gain).connect(destination);
    this.cleanupGain = () => {
      source.disconnect();
      gain.disconnect();
      void context.close().catch(() => undefined);
    };
    return destination.stream;
  }


  private async createVoiceIsolatedStream(input: MediaStream): Promise<MediaStream> {
    const denoised = await this.createDenoisedStream(input);
    const gained = this.createGainProcessedStream(denoised);
    return this.createVoiceGateStream(gained);
  }

  private async createVoiceGateStream(input: MediaStream): Promise<MediaStream> {
    const AudioContextCtor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextCtor || typeof AudioWorkletNode === 'undefined') return input;
    try {
      const context = new AudioContextCtor({ sampleRate: 48000 });
      await context.resume().catch(() => undefined);
      await context.audioWorklet.addModule(voiceGateWorkletUrl);
      const source = context.createMediaStreamSource(input);
      const gate = new AudioWorkletNode(context, 'voice-gate-processor', { processorOptions: voiceGateParamsForIntensity(this.settings.voiceIsolationIntensity) });
      const compressor = context.createDynamicsCompressor();
      compressor.threshold.value = -28;
      compressor.knee.value = 18;
      compressor.ratio.value = 5;
      compressor.attack.value = 0.003;
      compressor.release.value = 0.16;
      const destination = context.createMediaStreamDestination();
      source.connect(gate).connect(compressor).connect(destination);
      this.cleanupVoiceGate = () => {
        source.disconnect();
        gate.disconnect();
        compressor.disconnect();
        void context.close().catch(() => undefined);
      };
      return destination.stream;
    } catch (error) {
      this.debug('voice.gate.error', { error: cleanError(error) }, 'warn', cleanError(error));
      return input;
    }
  }

  private async createDenoisedStream(input: MediaStream): Promise<MediaStream> {
    const AudioContextCtor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextCtor || typeof AudioWorkletNode === 'undefined') return input;
    const context = new AudioContextCtor({ sampleRate: 48000 });
    void context.resume().catch(() => undefined);
    try {
      const source = context.createMediaStreamSource(input);
      const destination = context.createMediaStreamDestination();
      await context.audioWorklet.addModule(rnnoiseWorkletUrl);
      const wasmBinary = await loadRnnoise({ url: rnnoiseWasmUrl, simdUrl: rnnoiseSimdWasmUrl });
      const rnnoise = new RnnoiseWorkletNode(context, { maxChannels: 1, wasmBinary });
      source.connect(rnnoise).connect(destination);
      this.cleanupDenoise = () => {
        source.disconnect();
        rnnoise.disconnect();
        rnnoise.destroy();
        void context.close().catch(() => undefined);
      };
      return destination.stream;
    } catch (rnnoiseError) {
      try {
        await context.audioWorklet.addModule(speexWorkletUrl);
        const wasmBinary = await loadSpeex({ url: speexWasmUrl });
        const source = context.createMediaStreamSource(input);
        const speex = new SpeexWorkletNode(context, { maxChannels: 1, wasmBinary });
        const destination = context.createMediaStreamDestination();
        source.connect(speex).connect(destination);
        this.cleanupDenoise = () => {
          source.disconnect();
          speex.disconnect();
          speex.destroy();
          void context.close().catch(() => undefined);
        };
        return destination.stream;
      } catch (speexError) {
        await context.close().catch(() => undefined);
        this.onStatus(tr(`Rauschunterdrückung Fallback: ${cleanError(rnnoiseError)} / ${cleanError(speexError)}`));
        return input;
      }
    }
  }

  private cleanupMediaOnly() {
    this.stopMicStream();
    this.stopWebcamStream();
    this.stopScreenShareStream();
    for (const consumer of this.consumers.values()) if (!consumer.closed) consumer.close();
    this.consumers.clear();
    this.pendingRemoteProducers.clear();
    this.consumingRemoteProducers.clear();
    for (const stream of this.remoteAudioStreams.values()) stream.stream.getTracks().forEach((track) => track.stop());
    for (const stream of this.remoteVideoStreams.values()) stream.stream.getTracks().forEach((track) => track.stop());
    this.remoteAudioStreams.clear();
    this.remoteVideoStreams.clear();
  }

  private emitRemoteAudioStreams() {
    this.callbacks.onRemoteAudioStreams([...this.remoteAudioStreams.values()]);
  }

  private emitRemoteVideoStreams() {
    const remoteVideoStreams = [...this.remoteVideoStreams.values()].filter((item) => item.kind === VIDEO_KIND);
    const remoteScreenStreams = [...this.remoteVideoStreams.values()].filter((item) => item.kind === SCREEN_KIND);
    const remoteExternalVideoStreams = [...this.remoteVideoStreams.values()].filter((item) => item.kind === EXTERNAL_VIDEO_KIND);
    this.callbacks.onRemoteVideoStreams([...remoteVideoStreams, ...remoteScreenStreams, ...remoteExternalVideoStreams]);
  }
}

function mediasoupKind(kind: StreamKind): 'audio' | 'video' {
  return REMOTE_AUDIO_KINDS.has(kind) ? 'audio' : 'video';
}

function cleanError(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

function normalizeMediaDevices(devices: MediaDeviceInfo[], kind: MediaDeviceKind) {
  const seen = new Set<string>();
  return devices.filter((device) => {
    if (device.kind !== kind) return false;
    if (!device.deviceId || device.deviceId === 'default') return false;
    if (seen.has(device.deviceId)) return false;
    seen.add(device.deviceId);
    return true;
  });
}

export async function enumerateAudioDevices() {
  if (!navigator.mediaDevices?.enumerateDevices) return { inputs: [] as MediaDeviceInfo[], outputs: [] as MediaDeviceInfo[], videos: [] as MediaDeviceInfo[] };
  const devices = await navigator.mediaDevices.enumerateDevices();
  return {
    inputs: normalizeMediaDevices(devices, 'audioinput'),
    outputs: normalizeMediaDevices(devices, 'audiooutput'),
    videos: normalizeMediaDevices(devices, 'videoinput')
  };
}

export async function refreshMediaDeviceLists() {
  return enumerateAudioDevices();
}

export async function requestMediaDeviceAccess(kind: 'microphone' | 'camera') {
  if (!navigator.mediaDevices?.getUserMedia) throw new Error(tr('MediaDevices API nicht verfügbar'));
  const stream = kind === 'microphone'
    ? await navigator.mediaDevices.getUserMedia({ audio: true, video: false })
    : await navigator.mediaDevices.getUserMedia({ audio: false, video: true });
  const result = kind === 'microphone'
    ? { audioTracks: stream.getAudioTracks().length }
    : { videoTracks: stream.getVideoTracks().length };
  stream.getTracks().forEach((track) => track.stop());
  return result;
}

export async function applyAudioOutputDevice(audio: HTMLAudioElement | null, playbackId?: string) {
  if (!audio || !playbackId) return true;
  const audioWithSink = audio as HTMLAudioElement & { setSinkId?: (deviceId: string) => Promise<void>; sinkId?: string };
  if (typeof audioWithSink.setSinkId !== 'function') return true;
  if (audioWithSink.sinkId === playbackId) return true;
  await audioWithSink.setSinkId(playbackId);
  return true;
}
