import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const styleSource = readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');

test('user moderation and voice disconnect use app-owned confirmation dialog instead of native browser UI', () => {
  const moderateHandler = appSource.match(/function moderateContextUser\(user: SharkordUser, action: 'kick' \| 'ban' \| 'unban' \| 'delete'\) \{[\s\S]*?\n  \}/)?.[0] ?? '';
  const voiceHandler = appSource.match(/function disconnectContextVoiceUser\(user: SharkordUser\) \{[\s\S]*?\n  \}/)?.[0] ?? '';
  const dialog = appSource.match(/function AdminActionConfirmDialog\([\s\S]*?\n\}/)?.[0] ?? '';

  assert.match(appSource, /type AdminConfirmAction =/);
  assert.match(moderateHandler, /setPendingAdminConfirm\(\{ kind: 'moderate-user'/);
  assert.match(voiceHandler, /setPendingAdminConfirm\(\{ kind: 'disconnect-voice-user'/);
  assert.doesNotMatch(moderateHandler, /window\.confirm|prompt\(/);
  assert.doesNotMatch(voiceHandler, /window\.confirm|prompt\(/);
  assert.match(dialog, /role="dialog"/);
  assert.match(dialog, /adminConfirmField/);
  assert.match(dialog, /Benutzer-Daten endgültig löschen \(Wipe\)/);
  assert.match(styleSource, /\.adminConfirmField textarea/);
});

test('server role edit and delete buttons use app-owned dialogs instead of native prompt confirm', () => {
  const adminWorkbench = appSource.match(/function AdminWorkbench[\s\S]*?function AdminUserInfoModal/)?.[0] ?? '';
  const editRoleHandler = adminWorkbench.match(/const editRole = \(role: SharkordRole\) =>[\s\S]*?;\n/)?.[0] ?? '';
  const removeRoleHandler = adminWorkbench.match(/const removeRole = \(role: SharkordRole\) =>[\s\S]*?;\n/)?.[0] ?? '';
  const roleDialog = appSource.match(/function RoleActionDialog\([\s\S]*?\n\}/)?.[0] ?? '';

  assert.ok(editRoleHandler, 'editRole handler not found');
  assert.ok(removeRoleHandler, 'removeRole handler not found');
  assert.doesNotMatch(editRoleHandler, /prompt\(|window\.confirm/);
  assert.doesNotMatch(removeRoleHandler, /prompt\(|window\.confirm/);
  assert.match(editRoleHandler, /setPendingRoleAction\(\{ kind: 'edit'/);
  assert.match(removeRoleHandler, /setPendingRoleAction\(\{ kind: 'delete'/);
  assert.match(appSource, /type RoleAction =/);
  assert.match(appSource, /confirmRoleAction/);
  assert.match(roleDialog, /role="dialog"/);
  assert.match(roleDialog, /adminConfirmField/);
  assert.match(roleDialog, /Rolle löschen/);
});
