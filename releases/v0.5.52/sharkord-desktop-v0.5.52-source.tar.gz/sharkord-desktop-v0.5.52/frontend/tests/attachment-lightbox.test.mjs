import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const cssSource = readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');

const lightboxSource = () => appSource.match(/function AttachmentLightbox[\s\S]*?function MessageBubble/)?.[0] ?? '';
const messageFileCardsSource = () => appSource.match(/function MessageFileCards[\s\S]*?function MessageBubble/)?.[0] ?? '';
const storageModalSource = () => appSource.match(/storageOpen \? <div className="modalBackdrop userStorageBackdrop"[\s\S]*?<div className="messagesList messageScroller"/)?.[0] ?? '';

test('attachment lightbox exposes safe viewer overlay with controls and close affordances', () => {
  const source = lightboxSource();
  assert.ok(source, 'AttachmentLightbox component should be present before MessageBubble');
  assert.match(source, /role="dialog"/);
  assert.match(source, /aria-modal="true"/);
  assert.match(source, /attachmentLightboxBackdrop/);
  assert.match(source, /attachmentLightboxPanel/);
  assert.match(source, /onMouseDown=\{onClose\}/, 'backdrop should close the lightbox');
  assert.match(source, /event\.stopPropagation\(\)/, 'panel clicks should not close the lightbox');
  assert.match(source, /event\.key === 'Escape'/, 'Escape should close the lightbox');
  assert.match(source, /copyAttachmentUrl\(href\)/, 'Copy URL should use the existing resolved URL only');
  assert.match(appSource, /navigator\.clipboard\.writeText\(href\)/, 'Copy URL helper should write only the resolved href');
  for (const label of ['Datei öffnen', 'Herunterladen', 'URL kopieren', 'Schließen']) {
    assert.match(source, new RegExp(label));
  }
  assert.doesNotMatch(source, /dangerouslySetInnerHTML|innerHTML\s*=/, 'lightbox must not inject raw attachment HTML');
});

test('message attachments open the real lightbox and keep non-images as file cards with actions', () => {
  const source = messageFileCardsSource();
  assert.ok(source, 'MessageFileCards should be present');
  assert.match(source, /onOpenLightbox/, 'message file cards should receive a lightbox opener');
  assert.match(source, /type="button" className="messageFilePreview"/, 'previews should be buttons that open the in-app viewer, not only target=_blank links');
  assert.match(source, /isImage && href \? <img/, 'image attachments should render preview thumbnails');
  assert.match(source, /<HardDrive size=\{22\} \/>/, 'non-image attachments should stay as generic file cards');
  assert.match(source, /messageFileActions/);
  assert.match(source, /attachmentOpenButton/);
  assert.match(source, /attachmentCopyButton/);
  assert.doesNotMatch(source, /dangerouslySetInnerHTML/);
});

test('storage browser shares the attachment lightbox and URL actions', () => {
  const source = storageModalSource();
  assert.ok(source, 'storage modal source should be present');
  assert.match(source, /setAttachmentLightbox\(\{ file, href, label, isImage \}\)/, 'storage previews should open the shared attachment lightbox');
  assert.match(source, /type="button" className="userStoragePreview"/, 'storage previews should be in-app viewer buttons');
  assert.match(source, /userStorageFileActions/);
  assert.match(source, /download=\{label\}/, 'storage cards should expose download links');
  assert.match(source, /copyAttachmentUrl/, 'storage cards should expose copy URL action');
});

test('attachment lightbox CSS is fixed, scroll-safe, keyboard-visible, and above message actions', () => {
  assert.match(cssSource, /\.attachmentLightboxBackdrop\s*\{[^}]*position:\s*fixed;[^}]*inset:\s*0;[^}]*z-index:\s*(?:[5-9]\d|\d{3,})/s);
  assert.match(cssSource, /\.attachmentLightboxPanel\s*\{[^}]*max-width:\s*min\(960px,\s*calc\(100vw - 32px\)\);[^}]*max-height:\s*calc\(100dvh - 32px\);[^}]*overflow:\s*hidden/s);
  assert.match(cssSource, /\.attachmentLightboxPreview\s*\{[^}]*min-height:\s*0;[^}]*overflow:\s*auto/s);
  assert.match(cssSource, /\.attachmentLightboxPreview img\s*\{[^}]*max-width:\s*100%;[^}]*max-height:\s*calc\(100dvh - 220px\);[^}]*object-fit:\s*contain/s);
  assert.match(cssSource, /\.attachmentLightboxActions a:focus-visible,\s*\.attachmentLightboxActions button:focus-visible\s*\{[^}]*outline:/s);
});
