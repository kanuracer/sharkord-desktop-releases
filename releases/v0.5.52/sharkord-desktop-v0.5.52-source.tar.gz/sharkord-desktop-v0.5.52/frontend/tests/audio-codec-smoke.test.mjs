import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const voiceSource = readFileSync(new URL('../src/voiceEngine.ts', import.meta.url), 'utf8');

test('desktop voice source pins local audio producers to the Sharkord Opus contract', () => {
  assert.match(voiceSource, /AUDIO_OPUS_CODEC_MIME_TYPE\s*=\s*'audio\/opus'/);
  assert.match(voiceSource, /SHARKORD_AUDIO_OPUS_PRODUCER_CODEC_OPTIONS/);
  for (const option of ['opusStereo', 'opusFec', 'opusDtx', 'opusMaxPlaybackRate', 'opusMaxAverageBitrate']) {
    assert.match(voiceSource, new RegExp(`${option}:`));
  }
  assert.match(voiceSource, /codecOptions:\s*\{\s*\.\.\.SHARKORD_AUDIO_OPUS_PRODUCER_CODEC_OPTIONS,\s*opusStereo:\s*false\s*\}/s);
  assert.match(voiceSource, /codecOptions:\s*\{\s*\.\.\.SHARKORD_AUDIO_OPUS_PRODUCER_CODEC_OPTIONS,\s*opusStereo:\s*true\s*\}/s);
});

test('audio producer debug evidence records the negotiated RTP codec from Producer rtpParameters', () => {
  assert.match(voiceSource, /summarizeAudioCodecNegotiation/);
  assert.match(voiceSource, /producer\.rtpParameters/);
  assert.match(voiceSource, /voice\.produce\.codec/);
  assert.match(voiceSource, /codecMimeTypes/);
  assert.match(voiceSource, /negotiatedAudioCodec/);
  assert.match(voiceSource, /audioCodecNegotiated/);
  assert.match(voiceSource, /Expected audio\/opus/);
});
