import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

test('desktop channel drag/drop gates cross-category moves behind fork capability', () => {
  const handler = appSource.match(/async function handleChannelDrop\(target: SharkordChannel, group: ChannelGroup\) \{[\s\S]*?\n  \}/)?.[0] ?? '';
  assert.match(clientSource, /channelCrossCategoryMove: false/);
  assert.match(clientSource, /channelCrossCategoryMove: capabilityEnabled\(nested\.channelCrossCategoryMove, nested\.channelCrossCategoryReorder, nested\.crossCategoryChannelMove, nested\.crossCategoryChannelReorder\)/);
  assert.match(clientSource, /export async function reorderChannels\(connection: SharkordConnection, categoryId: number, channelIds: number\[\]\)/);
  assert.match(clientSource, /channels\.reorder\.mutate\(\{ categoryId, channelIds \}\)/);
  assert.match(handler, /const sourceChannel = liveChannels\.find\(\(channel\) => channel\.id === sourceId\)/);
  assert.match(handler, /sourceChannel\.categoryId !== categoryId && !connection\.serverCapabilities\.channelCrossCategoryMove/);
  assert.match(handler, /Dieser Server unterstützt Channels zwischen Kategorien verschieben nicht/);
  assert.match(handler, /return \{ \.\.\.channel, categoryId, position: nextPositions\.get\(channel\.id\)! \}/);
  assert.match(handler, /reorderChannels\(connection, categoryId, ids\)/);
  assert.match(handler, /Channel in Kategorie verschoben/);
});
