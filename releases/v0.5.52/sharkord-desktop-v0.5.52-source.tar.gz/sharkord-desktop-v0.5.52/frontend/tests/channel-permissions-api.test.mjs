import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

function extractFunction(name) {
  const marker = `export async function ${name}`;
  const start = clientSource.indexOf(marker);
  assert.notEqual(start, -1, `${name} export not found`);
  const next = clientSource.indexOf('\nexport async function ', start + marker.length);
  return clientSource.slice(start, next === -1 ? clientSource.length : next);
}

function firstMutatePayload(source, procedure) {
  const match = source.match(new RegExp(`${procedure}\\.mutate\\(([^\n]*)\\);`));
  assert.ok(match, `${procedure}.mutate payload not found`);
  return match[1];
}

test('channel permissions are fetched through the current server mutation route', () => {
  const getFn = extractFunction('getChannelPermissions');
  assert.match(getFn, /channels\.getPermissions\.mutate\(\{ channelId \}\)/);
  assert.doesNotMatch(getFn, /channels\.getPermissions\.query/);
  assert.match(getFn, /normalizeChannelPermissionOverrides/);
});

test('channel permission updates use userId or roleId plus permissions array payload', () => {
  const updateFn = extractFunction('updateChannelPermissions');
  assert.match(clientSource, /function channelPermissionTargetPayload\(targetType: ChannelPermissionTarget, targetId: number\): \{ roleId: number \} \| \{ userId: number \}/);
  assert.match(clientSource, /targetType === 'user' \? \{ userId: targetId \} : \{ roleId: targetId \}/);
  assert.match(updateFn, /const targetPayload = channelPermissionTargetPayload\(targetType, targetId\);/);

  const payload = firstMutatePayload(updateFn, 'updatePermissions');
  assert.match(payload, /\{ channelId, \.\.\.targetPayload, permissions: normalizeChannelPermissionNames\(allow\) \}/);
  assert.doesNotMatch(payload, /\btargetType\b|\btargetId\b|\ballow:/);
  assert.doesNotMatch(payload, /\bdeny\b/);
});

test('channel permission deletes use current userId or roleId target schema', () => {
  const deleteFn = extractFunction('deleteChannelPermissions');
  assert.match(deleteFn, /const targetPayload = channelPermissionTargetPayload\(targetType, targetId\);/);

  const payload = firstMutatePayload(deleteFn, 'deletePermissions');
  assert.match(payload, /\{ channelId, \.\.\.targetPayload \}/);
  assert.doesNotMatch(payload, /\btargetType\b|\btargetId\b/);
});

test('server channel permission rows are normalized for the Desktop allow-deny UI model', () => {
  assert.match(clientSource, /rolePermissions\?: ChannelPermissionRow\[\]/);
  assert.match(clientSource, /userPermissions\?: ChannelPermissionRow\[\]/);
  assert.match(clientSource, /pushChannelPermissionRow\(groups, 'role', row\.roleId, row\)/);
  assert.match(clientSource, /pushChannelPermissionRow\(groups, 'user', row\.userId, row\)/);
  assert.match(clientSource, /if \(row\.allow\)[\s\S]*override\.allow\.push\(permission\)[\s\S]*override\.deny\.push\(permission\)/);
});
