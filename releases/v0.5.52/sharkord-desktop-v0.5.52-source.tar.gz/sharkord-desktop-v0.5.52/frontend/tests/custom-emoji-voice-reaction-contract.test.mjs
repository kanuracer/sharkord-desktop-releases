import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const typesSource = readFileSync(new URL('../src/sharkordTypes.ts', import.meta.url), 'utf8');

test('desktop understands fork-only custom emoji reaction ids without enabling them for original servers', () => {
  assert.match(clientSource, /customEmojiReactionIds: boolean/);
  assert.match(clientSource, /customEmojiReactionIds: false/);
  assert.match(clientSource, /customEmojiReactionValue/);
  assert.match(appSource, /customEmojiReactionName/);
  assert.match(typesSource, /file\?: SharkordFile \| null/);
});

test('desktop voice reactions keep capability fallback and can display custom image badges', () => {
  assert.match(clientSource, /voiceReactions: false/);
  assert.match(clientSource, /file\?: SharkordFile \| null/);
  assert.match(appSource, /reaction\.file/);
  assert.match(appSource, /customEmojiReactionValue/);
});
