import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';

const root = resolve(import.meta.dirname, '..');
const read = (relativePath) => readFileSync(resolve(root, relativePath), 'utf8');

const app = read('src/App.tsx');
const types = read('src/sharkordTypes.ts');
const client = read('src/sharkordClient.ts');

assert.match(types, /statusMessage\?: string/);
assert.match(types, /statusOverride\?: string/);
assert.match(client, /customUserStatus: boolean/);
assert.match(client, /notificationSoundControls: boolean/);
assert.match(app, /notificationSounds/);
assert.match(app, /shouldPlayNotificationSound/);
assert.match(app, /statusMessage/);
assert.match(app, /statusOverride/);
assert.match(client, /customUserStatus/);
assert.match(client, /notificationSoundControls/);
console.log('custom status + notification sound source gates ok');
