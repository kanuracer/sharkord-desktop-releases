import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const cssSource = readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
const contextMenuSource = appSource.match(/function AdminContextMenu[\s\S]*?\n}\n\n\ntype InviteDraft/)?.[0] ?? '';
const membersPanelSource = appSource.match(/function MembersPanel[\s\S]*?const MESSAGE_URL_RE/)?.[0] ?? '';
const messageBubbleSource = appSource.match(/function MessageBubble[\s\S]*?\n}\n\nfunction ThreadPanel/)?.[0] ?? '';
const memberGroupingSource = appSource.match(/function groupMembersByAssignedRole[\s\S]*?\nfunction credsToAuth/)?.[0] ?? '';

test('desktop user context menu shows voice-only controls only when target is in voice', () => {
  assert.match(contextMenuSource, /voiceMap: VoiceMap/);
  assert.match(contextMenuSource, /const menuVoiceState = menu\.kind === 'user'/);
  assert.match(contextMenuSource, /const userInVoice = !!menuVoiceState/);
  assert.match(contextMenuSource, /activeServer && userInVoice/);
  assert.match(contextMenuSource, /connection\?\.serverCapabilities\.voiceUserDisconnect && canManageTargetVoice/);
  assert.match(contextMenuSource, /menuVoiceState\?\.webcamEnabled/);
  assert.match(contextMenuSource, /menuVoiceState\?\.sharingScreen/);
});

test('desktop context role toggles update local user state immediately', () => {
  assert.match(appSource, /const nextRoleIds = hasRole/);
  assert.match(appSource, /connection\.join\.users = \(connection\.join\.users \?\? \[\]\)\.map\(patchUserRoles\)/);
  assert.match(appSource, /setLiveUsers\(\(current\) => current\.map\(patchUserRoles\)\)/);
  assert.match(appSource, /setContextMenu\(\(current\) => current\?\.kind === 'user'/);
});

test('desktop members panel groups online users by role and keeps offline as one plain group', () => {
  assert.match(membersPanelSource, /roles: SharkordRole\[\]/);
  assert.match(membersPanelSource, /groupMembersByPresenceAndRole\(panelUsers, roles, ownUserId\)/);
  assert.match(appSource, /function memberPresenceStatus\(user: SharkordUser, ownUserId\?: number\)/);
  assert.match(appSource, /return user\.id === ownUserId \? 'online' : 'offline'/);
  assert.doesNotMatch(membersPanelSource, /user\.status \?\? 'online'/);
  assert.match(memberGroupingSource, /groupMembersByAssignedRole\(onlineUsers, roles\)/);
  assert.match(memberGroupingSource, /key:\s*'offline'/);
  assert.doesNotMatch(memberGroupingSource, /groupMembersByAssignedRole\(offlineUsers/);
});

test('desktop member role grouping uses server role weights with lower numbers sorted higher', () => {
  assert.match(appSource, /function roleSortWeight\(role: SharkordRole \| undefined\): number/);
  assert.match(appSource, /const weight = Number\(role\.weight\)/);
  assert.match(memberGroupingSource, /roleSortWeight\(a\) - roleSortWeight\(b\)/);
  assert.match(memberGroupingSource, /weight:\s*roleSortWeight/);
  assert.match(memberGroupingSource, /sort\(\(a, b\) => a\.weight - b\.weight/);
  assert.match(memberGroupingSource, /\(user\.roleIds \?\? \[\]\).*sort\(\(a, b\) => roleSortWeight\(a\) - roleSortWeight\(b\)/s);
  assert.match(appSource, /tr\('Rollengewichtung'\)/);
  assert.doesNotMatch(appSource, /memberRoleWeights/);
});

test('desktop message reaction action opens picker instead of hard-coded thumbs-up', () => {
  assert.match(messageBubbleSource, /reactionPickerOpen/);
  assert.match(messageBubbleSource, /messageReactionChoices/);
  assert.match(messageBubbleSource, /messageReactionPicker/);
  assert.match(messageBubbleSource, /reactionPickerOpen \? 'reactionPickerOpen'/);
  assert.doesNotMatch(messageBubbleSource, /onToggleReaction\(message, '👍'\)/);
});

test('desktop message reaction picker opens downward and stays visible while open', () => {
  const pickerRule = cssSource.match(/\.messageReactionPicker\s*\{[^}]*\}/)?.[0] ?? '';
  assert.match(pickerRule, /top:\s*calc\(100% \+ 0px\)/);
  assert.doesNotMatch(pickerRule, /bottom:/);
  assert.match(cssSource, /\.discordMessage\.reactionPickerOpen \.messageActions\s*\{[^}]*display:\s*flex/);
});

test('desktop voice participant rendering normalizes missing voice state to avoid blank grey screen', () => {
  assert.match(appSource, /function normalizeVoiceState\(/);
  assert.match(appSource, /function normalizeVoiceChannelState\(/);
  assert.match(appSource, /addVoiceUser\(channelId: number, userId: number, nextState\?: Partial<VoiceState> \| null\)/);
  assert.match(appSource, /updateVoiceUser\(channelId: number, userId: number, patch\?: Partial<VoiceState> \| null\)/);
  assert.match(appSource, /return user && !isDeletedUserPlaceholder\(user\) \? \{ \.\.\.user, state: normalizeVoiceState\(state\) \}/);
  assert.match(appSource, /Object\.entries\(normalizeVoiceChannelState\(voiceState\)\.users\)/);
  assert.match(appSource, /function findVoiceChannelIdForUser\(voiceMap: VoiceMap, userId: number\)/);
  assert.doesNotMatch(appSource, /Object\.entries\(voiceState\.users \?\? \{\}\)/);
  assert.doesNotMatch(appSource, /\[, state\]\) => !!state\.users\?\./);
  assert.doesNotMatch(appSource, /user\.state\.sharingScreen\)/);
  assert.doesNotMatch(appSource, /user\.state\.webcamEnabled/);
  assert.match(appSource, /const userVoiceState = normalizeVoiceState\(user\.state\)/);
});

test('desktop joined voice grid renders own user fallback instead of blank grey empty card while voice map catches up', () => {
  const voiceFn = appSource.match(/function VoiceGridView[\s\S]*?function VoiceUserCard/)?.[0] ?? '';
  assert.match(voiceFn, /const ownVoiceUser = ownUserId != null \? usersById\.get\(ownUserId\) : undefined/);
  assert.match(voiceFn, /const visibleVoiceUsers: VoiceUser\[\] = joined && ownVoiceUser/);
  assert.match(voiceFn, /!users\.some\(\(user\) => user\.id === ownVoiceUser\.id\)/);
  assert.match(voiceFn, /\{ \.\.\.ownVoiceUser, state: normalizeVoiceState\(voiceState\) \}, \.\.\.users/);
  assert.match(voiceFn, /visibleVoiceUsers\.flatMap/);
  assert.match(voiceFn, /const shouldShowEmptyVoiceCard = !hideCallMembers && !visibleScreenCards\.length && !pendingScreenUsers\.length && !participantCards\.length/);
});

test('desktop voice roster changes clear stale global overlays instead of leaving a full-screen blocker over 2+ participants', () => {
  const clearFn = appSource.match(/function clearTransientVoiceOverlays\([\s\S]*?\n  \}/)?.[0] ?? '';
  const selectVoiceSource = appSource.match(/async function selectVoice\(channel: SharkordChannel\) \{[\s\S]*?\n  \}/)?.[0] ?? '';
  const voiceJoinSource = appSource.match(/onVoiceJoin: \(\{ channelId, userId, state \}\) => \{[\s\S]*?\n      \},/)?.[0] ?? '';
  const joinSelectedSource = appSource.match(/async function joinSelectedVoice\(channel: SharkordChannel\) \{[\s\S]*?\n  \}/)?.[0] ?? '';

  for (const setter of ['setContextMenu(null)', 'setUserProfilePopover(null)', 'setServerDropdown(null)', 'setNotificationCenterOpen(false)', 'setCommandPaletteOpen(false)']) {
    assert.match(clearFn, new RegExp(setter.replace(/[()]/g, '\\$&')));
  }
  assert.match(selectVoiceSource, /clearTransientVoiceOverlays\('voice\.select\.clearOverlays'\)/);
  assert.match(selectVoiceSource, /emitVoiceUiAudit\('voice\.select\.afterState'/);
  assert.match(voiceJoinSource, /userId === next\.join\.ownUserId[\s\S]*clearTransientVoiceOverlays\('voice\.realtime\.ownJoin\.clearOverlays'\)/);
  assert.match(voiceJoinSource, /currentVoiceChannelIdRef\.current === channelId[\s\S]*clearTransientVoiceOverlays\('voice\.realtime\.remoteJoin\.clearOverlays'\)/);
  assert.match(joinSelectedSource, /emitVoiceUiAudit\('voice\.join\.before'/);
  assert.match(joinSelectedSource, /currentVoiceChannelIdRef\.current = channel\.id;[\s\S]*clearTransientVoiceOverlays\('voice\.join\.ok\.clearOverlays'\)/);
  assert.match(joinSelectedSource, /emitVoiceUiAudit\('voice\.join\.afterMediaInit'/);
  assert.match(appSource, /function collectVoiceUiDomDiagnostics\(\)/);
  assert.match(appSource, /document\.elementsFromPoint/);
  assert.doesNotMatch(voiceJoinSource, /setModalOpen\(true\)|setUserProfilePopover\(\{[^}]*user/);
});

test('desktop voice state patches preserve previous participant flags instead of clearing state on producer events', () => {
  assert.match(appSource, /function normalizeVoiceStatePatch\(/);
  assert.match(appSource, /if \('webcamEnabled' in state\) patch\.webcamEnabled = !!state\.webcamEnabled/);
  assert.match(appSource, /if \('sharingScreen' in state\) patch\.sharingScreen = !!state\.sharingScreen/);
  const updateFn = appSource.match(/function updateVoiceUser\(channelId: number, userId: number, patch\?: Partial<VoiceState> \| null\)[\s\S]*?\n  \}/)?.[0] ?? '';
  assert.match(updateFn, /\.\.\.previous, \.\.\.normalizeVoiceStatePatch\(patch\)/);
  assert.doesNotMatch(updateFn, /\.\.\.previous, \.\.\.normalizeVoiceState\(patch\)/);
});

test('desktop role and user update refreshes preserve live presence instead of forcing members offline', () => {
  assert.match(appSource, /function mergeUserPreservingPresence\(existing: SharkordUser, incoming: SharkordUser\): SharkordUser/);
  assert.match(appSource, /function upsertUserListPreservingPresence\(items: SharkordUser\[\], incoming: SharkordUser\): SharkordUser\[\]/);
  assert.match(appSource, /return \{ \.\.\.existing, \.\.\.incoming, status: preserveExistingStatus \? existing\.status : incoming\.status \?\? existing\.status \}/);
  assert.match(appSource, /onUserUpdate: \(user\) => \{ next\.join\.users = upsertUserListPreservingPresence\(next\.join\.users \?\? \[\], user\);/);
  assert.match(appSource, /setLiveUsers\(\(current\) => upsertUserListPreservingPresence\(current, user\)\)/);
  assert.match(appSource, /return mergeUserPreservingPresence\(user, incoming\)/);
  assert.doesNotMatch(appSource, /onUserUpdate: \(user\) => \{ next\.join\.users = upsertListById\(next\.join\.users \?\? \[\], user\)/);
});

test('desktop audio speaking watcher cannot unmount app shell when AudioContext setup fails', () => {
  const watcherSource = appSource.match(/function AudioSpeakingWatcher[\s\S]*?\n}\n\nfunction VoiceGridView/)?.[0] ?? '';
  assert.match(watcherSource, /try \{/);
  assert.match(watcherSource, /stream\.getAudioTracks\(\)\.length/);
  assert.match(watcherSource, /context = new AudioContextCtor\(\)/);
  assert.match(watcherSource, /source = context\.createMediaStreamSource\(stream\)/);
  assert.match(watcherSource, /catch \(err\) \{/);
  assert.match(watcherSource, /console\.warn\('voice\.speakingWatcher\.disabled', err\)/);
  assert.match(watcherSource, /onChange\(userId, false\)/);
  assert.match(watcherSource, /try \{ source\?\.disconnect\(\); \} catch/);
  assert.match(watcherSource, /try \{ analyser\?\.disconnect\(\); \} catch/);
  assert.doesNotMatch(watcherSource, /const context = new AudioContextCtor\(\)/);
  assert.match(appSource, /app\.frontend\.error/);
  assert.match(appSource, /app\.frontend\.unhandledRejection/);
});

