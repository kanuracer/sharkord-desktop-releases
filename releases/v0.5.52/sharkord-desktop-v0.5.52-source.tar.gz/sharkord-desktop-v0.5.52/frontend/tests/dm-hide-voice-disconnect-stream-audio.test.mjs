import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

test('desktop normalizes new server capabilities for DM hide and voice disconnect', () => {
  assert.match(clientSource, /directMessageHide:\s*boolean/);
  assert.match(clientSource, /voiceUserDisconnect:\s*boolean/);
  const defaults = clientSource.match(/export const DEFAULT_ORIGINAL_SERVER_CAPABILITIES:[\s\S]*?};/)?.[0] ?? '';
  assert.match(defaults, /directMessageHide:\s*false/);
  assert.match(defaults, /voiceUserDisconnect:\s*false/);
  assert.match(clientSource, /directMessageHide:\s*capabilityEnabled\(nested\.directMessageHide, nested\.dmHide, nested\.hideDirectMessage\)/);
  assert.match(clientSource, /voiceUserDisconnect:\s*capabilityEnabled\(nested\.voiceUserDisconnect, nested\.voiceDisconnectUser, nested\.disconnectVoiceUser\)/);
});

test('desktop calls new dms.hide endpoint instead of destructive DM delete from sidebar', () => {
  assert.match(clientSource, /export async function hideDirectMessage\(/);
  assert.match(clientSource, /connection\.trpc\.dms\.hide\.mutate\(\{ channelId \}\)/);
  assert.match(clientSource, /isMissingTrpcProcedureError\(error, 'dms\.hide'\)/);
  assert.match(appSource, /entry\.connection\.serverCapabilities\.directMessageHide/);
  assert.match(appSource, /await hideDirectMessage\(entry\.connection, entry\.channel\.id\)/);
  assert.match(appSource, /Direktnachricht ausblenden/);
  assert.doesNotMatch(appSource, /await deleteDirectMessage\(entry\.connection, entry\.channel\.id\)/);
});

test('desktop exposes voice disconnect in user context menu and updates local voice state', () => {
  assert.match(clientSource, /export async function disconnectVoiceUser\(/);
  assert.match(clientSource, /connection\.trpc\.voice\.disconnectUser\.mutate\(\{ userId \}\)/);
  assert.match(clientSource, /isMissingTrpcProcedureError\(error, 'voice\.disconnectUser'\)/);
  assert.match(appSource, /async function disconnectContextVoiceUser\(user: SharkordUser\)/);
  assert.match(appSource, /connection\?\.serverCapabilities\.voiceUserDisconnect/);
  assert.match(appSource, /await disconnectVoiceUser\(connection, user\.id\)/);
  assert.match(appSource, /removeVoiceUser\(Number\(sourceChannelId\), user\.id\)/);
  assert.match(appSource, /Aus Voice trennen/);
});

test('desktop stream audio is muted by default and can be explicitly unmuted', () => {
  assert.match(appSource, /type StreamAudioMuteSettings = Record<string, boolean \| undefined>/);
  assert.match(appSource, /function isStreamAudioMuted\(settings: StreamAudioMuteSettings, serverId: string, remoteId: number\) \{ return settings\[streamAudioMuteKey\(serverId, remoteId\)\] !== false; \}/);
  assert.match(appSource, /const currentlyMuted = current\[key\] !== false/);
  assert.match(appSource, /\[key\]: currentlyMuted \? false : true/);
  assert.match(appSource, /isStreamAudioMuted\(streamAudioMutedUsers, activeServerId, item\.remoteId\)/);
});

test('desktop clamps remote audio element volume to browser-safe 0..1 range', () => {
  assert.match(appSource, /function clampUserVolume\(value: number\) \{ return Math\.max\(0, Math\.min\(200, Math\.round\(value\)\)\); \}/);
  assert.match(appSource, /function clampMediaElementVolume\(value: number\) \{[\s\S]*Math\.min\(1, userVolume \/ 100\)[\s\S]*\}/);
  assert.match(appSource, /ref\.current\.volume = clampMediaElementVolume\(volume\)/);
  assert.doesNotMatch(appSource, /ref\.current\.volume = clampUserVolume\(volume\) \/ 100/);
});
