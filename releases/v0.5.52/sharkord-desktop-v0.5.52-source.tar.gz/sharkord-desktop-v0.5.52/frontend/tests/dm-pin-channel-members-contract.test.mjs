import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const i18nSource = readFileSync(new URL('../src/i18n.ts', import.meta.url), 'utf8');

test('desktop keeps DM pinning and channel access member filtering fork-only', () => {
  assert.match(clientSource, /directMessagePinning: boolean/);
  assert.match(clientSource, /channelAccessMembers: boolean/);
  assert.match(clientSource, /directMessagePinning: false/);
  assert.match(clientSource, /channelAccessMembers: false/);
  assert.match(clientSource, /getAccessibleMembers\(/);
  assert.match(clientSource, /channels\.getAccessibleMembers\.query\(\{\s*channelId,\s*includeAll/);
});

test('desktop gates DM pinning but hides old member filter checkbox while still using channel access data', () => {
  assert.match(appSource, /connection\??\.serverCapabilities\.channelAccessMembers/);
  assert.match(appSource, /getAccessibleMembers\(connection, selectedChannel\.id, false\)/);
  assert.match(appSource, /memberPanelDisplayUsers/);
  assert.doesNotMatch(appSource, /memberAccessFilter/);
  assert.doesNotMatch(appSource, /Nur Channel-Zugriff/);
  assert.match(appSource, /canToggleMessagePin/);
  assert.match(appSource, /serverCapabilities\.directMessagePinning/);
});

test('english i18n covers DM pin copy and removed member filter copy stays out of UI', () => {
  assert.doesNotMatch(appSource, /Nur Channel-Zugriff/);
  assert.match(i18nSource, /DM-Anpinnen wird von diesem Server nicht unterstützt/);
});
