import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const cssSource = readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');

test('DM home offers a user search that can start DMs without opening the profile popover', () => {
  assert.match(appSource, /type DirectMessageUserSearchResult = \{ server: SharkordServer; connection: SharkordConnection; user: SharkordUser; existingEntry: DirectMessageEntry \| null \}/);
  assert.match(appSource, /const \[userSearchQuery, setUserSearchQuery\] = useState\(''\)/);
  assert.match(appSource, /aria-label=\{tr\('User für Direktnachricht suchen'\)\}/);
  assert.match(appSource, /placeholder=\{t\('dm\.sidebar\.searchPlaceholder'\)\}/);
  assert.match(appSource, /const filteredUserSearchResults = useMemo/);
  assert.match(appSource, /onStartUserDm\(filteredUserSearchResults\[0\]\)/);
  assert.match(appSource, /className="dmUserSearchResult"/);
  assert.match(appSource, /\{result\.existingEntry \? tr\('Öffnen'\) : tr\('DM starten'\)\}/);
});

test('DM search candidates come from connected join users and avoid admin-only user APIs', () => {
  assert.match(appSource, /const directMessageSearchCandidates = useMemo<DirectMessageUserSearchResult\[\]>\(\(\) =>/);
  assert.match(appSource, /connectionsRef\.current\.get\(server\.id\)/);
  assert.match(appSource, /conn\.join\.users/);
  assert.match(appSource, /user\.id !== conn\.join\.ownUserId/);
  assert.match(appSource, /!isDeletedUserPlaceholder\(user\)/);
  assert.match(appSource, /conn\.join\.publicSettings\?\.directMessagesEnabled/);
  assert.doesNotMatch(appSource, /getAdminUsers\(conn\).*directMessageSearchCandidates/s);
  assert.doesNotMatch(clientSource, /users\.search|users\.getAll\.query\(\{.*search/s);
});

test('starting a DM from DM home uses the official dms.open flow and selects the conversation', () => {
  assert.match(appSource, /async function openDirectMessageForUser\(server: SharkordServer, conn: SharkordConnection, user: SharkordUser\)/);
  assert.match(appSource, /openDirectMessage\(conn, user\.id\)/);
  assert.match(appSource, /refreshDirectMessagesForServer\(server\.id, conn\)/);
  assert.match(appSource, /await loadDirectMessage\(entry\)/);
  assert.match(appSource, /onStartUserDm=\{\(result\) => \{ if \(result\.existingEntry\) void loadDirectMessage\(result\.existingEntry\); else void openDirectMessageForUser\(result\.server, result\.connection, result\.user\); \}\}/);
  assert.match(clientSource, /dms\.open\.mutate\(\{\s*userId\s*\}\)/);
});

test('DM user search has dedicated styling in the DM sidebar', () => {
  assert.match(cssSource, /\.dmSidebar\s*\{[^}]*grid-template-rows:\s*48px auto minmax\(0,1fr\) auto/s);
  assert.match(cssSource, /\.dmUserSearch\s*\{/);
  assert.match(cssSource, /\.dmUserSearchResults\s*\{/);
  assert.match(cssSource, /\.dmUserSearchResult\s*\{/);
});
