import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const typesSource = readFileSync(new URL('../src/sharkordTypes.ts', import.meta.url), 'utf8');

test('desktop gates Kanuracer-only edit attachments and role mentions behind explicit server capabilities', () => {
  assert.match(clientSource, /messageEditAttachments:\s*boolean/);
  assert.match(clientSource, /roleMentions:\s*boolean/);

  const defaults = clientSource.match(/export const DEFAULT_ORIGINAL_SERVER_CAPABILITIES:[\s\S]*?};/)?.[0] ?? '';
  assert.match(defaults, /messageEditAttachments:\s*false/);
  assert.match(defaults, /roleMentions:\s*false/);

  assert.match(clientSource, /messageEditAttachments:\s*capabilityEnabled\(nested\.messageEditAttachments, nested\.editMessageAttachments, nested\.messageAttachmentEdit/);
  assert.match(clientSource, /roleMentions:\s*capabilityEnabled\(nested\.roleMentions, nested\.roleMentionSuggestions, nested\.roleMention/);
  assert.match(clientSource, /editMessage\(connection: SharkordConnection, messageId: number, plainText: string, files: SharkordTempFile\[\]/);
  assert.match(clientSource, /Server unterstützt Anhänge beim Bearbeiten nicht\./);

  const messageArea = appSource.match(/function MessageArea[\s\S]*?function PluginSlotRenderer/)?.[0] ?? '';
  assert.ok(messageArea, 'MessageArea source not found');
  assert.match(messageArea, /connection\.serverCapabilities\.messageEditAttachments/);
  assert.match(messageArea, /connection\.serverCapabilities\.roleMentions/);
  assert.match(messageArea, /Rollen erwähnen/);
  assert.match(messageArea, /composerRoleMentionMenu/);
  assert.match(messageArea, /editTarget\?\.files/);
  assert.match(messageArea, /Dieser Server unterstützt Rollen-Erwähnungen nicht\./);
});

test('desktop filters role mention suggestions and admin editor by mentionable flag', () => {
  assert.match(typesSource, /mentionable\?: boolean/);
  assert.match(clientSource, /mentionable: !!role\.mentionable/);
  assert.match(appSource, /role\.mentionable/);
  assert.match(appSource, /Erwähnbar/);
  assert.match(appSource, /ownUserRoleIds/);
  assert.match(appSource, /messageMatchesRoleMention/);
  assert.match(appSource, /notificationSettings\.mentions/);
});
