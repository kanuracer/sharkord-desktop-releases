import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

test('desktop gates Kanuracer-only webhooks and retention behind explicit server capabilities', () => {
  assert.match(clientSource, /incomingWebhooks:\s*boolean/);
  assert.match(clientSource, /retentionPolicies:\s*boolean/);

  const defaults = clientSource.match(/export const DEFAULT_ORIGINAL_SERVER_CAPABILITIES:[\s\S]*?};/)?.[0] ?? '';
  assert.match(defaults, /incomingWebhooks:\s*false/);
  assert.match(defaults, /retentionPolicies:\s*false/);

  assert.match(clientSource, /incomingWebhooks:\s*capabilityEnabled\(nested\.incomingWebhooks, nested\.webhooks, nested\.incomingWebhook/);
  assert.match(clientSource, /retentionPolicies:\s*capabilityEnabled\(nested\.retentionPolicies, nested\.messageRetention, nested\.mediaRetention/);

  const adminWorkbench = appSource.match(/function AdminWorkbench[\s\S]*?function AdminUserInfoModal/)?.[0] ?? '';
  assert.ok(adminWorkbench, 'AdminWorkbench source not found');
  assert.match(adminWorkbench, /connection\.serverCapabilities\.incomingWebhooks/);
  assert.match(adminWorkbench, /connection\.serverCapabilities\.retentionPolicies/);
  assert.match(adminWorkbench, /Incoming Webhooks/);
  assert.match(adminWorkbench, /Retention Policies/);
  assert.match(adminWorkbench, /Dieser Server unterstützt Incoming Webhooks nicht\./);
  assert.match(adminWorkbench, /Dieser Server unterstützt Retention Policies nicht\./);
});
