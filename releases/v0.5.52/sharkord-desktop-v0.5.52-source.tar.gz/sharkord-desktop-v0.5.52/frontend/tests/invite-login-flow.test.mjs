import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const goCredentialsSource = readFileSync(new URL('../../credentials.go', import.meta.url), 'utf8');

test('invite login state carries invite codes through native auth and saved credentials', () => {
  assert.match(appSource, /type AuthState = \{ identity: string; password: string; totpCode: string; appPassword: string; serverPassword: string; invite: string \}/);
  assert.match(appSource, /const emptyAuth: AuthState = \{ identity: '', password: '', totpCode: '', appPassword: '', serverPassword: '', invite: '' \}/);
  assert.match(goCredentialsSource, /Invite\s+string `json:"invite"`/);
  assert.match(goCredentialsSource, /AppPassword\s+string `json:"appPassword"`/);
  assert.match(appSource, /type ServerCredentialsWithInvite = ServerCredentials & \{ invite\?: string; appPassword\?: string \}/);
  assert.match(appSource, /function credsToAuth\(creds: ServerCredentials\): AuthState \{ const stored = creds as ServerCredentialsWithInvite; return \{ identity: creds\.identity \|\| '', password: creds\.password \|\| '', totpCode: '', appPassword: stored\.appPassword \|\| '', serverPassword: creds\.serverPassword \|\| '', invite: stored\.invite \|\| '' \}; \}/);
  assert.match(appSource, /function authToCreds\(auth: AuthState\): ServerCredentials \{ return \{ identity: auth\.identity, password: auth\.password, appPassword: auth\.appPassword, serverPassword: auth\.serverPassword, invite: normalizeInviteInput\(auth\.invite\) \} as ServerCredentialsWithInvite; \}/);
});

test('login request sends normalized invite code without inventing server APIs', () => {
  assert.match(clientSource, /export function normalizeInviteInput/);
  assert.match(clientSource, /const invite = normalizeInviteInput\(input\.invite\)/);
  assert.match(clientSource, /body: JSON\.stringify\(\{ identity: input\.identity, password: input\.password, totpCode: input\.totpCode \|\| undefined, appPassword: input\.appPassword \|\| undefined, rememberDevice: !!input\.totpCode, deviceName: 'Sharkord Desktop', invite: invite \|\| undefined \}\)/);
  assert.doesNotMatch(clientSource, /\/invite|\/invites|invite.*fetch|fetch\([^`'\"]+invite/i);
});

test('native connect panel opens app-owned two-factor dialog and still sends remembered-device TOTP without storing it', () => {
  assert.match(appSource, /totpCode: ''/);
  assert.match(appSource, /appPassword: ''/);
  assert.match(appSource, /pendingTotpAuth/);
  assert.match(appSource, /function TwoFactorCodeDialog/);
  assert.match(appSource, /autoComplete="one-time-code"/);
  assert.match(clientSource, /rememberDevice: !!input\.totpCode/);
  assert.match(clientSource, /totpCode: input\.totpCode \|\| undefined/);
  assert.match(clientSource, /appPassword: input\.appPassword \|\| undefined/);
  assert.match(appSource, /appPassword: loginResult\.appPassword \|\| nextAuth\.appPassword/);
  assert.match(clientSource, /const loginInput: LoginInput = \{ \.\.\.input, serverUrl: baseUrl \}/);
  assert.match(clientSource, /loginInput\.appPassword = loginResult\.appPassword/);
  assert.match(clientSource, /loginInput\.totpCode = undefined/);
  assert.match(clientSource, /token = await refreshToken\(\)/);
  assert.match(clientSource, /export async function getOwnAppPasswords/);
  assert.match(clientSource, /users\.mfa\.appPasswords\.query/);
  assert.match(clientSource, /export async function revokeOwnAppPassword/);
  assert.match(clientSource, /users\.mfa\.revokeAppPassword\.mutate/);
  assert.match(appSource, /App-Passwörter/);
  assert.match(appSource, /revokeOwnAppPassword\(connection, entry\.id\)/);
  assert.doesNotMatch(appSource, /function authToCreds\([^)]*\): ServerCredentials \{[^}]*totpCode/);
});

test('native connect panel mirrors webclient invite and closed-registration UX', () => {
  assert.match(appSource, /function ConnectPanel\([^)]*allowNewUsers/);
  assert.match(appSource, /const inviteCode = normalizeInviteInput\(auth\.invite\)/);
  assert.match(appSource, /setAuth\(\{ \.\.\.auth, invite: event\.target\.value \}\)/);
  assert.match(appSource, /placeholder=\{tr\('Invite-Code oder Invite-Link'\)\}/);
  assert.match(appSource, /allowNewUsers === false && !inviteCode/);
  assert.match(appSource, /Neue Registrierungen sind aktuell deaktiviert/);
  assert.match(appSource, /inviteCode &&/);
  assert.match(appSource, /Du wurdest eingeladen/);
});

test('startup and pasted invite links are parsed into server URL plus invite code', () => {
  assert.match(appSource, /function inviteCodeFromLocation\(location: Location\)/);
  assert.match(appSource, /new URLSearchParams\(location\.search\)/);
  assert.match(appSource, /params\.get\('invite'\)/);
  assert.match(appSource, /function splitServerUrlAndInvite\(raw: string\)/);
  assert.match(appSource, /sharkord:\/\/invite\/INVITE-CODE/);
  assert.ok(appSource.includes('https://chat.example.tld/?invite=INVITE-CODE'));
  assert.match(appSource, /https:\/\/chat\.example\.tld\/invite\/INVITE-CODE/);
  assert.match(appSource, /const startupInviteCode = inviteCodeFromLocation\(window\.location\)/);
  assert.match(appSource, /if \(startupInviteCode\) setAuth\(\(current\) => \(\{ \.\.\.current, invite: current\.invite \|\| startupInviteCode \}\)\)/);
});

test('add-server modal accepts invite links without replacing server URL with the invite route', () => {
  assert.match(appSource, /function handleAddServerUrlChange\(value: string\)/);
  assert.match(appSource, /const parsed = splitServerUrlAndInvite\(value\)/);
  assert.match(appSource, /setNewCreds\(\{ \.\.\.newCreds, invite: parsed\.invite \}\)/);
  assert.match(appSource, /value=\{newCreds\.invite\}/);
  assert.match(appSource, /placeholder=\{tr\('Invite-Code oder Invite-Link'\)\}/);
});
