import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

const adminWorkbench = appSource.match(/function AdminWorkbench[\s\S]*?function AdminUserInfoModal/)?.[0] ?? '';

test('desktop gates IP security admin behind fork capability with original fallback disabled', () => {
  assert.match(clientSource, /securityIpRules:\s*boolean/);
  assert.match(clientSource, /securityIpRules:\s*false/);
  assert.match(clientSource, /securityIpRules:\s*capabilityEnabled\(nested\.securityIpRules, nested\.ipSecurityRules, nested\.ipAllowlist/);
  assert.match(clientSource, /probeIpSecurityCapability\(trpc\)/);

  assert.match(clientSource, /getIpSecurityRules\(/);
  assert.match(clientSource, /normalizeIpSecurityRulesResponse/);
  assert.match(clientSource, /\.\.\.\(raw\.allowed \?\? \[\]\), \.\.\.\(raw\.blocked \?\? \[\]\)/);
  assert.match(clientSource, /rule\.kind === 'allow'[\s\S]*?kind: 'allowlist'/);
  assert.match(clientSource, /rule\.kind === 'block'[\s\S]*?kind: 'blocklist'/);
  assert.match(clientSource, /security\.getIpRules\.query\(\)/);
  assert.match(clientSource, /security\.getSecurityEvents\.query\(\)/);
  assert.match(clientSource, /security\.getIpSecurityEvents\.query\(\)/);
  assert.match(clientSource, /security\.unblockIp\.mutate\(\{ ip: ipRange \}\)/);
  assert.match(clientSource, /addIpAllowlist\(/);
  assert.match(clientSource, /security\.addIpAllowlist\.mutate/);
  assert.match(clientSource, /unblockIp\(/);
  assert.match(clientSource, /security\.unblockIp\.mutate/);

  assert.match(appSource, /type AdminTab = .*'security'/);
  assert.ok(adminWorkbench, 'AdminWorkbench source not found');
  assert.match(adminWorkbench, /securityIpRules/);
  assert.match(adminWorkbench, /IP-Sicherheit/);
  assert.match(adminWorkbench, /172\.16\.0\.%/);
  assert.match(adminWorkbench, /Dieser Server unterstützt IP-Sicherheit nicht\./);
  assert.match(adminWorkbench, /getIpSecurityRules\(connection\)/);
  assert.match(adminWorkbench, /rule\.kind === 'allowlist' \|\| rule\.kind === 'allow'/);
  assert.match(adminWorkbench, /rule\.kind === 'blocklist' \|\| rule\.kind === 'block'/);
  assert.match(adminWorkbench, /unblockIp\(connection/);
});
