import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const stylesSource = readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');

const messageArea = appSource.match(/function MessageArea[\s\S]*?function PluginSlotRenderer/)?.[0] ?? '';
const messageBubble = appSource.match(/function MessageBubble[\s\S]*?function ThreadPanel/)?.[0] ?? '';
const adminWorkbench = appSource.match(/function AdminWorkbench[\s\S]*?function AdminUserInfoModal/)?.[0] ?? '';

test('desktop normalizes media, reaction, audit, and clear-event fork capabilities with original fallback disabled', () => {
  for (const name of ['messageReactions', 'gifAttachments', 'codeHighlight', 'securityEventsClear', 'securityAuditLog']) {
    assert.match(clientSource, new RegExp(`${name}:\\s*boolean`), `${name} typed`);
    assert.match(clientSource, new RegExp(`${name}:\\s*false`), `${name} original fallback disabled`);
    assert.match(clientSource, new RegExp(`${name}:\\s*capabilityEnabled`), `${name} normalized from desktop.capabilities`);
  }
});

test('desktop gates reactions, GIF upload, and code highlight UI before fork-only behavior', () => {
  assert.ok(messageArea, 'MessageArea source not found');
  assert.ok(messageBubble, 'MessageBubble source not found');
  assert.match(messageArea, /supportsGifAttachments/);
  assert.match(messageArea, /image\/gif/);
  assert.match(messageArea, /GIF-Anhänge werden von diesem Server nicht unterstützt\./);
  assert.match(messageArea, /accept=\{imageAccept\}/);
  assert.match(messageBubble, /canReactToMessages/);
  assert.match(messageBubble, /enableCodeHighlight/);
  assert.match(messageBubble, /messageReactions/);
  assert.match(appSource, /function MessageCodeBlock/);
  assert.match(appSource, /messageCodeBlock/);
  assert.match(appSource, /messageCodeToken keyword/);
  assert.match(stylesSource, /\.messageCodeBlock/);
  assert.match(stylesSource, /\.messageGifBadge/);
});

test('desktop gates security event clear and audit log admin UI before fork-only routes', () => {
  assert.ok(adminWorkbench, 'AdminWorkbench source not found');
  assert.match(clientSource, /export type SharkordSecurityAuditLogEntry/);
  assert.match(clientSource, /getSecurityAuditLog\(connection/);
  assert.match(clientSource, /clearSecurityEvents\(connection/);
  assert.match(clientSource, /security\.getAuditLog\.query/);
  assert.match(clientSource, /security\.clearSecurityEvents\.mutate/);
  assert.match(adminWorkbench, /securityEventsClear/);
  assert.match(adminWorkbench, /securityAuditLog/);
  assert.match(adminWorkbench, /clearSecurityEvents\(connection\)/);
  assert.match(adminWorkbench, /getSecurityAuditLog\(connection\)/);
  assert.match(adminWorkbench, /Security-Events leeren/);
  assert.match(adminWorkbench, /Audit-Log/);
});
