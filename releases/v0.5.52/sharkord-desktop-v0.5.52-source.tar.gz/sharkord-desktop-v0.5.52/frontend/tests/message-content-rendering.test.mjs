import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import vm from 'node:vm';

const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const cssSource = readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');

function extractTextFromHtml() {
  const match = clientSource.match(/export function textFromHtml\(html = ''\): string \{[\s\S]*?\n\}/);
  assert.ok(match, 'textFromHtml should stay exported for message display/search/edit conversion coverage');

  const jsSource = match[0]
    .replace('export ', '')
    .replace(/: string/g, '');

  const context = {};
  vm.runInNewContext(`${jsSource}; this.textFromHtml = textFromHtml;`, context);
  return context.textFromHtml;
}

test('chat message HTML converts to clean safe display text with preserved line breaks', () => {
  const textFromHtml = extractTextFromHtml();

  assert.equal(
    textFromHtml('<p>Hello<br>world</p><p>Second paragraph</p>'),
    'Hello\nworld\nSecond paragraph'
  );

  assert.equal(
    textFromHtml('<p>&lt;img src=x onerror=alert(1)&gt;</p>'),
    '<img src=x onerror=alert(1)>'
  );

  assert.equal(
    textFromHtml('<p>Safe</p><script>alert(1)</script><style>.x{}</style>'),
    'Safe'
  );
});

test('message bubble avoids blank text rows for attachment-only messages and stays safe', () => {
  const messageBubble = appSource.match(/function MessageBubble[\s\S]*?function ThreadPanel/)?.[0] ?? '';

  assert.ok(messageBubble, 'MessageBubble should be present');
  assert.doesNotMatch(messageBubble, /dangerouslySetInnerHTML/);
  assert.match(messageBubble, /const messageText = textFromHtml\(message\.content\)/);
  assert.match(messageBubble, /messageText \? <RichMessageContent html=\{message\.content\} usersById=\{usersById\} enableCodeHighlight=\{enableCodeHighlight\} \/> : null/);
});

test('message layout guards prevent common chat overflow and clipped metadata', () => {
  assert.match(
    cssSource,
    /\.messageScroller, \.messagesList\s*\{[^}]*overflow-y:\s*auto;[^}]*overflow-x:\s*hidden/s
  );
  assert.match(
    cssSource,
    /\.messageAuthorName\s*\{[^}]*font-size:\s*15px;[^}]*overflow:\s*hidden;[^}]*text-overflow:\s*ellipsis/s
  );
  assert.match(
    cssSource,
    /\.messageReplyContext\s*\{[^}]*min-width:\s*0;[^}]*overflow-wrap:\s*anywhere/s
  );
  assert.match(
    cssSource,
    /\.messageFileTray a\s*\{[^}]*max-width:\s*100%;[^}]*overflow-wrap:\s*anywhere/s
  );
  assert.match(
    cssSource,
    /\.messageActions\s*\{[^}]*z-index:\s*\d+/s
  );
});
