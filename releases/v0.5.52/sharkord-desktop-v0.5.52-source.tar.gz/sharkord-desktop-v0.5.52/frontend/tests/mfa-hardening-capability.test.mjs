import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

test('desktop treats MFA reauth hardening as fork-only capability metadata with original-server fallback', () => {
  assert.match(clientSource, /mfaReauthHardening: boolean/);
  assert.match(clientSource, /mfaReauthHardening: false/);
  assert.match(clientSource, /mfaReauthHardening: capabilityEnabled\(nested\.mfaReauthHardening, nested\.mfaHardening, nested\.accountSecurityAudit\)/);
  assert.match(appSource, /supportsKanuracerAccountSecurity\(connection, serverInfo\)/);
  assert.match(appSource, /regenerateOwnRecoveryCodes/);
  assert.match(appSource, /disableTotp/);
  assert.doesNotMatch(appSource, /mfaReauthHardening \? .*regenerateOwnRecoveryCodes/s);
});
