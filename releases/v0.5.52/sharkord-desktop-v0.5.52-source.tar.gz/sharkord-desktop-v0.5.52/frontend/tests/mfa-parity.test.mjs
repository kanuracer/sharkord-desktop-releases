import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

test('desktop login asks for TOTP in an app-owned popup instead of inline optional field', () => {
  assert.doesNotMatch(appSource, /2FA-Code optional/);
  assert.doesNotMatch(appSource, /<label>\{tr\('2FA-Code optional'\)\}<input value=\{auth\.totpCode\}/);
  assert.match(appSource, /function TwoFactorCodeDialog/);
  assert.match(appSource, /pendingTotpAuth/);
  assert.match(appSource, /setPendingTotpAuth\(nextAuth\)/);
  assert.match(appSource, /isTotpRequiredError/);
});

test('desktop exposes real user MFA setup routes in the own-profile settings UI', () => {
  for (const route of [
    /users\.mfa\.status\.query/,
    /users\.mfa\.start\.mutate/,
    /users\.mfa\.enable\.mutate/,
    /users\.mfa\.disable\.mutate/
  ]) assert.match(clientSource, route);
  for (const ui of [
    /Two-factor authentication/,
    /Authenticator app/,
    /totpSetup/,
    /mfaStatus/,
    /startTotpSetup/,
    /enableTotp/,
    /disableTotp/
  ]) assert.match(appSource, ui);
});

test('desktop TOTP setup renders a real QR code for authenticator app enrollment', () => {
  assert.match(appSource, /QRCode\.toString/);
  assert.match(appSource, /data:image\/svg\+xml/);
  assert.match(appSource, /className="totpQrCodeImage"/);
  assert.match(appSource, /alt=\{tr\('QR code for authenticator app setup'\)\}/);
  assert.doesNotMatch(appSource, /totpSetup \? <div className="totpSetupBox"><label className="settingsField">\{tr\('Authenticator app URI'\)\}/);
});


test('desktop app-password rows keep metadata and revoke action visible without chip clipping', () => {
  assert.match(appSource, /className="appPasswordRows"/);
  assert.match(appSource, /className="appPasswordRow"/);
  assert.match(appSource, /className="appPasswordRowMeta"/);
  assert.match(appSource, /aria-label=\{`\$\{tr\('App-Passwort widerrufen'\)\}: \$\{entry\.name\}`\}/);
  assert.match(appSource, /revokeAppPassword\(entry\)/);
  assert.doesNotMatch(appSource, /className="pluginCommandChip appPasswordRow"/);
});

test('desktop hides MFA and app-password panels only on original servers, not Kanuracer fork servers', () => {
  assert.match(clientSource, /mfaAppPasswords: boolean/);
  assert.match(clientSource, /mfaAppPasswords: false/);
  assert.match(clientSource, /const flavor = normalizeServerFlavor/);
  assert.match(clientSource, /mfaAppPasswords: flavor === 'kanuracer' \|\| capabilityEnabled/);
  assert.match(appSource, /function isKanuracerForkServerInfo/);
  assert.match(appSource, /kanuracer\|-kr\\\./);
  assert.match(appSource, /function supportsKanuracerAccountSecurity/);
  assert.match(appSource, /connection\.serverCapabilities\.flavor === 'kanuracer'/);
  assert.match(appSource, /supportsKanuracerAccountSecurity\(connection, serverInfo\)/);
  assert.match(appSource, /serverInfo=\{ownProfileServerInfo\}/);
  assert.match(appSource, /supportsAccountSecurity \? <article className="parityActionCard totpSetup"/);
  assert.match(appSource, /supportsAccountSecurity \? <article className="parityActionCard appPasswordList"/);
  assert.match(appSource, /if \(!supportsAccountSecurity\) \{ setAppPasswords\(\[\]\);/);
  assert.match(appSource, /if \(!supportsAccountSecurity\) \{ setMfaStatus\(\{ enabled: false \}\);/);
});

test('desktop exposes MFA recovery codes only behind account-security capability', () => {
  assert.match(clientSource, /recoveryCodesRemaining\?: number/);
  assert.match(clientSource, /recoveryCodes\?: string\[\]/);
  assert.match(clientSource, /users\.mfa\.regenerateRecoveryCodes\.mutate/);
  assert.match(appSource, /recoveryCodes/);
  assert.match(appSource, /Recovery-Codes/);
  assert.match(appSource, /recoveryCodesRemaining/);
  assert.match(appSource, /regenerateOwnRecoveryCodes/);
  assert.match(appSource, /supportsAccountSecurity \? <article className="parityActionCard recoveryCodesPanel"/);
});
