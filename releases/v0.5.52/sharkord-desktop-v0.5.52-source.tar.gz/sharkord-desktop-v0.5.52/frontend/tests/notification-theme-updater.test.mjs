import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const cssSource = readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
const i18nSource = readFileSync(new URL('../src/i18n.ts', import.meta.url), 'utf8');

test('notification center persists recent actionable items and respects mute/settings rules', () => {
  assert.match(appSource, /NOTIFICATION_CENTER_STORAGE_KEY\s*=\s*'sharkord-desktop:notification-center:v1'/);
  assert.match(appSource, /type NotificationCenterItem/);
  assert.match(appSource, /loadNotificationCenterItems/);
  assert.match(appSource, /saveNotificationCenterItems/);
  assert.match(appSource, /addNotificationCenterItem/);
  assert.match(appSource, /notificationCenterMuted/);
  assert.match(appSource, /shouldRecordNotificationItem/);
  assert.match(appSource, /notificationSettings\.allMessages/);
  assert.match(appSource, /notificationSettings\.mentions/);
  assert.match(appSource, /notificationSettings\.dms/);
  assert.match(appSource, /notificationSettings\.replies/);
  assert.match(appSource, /slice\(0,\s*32\)/);
});

test('notification center UI can open items, mark all read, and clear the list', () => {
  assert.match(appSource, /function NotificationCenter/);
  assert.match(appSource, /notificationCenterOpen/);
  assert.match(appSource, /notificationCenterBadge/);
  assert.match(appSource, /Benachrichtigungszentrum/);
  assert.match(appSource, /Benachrichtigungen leeren/);
  assert.match(appSource, /Alle als gelesen markieren/);
  assert.match(appSource, /onOpenItem/);
  assert.match(appSource, /openNotificationCenterItem/);
  assert.match(appSource, /markNotificationCenterRead/);
  assert.match(appSource, /clearNotificationCenter/);
  assert.match(appSource, /onGlobalSearchJump\(item\.channelId,\s*item\.messageId\)/);
  assert.match(cssSource, /\.notificationCenterPopover\b/);
  assert.match(cssSource, /\.notificationCenterBadge\b/);
  assert.match(cssSource, /\.notificationCenterItem\b/);
});

test('appearance settings persist compact font-size reduced-motion and high-contrast toggles', () => {
  assert.match(appSource, /APP_UI_SETTINGS_STORAGE_KEY\s*=\s*'sharkord-desktop:ui-settings:v1'/);
  assert.match(appSource, /type AppUiSettings/);
  assert.match(appSource, /loadAppUiSettings/);
  assert.match(appSource, /saveAppUiSettings/);
  assert.match(appSource, /compactMode/);
  assert.match(appSource, /fontSize/);
  assert.match(appSource, /reducedMotion/);
  assert.match(appSource, /highContrast/);
  assert.match(appSource, /dataset\.compact/);
  assert.match(appSource, /dataset\.reducedMotion/);
  assert.match(appSource, /dataset\.highContrast/);
  assert.match(appSource, /style\.setProperty\('--app-font-size'/);
  assert.match(appSource, /Darstellung & Barrierefreiheit/);
  for (const phrase of ['Kompakter Modus', 'Schriftgröße', 'Reduzierte Bewegung', 'Hoher Kontrast']) {
    assert.match(i18nSource, new RegExp(`${phrase.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}':\\s*'[^']+`));
  }
  assert.match(cssSource, /--app-font-size/);
  assert.match(cssSource, /data-compact='true'/);
  assert.match(cssSource, /data-reduced-motion='true'/);
  assert.match(cssSource, /data-high-contrast='true'/);
});

test('updater shows checksum/feed verification and safe rollback/manual install copy', () => {
  assert.match(appSource, /updateVerificationPanel/);
  assert.match(appSource, /updateChecksum/);
  assert.match(appSource, /updateFeedSource/);
  assert.match(appSource, /updateSafetyCopy/);
  assert.match(appSource, /updateAsset\?\.sha256/);
  assert.match(appSource, /release\?\.feedUrl/);
  assert.match(appSource, /Checksum|Prüfsumme/);
  assert.match(appSource, /latest\.json/);
  assert.match(appSource, /Rollback/);
  assert.match(appSource, /Manuelle Installation|Manual install/);
  assert.doesNotMatch(appSource, /internal QA|QA leakage|private test/i);
  assert.match(cssSource, /\.updateVerificationPanel\b/);
  assert.match(cssSource, /\.updateChecksum\b/);
  assert.match(i18nSource, /Checksum verified by latest\.json when present|Checksum/);
});
