import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const voiceEngineSource = readFileSync(new URL('../src/voiceEngine.ts', import.meta.url), 'utf8');

test('OIDC login is capability-gated and keeps local identity/password login available as breakglass', () => {
  assert.match(clientSource, /oidcLogin:\s*boolean/);
  const defaults = clientSource.match(/export const DEFAULT_ORIGINAL_SERVER_CAPABILITIES:[\s\S]*?};/)?.[0] ?? '';
  assert.match(defaults, /oidcLogin:\s*false/);
  assert.match(clientSource, /export type OidcLoginConfig/);
  assert.match(clientSource, /export async function fetchOidcLoginConfig/);
  assert.match(clientSource, /export function buildOidcAuthorizationUrl/);
  assert.match(clientSource, /auth\/oidc\/config/);
  assert.match(clientSource, /login\/oidc/);
  assert.match(appSource, /oidcConfig/);
  assert.match(appSource, /Mit SSO anmelden/);
  assert.match(appSource, /Lokaler Breakglass-Login bleibt verfügbar/);
  assert.match(appSource, /serverCapabilities\??\.oidcLogin/);
  assert.match(appSource, /buildOidcAuthorizationUrl/);
  assert.match(appSource, /beginOidcLogin/);
  assert.match(appSource, /SHARKORD_DESKTOP_OIDC_STATE_PREFIX/);
  assert.match(appSource, /sessionStorage\.setItem\(`\$\{SHARKORD_DESKTOP_OIDC_STATE_PREFIX\}\$\{oidcState\}`/);
  assert.match(appSource, /window\.location\.assign\(authUrl\)/);
  assert.match(appSource, /handleOidcCallback/);
  assert.match(appSource, /loginWithOidcCodeAndJoin\(/);
  assert.match(appSource, /sessionStorage\.removeItem\(`\$\{SHARKORD_DESKTOP_OIDC_STATE_PREFIX\}\$\{stateParam\}`/);
  assert.match(appSource, /history\.replaceState\(null, '', '\/'\)/);
  assert.match(appSource, /setStatus\(tr\('SSO Login erfolgreich'\)\)/);
  assert.match(appSource, /Identity<input/);
  assert.match(appSource, /Passwort/);
});

test('OIDC callback refuses missing state instead of exchanging arbitrary codes', () => {
  assert.match(appSource, /if \(!stateParam\) throw new Error\(tr\('OIDC State fehlt'\)\)/);
  assert.match(appSource, /if \(!stored\) throw new Error\(tr\('OIDC State ist abgelaufen oder ungültig'\)\)/);
  assert.match(appSource, /if \(!provider\.id\) throw new Error\(tr\('OIDC Provider fehlt'\)\)/);
});

test('voice device hot-swap uses mediasoup replaceTrack/applyConstraints instead of rejoining voice', () => {
  assert.match(clientSource, /voiceDeviceHotSwap:\s*boolean/);
  const defaults = clientSource.match(/export const DEFAULT_ORIGINAL_SERVER_CAPABILITIES:[\s\S]*?};/)?.[0] ?? '';
  assert.match(defaults, /voiceDeviceHotSwap:\s*false/);
  assert.match(clientSource, /voiceDeviceHotSwap:\s*capabilityEnabled\(nested\.voiceDeviceHotSwap, nested\.voiceHotSwap, nested\.deviceHotSwap\)/);
  assert.match(voiceEngineSource, /async hotSwapMicrophone\(/);
  assert.match(voiceEngineSource, /async hotSwapWebcam\(/);
  assert.match(voiceEngineSource, /replaceTrack\(\{ track/);
  assert.match(voiceEngineSource, /applyConstraints/);
  assert.match(voiceEngineSource, /voice\.deviceHotSwap\.mic\.ok/);
  assert.match(voiceEngineSource, /voice\.deviceHotSwap\.webcam\.ok/);
  assert.doesNotMatch(voiceEngineSource.match(/async hotSwapMicrophone\([\s\S]*?\n  \}/)?.[0] ?? '', /voice\.join|joinVoiceChannel/);
  assert.match(appSource, /voiceDeviceHotSwap/);
  assert.match(appSource, /hotSwapMicrophone/);
  assert.match(appSource, /hotSwapWebcam/);
});

test('audio-video settings explain original-server fallback for hot-swap while keeping normal settings usable', () => {
  assert.match(appSource, /hotSwapSupported/);
  assert.match(appSource, /connectedWithoutHotSwap/);
  assert.match(appSource, /Dieser Server unterstützt Geräte-Hot-Swap ohne Voice-Rejoin nicht/);
  assert.match(appSource, /Änderungen wirken beim nächsten Join bzw\. Neustart des jeweiligen Mediums/);
  assert.match(appSource, /Geräte-Hot-Swap aktiv/);
});
