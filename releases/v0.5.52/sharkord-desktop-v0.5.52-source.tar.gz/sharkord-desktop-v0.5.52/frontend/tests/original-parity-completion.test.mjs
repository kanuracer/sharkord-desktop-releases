import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

test('desktop covers original Sharkord routes and capability-gated fork routes with safe wrappers', () => {
  assert.match(clientSource, /export async function getMessage\(/);
  assert.match(clientSource, /messages\.getOne\.query\(\{\s*messageId\s*\}\)/);
  assert.match(clientSource, /messages\.getThread\.query\(input\)/);
  assert.match(clientSource, /export async function deleteDirectMessage\(/);
  assert.match(clientSource, /dms\.delete\.mutate\(\{\s*channelId\s*\}\)/);
  assert.match(clientSource, /export async function useSecretToken\(/);
  assert.match(clientSource, /others\.useSecretToken\.mutate\(\{\s*token\s*\}\)/);
  assert.match(clientSource, /export async function getServerUpdate\(/);
  assert.match(clientSource, /others\.getUpdate\.query\(\)/);
  assert.match(clientSource, /export async function updateServer\(/);
  assert.match(clientSource, /others\.updateServer\.mutate\(\)/);
});

test('desktop exposes original actions and gates fork-only DM hiding without fake local-only behavior', () => {
  assert.match(appSource, /hideDirectMessage\(entry\.connection, entry\.channel\.id\)/);
  assert.match(appSource, /className="dmConversationDeleteButton"/);
  assert.match(appSource, /useSecretToken\(connection, secretToken\.trim\(\)\)/);
  assert.match(appSource, /getServerUpdate\(connection\)/);
  assert.match(appSource, /updateServer\(connection\)/);
  assert.match(appSource, /Server-Owner-Token/);
  assert.match(appSource, /Server-Update prüfen/);
  assert.match(appSource, /Server aktualisieren/);
});

test('server owner token and server self-update controls live in server settings, not global updates', () => {
  const settingsPanel = appSource.match(/function SettingsPanel[\s\S]*?function ParitySprintSettings/)?.[0] ?? '';
  const adminWorkbench = appSource.match(/function AdminWorkbench[\s\S]*?function AdminUserInfoModal/)?.[0] ?? '';
  assert.ok(settingsPanel, 'SettingsPanel source not found');
  assert.ok(adminWorkbench, 'AdminWorkbench source not found');
  assert.doesNotMatch(settingsPanel, /Server-Owner-Token|serverTokenForm|serverUpdatePanel|Server-Update prüfen|Server aktualisieren/);
  assert.match(adminWorkbench, /Server-Owner-Token/);
  assert.match(adminWorkbench, /serverTokenForm/);
  assert.match(adminWorkbench, /serverUpdatePanel/);
  assert.match(adminWorkbench, /Server-Update prüfen/);
  assert.match(adminWorkbench, /Server aktualisieren/);
});

test('0.5.0 detects original versus Kanuracer servers through a safe capability contract', () => {
  assert.match(clientSource, /export type SharkordServerFlavor = 'original' \| 'kanuracer' \| 'unknown'/);
  assert.match(clientSource, /export type SharkordServerCapabilities =/);
  assert.match(clientSource, /DEFAULT_ORIGINAL_SERVER_CAPABILITIES/);
  assert.match(clientSource, /export async function detectServerCapabilities\(/);
  assert.match(clientSource, /trpc\.desktop\.capabilities\.query\(\)/);
  assert.match(clientSource, /isMissingTrpcProcedureError\(error, 'desktop\.capabilities'\)/);
  assert.match(clientSource, /serverCapabilities: await detectServerCapabilities\(trpc\)/);
  const originalDefaults = clientSource.match(/export const DEFAULT_ORIGINAL_SERVER_CAPABILITIES:[\s\S]*?};/)?.[0] ?? '';
  assert.match(originalDefaults, /flavor:\s*'original'/);
  assert.match(originalDefaults, /directMessageDelete:\s*false/);
  assert.match(originalDefaults, /ownerToken:\s*true/);
  assert.match(originalDefaults, /serverSelfUpdate:\s*true/);
  const detectFn = clientSource.match(/export async function detectServerCapabilities[\s\S]*?^}/m)?.[0] ?? '';
  assert.ok(detectFn, 'detectServerCapabilities source not found');
  assert.doesNotMatch(detectFn, /dms\.delete\.mutate|updateServer\.mutate|useSecretToken\.mutate/);
});

test('fork-only DM hiding shows a safe unsupported dialog on original servers while original update actions stay available', () => {
  const dmSidebar = appSource.match(/function DirectMessagesSidebar[\s\S]*?function ServerDropdownMenu/)?.[0] ?? '';
  const adminWorkbench = appSource.match(/function AdminWorkbench[\s\S]*?function AdminUserInfoModal/)?.[0] ?? '';
  assert.ok(dmSidebar, 'DirectMessagesSidebar source not found');
  assert.ok(adminWorkbench, 'AdminWorkbench source not found');
  assert.match(dmSidebar, /entry\.connection\.serverCapabilities\.directMessageHide/);
  assert.match(dmSidebar, /className="dmConversationDeleteButton"/);
  assert.doesNotMatch(dmSidebar, /capabilityUnsupportedHint/);
  assert.match(appSource, /UnsupportedDirectMessageDeleteDialog/);
  assert.match(adminWorkbench, /connection\.serverCapabilities\.serverSelfUpdate \|\| connection\.serverCapabilities\.ownerToken/);
  assert.match(clientSource, /ownerToken:\s*true/);
  assert.match(clientSource, /serverSelfUpdate:\s*true/);
  assert.match(adminWorkbench, /Server-Modus/);
  assert.match(adminWorkbench, /Original Sharkord/);
  assert.match(adminWorkbench, /Kanuracer/);
});
