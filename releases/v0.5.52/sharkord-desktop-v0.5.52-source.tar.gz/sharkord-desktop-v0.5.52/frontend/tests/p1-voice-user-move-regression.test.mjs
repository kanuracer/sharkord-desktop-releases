import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

test('voice user move capability is false for original servers and normalized for Kanuracer forks', () => {
  assert.match(clientSource, /voiceUserMove:\s*boolean/);
  const defaults = clientSource.match(/export const DEFAULT_ORIGINAL_SERVER_CAPABILITIES:[\s\S]*?};/)?.[0] ?? '';
  assert.match(defaults, /voiceUserMove:\s*false/);
  assert.match(clientSource, /voiceUserMove:\s*capabilityEnabled\(nested\.voiceUserMove, nested\.voiceMoveUser, nested\.moveVoiceUser\)/);
});

test('desktop wraps server-side voice.moveUser and fails safe when unsupported', () => {
  assert.match(clientSource, /export async function moveVoiceUser\(/);
  assert.match(clientSource, /connection\.serverCapabilities\.voiceUserMove/);
  assert.match(clientSource, /voice\.moveUser\.mutate\(\{\s*userId,\s*destinationChannelId\s*\}\)/);
  assert.match(clientSource, /isMissingTrpcProcedureError\(error, 'voice\.moveUser'\)/);
});

test('voice sidebar drag/drop is capability gated and uses real server mutation only', () => {
  const handler = appSource.match(/async function handleVoiceUserDrop\(target: SharkordChannel\) \{[\s\S]*?\n  \}/)?.[0] ?? '';
  assert.match(appSource, /voiceUserMoveEnabled=\{!!connection\?\.serverCapabilities\.voiceUserMove\}/);
  assert.match(appSource, /draggable=\{voiceUserMoveEnabled && voiceUser\.id !== ownUserId\}/);
  assert.match(appSource, /application\/x-sharkord-voice-user-id/);
  assert.match(handler, /moveVoiceUser\(connection, userId, target\.id\)/);
  assert.doesNotMatch(handler, /setVoiceMap\(/);
});
