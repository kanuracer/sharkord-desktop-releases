import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const typesSource = readFileSync(new URL('../src/sharkordTypes.ts', import.meta.url), 'utf8');

test('desktop plugin model never calls the removed plugins.getSlots route', () => {
  assert.doesNotMatch(clientSource, /getSlots/);
  assert.doesNotMatch(appSource, /getPluginSlots|getSlots/);
  assert.doesNotMatch(clientSource, /plugins\.getSlots/);
});

test('desktop initializes plugin components from joinServer data', () => {
  assert.match(typesSource, /pluginIdsWithComponents\?: string\[\]/);
  assert.match(typesSource, /pluginsMetadata\?: SharkordPluginMetadata\[\]/);
  assert.match(typesSource, /commands\?: Record<string, SharkordPluginCommand\[\]>/);
  assert.match(appSource, /connection\.join\.pluginIdsWithComponents \?\? \[\]/);
  assert.match(appSource, /connection\.join\.pluginsMetadata \?\? \[\]/);
  assert.match(appSource, /connection\.join\.commands \?\? \{\}/);
  assert.match(appSource, /processPluginComponents\(connection, connection\.join\.pluginIdsWithComponents/);
});

test('desktop follows webclient plugin components and metadata subscriptions', () => {
  assert.match(clientSource, /plugins\.onComponentsChange\.subscribe/);
  assert.match(clientSource, /plugins\.onMetadataChange\.subscribe/);
  assert.match(clientSource, /plugins\.onCommandsChange\.subscribe/);
  assert.match(clientSource, /normalizePluginCommands\(data\)/);
  assert.match(appSource, /onPluginComponentsChange/);
  assert.match(appSource, /refreshPluginComponentsForConnection\(next, pluginIdsWithComponents\)/);
  assert.match(appSource, /onPluginMetadataChange/);
  assert.match(appSource, /refreshPluginComponentsForConnection\(next, next\.join\.pluginIdsWithComponents \?\? \[\], metadata\)/);
  assert.match(appSource, /onPluginCommandsChange: \(commands\) =>/);
  assert.match(appSource, /next\.join\.commands = commands/);
});

test('desktop loads official plugin component bundles and maps official slots to native slots', () => {
  assert.match(clientSource, /CLIENT_PLUGIN_ENTRY_FILE = 'client\/index\.js'/);
  assert.match(clientSource, /\/plugin-bundle\/\$\{encodeURIComponent\(pluginId\)\}\/\$\{CLIENT_PLUGIN_ENTRY_FILE\}/);
  for (const slot of ['connect_screen', 'home_screen', 'chat_actions', 'topbar_right', 'full_screen']) {
    assert.match(clientSource, new RegExp(`${slot}:`));
  }
  assert.match(typesSource, /component\?: ComponentType/);
  assert.match(appSource, /const Component = item\.component/);
  assert.match(appSource, /<Component \/>/);
});
