import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const cssSource = readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
const i18nSource = readFileSync(new URL('../src/i18n.ts', import.meta.url), 'utf8');

test('quick switcher installs global Ctrl/Cmd+K command palette shortcut', () => {
  assert.match(appSource, /const \[commandPaletteOpen, setCommandPaletteOpen\] = useState\(false\)/);
  assert.match(appSource, /const \[commandPaletteQuery, setCommandPaletteQuery\] = useState\(''\)/);
  assert.match(appSource, /event\.(ctrlKey|metaKey).*event\.(ctrlKey|metaKey).*event\.key\.toLowerCase\(\) === 'k'/s);
  assert.match(appSource, /setCommandPaletteOpen\(true\)/);
  assert.match(appSource, /\{commandPaletteOpen \? <CommandPaletteDialog/);
});

test('quick switcher entries are built from existing servers channels DMs and app actions', () => {
  assert.match(appSource, /const commandPaletteItems = useMemo<CommandPaletteItem\[\]>\(\(\) =>/);
  assert.match(appSource, /state\.servers\.map\(\(server\) =>/);
  assert.match(appSource, /textChannels\.map\(\(channel\) =>/);
  assert.match(appSource, /voiceChannels\.map\(\(channel\) =>/);
  assert.match(appSource, /directMessageEntries\.map\(\(entry\) =>/);
  assert.match(appSource, /openUpdateSettings\(\)/);
  assert.match(appSource, /window\.dispatchEvent\(new CustomEvent\('sharkord:open-global-search'\)\)/);
  const paletteSource = appSource.match(/const commandPaletteItems = useMemo<CommandPaletteItem\[\]>[\s\S]+?\}, \[state\.servers[^\n]+\);/)?.[0] ?? '';
  assert.ok(paletteSource, 'command palette item builder is scoped for API regression checks');
  assert.doesNotMatch(paletteSource, /\bfetch\b|getAdminUsers/);
});

test('quick switcher dialog is accessible and keyboard navigable', () => {
  assert.match(appSource, /function CommandPaletteDialog/);
  assert.match(appSource, /role="dialog"[^>]*aria-modal="true"[^>]*aria-label=\{tr\('Command Palette'\)\}/s);
  assert.match(appSource, /placeholder=\{tr\('Search servers, channels, DMs, actions'\)\}/);
  assert.match(appSource, /if \(event\.key === 'Escape'\) onClose\(\)/);
  assert.match(appSource, /if \(event\.key === 'ArrowDown'\)/);
  assert.match(appSource, /if \(event\.key === 'ArrowUp'\)/);
  assert.match(appSource, /if \(event\.key === 'Enter'\)/);
  assert.match(appSource, /onClick=\{\(\) => onSelect\(item\)\}/);
  assert.match(cssSource, /\.commandPaletteDialog\s*\{/);
  assert.match(cssSource, /\.commandPaletteItem\.active\s*\{/);
  for (const phrase of ['Command Palette schließen', 'Command Palette suchen', 'Command Palette Ergebnisse', 'App-Einstellungen öffnen', 'Update-Einstellungen öffnen', 'Nachrichten- und Dateisuche öffnen']) {
    assert.match(i18nSource, new RegExp(`${phrase.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}':\\s*'[^']+`));
  }
});
