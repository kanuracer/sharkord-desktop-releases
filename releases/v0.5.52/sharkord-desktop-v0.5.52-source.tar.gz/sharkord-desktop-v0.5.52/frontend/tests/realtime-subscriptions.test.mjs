import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

const paritySubscriptions = [
  ['users.onCreate', 'onUserCreate'],
  ['users.onDelete', 'onUserDelete'],
  ['roles.onCreate', 'onRoleCreate'],
  ['roles.onUpdate', 'onRoleUpdate'],
  ['roles.onDelete', 'onRoleDelete'],
  ['emojis.onCreate', 'onEmojiCreate'],
  ['emojis.onUpdate', 'onEmojiUpdate'],
  ['emojis.onDelete', 'onEmojiDelete'],
  ['channels.onPermissionsUpdate', 'onChannelPermissionsUpdate'],
  ['others.onServerSettingsUpdate', 'onServerSettingsUpdate'],
  ['messages.onThreadReplyCountUpdate', 'onThreadReplyCountUpdate'],
  ['plugins.onCommandsChange', 'onPluginCommandsChange'],
  ['plugins.onComponentsChange', 'onPluginComponentsChange'],
  ['plugins.onMetadataChange', 'onPluginMetadataChange']
];

test('desktop core client registers missing webclient parity subscriptions', () => {
  for (const [route, handlerName] of paritySubscriptions) {
    const [namespace, procedure] = route.split('.');
    assert.match(clientSource, new RegExp(`sub\\('${route}'`));
    assert.match(clientSource, new RegExp(`connection\\.trpc\\.${namespace}\\.${procedure}\\.subscribe`));
    assert.match(clientSource, new RegExp(handlerName));
  }
});

test('desktop app wires parity event handlers to safe state refresh/update paths', () => {
  for (const handler of [
    'onUserCreate',
    'onUserDelete',
    'onRoleCreate',
    'onRoleUpdate',
    'onRoleDelete',
    'onEmojiCreate',
    'onEmojiUpdate',
    'onEmojiDelete',
    'onChannelPermissionsUpdate',
    'onServerSettingsUpdate',
    'onThreadReplyCountUpdate',
    'onPluginCommandsChange',
    'onPluginComponentsChange',
    'onPluginMetadataChange'
  ]) assert.match(appSource, new RegExp(`${handler}:`));

  assert.match(appSource, /emitAdminRealtime\('users'/);
  assert.match(appSource, /emitAdminRealtime\('roles'/);
  assert.match(appSource, /emitAdminRealtime\('emojis'/);
  assert.match(appSource, /emitAdminRealtime\('serverSettings'/);
  assert.match(appSource, /emitAdminRealtime\('plugins'/);
  assert.match(appSource, /emitChannelPermissionsRealtime\(serverId, payload\)/);
  assert.match(appSource, /applyThreadReplyCountUpdate\(event, serverId\)/);
  assert.match(appSource, /refreshPluginComponentsForConnection\(next/);
  assert.match(appSource, /permissionsRealtimeEvent=\{channelPermissionsRealtimeEvent\}/);
  assert.match(appSource, /realtimeEvent=\{adminRealtimeEvent\}/);
});
