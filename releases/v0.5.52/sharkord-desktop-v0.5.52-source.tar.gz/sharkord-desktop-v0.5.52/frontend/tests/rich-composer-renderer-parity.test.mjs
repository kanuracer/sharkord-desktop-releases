import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';

const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const cssSource = readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');

test('HTML-to-text conversion preserves rich context instead of dropping hrefs and media labels', () => {
  assert.ok(clientSource.includes('const attrValue = (tag: string, attr: string)'));
  assert.ok(clientSource.includes('return `${label} (${src})`;'));
  assert.ok(clientSource.includes(".replace(/<\\s*a\\b([^>]*)>([\\s\\S]*?)<\\s*\\/\\s*a\\s*>/gi"));
  assert.ok(clientSource.includes('if (!label || label === href) return href;'));
  assert.ok(clientSource.includes('return `${label} (${href})`;'));
  assert.ok(clientSource.includes('img|video|audio|source'));
});

test('composer serialization keeps visible mention and link affordances while escaping unsafe input', () => {
  assert.match(clientSource, /export function richTextToSafeHtml/);
  assert.match(clientSource, /class="mention"/);
  assert.match(clientSource, /target="_blank" rel="noreferrer"/);
  assert.match(clientSource, /replace\(/);
  assert.match(clientSource, /escapeHtml\(text\)/);
  assert.doesNotMatch(clientSource, /dangerouslySetInnerHTML/);
});

test('message renderer has first-class rich tokens, embeds, and media file cards without raw HTML injection', () => {
  assert.doesNotMatch(appSource, /dangerouslySetInnerHTML/);
  assert.match(appSource, /function RichMessageContent/);
  assert.match(appSource, /function MessageFileCards/);
  assert.match(appSource, /function LinkEmbedPreview/);
  assert.match(appSource, /className="messageMention"/);
  assert.match(appSource, /className="messageLink"/);
  assert.match(appSource, /messageFileCard/);
  assert.match(appSource, /className="messageLinkEmbed"/);
  assert.match(appSource, /onPaste=\{handleRichComposerPaste\}/);
  assert.match(cssSource, /\.messageMention\s*\{/);
  assert.match(cssSource, /\.messageFileCard\s*\{/);
  assert.match(cssSource, /\.messageLinkEmbed\s*\{/);
});

test('slash command composer executes supported plugin commands and renders selectable suggestions', () => {
  assert.match(appSource, /const pluginCommandSuggestions =/);
  assert.match(appSource, /parsePluginCommandArgs\(/);
  assert.match(appSource, /executePluginCommand\(connection, command\.pluginId/);
  assert.match(appSource, /selectPluginCommand\(command\)/);
  assert.match(appSource, /className="pluginCommandItem"/);
  assert.match(appSource, /data-plugin-id=\{command\.pluginId\}/);
  assert.match(cssSource, /\.pluginCommandItem\s*\{/);
});
