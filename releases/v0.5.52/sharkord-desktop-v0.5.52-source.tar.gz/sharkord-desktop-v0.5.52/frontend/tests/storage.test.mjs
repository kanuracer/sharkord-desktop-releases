import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const storageSource = readFileSync(new URL('../src/storage.ts', import.meta.url), 'utf8');
const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');

test('storage normalizes URLs and persists sharkord desktop state key', () => {
  assert.match(storageSource, /sharkord-desktop:v1/);
  assert.match(storageSource, /https:\/\//);
  assert.match(storageSource, /new URL/);
});

test('app renders discord-like server rail and theme switch', () => {
  assert.match(appSource, /serverRail/);
  assert.match(appSource, /serverList/);
  assert.match(appSource, /themeSwitch/);
  assert.match(appSource, /dataset\.theme/);
});

test('app starts without bundled demo server', () => {
  assert.doesNotMatch(appSource, /demoServer/);
  assert.doesNotMatch(appSource, /demo\.sharkord\.com/);
  assert.doesNotMatch(appSource, /Demoserver/i);
  assert.match(appSource, /NoServersEmptyState/);
});

test('server management supports auto-connect and direct deletion', () => {
  assert.match(storageSource, /autoConnect/);
  assert.match(appSource, /autoConnect/);
  assert.match(appSource, /autoConnectChecked/);
  assert.match(appSource, /removeActiveServer/);
  assert.match(appSource, /serverDeleteButton/);
});

test('app exposes core/admin workbench plus Discord-like context menus', () => {
  for (const marker of [
    /AdminWorkbench/,
    /adminTabs/,
    /Server-Einstellungen/,
    /Channels/,
    /Kategorien/,
    /Rollen/,
    /Benutzer/,
    /Invites/,
    /Emojis/,
    /getServerSettings/,
    /saveServerSettings/,
    /getAdminUsers/,
    /getInvites/,
    /getEmojis/,
    /createRole/,
    /setDefaultRole/,
    /AdminContextMenu/,
    /ContextMenuState/,
    /onContextMenu/,
    /openServerMenu/,
    /openChannelMenu/,
    /openUserMenu/,
    /roleMenuItem/,
    /toggleUserRole/,
    /addRoleToUser/,
    /removeRoleFromUser/,
    /moderateContextUser/,
    /createServerChannel/,
    /createServerCategory/,
    /createServerInvite/
  ]) assert.match(appSource, marker);
});

test('app avoids webview and iframe embedding', () => {
  assert.doesNotMatch(appSource, /<iframe/);
  assert.doesNotMatch(appSource, /<webview/);
});
