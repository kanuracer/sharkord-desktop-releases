import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const typesSource = readFileSync(new URL('../src/sharkordTypes.ts', import.meta.url), 'utf8');

test('desktop gates Kanuracer-only thread inbox behind explicit capability and original-server fallback', () => {
  assert.match(clientSource, /threadInbox:\s*boolean/);
  const defaults = clientSource.match(/export const DEFAULT_ORIGINAL_SERVER_CAPABILITIES:[\s\S]*?};/)?.[0] ?? '';
  assert.match(defaults, /threadInbox:\s*false/);
  assert.match(clientSource, /threadInbox:\s*capabilityEnabled\(nested\.threadInbox, nested\.threadUnreadAggregation, nested\.threadAggregation/);
  assert.match(typesSource, /export type ThreadInboxItem/);
  assert.match(clientSource, /export async function getThreadInbox/);
  assert.match(clientSource, /export async function getUnreadThreads/);
  assert.match(clientSource, /messages\.getThreadInbox\.query/);
  assert.match(appSource, /connection\.serverCapabilities\.threadInbox/);
  assert.match(appSource, /Thread-Antworten/);
  assert.match(appSource, /Dieser Server unterstützt Thread-Antworten nicht\./);
});

test('desktop prefers server role-mention fanout metadata before text fallback', () => {
  assert.match(clientSource, /roleMentionFanout:\s*boolean/);
  const defaults = clientSource.match(/export const DEFAULT_ORIGINAL_SERVER_CAPABILITIES:[\s\S]*?};/)?.[0] ?? '';
  assert.match(defaults, /roleMentionFanout:\s*false/);
  assert.match(clientSource, /roleMentionFanout:\s*capabilityEnabled\(nested\.roleMentionFanout, nested\.roleMentionNotifications, nested\.mentionFanout/);
  assert.match(typesSource, /mentionedRoleIds\?: number\[\]/);
  assert.match(typesSource, /mentionedUserIds\?: number\[\]/);
  assert.match(appSource, /message\.mentionedRoleIds/);
  assert.match(appSource, /serverCapabilities\.roleMentionFanout/);
});
