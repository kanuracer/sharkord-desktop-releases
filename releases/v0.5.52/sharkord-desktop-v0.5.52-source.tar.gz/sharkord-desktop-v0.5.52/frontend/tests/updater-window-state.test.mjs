import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const testDir = dirname(fileURLToPath(import.meta.url));
const projectRoot = join(testDir, '..', '..');
const appSource = readFileSync(join(testDir, '..', 'src', 'App.tsx'), 'utf8');
const cssSource = readFileSync(join(testDir, '..', 'src', 'style.css'), 'utf8');
const i18nSource = readFileSync(join(testDir, '..', 'src', 'i18n.ts'), 'utf8');
const storageSource = readFileSync(join(testDir, '..', 'src', 'storage.ts'), 'utf8');
const typesSource = readFileSync(join(testDir, '..', 'src', 'types.ts'), 'utf8');
const mainSource = readFileSync(join(projectRoot, 'main.go'), 'utf8');
const serviceSource = readFileSync(join(projectRoot, 'appservice.go'), 'utf8');
const stateStoreSource = readFileSync(join(projectRoot, 'state_store.go'), 'utf8');
const taskfileSource = readFileSync(join(projectRoot, 'Taskfile.yml'), 'utf8');
const macReleaseScript = readFileSync(join(projectRoot, 'scripts', 'build-macos-release.sh'), 'utf8');
const windowsReleaseScript = readFileSync(join(projectRoot, 'scripts', 'build-windows-release.sh'), 'utf8');
const frontendPackage = JSON.parse(readFileSync(join(testDir, '..', 'package.json'), 'utf8'));

test('main window restores and saves last position like ssh-vault2', () => {
  assert.match(mainSource, /loadWindowPrefs\(\)/);
  assert.match(mainSource, /WindowDidMove/);
  assert.match(mainSource, /WindowDidResize/);
  assert.match(mainSource, /WindowClosing/);
  assert.match(mainSource, /saveWindowPrefsFromWindow/);
  assert.ok(existsSync(join(projectRoot, 'window_state.go')));
});

test('backend exposes branch-aware release-channel updater and in-place installer', () => {
  assert.match(serviceSource, /githubReleaseFeedBaseURL/);
  assert.match(serviceSource, /releaseChannelBranches/);
  assert.match(serviceSource, /stable.*main/s);
  assert.match(serviceSource, /beta.*beta/s);
  assert.match(serviceSource, /func \(s \*AppService\) Info\(\)/);
  assert.match(serviceSource, /func \(s \*AppService\) GitHubRelease\(channel string\)/);
  assert.match(serviceSource, /latest\.json/);
  assert.doesNotMatch(serviceSource, /releases\/latest/);
  assert.match(serviceSource, /func \(s \*AppService\) InstallUpdate\(/);
  assert.match(serviceSource, /Start-Process/);
  assert.match(serviceSource, /os\.Exit\(0\)/);
});

test('backend appVersion matches package version and release builds inject it', () => {
  const match = serviceSource.match(/var\s+appVersion\s*=\s*"([^"]+)"/);
  assert.ok(match, 'appVersion must be a mutable var for -ldflags -X injection');
  assert.equal(match[1], frontendPackage.version);
  assert.doesNotMatch(serviceSource, /const\s+appVersion\s*=/);
  assert.match(taskfileSource, /-H windowsgui -X main\.appVersion=\{\{\.APP_VERSION\}\}/);
  assert.match(macReleaseScript, /-X main\.appVersion=\$\{VERSION\}/);
  assert.match(windowsReleaseScript, /-H windowsgui -X main\.appVersion=\$\{VERSION\}/);
  assert.match(windowsReleaseScript, /WINDOWS_GUI_SUBSYSTEM_CHECK_FAILED/);
});

test('frontend renders update controls and calls generated Wails API', () => {
  assert.match(appSource, /from '\.\.\/bindings\/github\.com\/kanuracer\/sharkord-desktop\/appservice'/);
  assert.match(appSource, /checkUpdates/);
  assert.match(appSource, /installSelectedUpdate/);
  assert.match(appSource, /GitHubRelease/);
  assert.match(appSource, /InstallUpdate/);
  assert.match(appSource, /updatePanel/);
});


test('frontend persists stable/beta release channel and checks selected channel', () => {
  assert.match(typesSource, /ReleaseChannel = 'stable' \| 'beta'/);
  assert.match(typesSource, /releaseChannel\?: ReleaseChannel/);
  assert.match(storageSource, /releaseChannel:\s*'stable'/);
  assert.match(storageSource, /normalizeReleaseChannel/);
  assert.match(stateStoreSource, /ReleaseChannel\s+string/);
  assert.match(appSource, /releaseChannel = normalizeReleaseChannel\(state\.releaseChannel\)/);
  assert.match(appSource, /setReleaseChannel/);
  assert.match(appSource, /API\.GitHubRelease\(channel\)/);
  assert.match(appSource, /value="stable"/);
  assert.match(appSource, /value="beta"/);
  assert.match(appSource, /Stable · main/);
  assert.match(appSource, /Beta · beta/);
});

test('startup update check raises a visible update CTA when a newer release is found', () => {
  assert.match(appSource, /checkUpdates\(info, true, releaseChannel\)/);
  assert.match(appSource, /startupUpdateNoticeVisible/);
  assert.match(appSource, /setStartupUpdateNoticeVisible\(true\)/);
  assert.match(appSource, /function StartupUpdateNotice/);
  assert.match(appSource, /role="status"/);
  assert.match(appSource, /aria-live="polite"/);
  assert.match(appSource, /openUpdateSettings/);
  assert.match(appSource, /setSettingsInitialTab\('updates'\)/);
  assert.match(appSource, /Update anzeigen/);
  assert.match(cssSource, /\.startupUpdateNotice\b/);
  assert.match(cssSource, /\.startupUpdateNoticeActions\b/);
});

test('update settings tab renders release channel and changelog from release feed', () => {
  assert.match(appSource, /release=\{release\}/);
  assert.match(appSource, /updateAsset=\{updateAsset\}/);
  assert.match(appSource, /release:\s*GitHubRelease \| null/);
  assert.match(appSource, /updateAsset:\s*ReleaseAsset \| null/);
  assert.match(appSource, /formatReleaseChangelog\(release\?\.changelog\)/);
  assert.match(appSource, /function formatReleaseChangelog/);
  assert.match(appSource, /Verification\|Verifikation\|QA\|Tests\?\|Build/);
  assert.match(appSource, /releaseChannelSelector/);
  assert.match(appSource, /updateChangelog/);
  assert.match(appSource, /Release-Changelog/);
  assert.match(appSource, /Kein Changelog im Release\./);
  assert.match(cssSource, /\.releaseChannelSelector\b/);
  assert.match(cssSource, /\.updatePanelHeader\b/);
  assert.match(cssSource, /\.updateControls\b/);
  assert.match(cssSource, /\.updateMetaGrid\b/);
  assert.match(cssSource, /\.updateChangelog\b/);
  assert.match(cssSource, /\.updateChangelog pre\s*\{[^}]*white-space:\s*pre-wrap/s);
  assert.doesNotMatch(cssSource, /\.settingsCard\.updatePanel\s*\{[^}]*display:\s*flex/s);
});

test('update notification and changelog phrases are translatable', () => {
  for (const phrase of ['Später', 'Update anzeigen', 'Release-Changelog', 'Kein Changelog im Release.', 'Neues Sharkord Desktop Release gefunden', 'Release-Kanal', 'Release-Info', 'Installiert', 'Kanal', 'Online', 'Paket']) {
    assert.match(appSource, new RegExp(`tr\\('${phrase.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`));
  }
  for (const english of ['Later', 'Show update', 'Release changelog', 'No changelog in this release', 'New Sharkord Desktop release found', 'Release channel', 'Release info', 'Installed', 'Channel', 'Online', 'Package']) {
    assert.match(i18nSource, new RegExp(english.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  }
});
