import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

test('desktop keeps voice media moderation and channel links fork-only', () => {
  assert.match(clientSource, /voiceUserMediaModeration: boolean/);
  assert.match(clientSource, /channelLinks: boolean/);
  assert.match(clientSource, /voiceUserMediaModeration: false/);
  assert.match(clientSource, /channelLinks: false/);
  assert.match(clientSource, /stopUserVoiceMedia\(/);
  assert.match(clientSource, /resolveChannelLink\(/);
});

test('desktop UI gates voice media moderation and channel link controls behind capabilities', () => {
  assert.match(appSource, /connection\??\.serverCapabilities\.voiceUserMediaModeration/);
  assert.match(appSource, /connection\??\.serverCapabilities\.channelLinks/);
  assert.match(appSource, /stopContextUserVoiceMedia/);
  assert.match(appSource, /copyContextChannelLink/);
  assert.match(appSource, /openChannelLinkTarget/);
});
