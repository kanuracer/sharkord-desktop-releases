import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

const selectVoiceSource = appSource.match(/async function selectVoice\(channel: SharkordChannel\) \{[\s\S]*?\n  \}/)?.[0] ?? '';
const voiceJoinSource = appSource.match(/onVoiceJoin: \(\{ channelId, userId, state \}\) => \{[\s\S]*?\n      \},/)?.[0] ?? '';

test('desktop gates fork-only voice reactions and text-chat coupling behind capabilities', () => {
  assert.match(clientSource, /voiceReactions: boolean/);
  assert.match(clientSource, /voiceTextChatCoupling: boolean/);
  assert.match(clientSource, /voiceReactions: false/);
  assert.match(clientSource, /voiceTextChatCoupling: false/);
  assert.match(clientSource, /reactVoice\(/);
  assert.match(appSource, /connection\.serverCapabilities\.voiceReactions/);
});

test('desktop does not permanently open voice text chat when joining/selecting voice', () => {
  assert.match(appSource, /async function openVoiceTextChat\(channel: SharkordChannel\)/);
  assert.match(appSource, /Textchat geöffnet: #\$\{channel\.name\}/);
  assert.match(appSource, /Textchat öffnen/);
  assert.doesNotMatch(selectVoiceSource, /loadMessages\(connection, channel\.id\)/);
  assert.doesNotMatch(voiceJoinSource, /voiceTextChatCoupling[\s\S]{0,80}loadMessages/);
});

test('desktop renders transient voice reactions behind compact action menu', () => {
  assert.match(appSource, /onVoiceReaction/);
  assert.match(appSource, /voiceReactionBadge/);
  assert.match(appSource, /sendCurrentVoiceReaction/);
  assert.match(appSource, /function VoiceConnectionPanel/);
  assert.match(appSource, /voiceActionsOpen/);
  assert.match(appSource, /voiceActionsPopover/);
});

test('voice media recovery is a separate voice action, not an emoji/reaction popover item', () => {
  const panelSource = appSource.match(/function VoiceConnectionPanel[\s\S]*?\n}\n\nfunction TwoFactorCodeDialog/)?.[0] ?? '';
  const popoverSource = panelSource.match(/<div className="voiceActionsPopover"[\s\S]*?<\/div> : null/)?.[0] ?? '';
  assert.match(panelSource, /className="voiceRecoveryButton"/);
  assert.match(panelSource, /onRecoverVoiceMedia/);
  assert.doesNotMatch(popoverSource, /onRecoverVoiceMedia/);
  assert.doesNotMatch(popoverSource, /Voice-Recovery/);
  assert.doesNotMatch(popoverSource, /RefreshCw/);
});
