import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

test('desktop keeps soundboard and media recovery fork-only', () => {
  assert.match(clientSource, /voiceSoundboard: boolean/);
  assert.match(clientSource, /voiceMediaRecovery: boolean/);
  assert.match(clientSource, /voiceSoundboard: false/);
  assert.match(clientSource, /voiceMediaRecovery: false/);
  assert.match(clientSource, /playVoiceSoundboard\(/);
  assert.match(clientSource, /recoverVoiceMedia\(/);
});

test('desktop UI gates soundboard and media recovery controls behind capabilities', () => {
  assert.match(appSource, /connection\.serverCapabilities\.voiceSoundboard/);
  assert.match(appSource, /connection\.serverCapabilities\.voiceMediaRecovery/);
  assert.match(appSource, /sendCurrentVoiceSoundboard/);
  assert.match(appSource, /recoverCurrentVoiceMedia/);
  assert.match(appSource, /onVoiceSoundboard/);
});
