import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');
const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');

test('desktop tracks WebRTC announced-address support as fork-only capability metadata', () => {
  assert.match(clientSource, /webRtcAnnouncedAddress:\s*boolean/);
  const defaults = clientSource.match(/export const DEFAULT_ORIGINAL_SERVER_CAPABILITIES:[\s\S]*?};/)?.[0] ?? '';
  assert.match(defaults, /webRtcAnnouncedAddress:\s*false/);
  assert.match(clientSource, /webRtcAnnouncedAddress:\s*capabilityEnabled\(nested\.webRtcAnnouncedAddress, nested\.webrtcAnnouncedAddress, nested\.voiceAnnouncedAddress\)/);
});

test('desktop reaction fallback keeps message reactions legible when emoji glyph rendering is unavailable', () => {
  assert.match(appSource, /function renderReactionEmoji/);
  assert.match(appSource, /const emojiName = customEmojiReactionName\(emoji\)/);
  assert.match(appSource, /aria-label=\{`:\$\{emojiName\}:`\}/);
  assert.match(appSource, /reactionEmojiTextFallback/);
});
