import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    rolldownOptions: {
      output: {
        manualChunks(id) {
          if (!id.includes('node_modules')) return undefined;
          if (id.includes('/react/') || id.includes('/react-dom/') || id.includes('scheduler')) return 'vendor-react';
          if (id.includes('/lucide-react/')) return 'vendor-icons';
          if (id.includes('/mediasoup-client/') || id.includes('/@sapphi-red/')) return 'vendor-media';
          if (id.includes('/@trpc/')) return 'vendor-trpc';
          if (id.includes('/@wailsio/')) return 'vendor-wails';
          return 'vendor';
        }
      }
    }
  },
  server: { port: 5173, strictPort: true }
});
