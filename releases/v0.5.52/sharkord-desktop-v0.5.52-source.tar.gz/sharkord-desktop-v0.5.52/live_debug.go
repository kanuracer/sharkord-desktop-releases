package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
	"sync"
	"time"
)

const maxDiagnosticLogPayloadBytes = 64 * 1024
const maxDiagnosticLogBytes int64 = 8 * 1024 * 1024

var liveDebugSensitiveKey = regexp.MustCompile(`(?i)(password|pass` + `wort|token|secret|authorization|cookie|credential|session|content|html|body)`)
var liveDebugSensitiveValue = regexp.MustCompile(`(?i)(bearer\s+[A-Za-z0-9._~+\-/]+=*|password\s+[^\s,;]+|token\s+[^\s,;]+)`)

type DiagnosticLogInfo struct {
	Path string `json:"path"`
	Size int64  `json:"size"`
}

var diagnosticLogMu sync.Mutex
var diagnosticConfigDirForTest string

type LiveDebugLogEntry struct {
	SessionID  string         `json:"sessionId"`
	Event      string         `json:"event"`
	Level      string         `json:"level"`
	Message    string         `json:"message,omitempty"`
	Data       map[string]any `json:"data,omitempty"`
	At         int64          `json:"at,omitempty"`
	AppVersion string         `json:"appVersion,omitempty"`
	Platform   string         `json:"platform,omitempty"`
	Arch       string         `json:"arch,omitempty"`
}

func redactLiveDebugValue(v any) any {
	switch x := v.(type) {
	case map[string]any:
		out := map[string]any{}
		for k, val := range x {
			if liveDebugSensitiveKey.MatchString(k) {
				out[k] = "[REDACTED]"
				continue
			}
			out[k] = redactLiveDebugValue(val)
		}
		return out
	case []any:
		out := make([]any, 0, len(x))
		for _, val := range x {
			out = append(out, redactLiveDebugValue(val))
		}
		return out
	case string:
		if liveDebugSensitiveValue.MatchString(x) {
			return liveDebugSensitiveValue.ReplaceAllString(x, "[REDACTED]")
		}
		if len(x) > 2048 {
			return x[:2048] + "…[truncated]"
		}
		return x
	default:
		return x
	}
}

func sanitizeLiveDebugEntry(entry LiveDebugLogEntry) LiveDebugLogEntry {
	entry.SessionID = strings.TrimSpace(entry.SessionID)
	if entry.SessionID == "" {
		entry.SessionID = "unknown"
	}
	entry.Event = strings.TrimSpace(entry.Event)
	if entry.Event == "" {
		entry.Event = "debug.event"
	}
	entry.Level = strings.ToLower(strings.TrimSpace(entry.Level))
	if entry.Level == "" {
		entry.Level = "info"
	}
	entry.Message, _ = redactLiveDebugValue(entry.Message).(string)
	if entry.Data != nil {
		entry.Data, _ = redactLiveDebugValue(entry.Data).(map[string]any)
	}
	if entry.At == 0 {
		entry.At = time.Now().UnixMilli()
	}
	entry.AppVersion = appVersion
	entry.Platform = runtime.GOOS
	entry.Arch = runtime.GOARCH
	return entry
}

func liveDebugJSONForTest(entry LiveDebugLogEntry) string {
	body, _ := json.Marshal(entry)
	return string(body)
}

func diagnosticConfigDir() (string, error) {
	if diagnosticConfigDirForTest != "" {
		return diagnosticConfigDirForTest, os.MkdirAll(diagnosticConfigDirForTest, 0700)
	}
	return configDir()
}

func diagnosticLogPath() (string, error) {
	dir, err := diagnosticConfigDir()
	if err != nil {
		return "", err
	}
	logDir := filepath.Join(dir, "logs")
	if err := os.MkdirAll(logDir, 0700); err != nil {
		return "", err
	}
	return filepath.Join(logDir, "diagnostic.ndjson"), nil
}

func rotateDiagnosticLogIfNeeded(path string) error {
	info, err := os.Stat(path)
	if os.IsNotExist(err) {
		return nil
	}
	if err != nil {
		return err
	}
	if info.Size() < maxDiagnosticLogBytes {
		return nil
	}
	backup := strings.TrimSuffix(path, filepath.Ext(path)) + ".1" + filepath.Ext(path)
	_ = os.Remove(backup)
	return os.Rename(path, backup)
}

func diagnosticLogInfo() (DiagnosticLogInfo, error) {
	path, err := diagnosticLogPath()
	if err != nil {
		return DiagnosticLogInfo{}, err
	}
	info := DiagnosticLogInfo{Path: path}
	if stat, err := os.Stat(path); err == nil {
		info.Size = stat.Size()
	}
	return info, nil
}

func DiagnosticLogInfoForTest() (DiagnosticLogInfo, error) { return diagnosticLogInfo() }

func AppendDiagnosticLogEntry(entry LiveDebugLogEntry) (DiagnosticLogInfo, error) {
	diagnosticLogMu.Lock()
	defer diagnosticLogMu.Unlock()
	path, err := diagnosticLogPath()
	if err != nil {
		return DiagnosticLogInfo{}, err
	}
	if err := rotateDiagnosticLogIfNeeded(path); err != nil {
		return DiagnosticLogInfo{}, err
	}
	entry = sanitizeLiveDebugEntry(entry)
	body, err := json.Marshal(entry)
	if err != nil {
		return DiagnosticLogInfo{}, err
	}
	if len(body) > maxDiagnosticLogPayloadBytes {
		return DiagnosticLogInfo{}, fmt.Errorf("diagnostic log payload too large")
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
	if err != nil {
		return DiagnosticLogInfo{}, err
	}
	defer f.Close()
	if _, err := f.Write(append(body, '\n')); err != nil {
		return DiagnosticLogInfo{}, err
	}
	return diagnosticLogInfo()
}

func (s *AppService) GetDiagnosticLogInfo() (DiagnosticLogInfo, error) { return diagnosticLogInfo() }

func (s *AppService) AppendDiagnosticLog(entry LiveDebugLogEntry) (DiagnosticLogInfo, error) {
	return AppendDiagnosticLogEntry(entry)
}
