package main

import (
	"strings"
	"testing"
)

func TestLiveDebugLogRedactsSensitiveValues(t *testing.T) {
	entry := LiveDebugLogEntry{
		SessionID: "session-1",
		Event:     "voice.produce.error",
		Level:     "error",
		Message:   "failed with password hunter2 and token abc123",
		Data: map[string]any{
			"password":      "hunter2",
			"accessToken":   "abc123",
			"authorization": "Bearer secret",
			"safe":          "kept",
		},
	}
	clean := sanitizeLiveDebugEntry(entry)
	raw := liveDebugJSONForTest(clean)
	for _, forbidden := range []string{"hunter2", "abc123", "Bearer secret"} {
		if strings.Contains(raw, forbidden) {
			t.Fatalf("live debug payload leaked secret %q in %s", forbidden, raw)
		}
	}
	if !strings.Contains(raw, "[REDACTED]") || !strings.Contains(raw, "kept") {
		t.Fatalf("expected redacted secrets and safe data in %s", raw)
	}
}
