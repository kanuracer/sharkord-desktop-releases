package main

import (
	"embed"
	"log"

	"github.com/wailsapp/wails/v3/pkg/application"
	"github.com/wailsapp/wails/v3/pkg/events"
)

//go:embed all:frontend/dist
var assets embed.FS

//go:embed frontend/src/assets/sharkord-logo.png
var appIcon []byte

func main() {
	svc := NewAppService()
	app := application.New(application.Options{
		Name:        "Sharkord Desktop",
		Description: "Cross-platform desktop client for Sharkord",
		Icon:        appIcon,
		Services:    []application.Service{application.NewService(svc)},
		Assets:      application.AssetOptions{Handler: application.AssetFileServerFS(assets)},
		Mac:         application.MacOptions{ApplicationShouldTerminateAfterLastWindowClosed: true},
	})
	svc.app = app

	wp := loadWindowPrefs()
	opts := application.WebviewWindowOptions{
		Title:            "Sharkord Desktop",
		Width:            1280,
		Height:           820,
		MinWidth:         960,
		MinHeight:        640,
		BackgroundColour: application.NewRGB(9, 10, 15),
		URL:              "/",
		Windows: application.WindowsWindow{
			Permissions: map[application.CoreWebView2PermissionKind]application.CoreWebView2PermissionState{
				application.CoreWebView2PermissionKindMicrophone: application.CoreWebView2PermissionStateAllow,
				application.CoreWebView2PermissionKindCamera:     application.CoreWebView2PermissionStateAllow,
			},
		},
	}
	if wp.Valid {
		opts.InitialPosition = application.WindowXY
		opts.X = wp.X
		opts.Y = wp.Y
		opts.Width = wp.Width
		opts.Height = wp.Height
	}
	win := app.Window.NewWithOptions(opts)
	win.OnWindowEvent(events.Common.WindowDidMove, func(_ *application.WindowEvent) { saveWindowPrefsFromWindow(win) })
	win.OnWindowEvent(events.Common.WindowDidResize, func(_ *application.WindowEvent) { saveWindowPrefsFromWindow(win) })
	win.OnWindowEvent(events.Common.WindowClosing, func(_ *application.WindowEvent) { saveWindowPrefsFromWindow(win) })

	if err := app.Run(); err != nil {
		log.Fatal(err)
	}
}
