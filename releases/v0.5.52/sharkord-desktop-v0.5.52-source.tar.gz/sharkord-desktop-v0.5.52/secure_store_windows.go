//go:build windows

package main

import (
	"errors"
	"syscall"
	"unsafe"
)

type dataBlob struct {
	cbData uint32
	pbData *byte
}

var (
	crypt32              = syscall.NewLazyDLL("crypt32.dll")
	kernel32             = syscall.NewLazyDLL("kernel32.dll")
	procCryptProtectData = crypt32.NewProc("CryptProtectData")
	procCryptUnprotect   = crypt32.NewProc("CryptUnprotectData")
	procLocalFree        = kernel32.NewProc("LocalFree")
)

func bytesToBlob(b []byte) dataBlob {
	if len(b) == 0 {
		return dataBlob{}
	}
	return dataBlob{cbData: uint32(len(b)), pbData: &b[0]}
}

func blobToBytes(blob dataBlob) []byte {
	if blob.cbData == 0 || blob.pbData == nil {
		return nil
	}
	defer procLocalFree.Call(uintptr(unsafe.Pointer(blob.pbData)))
	out := make([]byte, blob.cbData)
	copy(out, unsafe.Slice(blob.pbData, blob.cbData))
	return out
}

func encryptSecret(plain []byte) ([]byte, error) {
	in := bytesToBlob(plain)
	var out dataBlob
	ok, _, err := procCryptProtectData.Call(
		uintptr(unsafe.Pointer(&in)),
		0,
		0,
		0,
		0,
		0,
		uintptr(unsafe.Pointer(&out)),
	)
	if ok == 0 {
		if err != syscall.Errno(0) {
			return nil, err
		}
		return nil, errors.New("CryptProtectData failed")
	}
	return blobToBytes(out), nil
}

func decryptSecret(protected []byte) ([]byte, error) {
	in := bytesToBlob(protected)
	var out dataBlob
	ok, _, err := procCryptUnprotect.Call(
		uintptr(unsafe.Pointer(&in)),
		0,
		0,
		0,
		0,
		0,
		uintptr(unsafe.Pointer(&out)),
	)
	if ok == 0 {
		if err != syscall.Errno(0) {
			return nil, err
		}
		return nil, errors.New("CryptUnprotectData failed")
	}
	return blobToBytes(out), nil
}
