package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestReadSettingsImportJSONReturnsCleanValidatedJSON(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "settings.json")
	jsonWithBOM := "\ufeff{\"kind\":\"sharkord-desktop-settings-export\",\"schemaVersion\":1}"
	if err := os.WriteFile(path, []byte(jsonWithBOM), 0600); err != nil {
		t.Fatal(err)
	}
	got, err := NewAppService().ReadSettingsImportJSON(path)
	if err != nil {
		t.Fatalf("ReadSettingsImportJSON failed: %v", err)
	}
	if strings.HasPrefix(got, "\ufeff") {
		t.Fatalf("expected BOM stripped, got %q", got[:3])
	}
	if !strings.Contains(got, "sharkord-desktop-settings-export") {
		t.Fatalf("expected import JSON, got %q", got)
	}
}

func TestReadSettingsImportJSONRejectsInvalidOrWrongExtension(t *testing.T) {
	dir := t.TempDir()
	badExt := filepath.Join(dir, "settings.txt")
	if err := os.WriteFile(badExt, []byte("{}"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := NewAppService().ReadSettingsImportJSON(badExt); err == nil || !strings.Contains(err.Error(), "JSON") {
		t.Fatalf("expected JSON extension error, got %v", err)
	}

	badJSON := filepath.Join(dir, "settings.json")
	if err := os.WriteFile(badJSON, []byte("not-json"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := NewAppService().ReadSettingsImportJSON(badJSON); err == nil || !strings.Contains(err.Error(), "invalid JSON") {
		t.Fatalf("expected invalid JSON error, got %v", err)
	}
}
