package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"
)

type SharkordServer struct {
	ID           string          `json:"id"`
	Name         string          `json:"name"`
	URL          string          `json:"url"`
	Color        string          `json:"color"`
	LastOpenedAt int64           `json:"lastOpenedAt"`
	AutoConnect  bool            `json:"autoConnect"`
	Logo         json.RawMessage `json:"logo,omitempty"`
}

type StoredState struct {
	Theme             string           `json:"theme"`
	ActiveServerID    *string          `json:"activeServerId"`
	Servers           []SharkordServer `json:"servers"`
	ReleaseChannel    string           `json:"releaseChannel,omitempty"`
	AllowEmptyServers bool             `json:"allowEmptyServers,omitempty"`
}

var placeholderServerHosts = []string{"example.tld", "example.com", "example.org", "example.net"}

func statePath() (string, error) {
	dir, err := configDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(dir, "state.json"), nil
}

func normalizeStoredState(in StoredState) StoredState {
	out := StoredState{Theme: "dark", Servers: []SharkordServer{}, ReleaseChannel: defaultReleaseChannel}
	if in.Theme == "light" {
		out.Theme = "light"
	}
	out.ReleaseChannel = normalizeReleaseChannelValue(in.ReleaseChannel)
	seen := map[string]bool{}
	for _, server := range in.Servers {
		server.ID = strings.TrimSpace(server.ID)
		server.Name = strings.TrimSpace(server.Name)
		server.URL = strings.TrimRight(strings.TrimSpace(server.URL), "/")
		if server.ID == "" || server.URL == "" || seen[server.ID] {
			continue
		}
		if parsed, err := url.Parse(server.URL); err != nil || parsed.Scheme == "" || parsed.Host == "" {
			continue
		}
		if isPlaceholderServerURL(server.URL) {
			continue
		}
		if server.Name == "" {
			server.Name = server.URL
		}
		if server.Color == "" {
			server.Color = "#5865f2"
		}
		if server.LastOpenedAt <= 0 {
			server.LastOpenedAt = time.Now().UnixMilli()
		}
		seen[server.ID] = true
		out.Servers = append(out.Servers, server)
	}
	if in.ActiveServerID != nil {
		active := strings.TrimSpace(*in.ActiveServerID)
		for _, server := range out.Servers {
			if server.ID == active {
				out.ActiveServerID = &active
				break
			}
		}
	}
	if out.ActiveServerID == nil && len(out.Servers) > 0 {
		active := out.Servers[0].ID
		out.ActiveServerID = &active
	}
	return out
}

func isPlaceholderServerURL(raw string) bool {
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil {
		return false
	}
	host := strings.ToLower(parsed.Hostname())
	for _, placeholder := range placeholderServerHosts {
		if host == placeholder || strings.HasSuffix(host, "."+placeholder) {
			return true
		}
	}
	return false
}

func hasPlaceholderServers(state StoredState) bool {
	for _, server := range state.Servers {
		if isPlaceholderServerURL(server.URL) {
			return true
		}
	}
	return false
}

func serverListSignature(state StoredState) string {
	parts := make([]string, 0, len(state.Servers))
	for _, server := range state.Servers {
		parts = append(parts, server.ID+"\x00"+server.URL+"\x00"+server.Name+"\x00"+fmt.Sprint(server.AutoConnect))
	}
	return strings.Join(parts, "\x1f")
}

func backupStateFile(path string) error {
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return nil
	}
	if err != nil {
		return err
	}
	backupPath := fmt.Sprintf("%s.backup-%s", path, time.Now().UTC().Format("20060102T150405.000Z"))
	return os.WriteFile(backupPath, b, 0600)
}

func (s *AppService) LoadAppState() (StoredState, error) {
	var state StoredState
	path, err := statePath()
	if err != nil {
		return state, err
	}
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return normalizeStoredState(state), nil
	}
	if err != nil {
		return state, err
	}
	if err := json.Unmarshal(cleanJSONBytes(b), &state); err != nil {
		return StoredState{}, err
	}
	return normalizeStoredState(state), nil
}

func (s *AppService) SaveAppState(state StoredState) error {
	path, err := statePath()
	if err != nil {
		return err
	}
	incomingHadPlaceholder := hasPlaceholderServers(state)
	allowEmptyServers := state.AllowEmptyServers
	previous, err := s.LoadAppState()
	if err != nil {
		return err
	}
	state = normalizeStoredState(state)
	if len(previous.Servers) > 0 && len(state.Servers) == 0 && !allowEmptyServers {
		if incomingHadPlaceholder {
			return fmt.Errorf("refusing to overwrite existing server list with placeholder state")
		}
		return fmt.Errorf("refusing to overwrite existing server list with empty state without explicit allowEmptyServers")
	}
	if len(previous.Servers) > 0 && serverListSignature(previous) != serverListSignature(state) {
		if err := backupStateFile(path); err != nil {
			return err
		}
	}
	state.AllowEmptyServers = false
	b, err := json.MarshalIndent(state, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0600)
}
