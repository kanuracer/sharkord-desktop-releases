package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestNormalizeStoredStatePreservesReleaseChannel(t *testing.T) {
	active := "server-1"
	state := normalizeStoredState(StoredState{Theme: "dark", ReleaseChannel: "beta", ActiveServerID: &active, Servers: []SharkordServer{{ID: active, Name: "Prod", URL: "https://sharkord.test.internal"}}})
	if state.ReleaseChannel != "beta" {
		t.Fatalf("expected beta release channel, got %#v", state.ReleaseChannel)
	}
	fallback := normalizeStoredState(StoredState{Theme: "dark", ReleaseChannel: "canary"})
	if fallback.ReleaseChannel != "stable" {
		t.Fatalf("expected invalid channel to normalize to stable, got %#v", fallback.ReleaseChannel)
	}
}

func TestAppStateStoreRoundTrip(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)
	t.Setenv("XDG_CONFIG_HOME", tmp)
	t.Setenv("APPDATA", tmp)
	svc := NewAppService()
	active := "server-1"
	want := StoredState{
		Theme:          "light",
		ActiveServerID: &active,
		Servers: []SharkordServer{{
			ID:           "server-1",
			Name:         "Prod",
			URL:          "https://sharkord.test.internal",
			Color:        "#5865f2",
			LastOpenedAt: 123,
			AutoConnect:  true,
		}},
	}
	if err := svc.SaveAppState(want); err != nil {
		t.Fatalf("save app state: %v", err)
	}
	got, err := svc.LoadAppState()
	if err != nil {
		t.Fatalf("load app state: %v", err)
	}
	if got.Theme != want.Theme || got.ActiveServerID == nil || *got.ActiveServerID != active || len(got.Servers) != 1 || got.Servers[0].URL != want.Servers[0].URL || !got.Servers[0].AutoConnect {
		t.Fatalf("state mismatch: got %#v want %#v", got, want)
	}
	path, err := statePath()
	if err != nil {
		t.Fatalf("state path: %v", err)
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read state file: %v", err)
	}
	if !strings.Contains(string(raw), "sharkord.test.internal") {
		t.Fatalf("state file did not persist server URL: %s", string(raw))
	}
}

func TestAppStateStoreNormalizesMissingActiveServer(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)
	t.Setenv("XDG_CONFIG_HOME", tmp)
	t.Setenv("APPDATA", tmp)
	svc := NewAppService()
	missing := "missing"
	state := StoredState{Theme: "dark", ActiveServerID: &missing, Servers: []SharkordServer{{ID: "server-1", Name: "Prod", URL: "https://sharkord.test.internal"}}}
	if err := svc.SaveAppState(state); err != nil {
		t.Fatalf("save app state: %v", err)
	}
	got, err := svc.LoadAppState()
	if err != nil {
		t.Fatalf("load app state: %v", err)
	}
	if got.ActiveServerID == nil || *got.ActiveServerID != "server-1" {
		t.Fatalf("expected first server active fallback, got %#v", got.ActiveServerID)
	}
}

func TestAppStateStoreRefusesImplicitEmptyOverwrite(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)
	t.Setenv("XDG_CONFIG_HOME", tmp)
	t.Setenv("APPDATA", tmp)
	svc := NewAppService()
	active := "server-1"
	real := StoredState{Theme: "dark", ActiveServerID: &active, Servers: []SharkordServer{{ID: active, Name: "kanuracer", URL: "https://sharkord.kanuracer.eu"}}}
	if err := svc.SaveAppState(real); err != nil {
		t.Fatalf("save real state: %v", err)
	}
	if err := svc.SaveAppState(StoredState{Theme: "dark", Servers: nil}); err == nil || !strings.Contains(err.Error(), "refusing") {
		t.Fatalf("expected destructive empty overwrite to be refused, got %v", err)
	}
	got, err := svc.LoadAppState()
	if err != nil {
		t.Fatalf("load after refused overwrite: %v", err)
	}
	if len(got.Servers) != 1 || got.Servers[0].URL != real.Servers[0].URL {
		t.Fatalf("real server was not preserved: %#v", got)
	}
}

func TestAppStateStoreRefusesPlaceholderOverwrite(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)
	t.Setenv("XDG_CONFIG_HOME", tmp)
	t.Setenv("APPDATA", tmp)
	svc := NewAppService()
	active := "server-1"
	real := StoredState{Theme: "dark", ActiveServerID: &active, Servers: []SharkordServer{{ID: active, Name: "kanuracer", URL: "https://sharkord.kanuracer.eu"}}}
	if err := svc.SaveAppState(real); err != nil {
		t.Fatalf("save real state: %v", err)
	}
	placeholder := "placeholder"
	err := svc.SaveAppState(StoredState{Theme: "dark", ActiveServerID: &placeholder, Servers: []SharkordServer{{ID: placeholder, Name: "Prod", URL: "https://sharkord.example.tld"}}})
	if err == nil || !strings.Contains(err.Error(), "placeholder") {
		t.Fatalf("expected placeholder overwrite to be refused, got %v", err)
	}
	got, err := svc.LoadAppState()
	if err != nil {
		t.Fatalf("load after refused placeholder overwrite: %v", err)
	}
	if len(got.Servers) != 1 || got.Servers[0].URL != real.Servers[0].URL {
		t.Fatalf("real server was not preserved: %#v", got)
	}
}

func TestAppStateStoreAllowsExplicitEmptyStateWithBackup(t *testing.T) {
	tmp := t.TempDir()
	t.Setenv("HOME", tmp)
	t.Setenv("XDG_CONFIG_HOME", tmp)
	t.Setenv("APPDATA", tmp)
	svc := NewAppService()
	active := "server-1"
	real := StoredState{Theme: "dark", ActiveServerID: &active, Servers: []SharkordServer{{ID: active, Name: "kanuracer", URL: "https://sharkord.kanuracer.eu"}}}
	if err := svc.SaveAppState(real); err != nil {
		t.Fatalf("save real state: %v", err)
	}
	if err := svc.SaveAppState(StoredState{Theme: "dark", AllowEmptyServers: true}); err != nil {
		t.Fatalf("explicit empty save should be allowed: %v", err)
	}
	got, err := svc.LoadAppState()
	if err != nil {
		t.Fatalf("load after explicit empty save: %v", err)
	}
	if len(got.Servers) != 0 {
		t.Fatalf("expected no servers after explicit delete, got %#v", got)
	}
	path, err := statePath()
	if err != nil {
		t.Fatalf("state path: %v", err)
	}
	backups, err := filepath.Glob(path + ".backup-*")
	if err != nil || len(backups) == 0 {
		t.Fatalf("expected backup before destructive save, backups=%v err=%v", backups, err)
	}
	backupRaw, err := os.ReadFile(backups[0])
	if err != nil {
		t.Fatalf("read backup: %v", err)
	}
	if !strings.Contains(string(backupRaw), "sharkord.kanuracer.eu") {
		t.Fatalf("backup does not contain preserved server: %s", string(backupRaw))
	}
}
