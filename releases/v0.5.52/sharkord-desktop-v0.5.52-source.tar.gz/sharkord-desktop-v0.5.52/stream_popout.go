package main

import (
	"errors"
	"fmt"
	"net/url"
	"strings"
	"time"

	"github.com/wailsapp/wails/v3/pkg/application"
	"github.com/wailsapp/wails/v3/pkg/events"
)

type StreamPopoutRequest struct {
	ServerID              string `json:"serverId"`
	ServerURL             string `json:"serverUrl"`
	ChannelID             int    `json:"channelId"`
	RemoteID              int    `json:"remoteId"`
	Kind                  string `json:"kind"`
	Title                 string `json:"title"`
	RouterRtpCapabilities string `json:"routerRtpCapabilities"`
}

type StreamPopoutConfig struct {
	ID                    string `json:"id"`
	ServerID              string `json:"serverId"`
	ServerURL             string `json:"serverUrl"`
	ChannelID             int    `json:"channelId"`
	RemoteID              int    `json:"remoteId"`
	Kind                  string `json:"kind"`
	Title                 string `json:"title"`
	RouterRtpCapabilities string `json:"routerRtpCapabilities"`
}

func (s *AppService) OpenStreamPopoutWindow(req StreamPopoutRequest) error {
	if s.app == nil {
		return errors.New("app window service not ready")
	}
	req.ServerID = strings.TrimSpace(req.ServerID)
	req.ServerURL = strings.TrimSpace(req.ServerURL)
	req.Kind = strings.TrimSpace(strings.ToLower(req.Kind))
	req.Title = strings.TrimSpace(req.Title)
	if req.ServerID == "" || req.ServerURL == "" || req.ChannelID <= 0 || req.RemoteID <= 0 || req.Kind == "" || strings.TrimSpace(req.RouterRtpCapabilities) == "" {
		return errors.New("stream popout: incomplete stream data")
	}
	if req.Kind != "screen" && req.Kind != "external_video" && req.Kind != "video" {
		return fmt.Errorf("stream popout: unsupported stream type %q", req.Kind)
	}
	if req.Title == "" {
		req.Title = "Sharkord Stream"
	}
	id := fmt.Sprintf("%d-%d-%d", req.ChannelID, req.RemoteID, time.Now().UnixNano())
	config := StreamPopoutConfig{
		ID: id, ServerID: req.ServerID, ServerURL: req.ServerURL, ChannelID: req.ChannelID,
		RemoteID: req.RemoteID, Kind: req.Kind, Title: req.Title, RouterRtpCapabilities: req.RouterRtpCapabilities,
	}
	s.streamPopoutMu.Lock()
	s.streamPopoutConfigs[id] = config
	s.streamPopoutMu.Unlock()
	values := url.Values{}
	values.Set("streamPopout", "1")
	values.Set("streamPopoutId", id)
	window := s.app.Window.NewWithOptions(application.WebviewWindowOptions{
		Name:             "sharkord-stream-" + id,
		Title:            req.Title,
		Width:            1100,
		Height:           720,
		MinWidth:         520,
		MinHeight:        320,
		BackgroundColour: application.NewRGB(5, 5, 7),
		URL:              "/?" + values.Encode(),
	})
	s.streamPopoutMu.Lock()
	s.streamPopoutWindows[id] = window
	s.streamPopoutMu.Unlock()
	window.OnWindowEvent(events.Common.WindowClosing, func(_ *application.WindowEvent) {
		s.streamPopoutMu.Lock()
		delete(s.streamPopoutConfigs, id)
		delete(s.streamPopoutWindows, id)
		s.streamPopoutMu.Unlock()
	})
	return nil
}

func (s *AppService) GetStreamPopoutConfig(id string) (StreamPopoutConfig, error) {
	id = strings.TrimSpace(id)
	if id == "" {
		return StreamPopoutConfig{}, errors.New("stream popout ID missing")
	}
	s.streamPopoutMu.Lock()
	defer s.streamPopoutMu.Unlock()
	config, ok := s.streamPopoutConfigs[id]
	if !ok {
		return StreamPopoutConfig{}, errors.New("stream popout config not found")
	}
	return config, nil
}

func (s *AppService) CloseStreamPopoutWindow(id string) error {
	id = strings.TrimSpace(id)
	if id == "" {
		return errors.New("stream popout ID missing")
	}
	s.streamPopoutMu.Lock()
	window := s.streamPopoutWindows[id]
	delete(s.streamPopoutConfigs, id)
	delete(s.streamPopoutWindows, id)
	s.streamPopoutMu.Unlock()
	if window != nil {
		window.Close()
	}
	return nil
}
