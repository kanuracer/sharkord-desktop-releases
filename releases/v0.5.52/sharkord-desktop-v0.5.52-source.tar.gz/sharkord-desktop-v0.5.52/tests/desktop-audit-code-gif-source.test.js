import { describe, expect, test } from 'bun:test';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

describe('desktop audit/code/gif source', () => {
  const app = readFileSync(join(import.meta.dir, '../frontend/src/App.tsx'), 'utf8');
  const client = readFileSync(join(import.meta.dir, '../frontend/src/sharkordClient.ts'), 'utf8');

  test('role permissions include DM pin and security audit controls', () => {
    expect(app).toContain('PIN_DIRECT_MESSAGES');
    expect(app).toContain('VIEW_AUDIT_LOG');
    expect(app).toContain('MANAGE_SECURITY_EVENTS');
  });

  test('desktop audit log renders type, actor user, and JSON details', () => {
    expect(client).toContain('type?: string');
    expect(client).toContain('user?: {');
    expect(app).toContain('auditLogRow');
    expect(app).toContain('entry.type || entry.action');
    expect(app).toContain('JSON.stringify(payload, null, 2)');
  });

  test('desktop code and Tenor GIF picker are wired', () => {
    expect(client).toContain('data-language');
    expect(app).toContain('searchGifLibrary');
    expect(app).toContain('api.tenor.com/v1/search');
    expect(app).toContain('composerGifMenu');
  });
});
