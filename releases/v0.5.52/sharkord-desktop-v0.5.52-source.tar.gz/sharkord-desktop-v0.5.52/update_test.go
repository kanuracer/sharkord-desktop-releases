package main

import (
	"archive/zip"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

func writeZipForTest(t *testing.T, entries map[string][]byte) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "update.zip")
	file, err := os.Create(path)
	if err != nil {
		t.Fatalf("create zip: %v", err)
	}
	zw := zip.NewWriter(file)
	for name, body := range entries {
		w, err := zw.Create(name)
		if err != nil {
			t.Fatalf("create zip entry %s: %v", name, err)
		}
		if _, err := w.Write(body); err != nil {
			t.Fatalf("write zip entry %s: %v", name, err)
		}
	}
	if err := zw.Close(); err != nil {
		t.Fatalf("close zip: %v", err)
	}
	if err := file.Close(); err != nil {
		t.Fatalf("close file: %v", err)
	}
	return path
}

func TestReleaseChannelBranchRejectsUnknownChannel(t *testing.T) {
	cases := []struct {
		input       string
		wantChannel string
		wantBranch  string
		wantErr     bool
	}{
		{"", "stable", "main", false},
		{"stable", "stable", "main", false},
		{" beta ", "beta", "beta", false},
		{"../main", "", "", true},
		{"canary", "", "", true},
	}
	for _, tc := range cases {
		t.Run(tc.input, func(t *testing.T) {
			channel, branch, err := releaseChannelBranch(tc.input)
			if tc.wantErr {
				if err == nil {
					t.Fatalf("expected error for %q", tc.input)
				}
				return
			}
			if err != nil || channel != tc.wantChannel || branch != tc.wantBranch {
				t.Fatalf("got channel=%q branch=%q err=%v", channel, branch, err)
			}
		})
	}
}

func TestReleaseFeedURLUsesPinnedBranches(t *testing.T) {
	old := githubReleaseFeedBaseURL
	githubReleaseFeedBaseURL = "https://example.test/feeds"
	defer func() { githubReleaseFeedBaseURL = old }()
	stable, err := releaseFeedURL("stable")
	if err != nil || stable != "https://example.test/feeds/main/latest.json" {
		t.Fatalf("stable feed mismatch: %q err=%v", stable, err)
	}
	beta, err := releaseFeedURL("beta")
	if err != nil || beta != "https://example.test/feeds/beta/latest.json" {
		t.Fatalf("beta feed mismatch: %q err=%v", beta, err)
	}
	if _, err := releaseFeedURL("refs/heads/main"); err == nil {
		t.Fatalf("expected branch injection to be rejected")
	}
}

func TestGitHubReleaseFetchesRequestedChannelFeed(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/beta/latest.json" {
			t.Fatalf("expected beta feed path, got %s", r.URL.Path)
		}
		fmt.Fprintf(w, `{"channel":"beta","version":"9.9.9","tagName":"v9.9.9","htmlUrl":"https://example.test/v9.9.9","changelog":"Beta notes","assets":[{"name":"sharkord-desktop-9.9.9-%s-%s.%s","url":"https://example.test/asset","size":2048}]}`, runtime.GOOS, runtime.GOARCH, updateExtensionForTest())
	}))
	defer server.Close()
	old := githubReleaseFeedBaseURL
	githubReleaseFeedBaseURL = server.URL
	defer func() { githubReleaseFeedBaseURL = old }()
	release, err := NewAppService().GitHubRelease("beta")
	if err != nil {
		t.Fatalf("GitHubRelease beta feed: %v", err)
	}
	if release.Channel != "beta" || release.FeedURL != server.URL+"/beta/latest.json" || release.Version != "9.9.9" || release.Changelog != "Beta notes" {
		t.Fatalf("release mismatch: %#v", release)
	}
	if len(release.Assets) != 1 || release.Assets[0].Channel != "beta" || release.Assets[0].Version != "9.9.9" {
		t.Fatalf("asset defaults mismatch: %#v", release.Assets)
	}
}

func TestGitHubReleaseRejectsFeedChannelMismatch(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprint(w, `{"channel":"stable","version":"9.9.9","assets":[]}`)
	}))
	defer server.Close()
	old := githubReleaseFeedBaseURL
	githubReleaseFeedBaseURL = server.URL
	defer func() { githubReleaseFeedBaseURL = old }()
	if _, err := NewAppService().GitHubRelease("beta"); err == nil || !strings.Contains(err.Error(), "channel mismatch") {
		t.Fatalf("expected channel mismatch error, got %v", err)
	}
}

func updateExtensionForTest() string {
	switch runtime.GOOS {
	case "windows":
		return "exe"
	case "darwin":
		return "zip"
	default:
		return "tar.gz"
	}
}

func TestValidateDarwinUpdateArchiveAcceptsSingleAppBundle(t *testing.T) {
	bigBinary := make([]byte, 1024*1024+1)
	zipPath := writeZipForTest(t, map[string][]byte{
		"Sharkord Desktop.app/Contents/Info.plist":              []byte("plist"),
		"Sharkord Desktop.app/Contents/MacOS/sharkord-desktop":  bigBinary,
		"Sharkord Desktop.app/Contents/Resources/Sharkord.icns": []byte("icon"),
	})
	got, err := validateDarwinUpdateArchive(zipPath)
	if err != nil {
		t.Fatalf("expected valid darwin archive: %v", err)
	}
	if got != "Sharkord Desktop.app" {
		t.Fatalf("app root mismatch: got %q", got)
	}
}

func TestValidateDarwinUpdateArchiveRejectsUnsafeAndAmbiguousArchives(t *testing.T) {
	bigBinary := make([]byte, 1024*1024+1)
	cases := []struct {
		name    string
		entries map[string][]byte
		wantErr string
	}{
		{
			name:    "path traversal",
			entries: map[string][]byte{"../Sharkord Desktop.app/Contents/MacOS/sharkord-desktop": bigBinary},
			wantErr: "unsicherer ZIP-Pfad",
		},
		{
			name: "two apps",
			entries: map[string][]byte{
				"One.app/Contents/MacOS/sharkord-desktop": bigBinary,
				"Two.app/Contents/MacOS/sharkord-desktop": bigBinary,
			},
			wantErr: "exactly one .app",
		},
		{
			name:    "missing binary",
			entries: map[string][]byte{"Sharkord Desktop.app/Contents/Info.plist": []byte("plist")},
			wantErr: "genau ein .app/Contents/MacOS/sharkord-desktop",
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			_, err := validateDarwinUpdateArchive(writeZipForTest(t, tc.entries))
			if err == nil || !strings.Contains(err.Error(), tc.wantErr) {
				t.Fatalf("expected %q error, got %v", tc.wantErr, err)
			}
		})
	}
}

func TestCurrentMacOSAppRootFindsBundle(t *testing.T) {
	if runtime.GOOS != "darwin" {
		t.Skip("macOS app bundle root detection is only used on darwin")
	}
	root := filepath.Join(string(os.PathSeparator), "Applications", "Sharkord Desktop.app")
	exe := filepath.Join(root, "Contents", "MacOS", "sharkord-desktop")
	got, err := currentMacOSAppRoot(exe)
	if err != nil {
		t.Fatalf("current app root: %v", err)
	}
	if got != root {
		t.Fatalf("root mismatch: %q", got)
	}
	if _, err := currentMacOSAppRoot(filepath.Join(os.TempDir(), "sharkord-desktop")); err == nil {
		t.Fatalf("expected error for non-.app executable")
	}
}

func TestMacOSReleaseScriptMatchesUpdaterContract(t *testing.T) {
	body, err := os.ReadFile(filepath.Join("scripts", "build-macos-release.sh"))
	if err != nil {
		t.Fatalf("read macOS build script: %v", err)
	}
	script := string(body)
	for _, want := range []string{
		`BUNDLE_ID="eu.kanuracer.sharkord-desktop"`,
		`CFBundleExecutable</key><string>sharkord-desktop</string>`,
		`Contents/MacOS/sharkord-desktop`,
	} {
		if !strings.Contains(script, want) {
			t.Fatalf("macOS release script missing updater contract %q", want)
		}
	}
}

func TestCleanupUpdateCacheRemovesOldArtifactsButKeepsCurrentAndUnrelatedFiles(t *testing.T) {
	dir := t.TempDir()
	current := filepath.Join(dir, "sharkord-desktop-9.9.9-windows-amd64.exe")
	files := []string{
		current,
		filepath.Join(dir, "sharkord-desktop-0.5.37-windows-amd64.exe"),
		filepath.Join(dir, "sharkord-desktop-0.5.37-darwin-arm64.zip"),
		filepath.Join(dir, "sharkord-desktop-0.5.37-linux-amd64.tar.gz"),
		filepath.Join(dir, "apply-update.ps1"),
		filepath.Join(dir, "apply-update.sh"),
		filepath.Join(dir, "apply-update-macos.sh"),
		filepath.Join(dir, "apply-update.log"),
		filepath.Join(dir, "settings.json"),
	}
	for _, file := range files {
		if err := os.WriteFile(file, []byte("x"), 0600); err != nil {
			t.Fatalf("write %s: %v", file, err)
		}
	}
	if err := os.Mkdir(filepath.Join(dir, "sharkord-desktop-update.old"), 0700); err != nil {
		t.Fatalf("write temp update dir: %v", err)
	}
	if err := cleanupUpdateCache(dir, map[string]bool{current: true}); err != nil {
		t.Fatalf("cleanup update cache: %v", err)
	}
	for _, removed := range append(files[1:8], filepath.Join(dir, "sharkord-desktop-update.old")) {
		if _, err := os.Stat(removed); !errors.Is(err, os.ErrNotExist) {
			t.Fatalf("expected %s to be removed, stat err=%v", removed, err)
		}
	}
	for _, kept := range []string{current, filepath.Join(dir, "settings.json")} {
		if _, err := os.Stat(kept); err != nil {
			t.Fatalf("expected %s to remain: %v", kept, err)
		}
	}
}

func TestUpdaterInfoCleansExistingUpdateCacheOnStartup(t *testing.T) {
	cacheRoot := t.TempDir()
	t.Setenv("HOME", cacheRoot)
	t.Setenv("XDG_CACHE_HOME", cacheRoot)
	dir := updateCacheDir()
	old := filepath.Join(dir, "sharkord-desktop-0.5.37-windows-amd64.exe")
	if err := os.MkdirAll(dir, 0700); err != nil {
		t.Fatalf("mkdir update cache: %v", err)
	}
	if err := os.WriteFile(old, []byte("stale"), 0600); err != nil {
		t.Fatalf("write stale artifact: %v", err)
	}
	if _, err := NewAppService().Info(); err != nil {
		t.Fatalf("Info: %v", err)
	}
	if _, err := os.Stat(old); !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("expected startup cleanup to remove stale artifact, stat err=%v", err)
	}
}

func TestUpdaterApplyScriptsRemoveDownloadedArtifactAfterSuccessfulRestart(t *testing.T) {
	body, err := os.ReadFile("appservice.go")
	if err != nil {
		t.Fatalf("read appservice.go: %v", err)
	}
	source := string(body)
	for _, want := range []string{
		`Remove-Item -LiteralPath $downloaded -Force -ErrorAction SilentlyContinue`,
		`Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue`,
		`rm -f "$archive" "$0"`,
	} {
		if !strings.Contains(source, want) {
			t.Fatalf("updater apply script missing self-cleanup marker %q", want)
		}
	}
}
