package main

import (
	"archive/tar"
	"archive/zip"
	"compress/gzip"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
	"sync"
	"time"

	"github.com/wailsapp/wails/v3/pkg/application"
)

var appVersion = "0.5.43"

const defaultReleaseChannel = "stable"

var releaseChannelBranches = map[string]string{
	"stable": "main",
	"beta":   "beta",
}
var githubReleaseFeedBaseURL = "https://raw.githubusercontent.com/kanuracer/sharkord-desktop-releases"

const maxUpdateArtifactBytes int64 = 500 * 1024 * 1024
const maxReleaseBodyBytes int64 = 2 * 1024 * 1024
const maxSettingsImportBytes int64 = 5 * 1024 * 1024

type AppService struct {
	client              *http.Client
	app                 *application.App
	streamPopoutMu      sync.Mutex
	streamPopoutConfigs map[string]StreamPopoutConfig
	streamPopoutWindows map[string]*application.WebviewWindow
}

type ProbeResult struct {
	OK         bool   `json:"ok"`
	URL        string `json:"url"`
	StatusCode int    `json:"statusCode"`
	Error      string `json:"error,omitempty"`
}

type AppInfo struct {
	Version        string `json:"version"`
	Platform       string `json:"platform"`
	Arch           string `json:"arch"`
	ConfigDir      string `json:"configDir"`
	ReleaseAPI     string `json:"releaseApi"`
	ReleaseChannel string `json:"releaseChannel"`
}

type ReleaseAsset struct {
	Name               string `json:"name"`
	URL                string `json:"url"`
	BrowserDownloadURL string `json:"browserDownloadUrl"`
	Size               int64  `json:"size"`
	SHA256             string `json:"sha256,omitempty"`
	Version            string `json:"version,omitempty"`
	Channel            string `json:"channel,omitempty"`
}

type GitHubRelease struct {
	Version   string         `json:"version"`
	TagName   string         `json:"tagName"`
	HTMLURL   string         `json:"htmlUrl"`
	Changelog string         `json:"changelog,omitempty"`
	Assets    []ReleaseAsset `json:"assets"`
	Channel   string         `json:"channel"`
	FeedURL   string         `json:"feedUrl,omitempty"`
}

type githubReleaseResponse struct {
	TagName string `json:"tag_name"`
	Name    string `json:"name"`
	Body    string `json:"body"`
	HTMLURL string `json:"html_url"`
	Assets  []struct {
		Name               string `json:"name"`
		URL                string `json:"url"`
		BrowserDownloadURL string `json:"browser_download_url"`
		Size               int64  `json:"size"`
		Digest             string `json:"digest"`
	} `json:"assets"`
}

func NewAppService() *AppService {
	return &AppService{client: &http.Client{Timeout: 20 * time.Second}, streamPopoutConfigs: map[string]StreamPopoutConfig{}, streamPopoutWindows: map[string]*application.WebviewWindow{}}
}

func configDir() (string, error) {
	d, err := os.UserConfigDir()
	if err != nil {
		return "", err
	}
	p := filepath.Join(d, "sharkord-desktop")
	return p, os.MkdirAll(p, 0700)
}

func cleanJSONBytes(b []byte) []byte {
	return bytesTrimBOM(b)
}

func bytesTrimBOM(b []byte) []byte {
	if len(b) >= 3 && b[0] == 0xef && b[1] == 0xbb && b[2] == 0xbf {
		return b[3:]
	}
	return b
}

func readLimited(r io.Reader, limit int64) ([]byte, error) {
	b, err := io.ReadAll(io.LimitReader(r, limit+1))
	if err != nil {
		return nil, err
	}
	if int64(len(b)) > limit {
		return nil, fmt.Errorf("response too large")
	}
	return b, nil
}

func readErrorBody(r io.Reader) string {
	b, _ := readLimited(r, 16*1024)
	return strings.TrimSpace(string(cleanJSONBytes(b)))
}

func versionFromString(s string) string {
	re := regexp.MustCompile(`(?:^|[^0-9])(\d+\.\d+\.\d+)(?:[^0-9]|$)`)
	m := re.FindStringSubmatch(s)
	if len(m) >= 2 {
		return m[1]
	}
	return strings.TrimPrefix(strings.TrimSpace(s), "v")
}

func compareSemver(a, b string) int {
	parse := func(v string) [3]int {
		var out [3]int
		parts := strings.Split(versionFromString(v), ".")
		for i := 0; i < 3 && i < len(parts); i++ {
			_, _ = fmt.Sscanf(parts[i], "%d", &out[i])
		}
		return out
	}
	A, B := parse(a), parse(b)
	for i := 0; i < 3; i++ {
		if A[i] > B[i] {
			return 1
		}
		if A[i] < B[i] {
			return -1
		}
	}
	return 0
}

func releaseChannelBranch(channel string) (string, string, error) {
	channel = strings.ToLower(strings.TrimSpace(channel))
	if channel == "" {
		channel = defaultReleaseChannel
	}
	branch, ok := releaseChannelBranches[channel]
	if !ok {
		return "", "", fmt.Errorf("unknown release channel: %s", channel)
	}
	return channel, branch, nil
}

func normalizeReleaseChannelValue(channel string) string {
	channel, _, err := releaseChannelBranch(channel)
	if err != nil {
		return defaultReleaseChannel
	}
	return channel
}

func releaseFeedURL(channel string) (string, error) {
	_, branch, err := releaseChannelBranch(channel)
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("%s/%s/latest.json", strings.TrimRight(githubReleaseFeedBaseURL, "/"), branch), nil
}

func (s *AppService) Info() (AppInfo, error) {
	cleanupDefaultUpdateCache()
	d, err := configDir()
	feedURL, feedErr := releaseFeedURL(defaultReleaseChannel)
	if feedErr != nil && err == nil {
		err = feedErr
	}
	return AppInfo{Version: appVersion, Platform: runtime.GOOS, Arch: runtime.GOARCH, ConfigDir: d, ReleaseAPI: feedURL, ReleaseChannel: defaultReleaseChannel}, err
}

func (s *AppService) WriteSettingsExportJSON(targetPath string, exportJSON string, includeUserData bool) (string, error) {
	exportJSON = strings.TrimSpace(exportJSON)
	if exportJSON == "" {
		return "", fmt.Errorf("export data missing")
	}
	if includeUserData {
		var envelope map[string]any
		if err := json.Unmarshal([]byte(exportJSON), &envelope); err != nil {
			return "", fmt.Errorf("export data invalid: %w", err)
		}
		var typed struct {
			State struct {
				Servers []SharkordServer `json:"servers"`
			} `json:"state"`
		}
		if err := json.Unmarshal([]byte(exportJSON), &typed); err != nil {
			return "", fmt.Errorf("export data invalid: %w", err)
		}
		credentialsByServerID := map[string]ServerCredentials{}
		for _, server := range typed.State.Servers {
			creds, err := s.LoadServerCredentials(server.ID)
			if err != nil {
				return "", err
			}
			if creds.Identity != "" || creds.Password != "" || creds.ServerPassword != "" {
				credentialsByServerID[server.ID] = creds
			}
		}
		envelope["includesUserData"] = true
		envelope["credentialsByServerId"] = credentialsByServerID
		b, err := json.MarshalIndent(envelope, "", "  ")
		if err != nil {
			return "", err
		}
		exportJSON = string(b)
	}
	target := strings.TrimSpace(targetPath)
	if target == "" {
		return "", fmt.Errorf("target path missing")
	}
	if !strings.HasSuffix(strings.ToLower(target), ".json") {
		target += ".json"
	}
	if err := os.MkdirAll(filepath.Dir(target), 0700); err != nil {
		return "", err
	}
	if err := os.WriteFile(target, []byte(exportJSON), 0600); err != nil {
		return "", err
	}
	return target, nil
}

func (s *AppService) ReadSettingsImportJSON(sourcePath string) (string, error) {
	target := strings.TrimSpace(sourcePath)
	if target == "" {
		return "", fmt.Errorf("import path missing")
	}
	if !strings.HasSuffix(strings.ToLower(target), ".json") {
		return "", fmt.Errorf("settings import must be a JSON file")
	}
	file, err := os.Open(target)
	if err != nil {
		return "", err
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		return "", err
	}
	if info.IsDir() {
		return "", fmt.Errorf("settings import must be a JSON file")
	}
	if info.Size() > maxSettingsImportBytes {
		return "", fmt.Errorf("settings import JSON too large")
	}
	body, err := readLimited(file, maxSettingsImportBytes)
	if err != nil {
		return "", err
	}
	body = cleanJSONBytes(body)
	if !json.Valid(body) {
		return "", fmt.Errorf("invalid JSON import file")
	}
	return string(body), nil
}

func (s *AppService) NormalizeServerURL(raw string) (string, error) {
	trimmed := strings.TrimSpace(raw)
	if trimmed == "" {
		return "", nil
	}
	if !strings.HasPrefix(strings.ToLower(trimmed), "http://") && !strings.HasPrefix(strings.ToLower(trimmed), "https://") {
		trimmed = "https://" + trimmed
	}
	u, err := url.Parse(trimmed)
	if err != nil || u.Scheme == "" || u.Host == "" {
		return "", err
	}
	u.Fragment = ""
	return strings.TrimRight(u.String(), "/"), nil
}

func (s *AppService) ProbeServer(raw string) ProbeResult {
	normalized, err := s.NormalizeServerURL(raw)
	if err != nil || normalized == "" {
		return ProbeResult{OK: false, URL: raw, Error: "invalid URL"}
	}
	req, err := http.NewRequest(http.MethodHead, normalized, nil)
	if err != nil {
		return ProbeResult{OK: false, URL: normalized, Error: err.Error()}
	}
	resp, err := s.client.Do(req)
	if err != nil {
		return ProbeResult{OK: false, URL: normalized, Error: err.Error()}
	}
	defer resp.Body.Close()
	return ProbeResult{OK: resp.StatusCode < 500, URL: normalized, StatusCode: resp.StatusCode}
}

func (s *AppService) GitHubRelease(channel string) (GitHubRelease, error) {
	var out GitHubRelease
	channel, _, err := releaseChannelBranch(channel)
	if err != nil {
		return out, err
	}
	feedURL, err := releaseFeedURL(channel)
	if err != nil {
		return out, err
	}
	req, err := http.NewRequest(http.MethodGet, feedURL, nil)
	if err != nil {
		return out, err
	}
	req.Header.Set("Accept", "application/json")
	if token := strings.TrimSpace(os.Getenv("SHARKORD_DESKTOP_GITHUB_TOKEN")); token != "" && strings.Contains(feedURL, "githubusercontent.com/") {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	resp, err := s.client.Do(req)
	if err != nil {
		return out, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		detail := readErrorBody(resp.Body)
		if detail != "" {
			return out, fmt.Errorf("release feed HTTP %d: %s", resp.StatusCode, detail)
		}
		return out, fmt.Errorf("release feed HTTP %d", resp.StatusCode)
	}
	body, err := readLimited(resp.Body, maxReleaseBodyBytes)
	if err != nil {
		return out, err
	}
	if err := json.Unmarshal(cleanJSONBytes(body), &out); err != nil {
		return out, err
	}
	out.Channel = normalizeReleaseChannelValue(out.Channel)
	if out.Channel != channel {
		return GitHubRelease{}, fmt.Errorf("release feed channel mismatch: requested %s got %s", channel, out.Channel)
	}
	if out.Version == "" {
		out.Version = versionFromString(out.TagName)
	}
	if out.Version == "" {
		return GitHubRelease{}, fmt.Errorf("release feed version missing")
	}
	if out.TagName == "" {
		out.TagName = "v" + out.Version
	}
	out.FeedURL = feedURL
	filtered := make([]ReleaseAsset, 0, len(out.Assets))
	for _, asset := range out.Assets {
		if asset.Version == "" {
			asset.Version = out.Version
		}
		if asset.Channel == "" {
			asset.Channel = channel
		}
		if asset.BrowserDownloadURL == "" {
			asset.BrowserDownloadURL = asset.URL
		}
		if asset.URL == "" {
			asset.URL = asset.BrowserDownloadURL
		}
		if validUpdateAssetForCurrentPlatform(asset) == nil {
			filtered = append(filtered, asset)
		}
	}
	out.Assets = filtered
	return out, nil
}

func updateCacheDir() string {
	cache, err := os.UserCacheDir()
	if err != nil {
		cache = os.TempDir()
	}
	return filepath.Join(cache, "sharkord-desktop", "updates")
}

func cleanupDefaultUpdateCache() {
	_ = cleanupUpdateCache(updateCacheDir(), nil)
}

func shouldRemoveUpdateCacheEntry(name string, isDir bool) bool {
	lower := strings.ToLower(name)
	if isDir {
		return strings.HasPrefix(lower, "sharkord-desktop-update.")
	}
	if lower == "apply-update.ps1" || lower == "apply-update.sh" || lower == "apply-update-macos.sh" || lower == "apply-update.log" {
		return true
	}
	return strings.HasPrefix(lower, "sharkord-desktop-") && (strings.HasSuffix(lower, ".exe") || strings.HasSuffix(lower, ".zip") || strings.HasSuffix(lower, ".tar.gz"))
}

func cleanupUpdateCache(dir string, keep map[string]bool) error {
	entries, err := os.ReadDir(dir)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return nil
		}
		return err
	}
	for _, entry := range entries {
		name := entry.Name()
		full := filepath.Join(dir, name)
		if keep != nil && (keep[full] || keep[name]) {
			continue
		}
		if !shouldRemoveUpdateCacheEntry(name, entry.IsDir()) {
			continue
		}
		if entry.IsDir() {
			if err := os.RemoveAll(full); err != nil {
				return err
			}
			continue
		}
		if err := os.Remove(full); err != nil && !errors.Is(err, os.ErrNotExist) {
			return err
		}
	}
	return nil
}

func validUpdateAssetForCurrentPlatform(asset ReleaseAsset) error {
	name := strings.ToLower(asset.Name)
	if asset.Size <= 0 || asset.Size > maxUpdateArtifactBytes {
		return fmt.Errorf("invalid asset size")
	}
	if asset.URL == "" && asset.BrowserDownloadURL == "" {
		return fmt.Errorf("download URL missing")
	}
	version := strings.TrimSpace(asset.Version)
	if version == "" {
		version = versionFromString(asset.Name)
	}
	if version != "" && compareSemver(version, appVersion) <= 0 {
		return fmt.Errorf("no newer update")
	}
	switch runtime.GOOS {
	case "windows":
		if !strings.HasSuffix(name, ".exe") || !strings.Contains(name, "windows") {
			return fmt.Errorf("Windows braucht *.exe Asset")
		}
	case "linux":
		if !strings.Contains(name, "linux") || !strings.HasSuffix(name, ".tar.gz") {
			return fmt.Errorf("Linux braucht *.tar.gz Asset")
		}
	case "darwin":
		if !strings.Contains(name, "darwin") || !strings.HasSuffix(name, ".zip") {
			return fmt.Errorf("macOS braucht darwin-*.zip Asset")
		}
	default:
		return fmt.Errorf("updates unsupported for %s", runtime.GOOS)
	}
	return nil
}

func archivePathUnsafe(name string) bool {
	clean := path.Clean(strings.TrimSpace(name))
	if clean == "." || clean == "" || strings.HasPrefix(clean, "../") || strings.Contains(clean, "/../") || path.IsAbs(clean) || strings.Contains(name, "\\") {
		return true
	}
	return !regexp.MustCompile(`^[A-Za-z0-9._+@%=-]+(/[A-Za-z0-9._+@%=-]+)*$`).MatchString(clean)
}

func validateLinuxUpdateArchive(archivePath string) (string, error) {
	f, err := os.Open(archivePath)
	if err != nil {
		return "", err
	}
	defer f.Close()
	gz, err := gzip.NewReader(f)
	if err != nil {
		return "", err
	}
	defer gz.Close()
	tr := tar.NewReader(gz)
	matches := []string{}
	for {
		h, err := tr.Next()
		if errors.Is(err, io.EOF) {
			break
		}
		if err != nil {
			return "", err
		}
		if archivePathUnsafe(h.Name) {
			return "", fmt.Errorf("unsicherer Archivpfad: %s", h.Name)
		}
		if h.Typeflag == tar.TypeReg && path.Base(h.Name) == "sharkord-desktop" && h.Size > 1024*1024 {
			matches = append(matches, path.Clean(h.Name))
		}
		if h.Typeflag == tar.TypeSymlink || h.Typeflag == tar.TypeLink {
			return "", fmt.Errorf("archive contains symlink: %s", h.Name)
		}
	}
	if len(matches) != 1 {
		return "", fmt.Errorf("Linux-Archiv muss genau ein sharkord-desktop Binary enthalten, gefunden: %d", len(matches))
	}
	return matches[0], nil
}

func validateDarwinUpdateArchive(archivePath string) (string, error) {
	r, err := zip.OpenReader(archivePath)
	if err != nil {
		return "", err
	}
	defer r.Close()
	appRoots := map[string]bool{}
	binaryMatches := []string{}
	for _, f := range r.File {
		name := strings.TrimSpace(f.Name)
		clean := path.Clean(name)
		if clean == "." || clean == "" || strings.HasPrefix(clean, "../") || strings.Contains(clean, "/../") || path.IsAbs(clean) || strings.Contains(name, "\\") || strings.HasPrefix(name, "/") {
			return "", fmt.Errorf("unsicherer ZIP-Pfad: %s", f.Name)
		}
		if !regexp.MustCompile(`^[A-Za-z0-9 ._+@%=-]+(/[A-Za-z0-9 ._+@%=-]+)*$`).MatchString(clean) {
			return "", fmt.Errorf("unsicherer ZIP-Pfad: %s", f.Name)
		}
		mode := f.FileInfo().Mode()
		if mode&os.ModeSymlink != 0 {
			return "", fmt.Errorf("ZIP contains symlink: %s", f.Name)
		}
		parts := strings.Split(clean, "/")
		if len(parts) > 0 && strings.HasSuffix(parts[0], ".app") {
			appRoots[parts[0]] = true
		}
		if len(parts) >= 4 && strings.HasSuffix(parts[0], ".app") && parts[1] == "Contents" && parts[2] == "MacOS" && parts[3] == "sharkord-desktop" && !f.FileInfo().IsDir() && f.UncompressedSize64 > 1024*1024 {
			binaryMatches = append(binaryMatches, clean)
		}
	}
	if len(appRoots) != 1 {
		return "", fmt.Errorf("macOS ZIP must contain exactly one .app, found: %d", len(appRoots))
	}
	if len(binaryMatches) != 1 {
		return "", fmt.Errorf("macOS-ZIP muss genau ein .app/Contents/MacOS/sharkord-desktop Binary enthalten, gefunden: %d", len(binaryMatches))
	}
	return strings.Split(binaryMatches[0], "/")[0], nil
}

func currentMacOSAppRoot(exe string) (string, error) {
	parts := strings.Split(filepath.Clean(exe), string(os.PathSeparator))
	for i := len(parts) - 1; i >= 0; i-- {
		if strings.HasSuffix(parts[i], ".app") {
			if filepath.IsAbs(exe) {
				return string(os.PathSeparator) + filepath.Join(parts[1:i+1]...), nil
			}
			return filepath.Join(parts[:i+1]...), nil
		}
	}
	return "", fmt.Errorf("running app is not inside an .app bundle: %s", exe)
}

func (s *AppService) InstallUpdate(asset ReleaseAsset) (string, error) {
	if err := validUpdateAssetForCurrentPlatform(asset); err != nil {
		return "", err
	}
	downloadURL := asset.URL
	if downloadURL == "" {
		downloadURL = asset.BrowserDownloadURL
	}
	dir := updateCacheDir()
	if err := os.MkdirAll(dir, 0700); err != nil {
		return "", err
	}
	if err := cleanupUpdateCache(dir, nil); err != nil {
		return "", err
	}
	target := filepath.Join(dir, filepath.Base(asset.Name))
	req, err := http.NewRequest(http.MethodGet, downloadURL, nil)
	if err != nil {
		return "", err
	}
	if token := strings.TrimSpace(os.Getenv("SHARKORD_DESKTOP_GITHUB_TOKEN")); token != "" && strings.Contains(downloadURL, "github.com/") {
		req.Header.Set("Authorization", "Bearer "+token)
		req.Header.Set("Accept", "application/octet-stream")
	}
	resp, err := s.client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", fmt.Errorf("Download HTTP %d: %s", resp.StatusCode, readErrorBody(resp.Body))
	}
	out, err := os.Create(target)
	if err != nil {
		return "", err
	}
	h := sha256.New()
	written, err := io.Copy(io.MultiWriter(out, h), io.LimitReader(resp.Body, maxUpdateArtifactBytes+1))
	if err != nil {
		out.Close()
		_ = os.Remove(target)
		return "", err
	}
	if written > maxUpdateArtifactBytes {
		out.Close()
		_ = os.Remove(target)
		return "", fmt.Errorf("update artifact too large")
	}
	if err := out.Close(); err != nil {
		_ = os.Remove(target)
		return "", err
	}
	sum := fmt.Sprintf("%x", h.Sum(nil))
	if asset.SHA256 != "" && !strings.EqualFold(asset.SHA256, sum) {
		_ = os.Remove(target)
		return "", fmt.Errorf("SHA256 mismatch: %s", sum)
	}
	exe, err := os.Executable()
	if err != nil {
		return "", err
	}
	if resolved, err := filepath.EvalSymlinks(exe); err == nil {
		exe = resolved
	}
	pid := os.Getpid()
	logPath := filepath.Join(dir, "apply-update.log")
	switch runtime.GOOS {
	case "windows":
		script := filepath.Join(dir, "apply-update.ps1")
		body := fmt.Sprintf(`$ErrorActionPreference = 'Stop'
$pidToWait = %d
$downloaded = %q
$appExe = %q
$log = %q
$expectedSha = %q
function Log($m) { Add-Content -Path $log -Value ((Get-Date).ToString('s') + ' ' + $m) }
try {
  Log "apply-start pid=$pidToWait downloaded=$downloaded app=$appExe"
  while (Get-Process -Id $pidToWait -ErrorAction SilentlyContinue) { Start-Sleep -Milliseconds 500 }
  $actualSha = (Get-FileHash -Algorithm SHA256 -Path $downloaded).Hash.ToLowerInvariant()
  if ($expectedSha -and $actualSha -ne $expectedSha.ToLowerInvariant()) { throw "sha256 mismatch: $actualSha" }
  Copy-Item -LiteralPath $downloaded -Destination $appExe -Force
  Start-Sleep -Seconds 1
  Start-Process -FilePath $appExe
  Log "restart $appExe"
  Remove-Item -LiteralPath $downloaded -Force -ErrorAction SilentlyContinue
  if ($PSCommandPath) { Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue }
} catch { Log ("ERROR " + $_.Exception.Message) }
`, pid, target, exe, logPath, asset.SHA256)
		if err := os.WriteFile(script, []byte(body), 0600); err != nil {
			return "", err
		}
		cmd := exec.Command("powershell.exe", "-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-File", script)
		cmd.SysProcAttr = detachedSysProcAttr()
		if err := cmd.Start(); err != nil {
			return "", err
		}
		_ = cmd.Process.Release()
		go func() { time.Sleep(2500 * time.Millisecond); os.Exit(0) }()
		return "Update installing. Sharkord Desktop closes and restarts. Log: " + logPath, nil
	case "linux":
		archiveMember, err := validateLinuxUpdateArchive(target)
		if err != nil {
			_ = os.Remove(target)
			return "", err
		}
		script := filepath.Join(dir, "apply-update.sh")
		body := fmt.Sprintf(`#!/bin/sh
set -eu
pid=%d
archive=%q
member=%q
app=%q
log=%q
logmsg(){ echo "$(date) $1" >> "$log"; }
logmsg "apply-start pid=$pid archive=$archive app=$app"
while kill -0 "$pid" >/dev/null 2>&1; do sleep 0.5; done
work="$(mktemp -d "${TMPDIR:-/tmp}/sharkord-desktop-update.XXXXXX")"
trap 'rm -rf "$work"' EXIT
tar -xzf "$archive" -C "$work"
cp "$work/$member" "$app"
chmod +x "$app"
nohup "$app" >/dev/null 2>&1 &
logmsg "restart $app"
rm -f "$archive" "$0"
`, pid, target, archiveMember, exe, logPath)
		if err := os.WriteFile(script, []byte(body), 0700); err != nil {
			return "", err
		}
		cmd := exec.Command("/bin/sh", script)
		cmd.SysProcAttr = detachedSysProcAttr()
		if err := cmd.Start(); err != nil {
			return "", err
		}
		_ = cmd.Process.Release()
		go func() { time.Sleep(2500 * time.Millisecond); os.Exit(0) }()
		return "Update installing. Sharkord Desktop closes and restarts. Log: " + logPath, nil
	case "darwin":
		appRootName, err := validateDarwinUpdateArchive(target)
		if err != nil {
			_ = os.Remove(target)
			return "", err
		}
		appRoot, err := currentMacOSAppRoot(exe)
		if err != nil {
			return "", err
		}
		script := filepath.Join(dir, "apply-update-macos.sh")
		body := fmt.Sprintf(`#!/bin/sh
set -eu
pid=%d
archive=%q
app_root_name=%q
app=%q
log=%q
expected_sha=%q
logmsg(){ echo "$(date) $1" >> "$log"; }
logmsg "apply-start pid=$pid archive=$archive app=$app"
while kill -0 "$pid" >/dev/null 2>&1; do sleep 0.5; done
actual_sha="$(/usr/bin/shasum -a 256 "$archive" | /usr/bin/awk '{print $1}')"
if [ -n "$expected_sha" ] && [ "$actual_sha" != "$expected_sha" ]; then logmsg "ERROR sha256 mismatch: $actual_sha"; exit 1; fi
work="$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/sharkord-desktop-update.XXXXXX")"
backup="${app}.previous-update"
trap 'rm -rf "$work"' EXIT
/usr/bin/ditto -x -k "$archive" "$work"
if [ ! -x "$work/$app_root_name/Contents/MacOS/sharkord-desktop" ]; then logmsg "ERROR extracted app binary missing"; exit 1; fi
/usr/bin/codesign --verify --deep --strict "$work/$app_root_name" >> "$log" 2>&1 || { logmsg "ERROR codesign verify failed"; exit 1; }
rm -rf "$backup"
if [ -d "$app" ]; then mv "$app" "$backup"; fi
if mv "$work/$app_root_name" "$app"; then
  rm -rf "$backup"
  /usr/bin/open -n "$app"
  logmsg "restart $app"
  rm -f "$archive" "$0"
else
  logmsg "ERROR move failed, restoring backup"
  rm -rf "$app"
  if [ -d "$backup" ]; then mv "$backup" "$app"; /usr/bin/open -n "$app"; fi
  exit 1
fi
`, pid, target, appRootName, appRoot, logPath, asset.SHA256)
		if err := os.WriteFile(script, []byte(body), 0700); err != nil {
			return "", err
		}
		cmd := exec.Command("/bin/sh", script)
		cmd.SysProcAttr = detachedSysProcAttr()
		if err := cmd.Start(); err != nil {
			return "", err
		}
		_ = cmd.Process.Release()
		go func() { time.Sleep(2500 * time.Millisecond); os.Exit(0) }()
		return "Update installing. Sharkord Desktop closes and restarts. Log: " + logPath, nil
	default:
		return "", fmt.Errorf("updates unsupported for %s", runtime.GOOS)
	}
}
