#!/usr/bin/env bash
set -euo pipefail
VERSION="${1:-${SHARKORD_VERSION:-0.5.44}}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RC="$ROOT/build/windows/sharkord-desktop.rc"
SYSo="$ROOT/wails_windows_amd64.syso"
INFO="$ROOT/build/windows/info.json"
IFS=. read -r MAJOR MINOR PATCH <<<"$VERSION"
MAJOR="${MAJOR:-0}"; MINOR="${MINOR:-0}"; PATCH="${PATCH:-0}"
python3 - "$ROOT/build/windows/wails.exe.manifest" "$VERSION" <<'PY'
import re, sys
path, version = sys.argv[1], sys.argv[2]
text = open(path, encoding='utf-8').read()
text = re.sub(r'(name="com\.sharkord\.desktop" version=")[^"]+(" processorArchitecture=)', rf'\g<1>{version}.0\2', text, count=1)
open(path, 'w', encoding='utf-8').write(text)
PY
python3 - "$INFO" "$VERSION" <<'PY'
import json, sys
path, version = sys.argv[1], sys.argv[2]
with open(path, encoding='utf-8') as fh:
    data = json.load(fh)
data.setdefault('fixed', {})['file_version'] = f'{version}.0'
data.setdefault('fixed', {})['product_version'] = f'{version}.0'
data.setdefault('info', {}).setdefault('0409', {})['ProductVersion'] = version
with open(path, 'w', encoding='utf-8') as fh:
    json.dump(data, fh, indent=2)
    fh.write('\n')
PY
cat > "$RC" <<RC
#include <winver.h>

1 ICON "icon.ico"
1 24 "wails.exe.manifest"

1 VERSIONINFO
FILEVERSION ${MAJOR},${MINOR},${PATCH},0
PRODUCTVERSION ${MAJOR},${MINOR},${PATCH},0
FILEFLAGSMASK 0x3fL
FILEFLAGS 0x0L
FILEOS 0x40004L
FILETYPE 0x1L
FILESUBTYPE 0x0L
BEGIN
  BLOCK "StringFileInfo"
  BEGIN
    BLOCK "040904B0"
    BEGIN
      VALUE "CompanyName", "Sharkord\0"
      VALUE "FileDescription", "Sharkord Desktop\0"
      VALUE "FileVersion", "${VERSION}.0\0"
      VALUE "InternalName", "sharkord-desktop\0"
      VALUE "LegalCopyright", "Copyright Sharkord\0"
      VALUE "OriginalFilename", "sharkord-desktop.exe\0"
      VALUE "ProductName", "Sharkord Desktop\0"
      VALUE "ProductVersion", "${VERSION}\0"
      VALUE "Comments", "Cross-platform desktop client for Sharkord\0"
    END
  END
  BLOCK "VarFileInfo"
  BEGIN
    VALUE "Translation", 0x0409, 1200
  END
END
RC
( cd "$ROOT/build/windows" && x86_64-w64-mingw32-windres -O coff -F pe-x86-64 -i sharkord-desktop.rc -o "$SYSo" )
echo "WINDOWS_SYSO_OK $VERSION $SYSo"
