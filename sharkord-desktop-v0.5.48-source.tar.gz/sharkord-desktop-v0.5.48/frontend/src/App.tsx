import { FormEvent, type ReactNode, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as QRCode from 'qrcode';
import {
  AtSign,
  Bell,
  Camera,
  ChevronDown,
  ChevronRight,
  Download,
  GripVertical,
  Hash,
  Headphones,
  HardDrive,
  HelpCircle,
  KeyRound,
  Image as ImageIcon,
  LogIn,
  Mic,
  MicOff,
  Moon,
  MoreVertical,
  Pencil,
  PhoneCall,
  PhoneOff,
  Pin,
  PinOff,
  Play,
  Plus,
  RefreshCw,
  Search,
  Send,
  Settings,
  Smile,
  Sun,
  Trash2,
  Users,
  Video,
  Monitor,
  Volume2,
  VolumeX,
  WifiOff
} from 'lucide-react';
import { createServer, defaultState, initials, loadState, normalizeReleaseChannel, saveState } from './storage';
import type { ReleaseChannel, SharkordServer, StoredState, ThemeMode } from './types';
import {
  changeServerLogo,
  changeOwnAvatar,
  changeOwnBanner,
  executePluginAction,
  executePluginCommand,
  executePluginSlotAction,
  getMessagePageAround,
  getThreadMessages,
  getAccessibleMembers,
  getUnreadThreads,
  getPinnedMessages,
  globalSearchMessages,
  getPluginLogs,
  getPluginSettings,
  processPluginComponents,
  markChannelAsRead,
  requestDesktopNotificationPermission,
  setConsumerQuality,
  updateOwnPassword,
  getOwnMfaStatus,
  startOwnTotpSetup,
  enableOwnTotp,
  disableOwnTotp,
  updateOwnProfile,
  updatePluginSetting,
  createCategory,
  createChannel,
  createInvite,
  createRole,
  deleteCategory,
  deleteChannel,
  disconnectVoiceUser,
  deleteEmoji,
  deleteInvite,
  deleteMessage,
  deleteRole,
  deleteTemporaryFile,
  deleteStoredFile,
  deleteChannelPermissions,
  editMessage,
  fetchOidcLoginConfig,
  buildOidcAuthorizationUrl,
  customEmojiReactionName,
  customEmojiReactionValue,
  fetchServerInfo,
  fileUrl,
  getAdminUsers,
  getDirectMessages,
  hideDirectMessage,
  getUserInfo,
  openDirectMessage,
  isDeletedUserPlaceholder,
  getChannelMessages,
  getChannelDetail,
  getChannelPermissions,
  getCategoryDetail,
  getEmojis,
  getServerUpdate,
  getInvites,
  getIpSecurityRules,
  getIpSecurityEvents,
  addIpAllowlist,
  addIpBlock,
  removeIpSecurityRule,
  unblockIp,
  listIncomingWebhooks,
  createIncomingWebhook,
  deleteIncomingWebhook,
  previewRetention,
  runRetentionCleanup,
  getMarketplacePlugins,
  getPlugins,
  getRoles,
  getServerSettings,
  getOwnAppPasswords,
  getOwnStorageFiles,
  getStorageSettings,
  joinVoiceChannel,
  leaveVoiceChannel,
  loginAndJoin,
  loginWithOidcCodeAndJoin,
  moveVoiceUser,
  moderateUser,
  normalizeInviteInput,
  addRoleToUser,
  playDesktopSound,
  playVoiceSoundboard,
  recoverVoiceMedia,
  resolveChannelLink,
  stopUserVoiceMedia,
  removePlugin,
  removeRoleFromUser,
  reorderCategories,
  reorderChannels,
  regenerateOwnRecoveryCodes,
  reactVoice,
  revokeOwnAppPassword,
  saveServerSettings,
  sendChannelMessage,
  signalTyping,
  uploadTemporaryFile,
  subscribeToCoreEvents,
  textFromHtml,
  toggleMessagePin,
  togglePlugin,
  toggleReaction,
  updateCategory,
  updateChannel,
  updateChannelPermissions,
  updateEmoji,
  updatePlugin,
  updateRole,
  setDefaultRole,
  updateServer,
  useSecretToken,
  updateVoiceState,
  installPlugin,
  uploadEmoji,
  type IncomingWebhookSummary,
  type AppPasswordSummary,
  type MfaStatus,
  type TotpSetupResponse,
  type OidcLoginConfig,
  type SharkordIpSecurityRule,
  type SharkordIpSecurityEvent,
  type SharkordConnection
} from './sharkordClient';
import type { ChannelPermissionOverride, ChannelPermissionTarget, DirectMessageConversation, GlobalSearchFileResult, GlobalSearchMessageResult, PluginSlotId, SharkordCategory, SharkordChannel, SharkordEmoji, SharkordFile, SharkordInvite, SharkordMarketplaceEntry, SharkordMessage, SharkordExternalStream, SharkordPluginCommand, SharkordPluginInfo, SharkordPluginLog, SharkordPluginMetadata, SharkordPluginSetting, SharkordPluginSlotRender, SharkordRole, SharkordServerInfo, SharkordServerSettings, SharkordDiskMetrics, SharkordTempFile, SharkordUser, SharkordUserInfo, StreamQualitySetting, UnreadThreadItem, VoiceMap, VoiceProducerEvent, VoiceState, VoiceUser } from './sharkordTypes';
import { applyAudioOutputDevice, refreshMediaDeviceLists, requestMediaDeviceAccess, SharkordVoiceEngine, type AudioDeviceSettings, type RemoteAudioStream, type RemoteVideoStream, type StreamKind } from './voiceEngine';
import { getLocale, installVisiblePhraseTranslator, setLocale, t, tr, translateVisiblePhrases, type Locale } from './i18n';
import sharkordLogo from './assets/sharkord-logo.png';
import { Dialogs } from '@wailsio/runtime';
import * as API from '../bindings/github.com/kanuracer/sharkord-desktop/appservice';
import { appendDiagnosticLog, getDiagnosticLogInfo } from './liveDebug';
import type { AppInfo, GitHubRelease, ReleaseAsset, ServerCredentials } from '../bindings/github.com/kanuracer/sharkord-desktop/models';

type AuthState = { identity: string; password: string; totpCode: string; appPassword: string; serverPassword: string; invite: string };
type AppView = 'chat' | 'settings' | 'dms';
type SettingsTab = 'appearance' | 'updates' | 'audioVideo' | 'notifications' | 'importExport';
type DirectMessageSelection = { serverId: string; channelId: number } | null;
type VisibleMessagesSource = { view: 'chat' | 'dms'; serverId: string; channelId: number } | null;
type DirectMessageEntry = { server: SharkordServer; connection: SharkordConnection; channel: SharkordChannel; user: SharkordUser; conversation: DirectMessageConversation };
type DirectMessageUserSearchResult = { server: SharkordServer; connection: SharkordConnection; user: SharkordUser; existingEntry: DirectMessageEntry | null };
type VoiceReactionState = Record<number, { emoji: string; file?: SharkordFile | null; expiresAt: number }>;
type CommandPaletteItem = { id: string; kind: 'server' | 'text' | 'voice' | 'dm' | 'action'; label: string; detail: string; keywords: string; action: () => void };
type AdminUserInfoState = { userId: number; info: SharkordUserInfo | null; loading: boolean } | null;
type ContextMenuState =
  | { kind: 'channel'; x: number; y: number; channel: SharkordChannel }
  | { kind: 'category'; x: number; y: number; category: SharkordCategory; channelCount: number }
  | { kind: 'user'; x: number; y: number; user: SharkordUser }
  | null;
type ServerDropdownState = { left: number; top: number; width: number } | null;
type UserProfilePopoverState = { x: number; y: number; user: SharkordUser; serverId?: string } | null;
type ThreadPanelState = { parent: SharkordMessage; messages: SharkordMessage[]; status: string; loading: boolean } | null;
type AttachmentLightboxItem = { file: SharkordFile; href: string; label: string; isImage: boolean; mime?: string };
type ServerSessionSnapshot = {
  connection: SharkordConnection | null;
  serverInfo: SharkordServerInfo | null;
  liveUsers: SharkordUser[];
  adminRoles: SharkordRole[];
  liveChannels: SharkordChannel[];
  liveCategories: SharkordCategory[];
  voiceMap: VoiceMap;
  externalStreamsMap: Record<number, Record<number, SharkordExternalStream>>;
  readStates: Record<number, number>;
  typingUsers: Record<number, number[]>;
  messages: SharkordMessage[];
  selectedChannelId: number | null;
  selectedVoiceId: number | null;
  currentVoiceChannelId: number | null;
  voiceState: VoiceState;
  voiceMediaReady: boolean;
  remoteAudioStreams: RemoteAudioStream[];
  remoteVideoStreams: RemoteVideoStream[];
  localAudioStream: MediaStream | null;
  localVideoStream: MediaStream | null;
  localScreenStream: MediaStream | null;
  status: string;
};
type ChannelGroup = { id: number | null; name: string; channels: SharkordChannel[] };
type PluginSlotMap = Record<PluginSlotId, SharkordPluginSlotRender[]>;
type PluginSlotContext = Record<string, unknown>;
type StreamPopupItem = { key: string; label: string; stream: MediaStream; remoteId: number; kind: StreamKind; muted?: boolean; mirror?: boolean; own?: boolean; watched?: boolean };
type AdminRealtimeKind = 'users' | 'roles' | 'emojis' | 'serverSettings' | 'plugins';
type AdminRealtimeEvent = { serverId?: string | null; kind: AdminRealtimeKind; action?: string; payload?: unknown; at: number } | null;
type ChannelPermissionsRealtimeEvent = { serverId?: string | null; channelId?: number | null; payload?: unknown; at: number } | null;
const PLUGIN_SLOT_IDS: PluginSlotId[] = ['topbar', 'chat-actions', 'connect', 'content-wrapper'];
const emptyPluginSlots = (): PluginSlotMap => ({ topbar: [], 'chat-actions': [], connect: [], 'content-wrapper': [] });
const emptyAuth: AuthState = { identity: '', password: '', totpCode: '', appPassword: '', serverPassword: '', invite: '' };
const defaultVoiceState: VoiceState = { micMuted: false, soundMuted: false, webcamEnabled: false, sharingScreen: false };
function normalizeVoiceState(state?: Partial<VoiceState> | null): VoiceState {
  return {
    micMuted: !!state?.micMuted,
    soundMuted: !!state?.soundMuted,
    webcamEnabled: !!state?.webcamEnabled,
    sharingScreen: !!state?.sharingScreen
  };
}
function normalizeVoiceStatePatch(state?: Partial<VoiceState> | null): Partial<VoiceState> {
  const patch: Partial<VoiceState> = {};
  if (!state) return patch;
  if ('micMuted' in state) patch.micMuted = !!state.micMuted;
  if ('soundMuted' in state) patch.soundMuted = !!state.soundMuted;
  if ('webcamEnabled' in state) patch.webcamEnabled = !!state.webcamEnabled;
  if ('sharingScreen' in state) patch.sharingScreen = !!state.sharingScreen;
  return patch;
}
function normalizeVoiceChannelState(channelState?: { users?: Record<number, Partial<VoiceState> | null> } | null): { users: Record<number, VoiceState> } {
  const users = channelState && typeof channelState === 'object' && channelState.users && typeof channelState.users === 'object' ? channelState.users : {};
  return { users: Object.fromEntries(Object.entries(users).map(([userId, state]) => [userId, normalizeVoiceState(state)])) };
}
const defaultAudioDeviceSettings: AudioDeviceSettings = { microphoneId: 'default', playbackId: 'default', webcamId: 'default', echoCancellation: true, noiseSuppression: true, autoGainControl: true, denoiseEnabled: true, voiceIsolationEnabled: true, noiseGate: true, videoResolution: '720p', videoFps: 30, mirrorOwnVideo: false, simulcastEnabled: false, screenResolution: '720p', screenFps: 30, screenCodec: 'auto', screenContentHint: 'motion', screenSourceMode: 'window', screenMaxBitrateMbps: 12, restrictOwnAudio: false, suppressLocalAudioPlayback: false, includeScreenAudio: true, voiceIsolationIntensity: 60, microphoneGain: 1 };
const SPEAKING_THRESHOLD = 8;
const AUDIO_DEVICE_STORAGE_KEY = 'sharkord-desktop:audio-devices:v1';
const SHARKORD_DESKTOP_OIDC_STATE_PREFIX = 'sharkord-desktop:oidc-state:';
type PendingOidcLogin = { serverId: string; serverUrl: string; provider: { id: string; name: string }; redirectUri: string; serverPassword?: string };
function loadAudioDeviceSettings(): AudioDeviceSettings {
  try { return { ...defaultAudioDeviceSettings, ...JSON.parse(localStorage.getItem(AUDIO_DEVICE_STORAGE_KEY) || '{}') }; }
  catch { return defaultAudioDeviceSettings; }
}
function saveAudioDeviceSettings(settings: AudioDeviceSettings) { localStorage.setItem(AUDIO_DEVICE_STORAGE_KEY, JSON.stringify(settings)); }
function ensureAudioSettingStillSelectable(devices: MediaDeviceInfo[], selectedId: string | undefined, missingLabel: string) {
  const options = devices
    .filter((device) => device.deviceId && device.deviceId !== 'default')
    .map((device) => ({ deviceId: device.deviceId, label: device.label || missingLabel }));
  if (selectedId && selectedId !== 'default' && !options.some((device) => device.deviceId === selectedId)) {
    return [{ deviceId: selectedId, label: tr(`${missingLabel} (nicht verbunden)`) }, ...options];
  }
  return options;
}

type VoicePreviewSettings = { showOwnVideoPreview: boolean; showOwnScreenPreview: boolean };
const VOICE_PREVIEW_STORAGE_KEY = 'sharkord-desktop:voice-preview:v1';
const defaultVoicePreviewSettings: VoicePreviewSettings = { showOwnVideoPreview: true, showOwnScreenPreview: true };
function loadVoicePreviewSettings(): VoicePreviewSettings {
  try { return { ...defaultVoicePreviewSettings, ...JSON.parse(localStorage.getItem(VOICE_PREVIEW_STORAGE_KEY) || '{}') }; }
  catch { return defaultVoicePreviewSettings; }
}
function saveVoicePreviewSettings(settings: VoicePreviewSettings) { localStorage.setItem(VOICE_PREVIEW_STORAGE_KEY, JSON.stringify(settings)); }

type StreamAudioMuteSettings = Record<string, boolean | undefined>;
type UserVolumeSettings = Record<string, number>;
const STREAM_AUDIO_MUTE_STORAGE_KEY = 'sharkord-desktop:stream-audio-muted:v1';
const USER_VOLUME_STORAGE_KEY = 'sharkord-desktop:user-volume:v1';
function streamAudioMuteKey(serverId: string, remoteId: number) { return `${serverId}:${remoteId}`; }
function userVolumeKey(serverId: string, remoteId: number) { return `${serverId}:${remoteId}`; }
function clampUserVolume(value: number) { return Math.max(0, Math.min(200, Math.round(value))); }
function clampMediaElementVolume(value: number) {
  const userVolume = Number.isFinite(value) ? clampUserVolume(value) : 100;
  return Math.max(0, Math.min(1, userVolume / 100));
}
function isStreamAudioKind(kind: StreamKind) { return kind === 'screen_audio' || kind === 'external_audio'; }
function isStreamAudioMuted(settings: StreamAudioMuteSettings, serverId: string, remoteId: number) { return settings[streamAudioMuteKey(serverId, remoteId)] !== false; }
function loadStreamAudioMuteSettings(): StreamAudioMuteSettings {
  try { return JSON.parse(localStorage.getItem(STREAM_AUDIO_MUTE_STORAGE_KEY) || '{}') as StreamAudioMuteSettings; }
  catch { return {}; }
}
function saveStreamAudioMuteSettings(settings: StreamAudioMuteSettings) { localStorage.setItem(STREAM_AUDIO_MUTE_STORAGE_KEY, JSON.stringify(settings)); }
function loadUserVolumeSettings(): UserVolumeSettings {
  try {
    const parsed = JSON.parse(localStorage.getItem(USER_VOLUME_STORAGE_KEY) || '{}') as UserVolumeSettings;
    return Object.fromEntries(Object.entries(parsed).filter(([, value]) => Number.isFinite(value)).map(([key, value]) => [key, clampUserVolume(value)]));
  } catch { return {}; }
}
function saveUserVolumeSettings(settings: UserVolumeSettings) { localStorage.setItem(USER_VOLUME_STORAGE_KEY, JSON.stringify(settings)); }

const RECENT_EMOJIS_STORAGE_KEY = 'sharkord-desktop:recent-emojis:v1';
const NOTIFICATION_SETTINGS_STORAGE_KEY = 'sharkord-desktop:notifications:v1';
const WELCOME_PROFILE_SETUP_STORAGE_KEY = 'sharkord-desktop:welcome-profile-setup:v1';
type NotificationSettings = { allMessages: boolean; mentions: boolean; dms: boolean; replies: boolean; notificationSounds: boolean };
const defaultNotificationSettings: NotificationSettings = { allMessages: false, mentions: true, dms: true, replies: true, notificationSounds: true };
type NotificationCenterKind = 'message' | 'mention' | 'reply' | 'dm';
type NotificationCenterItem = { id: string; kind: NotificationCenterKind; serverId: string; serverName: string; channelId: number; channelName: string; messageId: number; authorId: number; authorName: string; body: string; createdAt: number; read: boolean };
type AdminConfirmAction =
  | { kind: 'moderate-user'; user: SharkordUser; action: 'kick' | 'ban' | 'unban' | 'delete'; reason: string; wipe: boolean }
  | { kind: 'disconnect-voice-user'; user: SharkordUser };
type RoleAction =
  | { kind: 'edit'; role: SharkordRole; name: string; color: string }
  | { kind: 'delete'; role: SharkordRole };
type AppUiSettings = { compactMode: boolean; fontSize: number; reducedMotion: boolean; highContrast: boolean; diagnosticLoggingEnabled: boolean };
const NOTIFICATION_CENTER_STORAGE_KEY = 'sharkord-desktop:notification-center:v1';
const APP_UI_SETTINGS_STORAGE_KEY = 'sharkord-desktop:ui-settings:v1';
const defaultAppUiSettings: AppUiSettings = { compactMode: false, fontSize: 100, reducedMotion: false, highContrast: false, diagnosticLoggingEnabled: false };
function loadRecentEmojis(): string[] { try { const parsed = JSON.parse(localStorage.getItem(RECENT_EMOJIS_STORAGE_KEY) || '[]'); return Array.isArray(parsed) ? parsed.filter((item) => typeof item === 'string').slice(0, 32) : []; } catch { return []; } }
function saveRecentEmojis(emojis: string[]) { localStorage.setItem('sharkord-desktop:recent-emojis:v1', JSON.stringify(emojis.slice(0, 32))); }
function loadNotificationSettings(): NotificationSettings { try { return { ...defaultNotificationSettings, ...JSON.parse(localStorage.getItem(NOTIFICATION_SETTINGS_STORAGE_KEY) || '{}') }; } catch { return defaultNotificationSettings; } }
function saveNotificationSettings(settings: NotificationSettings) { localStorage.setItem(NOTIFICATION_SETTINGS_STORAGE_KEY, JSON.stringify(settings)); }
function loadNotificationCenterItems(): NotificationCenterItem[] { try { const parsed = JSON.parse(localStorage.getItem(NOTIFICATION_CENTER_STORAGE_KEY) || '[]'); return Array.isArray(parsed) ? parsed.flatMap(normalizeNotificationCenterItem).slice(0, 32) : []; } catch { return []; } }
function saveNotificationCenterItems(items: NotificationCenterItem[]) { localStorage.setItem(NOTIFICATION_CENTER_STORAGE_KEY, JSON.stringify(items.slice(0, 32))); }
function normalizeNotificationCenterItem(input: unknown): NotificationCenterItem[] {
  if (!input || typeof input !== 'object') return [];
  const item = input as Partial<NotificationCenterItem>;
  const messageId = Number(item.messageId);
  const channelId = Number(item.channelId);
  if (!Number.isFinite(messageId) || !Number.isFinite(channelId)) return [];
  return [{
    id: String(item.id || `${item.serverId || 'server'}:${channelId}:${messageId}`),
    kind: ['mention', 'reply', 'dm'].includes(String(item.kind)) ? item.kind as NotificationCenterKind : 'message',
    serverId: String(item.serverId || ''),
    serverName: String(item.serverName || ''),
    channelId,
    channelName: String(item.channelName || `#${channelId}`),
    messageId,
    authorId: Number(item.authorId) || 0,
    authorName: String(item.authorName || tr('Unbekannt')),
    body: String(item.body || '').slice(0, 500),
    createdAt: Number(item.createdAt) || Date.now(),
    read: !!item.read
  }];
}
function clampAppFontSize(value: unknown): number { const next = Number(value); return Number.isFinite(next) ? Math.max(85, Math.min(125, Math.round(next))) : defaultAppUiSettings.fontSize; }
function loadAppUiSettings(): AppUiSettings { try { const parsed = JSON.parse(localStorage.getItem(APP_UI_SETTINGS_STORAGE_KEY) || '{}') as Partial<AppUiSettings>; return { compactMode: !!parsed.compactMode, fontSize: clampAppFontSize(parsed.fontSize), reducedMotion: !!parsed.reducedMotion, highContrast: !!parsed.highContrast, diagnosticLoggingEnabled: !!parsed.diagnosticLoggingEnabled }; } catch { return defaultAppUiSettings; } }
function saveAppUiSettings(settings: AppUiSettings) { localStorage.setItem(APP_UI_SETTINGS_STORAGE_KEY, JSON.stringify({ ...settings, fontSize: clampAppFontSize(settings.fontSize) })); }

function welcomeProfileSetupStorageKey(connection: SharkordConnection) {
  return `${WELCOME_PROFILE_SETUP_STORAGE_KEY}:${connection.join.serverId}:${connection.join.ownUserId}`;
}
function shouldShowWelcomeProfileSetup(connection: SharkordConnection) {
  try { return !!connection.join.showWelcomeDialog && localStorage.getItem(welcomeProfileSetupStorageKey(connection)) !== 'done'; }
  catch { return !!connection.join.showWelcomeDialog; }
}
function markWelcomeProfileSetupDone(connection: SharkordConnection) {
  try { localStorage.setItem(welcomeProfileSetupStorageKey(connection), 'done'); }
  catch { /* noop */ }
}


const semverGreater = (a = '', b = '') => {
  const A = a.replace(/^v/, '').split('.').map(Number); const B = b.replace(/^v/, '').split('.').map(Number);
  for (let i = 0; i < 3; i += 1) { const delta = (A[i] || 0) - (B[i] || 0); if (delta) return delta > 0; }
  return false;
};
const formatBytes = (n = 0) => n > 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : n > 1024 ? `${(n / 1024).toFixed(1)} KB` : `${n} B`;
function pluginCommandLabel(command: SharkordPluginCommand) {
  return command.pluginId ? `${command.pluginId}:${command.name}` : command.name;
}
function coercePluginCommandArg(value: string, type?: string) {
  if (type === 'number') {
    const n = Number(value);
    return Number.isFinite(n) ? n : value;
  }
  if (type === 'boolean') return ['1', 'true', 'yes', 'ja', 'on'].includes(value.toLowerCase());
  return value;
}
function formatStorageSize(bytes?: number | null) {
  const value = Number(bytes ?? 0);
  if (!Number.isFinite(value) || value <= 0) return '0 B';
  if (value >= BYTES_PER_GB) return `${(value / BYTES_PER_GB).toFixed(1)} GB`;
  if (value >= 1024 * 1024) return `${(value / 1024 / 1024).toFixed(1)} MB`;
  if (value >= 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${Math.round(value)} B`;
}
function attachmentLabel(file: SharkordFile) {
  return file.originalName || file.name || `${tr('Datei')} ${file.id}`;
}
function attachmentMime(file: SharkordFile) {
  return file.mimeType || file.type || '';
}
function isImageAttachment(file: SharkordFile, label = attachmentLabel(file)) {
  const mime = attachmentMime(file);
  return mime.startsWith('image/') || /\.(png|jpe?g|gif|webp|avif|bmp|svg)$/i.test(label);
}
async function copyAttachmentUrl(href: string) {
  if (!href) return;
  await navigator.clipboard.writeText(href);
}
const BYTES_PER_GB = 1024 * 1024 * 1024;
function bytesToGbValue(bytes?: number | null) {
  if (!bytes) return 0;
  const gb = bytes / BYTES_PER_GB;
  return Number.isInteger(gb) ? gb : Number(gb.toFixed(3));
}
function gbInputToBytes(value: string) {
  const gb = Number(value);
  if (!Number.isFinite(gb) || gb <= 0) return 0;
  return Math.round(gb * BYTES_PER_GB);
}
const channelType = (channel: SharkordChannel) => String(channel.type).trim().toUpperCase();

const SERVER_PERMISSION_OPTIONS = [
  'SEND_MESSAGES', 'REACT_TO_MESSAGES', 'PIN_MESSAGES', 'UPLOAD_FILES', 'JOIN_VOICE_CHANNELS', 'SHARE_SCREEN', 'ENABLE_WEBCAM', 'MOVE_MEMBERS',
  'MANAGE_CHANNELS', 'MANAGE_CHANNEL_PERMISSIONS', 'MANAGE_CATEGORIES', 'MANAGE_ROLES', 'MANAGE_EMOJIS', 'MANAGE_SETTINGS',
  'MANAGE_USERS', 'MANAGE_MESSAGES', 'MANAGE_STORAGE', 'MANAGE_INVITES', 'MANAGE_UPDATES', 'MANAGE_PLUGINS', 'USE_PLUGINS', 'VIEW_USER_SENSITIVE_DATA'
];
type PermissionCopy = { label: string; description: string };
const SERVER_PERMISSION_COPY: Record<string, PermissionCopy> = {
  SEND_MESSAGES: { label: tr('Nachrichten senden'), description: tr('Textnachrichten in erlaubten Channels schreiben.') },
  REACT_TO_MESSAGES: { label: tr('Reaktionen hinzufügen'), description: tr('Mit Emojis auf Nachrichten reagieren.') },
  PIN_MESSAGES: { label: tr('Nachrichten anpinnen'), description: tr('Wichtige Nachrichten im Channel anheften.') },
  UPLOAD_FILES: { label: tr('Dateien hochladen'), description: tr('Anhänge, Bilder und Medien teilen.') },
  JOIN_VOICE_CHANNELS: { label: tr('Voice beitreten'), description: tr('Sprachkanäle betreten und hören.') },
  SHARE_SCREEN: { label: tr('Bildschirm teilen'), description: tr('Screenshare in Voice-Channels starten.') },
  ENABLE_WEBCAM: { label: tr('Kamera aktivieren'), description: tr('Webcam-Video in Voice-Channels senden.') },
  MOVE_MEMBERS: { label: tr('Mitglieder verschieben'), description: tr('Benutzer zwischen Voice-Channels bewegen.') },
  MANAGE_CHANNELS: { label: tr('Channels verwalten'), description: tr('Channels erstellen, umbenennen und löschen.') },
  MANAGE_CHANNEL_PERMISSIONS: { label: tr('Channel-Berechtigungen'), description: tr('Berechtigungs-Overrides für Rollen und Benutzer ändern.') },
  MANAGE_CATEGORIES: { label: tr('Kategorien verwalten'), description: tr('Channel-Kategorien erstellen, sortieren und löschen.') },
  MANAGE_ROLES: { label: tr('Rollen verwalten'), description: tr('Rollen erstellen, ändern und zuweisen.') },
  MANAGE_EMOJIS: { label: tr('Emojis verwalten'), description: tr('Server-Emojis hochladen, umbenennen und entfernen.') },
  MANAGE_SETTINGS: { label: tr('Server-Einstellungen'), description: tr('Server-Konfiguration und Admin-Optionen ändern.') },
  MANAGE_USERS: { label: tr('Mitglieder verwalten'), description: tr('Benutzer moderieren, kicken, bannen oder löschen.') },
  MANAGE_MESSAGES: { label: tr('Nachrichten moderieren'), description: tr('Nachrichten löschen und Moderationsaktionen ausführen.') },
  MANAGE_STORAGE: { label: tr('Speicher verwalten'), description: tr('Dateien, Quotas und Storage-Cleanup verwalten.') },
  MANAGE_INVITES: { label: tr('Invites verwalten'), description: tr('Einladungen erstellen, kopieren und widerrufen.') },
  MANAGE_UPDATES: { label: tr('Updates verwalten'), description: tr('Server-Updates prüfen und starten.') },
  MANAGE_PLUGINS: { label: tr('Plugins verwalten'), description: tr('Plugins installieren, konfigurieren und entfernen.') },
  USE_PLUGINS: { label: tr('Plugins nutzen'), description: tr('Plugin-Befehle und Plugin-Actions ausführen.') },
  VIEW_USER_SENSITIVE_DATA: { label: tr('Sensible Benutzerdaten ansehen'), description: tr('Admin-Details wie Logins, Dateien und Speicher einsehen.') }
};
function permissionCopy(permission: string): PermissionCopy {
  return SERVER_PERMISSION_COPY[permission] ?? { label: permission.split('_').map((part) => part.charAt(0) + part.slice(1).toLowerCase()).join(' '), description: tr('Server-Berechtigung') };
}
const CHANNEL_PERMISSION_OPTIONS = [
  'SEND_MESSAGES', 'REACT_TO_MESSAGES', 'PIN_MESSAGES', 'UPLOAD_FILES', 'MANAGE_MESSAGES', 'JOIN_VOICE_CHANNELS', 'SHARE_SCREEN',
  'ENABLE_WEBCAM', 'MOVE_MEMBERS', 'MANAGE_CHANNELS', 'MANAGE_CHANNEL_PERMISSIONS'
];
type PermissionOverrideTarget = { targetType: ChannelPermissionTarget; targetId: number; label: string; color?: string; isDefault?: boolean };
type ChannelSettingsTab = 'general' | 'permissions';
type PermissionState = 'inherit' | 'allow' | 'deny';
function overrideKey(targetType: ChannelPermissionTarget, targetId: number) { return `${targetType}:${targetId}`; }
function permissionStateFor(permission: string, allow: string[], deny: string[]): PermissionState {
  if (allow.includes(permission)) return 'allow';
  if (deny.includes(permission)) return 'deny';
  return 'inherit';
}
function setPermissionState(allow: string[], deny: string[], permission: string, state: PermissionState) {
  const nextAllow = new Set(allow);
  const nextDeny = new Set(deny);
  nextAllow.delete(permission);
  nextDeny.delete(permission);
  if (state === 'allow') nextAllow.add(permission);
  if (state === 'deny') nextDeny.add(permission);
  return { allow: [...nextAllow], deny: [...nextDeny] };
}
function userHasChannelPermissionGuard(user: SharkordUser | null | undefined, roles: SharkordRole[]) {
  return userHasServerPermission(user, roles, ['MANAGE_CHANNEL_PERMISSIONS', 'MANAGE_CHANNELS', 'ADMINISTRATOR']);
}
function channelPermissionTargets(roles: SharkordRole[], users: SharkordUser[]): PermissionOverrideTarget[] {
  const roleTargets = roles.map((role) => ({ targetType: 'role' as const, targetId: role.id, label: role.isDefault ? `${role.name} (${tr('Default')})` : role.name, color: role.color, isDefault: !!role.isDefault }));
  const userTargets = users.filter((user) => !isDeletedUserPlaceholder(user)).map((user) => ({ targetType: 'user' as const, targetId: user.id, label: displayUserName(user) }));
  return [...roleTargets, ...userTargets];
}
function normalisePermissionOverrides(raw: ChannelPermissionOverride[] | { overrides?: ChannelPermissionOverride[] }): ChannelPermissionOverride[] {
  return Array.isArray(raw) ? raw : raw.overrides ?? [];
}
function ttlSecondsToMinutesValue(seconds?: number | null) {
  if (!seconds) return 0;
  const minutes = seconds / 60;
  return Number.isInteger(minutes) ? minutes : Number(minutes.toFixed(2));
}
function minutesInputToTtlSeconds(value: string) {
  const minutes = Number(value);
  if (!Number.isFinite(minutes) || minutes <= 0) return 0;
  return Math.round(minutes * 60);
}
function formatShortDate(value?: number | null) {
  if (!value) return tr('nie');
  return new Date(value).toLocaleDateString(getLocale() === 'en' ? 'en-US' : 'de-DE');
}
function pluginVersion(entry: SharkordMarketplaceEntry) {
  return entry.versions?.[0]?.version ?? 'latest';
}
const isTextChannel = (channel: SharkordChannel) => channelType(channel) === 'TEXT' && !channel.isDm;
const isVoiceChannel = (channel: SharkordChannel) => channelType(channel) === 'VOICE' && !channel.isDm;
function userHasServerPermission(user: SharkordUser | null | undefined, roles: SharkordRole[], permissions: string[]) {
  const roleIds = new Set(user?.roleIds ?? []);
  return roles.some((role) => (role.isDefault || roleIds.has(role.id)) && (role.permissions ?? []).some((permission) => permissions.includes(permission)));
}
const byPosition = (a: SharkordChannel, b: SharkordChannel) => (a.position ?? 0) - (b.position ?? 0) || a.id - b.id;
const avatarInitial = (name = '') => (name.trim()[0] || '?').toUpperCase();
const LEGACY_PLACEHOLDER_HOSTS = ['example.tld'];

function stripPlaceholderServers(input: StoredState = defaultState): StoredState {
  const servers = (input.servers ?? []).filter((server) => !LEGACY_PLACEHOLDER_HOSTS.some((host) => String(server.url || '').includes(host)));
  const activeServerId = servers.some((server) => server.id === input.activeServerId) ? input.activeServerId : (servers[0]?.id ?? null);
  return { theme: input.theme === 'light' ? 'light' : 'dark', servers, activeServerId, releaseChannel: normalizeReleaseChannel(input.releaseChannel) };
}

function hasUsableServers(input?: StoredState | null) {
  return stripPlaceholderServers(input ?? defaultState).servers.length > 0;
}

function resolveStartupState(nativeState: StoredState | null | undefined, localState: StoredState): StoredState {
  const nativeClean = stripPlaceholderServers(nativeState ?? defaultState);
  if (nativeClean.servers.length) return nativeClean;
  const localClean = stripPlaceholderServers(localState);
  if (localClean.servers.length) return localClean;
  return { ...defaultState, theme: nativeClean.theme === 'light' || localClean.theme === 'light' ? 'light' : 'dark', releaseChannel: nativeClean.releaseChannel ?? localClean.releaseChannel ?? 'stable' };
}

function inviteCodeFromLocation(location: Location) {
  const params = new URLSearchParams(location.search);
  return normalizeInviteInput(params.get('invite') || params.get('code') || '');
}

function splitServerUrlAndInvite(raw: string) {
  const trimmed = raw.trim();
  if (!trimmed) return { serverUrl: '', invite: '' };
  // Supported examples: sharkord://invite/INVITE-CODE, https://chat.example.tld/?invite=INVITE-CODE, https://chat.example.tld/invite/INVITE-CODE
  const withProtocol = /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  try {
    const parsed = new URL(withProtocol);
    const invite = normalizeInviteInput(trimmed);
    if (parsed.protocol === 'sharkord:') return { serverUrl: '', invite };
    parsed.hash = '';
    parsed.searchParams.delete('invite');
    parsed.searchParams.delete('code');
    const parts = parsed.pathname.split('/').filter(Boolean);
    const inviteIndex = parts.findIndex((part) => ['invite', 'invites', 'join'].includes(part.toLowerCase()));
    if (inviteIndex >= 0) parsed.pathname = `/${parts.slice(0, inviteIndex).join('/')}`;
    const serverUrl = parsed.toString().replace(/\/$/, '');
    return { serverUrl, invite };
  } catch {
    return { serverUrl: trimmed, invite: normalizeInviteInput(trimmed) };
  }
}


type SettingsExportFile = {
  kind: 'sharkord-desktop-settings-export';
  schemaVersion: 1;
  exportedAt: string;
  appVersion: string;
  state: StoredState;
  audioSettings: AudioDeviceSettings;
  streamAudioMuted: StreamAudioMuteSettings;
  includesUserData?: boolean;
  credentialsByServerId?: Record<string, ServerCredentials>;
};

function normalizeImportedState(raw: unknown): StoredState {
  const input = (raw && typeof raw === 'object' ? raw : {}) as Partial<StoredState>;
  const servers = Array.isArray(input.servers) ? input.servers.flatMap((server) => {
    if (!server || typeof server !== 'object') return [];
    const candidate = server as Partial<SharkordServer>;
    const id = String(candidate.id ?? '').trim();
    const name = String(candidate.name ?? '').trim();
    const url = String(candidate.url ?? '').trim();
    if (!id || !url) return [];
    try { new URL(url); }
    catch { return []; }
    return [{
      id,
      name: name || new URL(url).hostname,
      url: url.replace(/\/$/, ''),
      color: String(candidate.color || '#5865f2'),
      lastOpenedAt: Number(candidate.lastOpenedAt) || Date.now(),
      autoConnect: !!candidate.autoConnect,
      logo: candidate.logo ?? null
    } satisfies SharkordServer];
  }) : [];
  const activeServerId = servers.some((server) => server.id === input.activeServerId) ? input.activeServerId ?? null : (servers[0]?.id ?? null);
  return stripPlaceholderServers({ theme: input.theme === 'light' ? 'light' : 'dark', activeServerId, servers, releaseChannel: normalizeReleaseChannel(input.releaseChannel), allowEmptyServers: servers.length === 0 });
}

function createSettingsExport({ state, audioSettings, streamAudioMuted, appVersion }: { state: StoredState; audioSettings: AudioDeviceSettings; streamAudioMuted: StreamAudioMuteSettings; appVersion: string }): SettingsExportFile {
  return {
    kind: 'sharkord-desktop-settings-export',
    schemaVersion: 1,
    exportedAt: new Date().toISOString(),
    appVersion,
    state: stripPlaceholderServers(state),
    audioSettings: { ...defaultAudioDeviceSettings, ...audioSettings },
    streamAudioMuted: { ...streamAudioMuted }
  };
}

async function saveSettingsExportFile(filename: string): Promise<string> {
  return Dialogs.SaveFile({
    Title: tr('Sharkord Einstellungen exportieren'),
    Filename: filename,
    ButtonText: tr('Exportieren'),
    CanCreateDirectories: true,
    Detached: false,
    Filters: [{ DisplayName: tr('JSON-Dateien'), Pattern: '*.json' }]
  });
}

async function openSettingsImportFile(): Promise<string> {
  const selected = await Dialogs.OpenFile({
    Title: tr('Sharkord Einstellungen importieren'),
    ButtonText: tr('Importieren'),
    CanChooseFiles: true,
    CanChooseDirectories: false,
    AllowsMultipleSelection: false,
    Detached: false,
    Filters: [{ DisplayName: tr('JSON-Dateien'), Pattern: '*.json' }]
  });
  return Array.isArray(selected) ? (selected[0] ?? '') : selected;
}

async function confirmSettingsImport(message: string, title = tr('Import bestätigen'), confirmLabel = tr('Importieren')): Promise<boolean> {
  const answer = await Dialogs.Question({
    Title: title,
    Message: message,
    Buttons: [
      { Label: confirmLabel, IsDefault: true },
      { Label: tr('Abbrechen'), IsCancel: true }
    ],
    Detached: false
  });
  return answer === confirmLabel;
}

function parseSettingsImport(raw: string): SettingsExportFile {
  let parsed: unknown;
  try { parsed = JSON.parse(raw); }
  catch { throw new Error(tr('Ungültige Import-Datei: JSON konnte nicht gelesen werden')); }
  if (!parsed || typeof parsed !== 'object') throw new Error(tr('Ungültige Import-Datei'));
  const candidate = parsed as Partial<SettingsExportFile>;
  if (candidate.kind !== 'sharkord-desktop-settings-export' || candidate.schemaVersion !== 1) throw new Error(tr('Ungültige Import-Datei: falscher Typ oder Version'));
  return {
    kind: 'sharkord-desktop-settings-export',
    schemaVersion: 1,
    exportedAt: String(candidate.exportedAt || ''),
    appVersion: String(candidate.appVersion || tr('unbekannt')),
    state: normalizeImportedState(candidate.state),
    audioSettings: { ...defaultAudioDeviceSettings, ...(candidate.audioSettings && typeof candidate.audioSettings === 'object' ? candidate.audioSettings : {}) },
    streamAudioMuted: candidate.streamAudioMuted && typeof candidate.streamAudioMuted === 'object' ? candidate.streamAudioMuted as StreamAudioMuteSettings : {},
    includesUserData: !!candidate.includesUserData,
    credentialsByServerId: candidate.credentialsByServerId && typeof candidate.credentialsByServerId === 'object' ? candidate.credentialsByServerId as Record<string, ServerCredentials> : {}
  };
}

function compatibleAsset(info: AppInfo | null, release: GitHubRelease | null): ReleaseAsset | null {
  const assets = release?.assets ?? [];
  if (!info) return assets[0] ?? null;
  const platform = info.platform;
  const arch = info.arch || 'amd64';
  if (platform === 'windows') return assets.find((asset) => asset.name.includes('windows') && asset.name.endsWith('.exe')) ?? null;
  if (platform === 'linux') return assets.find((asset) => asset.name.includes(`linux-${arch}`) && asset.name.endsWith('.tar.gz')) ?? assets.find((asset) => asset.name.includes('linux') && asset.name.endsWith('.tar.gz')) ?? null;
  if (platform === 'darwin') return assets.find((asset) => asset.name.includes(`darwin-${arch}`) && asset.name.endsWith('.zip')) ?? assets.find((asset) => asset.name.includes('darwin') && asset.name.endsWith('.zip')) ?? null;
  return null;
}

function resolutionToSize(resolution: AudioDeviceSettings['videoResolution']) {
  if (resolution === '480p') return { width: 854, height: 480 };
  if (resolution === '1080p') return { width: 1920, height: 1080 };
  if (resolution === '1440p') return { width: 2560, height: 1440 };
  if (resolution === '2160p') return { width: 3840, height: 2160 };
  return { width: 1280, height: 720 };
}



function parseStreamPopoutRoute() {
  const params = new URLSearchParams(window.location.search);
  if (params.get('streamPopout') !== '1') return null;
  return params.get('streamPopoutId') || '';
}

function StreamPopoutViewer({ configId }: { configId: string }) {
  const [title, setTitle] = useState('Sharkord Stream');
  const [status, setStatus] = useState(() => tr('Stream-Fenster wird verbunden…'));
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [streamAudio, setStreamAudio] = useState<MediaStream | null>(null);
  useEffect(() => {
    let disposed = false;
    let connection: SharkordConnection | null = null;
    let engine: SharkordVoiceEngine | null = null;
    let unsubscribe: (() => void) | null = null;
    const run = async () => {
      try {
        const config = await API.GetStreamPopoutConfig(configId);
        if (disposed) return;
        setTitle(config.title || 'Sharkord Stream');
        document.title = config.title || 'Sharkord Stream';
        const creds = await API.LoadServerCredentials(config.serverId);
        const auth = credsToAuth(creds);
        if (!auth.identity || !auth.password) throw new Error(tr('Gespeicherte Server-Anmeldedaten fehlen'));
        connection = await loginAndJoin({ serverUrl: config.serverUrl, ...auth });
        if (disposed) return;
        const joinResult = await joinVoiceChannel(connection, config.channelId, { micMuted: true, soundMuted: false, webcamEnabled: false, sharingScreen: false }) as { routerRtpCapabilities?: unknown };
        if (disposed) return;
        const targetKind = config.kind as StreamKind;
        const targetAudioKind: StreamKind = targetKind === 'external_video' ? 'external_audio' : 'screen_audio';
        engine = new SharkordVoiceEngine(connection, defaultAudioDeviceSettings, {
          onRemoteAudioStreams: (streams) => {
            const audio = streams.find((item) => item.remoteId === config.remoteId && item.kind === targetAudioKind);
            setStreamAudio(audio?.stream ?? null);
          },
          onRemoteVideoStreams: (streams) => {
            const match = streams.find((item) => item.remoteId === config.remoteId && item.kind === targetKind);
            setStream(match?.stream ?? null);
            if (match?.stream) setStatus(tr('Stream verbunden'));
          },
          onLocalAudioStream: () => undefined,
          onLocalVideoStream: () => undefined,
          onLocalScreenStream: () => undefined,
          onStatus: setStatus
        });
        const routerRtpCapabilities = joinResult.routerRtpCapabilities ?? JSON.parse(config.routerRtpCapabilities);
        await engine.initConsumerOnly(routerRtpCapabilities as never);
        unsubscribe = subscribeToCoreEvents(connection, {
          onVoiceNewProducer: (event) => {
            const eventKind = String(event.kind).toLowerCase() as StreamKind;
            if (event.channelId === config.channelId && event.remoteId === config.remoteId && (eventKind === targetKind || eventKind === targetAudioKind)) {
              setStatus(tr('Stream neu gestartet · verbinde…'));
              void engine?.consumeProducer(config.remoteId, eventKind).catch((err) => setStatus(tr(`Stream neu verbinden: ${cleanError(err)}`)));
            }
          },
          onVoiceProducerClosed: (event) => {
            const eventKind = String(event.kind).toLowerCase() as StreamKind;
            if (event.channelId === config.channelId && event.remoteId === config.remoteId && (eventKind === targetKind || eventKind === targetAudioKind)) {
              engine?.removeRemoteProducer(config.remoteId, eventKind);
              if (eventKind === targetKind) { setStream(null); setStatus(tr('Stream beendet')); }
              if (eventKind === targetAudioKind) setStreamAudio(null);
            }
          },
          onError: (label, err) => setStatus(tr(`${label}: ${cleanError(err)}`))
        });
        setStatus(tr('Stream-Producer werden gesucht…'));
        await engine.refreshExistingProducers();
        await engine.consumeProducer(config.remoteId, targetKind);
        await engine.consumeProducer(config.remoteId, targetAudioKind).catch(() => undefined);
      } catch (err) {
        if (!disposed) setStatus(tr(`Stream-Popout: ${cleanError(err)}`));
      }
    };
    void run();
    return () => {
      disposed = true;
      unsubscribe?.();
      engine?.close();
      connection?.close();
    };
  }, [configId]);
  const closePopout = () => { void API.CloseStreamPopoutWindow(configId).finally(() => window.close()); };
  return <main className="nativeStreamPopout"><header><strong>{title}</strong><button type="button" onClick={closePopout} aria-label={tr('Popout schließen')}>×</button></header><section className="nativeStreamPopoutGrid singleStream">{stream ? <><VideoTile label={title} stream={stream} muted={false} screen={true} />{streamAudio ? <InlineAudioStream stream={streamAudio} /> : null}</> : <div className="streamPopoutWaiting"><Monitor size={36} /><strong>{status}</strong><span>{tr('Das Fenster konsumiert den Stream eigenständig.')}</span></div>}</section></main>;
}


function isKanuracerForkServerInfo(serverInfo?: SharkordServerInfo | null): boolean {
  const markers = [serverInfo?.version, serverInfo?.name, serverInfo?.description, serverInfo?.serverId];
  return markers.some((value) => /kanuracer|-kr\./i.test(String(value ?? '')));
}

function supportsKanuracerAccountSecurity(connection: SharkordConnection, serverInfo?: SharkordServerInfo | null): boolean {
  return connection.serverCapabilities.mfaAppPasswords
    || connection.serverCapabilities.flavor === 'kanuracer'
    || isKanuracerForkServerInfo(serverInfo);
}

function diagnosticElementSummary(element: Element, index: number) {
  const rect = element.getBoundingClientRect();
  const style = window.getComputedStyle(element);
  return {
    index,
    tag: element.tagName.toLowerCase(),
    id: element.id || '',
    className: typeof element.className === 'string' ? element.className : '',
    role: element.getAttribute('role') || '',
    ariaModal: element.getAttribute('aria-modal') || '',
    ariaLabel: element.getAttribute('aria-label') || '',
    pointerEvents: style.pointerEvents,
    position: style.position,
    zIndex: style.zIndex,
    display: style.display,
    visibility: style.visibility,
    opacity: style.opacity,
    rect: {
      x: Math.round(rect.x),
      y: Math.round(rect.y),
      width: Math.round(rect.width),
      height: Math.round(rect.height)
    }
  };
}

function collectVoiceUiDomDiagnostics() {
  const centerX = Math.max(0, Math.floor(window.innerWidth / 2));
  const centerY = Math.max(0, Math.floor(window.innerHeight / 2));
  const overlaySelectors = [
    '.modalBackdrop',
    '.attachmentLightboxBackdrop',
    '.userProfilePopoverBackdrop',
    '.commandPaletteBackdrop',
    '.twoFactorBackdrop',
    '.globalSearchBackdrop',
    '.welcomeProfileBackdrop',
    '.ownProfileBackdrop',
    '.adminWorkbenchBackdrop',
    '.adminUserInfoBackdrop',
    '.channelSettingsBackdrop',
    '.serverDropdown',
    '.contextMenu',
    '.adminContextMenu',
    '.notificationCenter',
    '.startupUpdateNotice'
  ];
  const visibleOverlays = overlaySelectors.flatMap((selector) => Array.from(document.querySelectorAll(selector)).map((element, index) => ({ selector, ...diagnosticElementSummary(element, index) })))
    .filter((item) => item.display !== 'none' && item.visibility !== 'hidden' && item.rect.width > 0 && item.rect.height > 0);
  const centerStack = document.elementsFromPoint(centerX, centerY).slice(0, 16).map(diagnosticElementSummary);
  const active = document.activeElement ? diagnosticElementSummary(document.activeElement, 0) : null;
  return {
    viewport: { width: window.innerWidth, height: window.innerHeight, centerX, centerY },
    documentClassName: document.documentElement.className,
    bodyClassName: document.body.className,
    activeElement: active,
    visibleOverlays,
    centerStack
  };
}

export default function App() {
  const streamPopoutId = parseStreamPopoutRoute();
  if (streamPopoutId !== null) return <StreamPopoutViewer configId={streamPopoutId} />;
  useEffect(() => installVisiblePhraseTranslator(), []);
  const [state, setState] = useState<StoredState>(() => defaultState);
  const startupInviteCode = inviteCodeFromLocation(window.location);
  const [nativeStateLoaded, setNativeStateLoaded] = useState(false);
  const [activeView, setActiveView] = useState<AppView>('chat');
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [commandPaletteQuery, setCommandPaletteQuery] = useState('');
  const [settingsInitialTab, setSettingsInitialTab] = useState<SettingsTab>('appearance');
  const [contextMenu, setContextMenu] = useState<ContextMenuState>(null);
  const [serverDropdown, setServerDropdown] = useState<ServerDropdownState>(null);
  const [userProfilePopover, setUserProfilePopover] = useState<UserProfilePopoverState>(null);
  const [actionStatus, setActionStatus] = useState(tr('Bereit'));
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [autoConnectChecked, setAutoConnectChecked] = useState(true);
  const [newCreds, setNewCreds] = useState<AuthState>(emptyAuth);
  const [error, setError] = useState('');
  const [auth, setAuth] = useState<AuthState>(emptyAuth);
  const [pendingTotpAuth, setPendingTotpAuth] = useState<AuthState | null>(null);
  const [totpCodeInput, setTotpCodeInput] = useState('');
  const [totpError, setTotpError] = useState('');
  const [serverInfo, setServerInfo] = useState<SharkordServerInfo | null>(null);
  const [oidcConfig, setOidcConfig] = useState<OidcLoginConfig>({ enabled: false, providers: [] });
  const [connection, setConnection] = useState<SharkordConnection | null>(null);
  const [pluginSlots, setPluginSlots] = useState<PluginSlotMap>(() => emptyPluginSlots());
  const [pluginCommandsByPlugin, setPluginCommandsByPlugin] = useState<Record<string, SharkordPluginCommand[]>>({});
  const [, setPluginMetadata] = useState<SharkordPluginMetadata[]>([]);
  const [adminRealtimeEvent, setAdminRealtimeEvent] = useState<AdminRealtimeEvent>(null);
  const [channelPermissionsRealtimeEvent, setChannelPermissionsRealtimeEvent] = useState<ChannelPermissionsRealtimeEvent>(null);
  const [liveUsers, setLiveUsers] = useState<SharkordUser[]>([]);
  const [adminRoles, setAdminRoles] = useState<SharkordRole[]>([]);
  const [liveChannels, setLiveChannels] = useState<SharkordChannel[]>([]);
  const [liveCategories, setLiveCategories] = useState<SharkordCategory[]>([]);
  const [voiceMap, setVoiceMap] = useState<VoiceMap>({});
  const [voiceReactionsMap, setVoiceReactionsMap] = useState<VoiceReactionState>({});
  const [externalStreamsMap, setExternalStreamsMap] = useState<Record<number, Record<number, SharkordExternalStream>>>({});
  const [readStates, setReadStates] = useState<Record<number, number>>({});
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>(() => loadNotificationSettings());
  const [notificationCenterItems, setNotificationCenterItems] = useState<NotificationCenterItem[]>(() => loadNotificationCenterItems());
  const [notificationCenterOpen, setNotificationCenterOpen] = useState(false);
  const [notificationCenterMuted, setNotificationCenterMuted] = useState(false);
  const [uiSettings, setUiSettings] = useState<AppUiSettings>(() => loadAppUiSettings());
  const [typingUsers, setTypingUsers] = useState<Record<number, number[]>>({});
  const [speakingUserIds, setSpeakingUserIds] = useState<Set<number>>(new Set());
  const [selectedChannelId, setSelectedChannelId] = useState<number | null>(null);
  const [selectedVoiceId, setSelectedVoiceId] = useState<number | null>(null);
  const [currentVoiceChannelId, setCurrentVoiceChannelId] = useState<number | null>(null);
  const [voiceState, setVoiceState] = useState<VoiceState>(defaultVoiceState);
  const [voiceBusy, setVoiceBusy] = useState(false);
  const [voiceJoinCooldownUntil, setVoiceJoinCooldownUntil] = useState(0);
  const [voiceMediaReady, setVoiceMediaReady] = useState(false);
  const [audioSettings, setAudioSettings] = useState<AudioDeviceSettings>(() => loadAudioDeviceSettings());
  const [screenShareSettingsOpen, setScreenShareSettingsOpen] = useState(false);
  const [streamAudioMutedUsers, setStreamAudioMutedUsers] = useState<StreamAudioMuteSettings>(() => loadStreamAudioMuteSettings());
  const [userVolumes, setUserVolumes] = useState<UserVolumeSettings>(() => loadUserVolumeSettings());
  const [audioInputs, setAudioInputs] = useState<MediaDeviceInfo[]>([]);
  const [audioOutputs, setAudioOutputs] = useState<MediaDeviceInfo[]>([]);
  const [videoInputs, setVideoInputs] = useState<MediaDeviceInfo[]>([]);
  const [localAudioStream, setLocalAudioStream] = useState<MediaStream | null>(null);
  const [remoteAudioStreams, setRemoteAudioStreams] = useState<RemoteAudioStream[]>([]);
  const [remoteVideoStreams, setRemoteVideoStreams] = useState<RemoteVideoStream[]>([]);
  const [localVideoStream, setLocalVideoStream] = useState<MediaStream | null>(null);
  const [localScreenStream, setLocalScreenStream] = useState<MediaStream | null>(null);
  const [messages, setMessages] = useState<SharkordMessage[]>([]);
  const [directMessagesByServer, setDirectMessagesByServer] = useState<Record<string, DirectMessageConversation[]>>({});
  const [selectedDirectMessage, setSelectedDirectMessage] = useState<DirectMessageSelection>(null);
  const [composer, setComposer] = useState('');
  const [replyTarget, setReplyTarget] = useState<SharkordMessage | null>(null);
  const [threadPanel, setThreadPanel] = useState<ThreadPanelState>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState(() => tr('Nicht verbunden'));
  const [appInfo, setAppInfo] = useState<AppInfo | null>(null);
  const [release, setRelease] = useState<GitHubRelease | null>(null);
  const [updateStatus, setUpdateStatus] = useState<'unknown' | 'checking' | 'current' | 'available' | 'error'>('unknown');
  const [installingUpdate, setInstallingUpdate] = useState(false);
  const [updateMessage, setUpdateMessage] = useState(() => tr('Updater bereit'));
  const [startupUpdateNoticeVisible, setStartupUpdateNoticeVisible] = useState(false);
  const [membersOpen, setMembersOpen] = useState(true);
  const [memberPanelUserIds, setMemberPanelUserIds] = useState<Set<number> | null>(null);
  const [welcomeProfileSetupOpen, setWelcomeProfileSetupOpen] = useState(false);
  const [ownProfilePopupOpen, setOwnProfilePopupOpen] = useState(false);
  const [ownProfileServerId, setOwnProfileServerId] = useState<string | null>(null);
  const [adminWorkbenchOpen, setAdminWorkbenchOpen] = useState(false);
  const [adminInitialTab, setAdminInitialTab] = useState<AdminTab>('general');
  const [channelSettingsOpen, setChannelSettingsOpen] = useState<SharkordChannel | null>(null);
  const [pendingChannelDelete, setPendingChannelDelete] = useState<SharkordChannel | null>(null);
  const [pendingCategoryDelete, setPendingCategoryDelete] = useState<{ category: SharkordCategory; channelCount: number } | null>(null);
  const [pendingServerRemoval, setPendingServerRemoval] = useState<SharkordServer | null>(null);
  const [pendingDirectMessageDelete, setPendingDirectMessageDelete] = useState<DirectMessageEntry | null>(null);
  const [pendingUnsupportedDirectMessageDelete, setPendingUnsupportedDirectMessageDelete] = useState<DirectMessageEntry | null>(null);
  const [pendingAdminConfirm, setPendingAdminConfirm] = useState<AdminConfirmAction | null>(null);
  const [channelActionStatus, setChannelActionStatus] = useState(tr('Bereit'));
  const [draggedChannelId, setDraggedChannelId] = useState<number | null>(null);
  const [draggedVoiceUserId, setDraggedVoiceUserId] = useState<number | null>(null);
  const [dragOverChannelId, setDragOverChannelId] = useState<number | null>(null);
  const [draggedCategoryId, setDraggedCategoryId] = useState<number | null>(null);
  const [dragOverCategoryId, setDragOverCategoryId] = useState<number | null>(null);
  const [categoryCollapsedIds, setCategoryCollapsedIds] = useState<Set<number>>(new Set());
  const connectionRef = useRef<SharkordConnection | null>(null);
  const connectionsRef = useRef<Map<string, SharkordConnection>>(new Map());
  const connectingServerIdsRef = useRef<Set<string>>(new Set());
  const unsubscribeRef = useRef<(() => void) | null>(null);
  const unsubscribesRef = useRef<Map<string, () => void>>(new Map());
  const voiceEngineRef = useRef<SharkordVoiceEngine | null>(null);
  const voiceEnginesRef = useRef<Map<string, SharkordVoiceEngine>>(new Map());
  const voiceRouterRtpCapabilitiesRef = useRef<unknown | null>(null);
  const voiceRouterRtpCapabilitiesByServerRef = useRef<Map<string, unknown>>(new Map());
  const serverSessionSnapshotsRef = useRef<Map<string, ServerSessionSnapshot>>(new Map());
  const currentSessionSnapshotRef = useRef<ServerSessionSnapshot | null>(null);
  const pluginMetadataRef = useRef<SharkordPluginMetadata[]>([]);
  const currentVoiceChannelIdRef = useRef<number | null>(null);
  const voiceBusyRef = useRef(false);
  const voiceJoinCooldownUntilRef = useRef(0);
  const lastVoiceMediaErrorRef = useRef<string>('');
  const diagnosticSessionIdRef = useRef(`voice-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  const diagnosticLogPathRef = useRef('');
  const selectedDirectMessageRef = useRef<DirectMessageSelection>(null);
  const visibleMessagesSourceRef = useRef<VisibleMessagesSource>(null);
  const selectedChannelIdRef = useRef<number | null>(null);
  const activeViewRef = useRef<AppView>('chat');
  const activeServerIdRef = useRef<string | null>(state.activeServerId ?? null);
  const realtimeAuthReconnectServerIdsRef = useRef<Set<string>>(new Set());
  const allowEmptyServersSaveRef = useRef(false);
  const previousAudioSettingsRef = useRef<AudioDeviceSettings>(audioSettings);
  const oidcCallbackHandledRef = useRef(false);
  useEffect(() => {
    if (startupInviteCode) setAuth((current) => ({ ...current, invite: current.invite || startupInviteCode }));
    if (startupInviteCode) setNewCreds((current) => ({ ...current, invite: current.invite || startupInviteCode }));
  }, [startupInviteCode]);
  useEffect(() => { selectedDirectMessageRef.current = selectedDirectMessage; }, [selectedDirectMessage]);
  useEffect(() => { selectedChannelIdRef.current = selectedChannelId; }, [selectedChannelId]);
  useEffect(() => { activeViewRef.current = activeView; }, [activeView]);
  useEffect(() => { activeServerIdRef.current = state.activeServerId ?? null; }, [state.activeServerId]);
  useEffect(() => { saveNotificationCenterItems(notificationCenterItems); }, [notificationCenterItems]);
  useEffect(() => { saveAppUiSettings(uiSettings); }, [uiSettings]);
  useEffect(() => {
    const root = document.documentElement;
    root.dataset.compact = uiSettings.compactMode ? 'true' : 'false';
    root.dataset.reducedMotion = uiSettings.reducedMotion ? 'true' : 'false';
    root.dataset.highContrast = uiSettings.highContrast ? 'true' : 'false';
    root.style.setProperty('--app-font-size', `${clampAppFontSize(uiSettings.fontSize)}%`);
  }, [uiSettings]);
  const emitAdminRealtime = (kind: AdminRealtimeKind, serverId?: string | null, action?: string, payload?: unknown) => setAdminRealtimeEvent({ kind, serverId, action, payload, at: Date.now() });
  const emitChannelPermissionsRealtime = (serverId: string | null | undefined, payload: unknown) => setChannelPermissionsRealtimeEvent({ serverId, channelId: channelIdFromPermissionsEvent(payload), payload, at: Date.now() });

  const activeServer = useMemo(() => state.servers.find((server) => server.id === state.activeServerId) ?? state.servers[0] ?? null, [state.activeServerId, state.servers]);
  useEffect(() => {
    let cancelled = false;
    if (!activeServer) { setOidcConfig({ enabled: false, providers: [] }); return; }
    fetchOidcLoginConfig(activeServer.url)
      .then((next) => { if (!cancelled) setOidcConfig(next); })
      .catch(() => { if (!cancelled) setOidcConfig({ enabled: false, providers: [] }); });
    return () => { cancelled = true; };
  }, [activeServer]);
  const allChannels = useMemo(() => [...liveChannels].filter((channel) => !channel.isDm).sort(byPosition), [liveChannels]);
  const textChannels = useMemo(() => allChannels.filter(isTextChannel), [allChannels]);
  const voiceChannels = useMemo(() => allChannels.filter(isVoiceChannel), [allChannels]);
  const categories = useMemo(() => [...liveCategories].sort((a, b) => (a.position ?? 0) - (b.position ?? 0) || a.id - b.id), [liveCategories]);
  const usersById = useMemo(() => {
    const map = new Map<number, SharkordUser>();
    liveUsers.forEach((user) => map.set(user.id, user));
    return map;
  }, [liveUsers]);
  const voiceUsersByChannelId = useMemo(() => buildVoiceUsersByChannelId(voiceMap, usersById), [voiceMap, usersById]);
  const channelGroups = useMemo(() => buildChannelGroups(allChannels, categories), [allChannels, categories]);
  const selectedChannel = useMemo(() => allChannels.find((channel) => channel.id === selectedChannelId) ?? null, [selectedChannelId, allChannels]);
  const liveUserRoleSignature = useMemo(() => liveUsers
    .map((user) => `${user.id}:${[...(user.roleIds ?? [])].sort((a, b) => a - b).join(',')}`)
    .sort()
    .join('|'), [liveUsers]);
  useEffect(() => {
    let disposed = false;
    setMemberPanelUserIds(null);
    if (!connection || !selectedChannel || !connection.serverCapabilities.channelAccessMembers) return undefined;
    void getAccessibleMembers(connection, selectedChannel.id, false)
      .then((rows) => { if (!disposed) setMemberPanelUserIds(new Set(rows.map((user) => user.id))); })
      .catch((err) => { if (!disposed) { setMemberPanelUserIds(null); setStatus(tr(`Memberliste konnte nicht geladen werden: ${cleanError(err)}`)); } });
    return () => { disposed = true; };
  }, [connection, selectedChannel?.id, liveUsers.length, liveUserRoleSignature, channelPermissionsRealtimeEvent]);
  const directMessageEntries = useMemo<DirectMessageEntry[]>(() => state.servers.flatMap((server) => {
    const conn = connectionsRef.current.get(server.id);
    if (!conn) return [];
    const conversations = directMessagesByServer[server.id] ?? [];
    return conversations.map((conversation) => {
      const user = conn.join.users.find((item) => item.id === conversation.userId) ?? { id: conversation.userId, name: `User ${conversation.userId}` } as SharkordUser;
      const channel = conn.join.channels.find((item) => item.id === conversation.channelId) ?? { id: conversation.channelId, name: displayUserName(user), type: 'TEXT', categoryId: null, position: 0, isDm: true } as SharkordChannel;
      return { server, connection: conn, channel: { ...channel, isDm: true }, user, conversation };
    });
  }).sort((a, b) => b.conversation.lastMessageAt - a.conversation.lastMessageAt), [state.servers, directMessagesByServer]);
  const directMessageSearchCandidates = useMemo<DirectMessageUserSearchResult[]>(() => {
    const existingByServerUser = new Map(directMessageEntries.map((entry) => [`${entry.server.id}:${entry.user.id}`, entry]));
    return state.servers.flatMap((server) => {
      const conn = connectionsRef.current.get(server.id);
      if (!conn) return [];
      if (!conn.join.publicSettings?.directMessagesEnabled) return [];
      return [...(conn.join.users ?? [])]
        .filter((user) => user.id !== conn.join.ownUserId && !isDeletedUserPlaceholder(user))
        .sort((a, b) => displayUserName(a).localeCompare(displayUserName(b), undefined, { sensitivity: 'base' }))
        .map((user) => ({
          server,
          connection: conn,
          user,
          existingEntry: existingByServerUser.get(`${server.id}:${user.id}`) ?? null
        }));
    });
  }, [state.servers, directMessageEntries]);
  const selectedDirectMessageEntry = useMemo(() => selectedDirectMessage ? directMessageEntries.find((entry) => entry.server.id === selectedDirectMessage.serverId && entry.channel.id === selectedDirectMessage.channelId) ?? null : null, [directMessageEntries, selectedDirectMessage]);
  const selectedDirectMessageUsersById = useMemo(() => {
    const map = new Map<number, SharkordUser>();
    selectedDirectMessageEntry?.connection.join.users.forEach((user) => map.set(user.id, user));
    return map;
  }, [selectedDirectMessageEntry]);
  const selectedVoice = useMemo(() => voiceChannels.find((channel) => channel.id === selectedVoiceId) ?? null, [selectedVoiceId, voiceChannels]);
  const currentVoiceChannel = useMemo(() => voiceChannels.find((channel) => channel.id === currentVoiceChannelId) ?? null, [currentVoiceChannelId, voiceChannels]);
  const ownUser = useMemo(() => usersById.get(connection?.join.ownUserId ?? -1) ?? null, [connection, usersById]);
  const dmAccountEntry = selectedDirectMessageEntry ?? directMessageEntries[0] ?? null;
  const dmAccountConnection = dmAccountEntry?.connection ?? connection;
  const dmAccountServerId = dmAccountEntry?.server.id ?? activeServer?.id ?? null;
  const dmOwnUser = dmAccountConnection?.join.users.find((user) => user.id === dmAccountConnection.join.ownUserId) ?? null;
  const ownProfileConnection = ownProfileServerId ? connectionsRef.current.get(ownProfileServerId) ?? (ownProfileServerId === activeServer?.id ? connection : null) : connection;
  const ownProfileServerInfo = ownProfileServerId
    ? (ownProfileServerId === activeServer?.id ? serverInfo : serverSessionSnapshotsRef.current.get(ownProfileServerId)?.serverInfo ?? null)
    : serverInfo;
  const ownProfileUser = ownProfileConnection?.join.users.find((user) => user.id === ownProfileConnection.join.ownUserId) ?? null;
  const canManageChannelPermissions = useMemo(() => userHasChannelPermissionGuard(ownUser, adminRoles), [ownUser, adminRoles]);
  const canManageUsers = useMemo(() => userHasServerPermission(ownUser, adminRoles, ['MANAGE_USERS', 'ADMINISTRATOR']), [ownUser, adminRoles]);
  const canManageMessages = useMemo(() => userHasServerPermission(ownUser, adminRoles, ['MANAGE_MESSAGES', 'ADMINISTRATOR']), [ownUser, adminRoles]);
  const profilePopoverServer = useMemo(() => userProfilePopover?.serverId ? state.servers.find((server) => server.id === userProfilePopover.serverId) ?? activeServer : activeServer, [activeServer, state.servers, userProfilePopover?.serverId]);
  const profilePopoverConnection = userProfilePopover?.serverId ? connectionsRef.current.get(userProfilePopover.serverId) ?? connection : connection;
  const profilePopoverOwnUserId = profilePopoverConnection?.join.ownUserId;
  const profilePopoverDirectMessagesEnabled = !!profilePopoverConnection?.join.publicSettings?.directMessagesEnabled;
  const profilePopoverCanManageUsers = canManageUsers && (!userProfilePopover?.serverId || userProfilePopover.serverId === activeServer?.id);
  useEffect(() => {
    let disposed = false;
    if (!connection) { pluginMetadataRef.current = []; setPluginMetadata([]); setPluginCommandsByPlugin({}); setPluginSlots(emptyPluginSlots()); return undefined; }
    const joinMetadata = connection.join.pluginsMetadata ?? [];
    pluginMetadataRef.current = joinMetadata;
    setPluginMetadata(joinMetadata);
    setPluginCommandsByPlugin(connection.join.commands ?? {});
    void processPluginComponents(connection, connection.join.pluginIdsWithComponents ?? [], joinMetadata).then((rows) => {
      if (!disposed) setPluginSlots(groupPluginSlots(rows));
    }).catch((err) => {
      if (!disposed) setStatus(tr(`Plugin-Komponenten: ${cleanError(err)}`));
    });
    return () => { disposed = true; };
  }, [connection]);
  const isSelectedVoiceJoined = selectedVoice ? selectedVoice.id === currentVoiceChannelId : false;
  const serverVoicePresence = useMemo(() => {
    if (!selectedVoice || !connection) return false;
    return !!voiceMap[selectedVoice.id]?.users?.[connection.join.ownUserId];
  }, [selectedVoice, connection, voiceMap]);
  const voiceJoinCooldownActive = voiceJoinCooldownUntil > Date.now();
  const startVoiceJoinCooldown = useCallback((durationMs = 60_000) => {
    const until = Date.now() + durationMs;
    voiceJoinCooldownUntilRef.current = until;
    setVoiceJoinCooldownUntil(until);
    window.setTimeout(() => {
      if (voiceJoinCooldownUntilRef.current <= Date.now()) setVoiceJoinCooldownUntil(0);
    }, durationMs + 250);
  }, []);
  const sortedUsers = useMemo(() => liveUsers.filter((user) => !isDeletedUserPlaceholder(user)).sort((a, b) => (a.name || '').localeCompare(b.name || '', undefined, { sensitivity: 'base' })), [liveUsers]);
  const memberPanelDisplayUsers = useMemo(() => {
    const source = connection?.serverCapabilities.channelAccessMembers && memberPanelUserIds ? sortedUsers.filter((user) => memberPanelUserIds.has(user.id)) : sortedUsers;
    return [...source].filter((user) => !isDeletedUserPlaceholder(user)).sort((a, b) => (a.name || '').localeCompare(b.name || '', undefined, { sensitivity: 'base' }));
  }, [connection?.serverCapabilities.channelAccessMembers, memberPanelUserIds, sortedUsers]);
  currentSessionSnapshotRef.current = {
    connection,
    serverInfo,
    liveUsers,
    adminRoles,
    liveChannels,
    liveCategories,
    voiceMap,
    externalStreamsMap,
    readStates,
    typingUsers,
    messages,
    selectedChannelId,
    selectedVoiceId,
    currentVoiceChannelId,
    voiceState,
    voiceMediaReady,
    remoteAudioStreams,
    remoteVideoStreams,
    localAudioStream,
    localVideoStream,
    localScreenStream,
    status
  };
  function toggleStreamAudioMute(serverId: string, remoteId: number) {
    const key = streamAudioMuteKey(serverId, remoteId);
    setStreamAudioMutedUsers((current) => {
      const currentlyMuted = current[key] !== false;
      const next = { ...current, [key]: currentlyMuted ? false : true };
      saveStreamAudioMuteSettings(next);
      return next;
    });
  }
  function setUserVolume(serverId: string, remoteId: number, volume: number) {
    const key = userVolumeKey(serverId, remoteId);
    setUserVolumes((current) => {
      const next = { ...current, [key]: clampUserVolume(volume) };
      saveUserVolumeSettings(next);
      return next;
    });
  }
  function toggleCategoryCollapsed(categoryId: number) {
    setCategoryCollapsedIds((current) => {
      const next = new Set(current);
      if (next.has(categoryId)) next.delete(categoryId);
      else next.add(categoryId);
      return next;
    });
  }
  const syncLiveUsersFromAdminRows = useCallback((nextUsers: SharkordUser[]) => {
    const rows = nextUsers.filter((user) => !isDeletedUserPlaceholder(user));
    const byId = new Map(rows.map((user) => [user.id, user]));
    const mergeRows = (current: SharkordUser[]) => {
      const seen = new Set<number>();
      const merged = current
        .filter((user) => !isDeletedUserPlaceholder(user))
        .map((user) => {
          const incoming = byId.get(user.id);
          if (!incoming) return user;
          seen.add(user.id);
          return mergeUserPreservingPresence(user, incoming);
        });
      for (const row of rows) if (!seen.has(row.id)) merged.push(row);
      return merged;
    };
    const activeConnection = connectionRef.current;
    if (activeConnection) activeConnection.join.users = mergeRows(activeConnection.join.users ?? []);
    if (activeServerIdRef.current) {
      const snapshot = serverSessionSnapshotsRef.current.get(activeServerIdRef.current);
      if (snapshot) serverSessionSnapshotsRef.current.set(activeServerIdRef.current, { ...snapshot, liveUsers: mergeRows(snapshot.liveUsers ?? []) });
    }
    setLiveUsers((current) => mergeRows(current));
  }, []);
  const releaseChannel = normalizeReleaseChannel(state.releaseChannel);
  const updateAsset = useMemo(() => compatibleAsset(appInfo, release), [appInfo, release]);
  const updateAvailable = !!(appInfo && release?.version && semverGreater(release.version, appInfo.version) && updateAsset);
  const emitLiveDebug = useCallback((event: string, data: Record<string, unknown> = {}, level = 'info', message = '') => {
    if (!uiSettings.diagnosticLoggingEnabled) return;
    void appendDiagnosticLog(event, data, level, message, diagnosticSessionIdRef.current)
      .then((info) => { diagnosticLogPathRef.current = info.path; })
      .catch((err) => console.warn('voice.diagnostics.writeFailed', err));
  }, [uiSettings.diagnosticLoggingEnabled]);
  const emitVoiceUiAudit = useCallback((reason: string, extra: Record<string, unknown> = {}) => {
    const buildPayload = (stage: string) => ({
      reason,
      stage,
      activeView,
      serverId: activeServer?.id,
      selectedChannelId,
      selectedVoiceId,
      selectedVoiceName: selectedVoice?.name ?? null,
      currentVoiceChannelId,
      joined: isSelectedVoiceJoined,
      serverVoicePresence,
      voiceBusy,
      voiceMediaReady,
      voiceState,
      overlayState: {
        contextMenu: contextMenu ? { kind: contextMenu.kind, x: contextMenu.x, y: contextMenu.y } : null,
        userProfilePopover: userProfilePopover ? { x: userProfilePopover.x, y: userProfilePopover.y, userId: userProfilePopover.user.id, serverId: userProfilePopover.serverId ?? null } : null,
        serverDropdown: serverDropdown ? { left: serverDropdown.left, top: serverDropdown.top, width: serverDropdown.width } : null,
        notificationCenterOpen,
        commandPaletteOpen,
        adminWorkbenchOpen,
        channelSettingsOpen: channelSettingsOpen ? { id: channelSettingsOpen.id, name: channelSettingsOpen.name } : null,
        pendingChannelDelete: pendingChannelDelete ? { id: pendingChannelDelete.id, name: pendingChannelDelete.name } : null,
        pendingCategoryDelete: pendingCategoryDelete ? { id: pendingCategoryDelete.category.id, name: pendingCategoryDelete.category.name } : null,
        pendingServerRemoval: pendingServerRemoval ? { id: pendingServerRemoval.id, name: pendingServerRemoval.name } : null,
        pendingDirectMessageDelete: pendingDirectMessageDelete ? { serverId: pendingDirectMessageDelete.server.id, channelId: pendingDirectMessageDelete.channel.id, userId: pendingDirectMessageDelete.user.id } : null,
        pendingUnsupportedDirectMessageDelete: pendingUnsupportedDirectMessageDelete ? { serverId: pendingUnsupportedDirectMessageDelete.server.id, channelId: pendingUnsupportedDirectMessageDelete.channel.id, userId: pendingUnsupportedDirectMessageDelete.user.id } : null,
        pendingAdminConfirm: pendingAdminConfirm ? { kind: pendingAdminConfirm.kind } : null,
        pendingTotpAuth: !!pendingTotpAuth,
        modalOpen,
        screenShareSettingsOpen,
        welcomeProfileSetupOpen,
        ownProfilePopupOpen
      },
      voiceUsers: selectedVoice ? (voiceUsersByChannelId.get(selectedVoice.id) ?? []).map((user) => ({ id: user.id, state: normalizeVoiceState(user.state) })) : [],
      remoteAudioStreams: remoteAudioStreams.map((item) => ({ remoteId: item.remoteId, kind: item.kind, tracks: item.stream.getTracks().map((track) => ({ kind: track.kind, readyState: track.readyState, muted: track.muted })) })),
      remoteVideoStreams: remoteVideoStreams.map((item) => ({ remoteId: item.remoteId, kind: item.kind, tracks: item.stream.getTracks().map((track) => ({ kind: track.kind, readyState: track.readyState, muted: track.muted })) })),
      dom: collectVoiceUiDomDiagnostics(),
      ...extra
    });
    emitLiveDebug('voice.ui.audit', buildPayload('sync'));
    window.requestAnimationFrame(() => emitLiveDebug('voice.ui.audit', buildPayload('raf')));
    window.setTimeout(() => emitLiveDebug('voice.ui.audit', buildPayload('delay250')), 250);
    window.setTimeout(() => emitLiveDebug('voice.ui.audit', buildPayload('delay1000')), 1000);
  }, [activeServer?.id, activeView, adminWorkbenchOpen, channelSettingsOpen, commandPaletteOpen, contextMenu, currentVoiceChannelId, emitLiveDebug, isSelectedVoiceJoined, modalOpen, notificationCenterOpen, ownProfilePopupOpen, pendingAdminConfirm, pendingCategoryDelete, pendingChannelDelete, pendingDirectMessageDelete, pendingServerRemoval, pendingTotpAuth, pendingUnsupportedDirectMessageDelete, remoteAudioStreams, remoteVideoStreams, screenShareSettingsOpen, selectedChannelId, selectedVoice, selectedVoiceId, serverDropdown, serverVoicePresence, userProfilePopover, voiceBusy, voiceMediaReady, voiceState, voiceUsersByChannelId, welcomeProfileSetupOpen]);
  useEffect(() => {
    if (!uiSettings.diagnosticLoggingEnabled) return;
    let cancelled = false;
    getDiagnosticLogInfo()
      .then((info) => {
        if (cancelled) return;
        diagnosticLogPathRef.current = info.path;
        emitLiveDebug('voice.diagnostics.ready', { path: info.path, size: info.size });
      })
      .catch((err) => emitLiveDebug('voice.diagnostics.infoFailed', { error: cleanError(err) }, 'warn', cleanError(err)));
    return () => { cancelled = true; };
  }, [emitLiveDebug, uiSettings.diagnosticLoggingEnabled]);
  useEffect(() => {
    const onError = (event: ErrorEvent) => {
      emitLiveDebug('app.frontend.error', {
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        error: cleanError(event.error)
      }, 'error', event.message || cleanError(event.error));
    };
    const onUnhandledRejection = (event: PromiseRejectionEvent) => {
      emitLiveDebug('app.frontend.unhandledRejection', { reason: cleanError(event.reason) }, 'error', cleanError(event.reason));
    };
    window.addEventListener('error', onError);
    window.addEventListener('unhandledrejection', onUnhandledRejection);
    return () => {
      window.removeEventListener('error', onError);
      window.removeEventListener('unhandledrejection', onUnhandledRejection);
    };
  }, [emitLiveDebug]);
  useEffect(() => {
    if (!selectedVoice) return;
    const users = (voiceUsersByChannelId.get(selectedVoice.id) ?? []).map((user) => ({ id: user.id, state: normalizeVoiceState(user.state) }));
    emitLiveDebug('voice.render.snapshot', {
      serverId: activeServer?.id,
      selectedVoiceId: selectedVoice.id,
      currentVoiceChannelId,
      joined: isSelectedVoiceJoined,
      serverVoicePresence,
      users,
      remoteAudioStreams: remoteAudioStreams.map((item) => ({ remoteId: item.remoteId, kind: item.kind, tracks: item.stream.getTracks().map((track) => ({ kind: track.kind, readyState: track.readyState, muted: track.muted })) })),
      remoteVideoStreams: remoteVideoStreams.map((item) => ({ remoteId: item.remoteId, kind: item.kind, tracks: item.stream.getTracks().map((track) => ({ kind: track.kind, readyState: track.readyState, muted: track.muted })) }))
    });
    emitVoiceUiAudit('voice.render.snapshot', { selectedVoiceId: selectedVoice.id, usersCount: users.length });
  }, [activeServer?.id, currentVoiceChannelId, emitLiveDebug, emitVoiceUiAudit, isSelectedVoiceJoined, remoteAudioStreams, remoteVideoStreams, selectedVoice, serverVoicePresence, voiceUsersByChannelId]);
  useEffect(() => {
    if (!selectedVoice && !currentVoiceChannelId) return;
    emitVoiceUiAudit('voice.overlay.stateChange');
  }, [adminWorkbenchOpen, channelSettingsOpen, commandPaletteOpen, contextMenu, currentVoiceChannelId, emitVoiceUiAudit, modalOpen, notificationCenterOpen, ownProfilePopupOpen, pendingAdminConfirm, pendingCategoryDelete, pendingChannelDelete, pendingDirectMessageDelete, pendingServerRemoval, pendingTotpAuth, pendingUnsupportedDirectMessageDelete, screenShareSettingsOpen, selectedVoice, serverDropdown, userProfilePopover, welcomeProfileSetupOpen]);
  const setUserSpeaking = useCallback((userId: number, speaking: boolean) => {
    setSpeakingUserIds((current) => {
      if (current.has(userId) === speaking) return current;
      const next = new Set(current);
      if (speaking) next.add(userId);
      else next.delete(userId);
      return next;
    });
  }, []);

  function snapshotFromConnection(serverId: string, next: SharkordConnection): ServerSessionSnapshot {
    return {
      connection: next,
      serverInfo: { serverId: next.join.serverId, name: next.join.serverName, version: '', description: '', logo: null, allowNewUsers: true },
      liveUsers: next.join.users ?? [],
      adminRoles: next.join.roles ?? [],
      liveChannels: next.join.channels ?? [],
      liveCategories: next.join.categories ?? [],
      voiceMap: next.join.voiceMap ?? {},
      externalStreamsMap: (next.join.externalStreamsMap ?? {}) as Record<number, Record<number, SharkordExternalStream>>,
      readStates: next.join.readStates ?? {},
      typingUsers: {},
      messages: [],
      selectedChannelId: next.join.channels.filter(isTextChannel).sort(byPosition)[0]?.id ?? null,
      selectedVoiceId: null,
      currentVoiceChannelId: null,
      voiceState: defaultVoiceState,
      voiceMediaReady: false,
      remoteAudioStreams: [],
      remoteVideoStreams: [],
      localAudioStream: null,
      localVideoStream: null,
      localScreenStream: null,
      status: tr(`Verbunden mit ${next.join.serverName}`)
    };
  }

  function snapshotServerSession(serverId: string) {
    const current = currentSessionSnapshotRef.current;
    const activeConnection = connectionsRef.current.get(serverId) ?? current?.connection ?? null;
    if (current) {
      serverSessionSnapshotsRef.current.set(serverId, { ...current, connection: activeConnection });
    } else if (activeConnection) {
      serverSessionSnapshotsRef.current.set(serverId, snapshotFromConnection(serverId, activeConnection));
    }
  }

  function applyServerSession(serverId: string) {
    const snapshot = serverSessionSnapshotsRef.current.get(serverId);
    const activeConnection = connectionsRef.current.get(serverId) ?? snapshot?.connection ?? null;
    const joinChannels = activeConnection?.join.channels ?? [];
    const joinCategories = activeConnection?.join.categories ?? [];
    const joinUsers = activeConnection?.join.users ?? [];
    const joinRoles = activeConnection?.join.roles ?? [];
    const liveChannelRows = snapshot?.liveChannels?.length ? snapshot.liveChannels : joinChannels;
    const liveCategoryRows = snapshot?.liveCategories?.length ? snapshot.liveCategories : joinCategories;
    const liveUserRows = snapshot?.liveUsers?.length ? snapshot.liveUsers : joinUsers;
    const roleRows = snapshot?.adminRoles?.length ? snapshot.adminRoles : joinRoles;
    const selectedTextChannel = snapshot?.selectedChannelId ?? liveChannelRows.filter(isTextChannel).sort(byPosition)[0]?.id ?? null;
    connectionRef.current = activeConnection;
    voiceEngineRef.current = voiceEnginesRef.current.get(serverId) ?? null;
    voiceRouterRtpCapabilitiesRef.current = voiceRouterRtpCapabilitiesByServerRef.current.get(serverId) ?? null;
    setConnection(activeConnection);
    setServerInfo(snapshot?.serverInfo ?? (activeConnection ? { serverId: activeConnection.join.serverId, name: activeConnection.join.serverName, version: '', description: '', logo: null, allowNewUsers: true } : null));
    setLiveUsers(liveUserRows);
    setAdminRoles(roleRows);
    setLiveChannels(liveChannelRows);
    setLiveCategories(liveCategoryRows);
    setVoiceMap(Object.keys(snapshot?.voiceMap ?? {}).length ? snapshot?.voiceMap ?? {} : activeConnection?.join.voiceMap ?? {});
    setExternalStreamsMap(Object.keys(snapshot?.externalStreamsMap ?? {}).length ? snapshot?.externalStreamsMap ?? {} : (activeConnection?.join.externalStreamsMap ?? {}) as Record<number, Record<number, SharkordExternalStream>>);
    setReadStates(Object.keys(snapshot?.readStates ?? {}).length ? snapshot?.readStates ?? {} : activeConnection?.join.readStates ?? {});
    setTypingUsers(snapshot?.typingUsers ?? {});
    visibleMessagesSourceRef.current = activeConnection && selectedTextChannel && snapshot?.messages?.length ? { view: 'chat', serverId, channelId: selectedTextChannel } : null;
    setMessages(snapshot?.messages ?? []);
    setSelectedChannelId(selectedTextChannel);
    setSelectedVoiceId(snapshot?.selectedVoiceId ?? null);
    setCurrentVoiceChannelId(snapshot?.currentVoiceChannelId ?? null);
    currentVoiceChannelIdRef.current = snapshot?.currentVoiceChannelId ?? null;
    setVoiceState(snapshot?.voiceState ?? defaultVoiceState);
    setVoiceMediaReady(snapshot?.voiceMediaReady ?? !!voiceEnginesRef.current.get(serverId)?.isReadyToProduce());
    setRemoteAudioStreams(snapshot?.remoteAudioStreams ?? []);
    setRemoteVideoStreams(snapshot?.remoteVideoStreams ?? []);
    setLocalAudioStream(snapshot?.localAudioStream ?? null);
    setLocalVideoStream(snapshot?.localVideoStream ?? null);
    setLocalScreenStream(snapshot?.localScreenStream ?? null);
    setSpeakingUserIds(new Set());
    setStatus(snapshot?.status ?? (activeConnection ? tr(`Verbunden mit ${activeConnection.join.serverName}`) : tr('Nicht verbunden')));
    setWelcomeProfileSetupOpen(activeConnection ? shouldShowWelcomeProfileSetup(activeConnection) : false);
    if (activeConnection && selectedTextChannel && !(snapshot?.messages?.length)) void loadMessages(activeConnection, selectedTextChannel);
  }

  function cleanupServerSession(serverId: string, leaveVoice = false) {
    const connectionToClose = connectionsRef.current.get(serverId);
    const unsubscribe = unsubscribesRef.current.get(serverId);
    const engine = voiceEnginesRef.current.get(serverId);
    unsubscribe?.();
    if (leaveVoice && connectionToClose) void leaveVoiceChannel(connectionToClose).catch(() => undefined);
    engine?.close();
    connectionToClose?.close();
    unsubscribesRef.current.delete(serverId);
    voiceEnginesRef.current.delete(serverId);
    voiceRouterRtpCapabilitiesByServerRef.current.delete(serverId);
    connectionsRef.current.delete(serverId);
    connectingServerIdsRef.current.delete(serverId);
    serverSessionSnapshotsRef.current.delete(serverId);
    if (activeServer?.id === serverId) {
      connectionRef.current = null;
      unsubscribeRef.current = null;
      voiceEngineRef.current = null;
      voiceRouterRtpCapabilitiesRef.current = null;
    }
  }

  function clearTransientVoiceOverlays(reason = 'voice.transient.clear') {
    emitVoiceUiAudit(`${reason}.before`);
    setContextMenu(null);
    setUserProfilePopover(null);
    setServerDropdown(null);
    setNotificationCenterOpen(false);
    setCommandPaletteOpen(false);
    window.setTimeout(() => emitVoiceUiAudit(`${reason}.after`), 0);
  }

  function resetTransientUiForServerSwitch() {
    setContextMenu(null);
    setUserProfilePopover(null);
    setServerDropdown(null);
    setNotificationCenterOpen(false);
    setCommandPaletteOpen(false);
    setAdminWorkbenchOpen(false);
    setChannelSettingsOpen(null);
    setPendingChannelDelete(null);
    setPendingCategoryDelete(null);
    setScreenShareSettingsOpen(false);
    setModalOpen(false);
    setWelcomeProfileSetupOpen(false);
    setDraggedChannelId(null);
    setDragOverChannelId(null);
    setDraggedCategoryId(null);
    setDragOverCategoryId(null);
    setActionStatus(tr('Bereit'));
    setChannelActionStatus(tr('Bereit'));
    setError('');
  }

  function serverIdForConnection(conn: SharkordConnection | null) {
    if (!conn) return null;
    for (const [serverId, knownConnection] of connectionsRef.current.entries()) {
      if (knownConnection === conn) return serverId;
    }
    return null;
  }

  function isActiveServerRequest(serverId: string | null) {
    return !!serverId && activeServer?.id === serverId && connectionRef.current === connectionsRef.current.get(serverId);
  }

  function snapshotMessagesForServer(serverId: string | null, channelId: number, nextMessages: SharkordMessage[]) {
    if (!serverId) return;
    const snapshot = serverSessionSnapshotsRef.current.get(serverId);
    if (!snapshot) return;
    serverSessionSnapshotsRef.current.set(serverId, {
      ...snapshot,
      messages: nextMessages,
      selectedChannelId: channelId,
      selectedVoiceId: null,
      typingUsers: { ...snapshot.typingUsers, [channelId]: [] },
      readStates: { ...snapshot.readStates, [channelId]: 0 }
    });
  }

  async function connectSavedServers() {
    for (const server of state.servers) {
      if (connectionsRef.current.has(server.id) || connectingServerIdsRef.current.has(server.id)) continue;
      connectingServerIdsRef.current.add(server.id);
      try {
        const creds = await API.LoadServerCredentials(server.id);
        const loadedAuth = credsToAuth(creds);
        if (!loadedAuth.identity || !loadedAuth.password) continue;
        if (connectionsRef.current.has(server.id)) continue;
        const next = await loginAndJoin({ serverUrl: server.url, ...loadedAuth });
        connectionsRef.current.set(server.id, next);
        serverSessionSnapshotsRef.current.set(server.id, snapshotFromConnection(server.id, next));
        void refreshDirectMessagesForServer(server.id, next);
        wireSubscriptions(next, server.id);
        if (activeServer?.id === server.id) {
          setAuth(loadedAuth);
          applyServerSession(server.id);
          setWelcomeProfileSetupOpen(shouldShowWelcomeProfileSetup(next));
          const firstTextChannel = next.join.channels.filter(isTextChannel).sort(byPosition)[0] ?? null;
          if (firstTextChannel) void loadMessages(next, firstTextChannel.id);
        }
      } catch (err) {
        if (activeServer?.id === server.id) setStatus(tr(`Auto-Connect ${server.name}: ${cleanError(err)}`));
      } finally {
        connectingServerIdsRef.current.delete(server.id);
      }
    }
  }

  async function reconnectServerAfterRealtimeAuthFailure(serverId: string | undefined | null, staleConnection: SharkordConnection, label: string, err: unknown) {
    if (!serverId) return false;
    const message = cleanError(err);
    if (!isAuthenticationError(message)) return false;
    if (connectionsRef.current.get(serverId) !== staleConnection) return true;
    if (realtimeAuthReconnectServerIdsRef.current.has(serverId)) return true;
    const server = state.servers.find((item) => item.id === serverId);
    if (!server) return false;
    realtimeAuthReconnectServerIdsRef.current.add(serverId);
    if (serverId === activeServerIdRef.current) setStatus(tr(`${label}: Sitzung abgelaufen · verbinde neu...`));
    try {
      const loadedAuth = await API.LoadServerCredentials(serverId)
        .then(credsToAuth)
        .catch(() => ({ identity: '', password: '', totpCode: '', appPassword: '', serverPassword: '', invite: '' }));
      const reconnectAuth = loadedAuth.identity && loadedAuth.password ? loadedAuth : (serverId === activeServerIdRef.current ? auth : loadedAuth);
      if (!reconnectAuth.identity || !reconnectAuth.password) throw new Error(tr('Gespeicherte Server-Anmeldedaten fehlen'));
      const selectedBeforeReconnect = serverId === activeServerIdRef.current ? selectedChannelIdRef.current : null;
      cleanupServerSession(serverId, false);
      const next = await loginAndJoin({ serverUrl: server.url, ...reconnectAuth });
      connectionsRef.current.set(serverId, next);
      const snapshot = snapshotFromConnection(serverId, next);
      if (selectedBeforeReconnect && next.join.channels.some((channel) => channel.id === selectedBeforeReconnect)) snapshot.selectedChannelId = selectedBeforeReconnect;
      serverSessionSnapshotsRef.current.set(serverId, snapshot);
      void refreshDirectMessagesForServer(serverId, next);
      wireSubscriptions(next, serverId);
      if (serverId === activeServerIdRef.current) {
        setAuth(reconnectAuth);
        applyServerSession(serverId);
        setStatus(tr('Sitzung neu verbunden'));
      }
      return true;
    } catch (reconnectErr) {
      if (serverId === activeServerIdRef.current) setStatus(tr(`${label}: ${message} · Reconnect fehlgeschlagen: ${cleanError(reconnectErr)}`));
      return true;
    } finally {
      realtimeAuthReconnectServerIdsRef.current.delete(serverId);
    }
  }

  async function refreshDirectMessagesForServer(serverId: string, conn = connectionsRef.current.get(serverId)) {
    if (!conn) return;
    try {
      const rows = await getDirectMessages(conn);
      setDirectMessagesByServer((current) => ({ ...current, [serverId]: rows }));
    } catch (err) {
      setDirectMessagesByServer((current) => ({ ...current, [serverId]: [] }));
      if (activeView === 'dms') setStatus(tr(`Direktnachrichten ${state.servers.find((server) => server.id === serverId)?.name ?? serverId}: ${cleanError(err)}`));
    }
  }

  async function refreshDirectMessages() {
    await Promise.all([...connectionsRef.current.entries()].map(([serverId, conn]) => refreshDirectMessagesForServer(serverId, conn)));
  }

  function deleteDirectMessageConversation(entry: DirectMessageEntry) {
    if (!entry.connection.serverCapabilities.directMessageHide) {
      setPendingUnsupportedDirectMessageDelete(entry);
      setStatus(tr('Direktnachricht ausblenden wird von diesem Server nicht unterstützt'));
      return;
    }
    setPendingDirectMessageDelete(entry);
    setStatus(tr('Direktnachricht ausblenden bestätigen'));
  }
  async function confirmDeleteDirectMessageConversation() {
    const entry = pendingDirectMessageDelete;
    if (!entry) return;
    try {
      setStatus(tr('Direktnachricht wird ausgeblendet…'));
      await hideDirectMessage(entry.connection, entry.channel.id);
      setDirectMessagesByServer((current) => ({ ...current, [entry.server.id]: (current[entry.server.id] ?? []).filter((conversation) => conversation.channelId !== entry.channel.id) }));
      const source = visibleMessagesSourceRef.current;
      if (selectedDirectMessage?.serverId === entry.server.id && selectedDirectMessage.channelId === entry.channel.id) {
        setSelectedDirectMessage(null);
        setMessages([]);
        setActiveView('dms');
        visibleMessagesSourceRef.current = source?.view === 'dms' && source.serverId === entry.server.id && source.channelId === entry.channel.id ? null : source;
      }
      setPendingDirectMessageDelete(null);
      setStatus(tr('Direktnachricht ausgeblendet'));
    } catch (err) {
      setStatus(tr(`Direktnachricht ausblenden fehlgeschlagen: ${cleanError(err)}`));
    }
  }

  useEffect(() => {
    document.documentElement.dataset.theme = state.theme;
    if (nativeStateLoaded) saveState(state);
  }, [state, nativeStateLoaded]);
  useEffect(() => {
    let cancelled = false;
    const localState = loadState();
    API.LoadAppState()
      .then((stored) => {
        if (cancelled) return;
        const nativeState = stored as StoredState;
        setState(resolveStartupState(nativeState, localState));
      })
      .catch((err) => {
        if (hasUsableServers(localState)) setState(stripPlaceholderServers(localState));
        setStatus(tr(`State konnte nicht geladen werden: ${cleanError(err)}`));
      })
      .finally(() => { if (!cancelled) setNativeStateLoaded(true); });
    return () => { cancelled = true; };
  }, []);
  useEffect(() => {
    if (!nativeStateLoaded) return;
    const allowEmptyServers = allowEmptyServersSaveRef.current;
    allowEmptyServersSaveRef.current = false;
    void API.SaveAppState({ ...state, allowEmptyServers } as unknown as Parameters<typeof API.SaveAppState>[0]).catch((err) => setStatus(tr(`State konnte nicht gespeichert werden: ${cleanError(err)}`)));
  }, [state, nativeStateLoaded]);
  useEffect(() => { currentVoiceChannelIdRef.current = currentVoiceChannelId; }, [currentVoiceChannelId]);
  const refreshMediaDeviceListsForUi = useCallback(async () => {
    const { inputs, outputs, videos } = await refreshMediaDeviceLists();
    setAudioInputs(inputs);
    setAudioOutputs(outputs);
    setVideoInputs(videos);
    return { inputs, outputs, videos };
  }, []);
  useEffect(() => {
    saveAudioDeviceSettings(audioSettings);
    const previous = previousAudioSettingsRef.current;
    previousAudioSettingsRef.current = audioSettings;
    const engine = voiceEngineRef.current;
    engine?.updateSettings(audioSettings);
    if (!engine || !connection?.serverCapabilities.voiceDeviceHotSwap || !currentVoiceChannelId) return;
    if (previous.microphoneId !== audioSettings.microphoneId && !voiceState.micMuted) {
      void engine.hotSwapMicrophone(audioSettings).catch((err) => setStatus(tr(`Mikrofon Hot-Swap: ${cleanError(err)}`)));
    }
    if (previous.webcamId !== audioSettings.webcamId && voiceState.webcamEnabled) {
      void engine.hotSwapWebcam(audioSettings).catch((err) => setStatus(tr(`Kamera Hot-Swap: ${cleanError(err)}`)));
    }
  }, [audioSettings, connection, currentVoiceChannelId, voiceState.micMuted, voiceState.webcamEnabled]);
  useEffect(() => { saveNotificationSettings(notificationSettings); }, [notificationSettings]);
  useEffect(() => { void refreshMediaDeviceListsForUi().catch((err) => setStatus(tr(`Mediengeräte: ${cleanError(err)}`))); }, [refreshMediaDeviceListsForUi]);
  useEffect(() => {
    const refresh = () => void refreshMediaDeviceListsForUi().catch(() => undefined);
    navigator.mediaDevices?.addEventListener?.('devicechange', refresh);
    return () => navigator.mediaDevices?.removeEventListener?.('devicechange', refresh);
  }, [refreshMediaDeviceListsForUi]);
  useEffect(() => {
    if (!nativeStateLoaded) return;
    API.Info().then((info) => { setAppInfo(info); void checkUpdates(info, true, releaseChannel); }).catch((err) => { setUpdateStatus('error'); setUpdateMessage(tr(`Updater nicht verfügbar: ${cleanError(err)}`)); });
  }, [nativeStateLoaded, releaseChannel]);
  useEffect(() => {
    let cancelled = false;
    if (!activeServer) {
      connectionRef.current = null;
      unsubscribeRef.current = null;
      visibleMessagesSourceRef.current = null;
      voiceEngineRef.current = null;
      voiceRouterRtpCapabilitiesRef.current = null;
      setConnection(null); setMessages([]); setLiveUsers([]); setAdminRoles([]); setLiveChannels([]); setLiveCategories([]); setVoiceMap({}); setVoiceReactionsMap({}); setExternalStreamsMap({}); setReadStates({}); setTypingUsers({}); setSpeakingUserIds(new Set()); setSelectedChannelId(null); setSelectedVoiceId(null); setCurrentVoiceChannelId(null); setVoiceState(defaultVoiceState); setAuth(emptyAuth); setStatus(tr('Nicht verbunden')); setServerInfo(null);
      return;
    }
    connectionRef.current = connectionsRef.current.get(activeServer.id) ?? null;
    unsubscribeRef.current = unsubscribesRef.current.get(activeServer.id) ?? null;
    voiceEngineRef.current = voiceEnginesRef.current.get(activeServer.id) ?? null;
    voiceRouterRtpCapabilitiesRef.current = voiceRouterRtpCapabilitiesByServerRef.current.get(activeServer.id) ?? null;
    applyServerSession(activeServer.id);
    if (connectionRef.current) wireSubscriptions(connectionRef.current, activeServer.id);
    API.LoadServerCredentials(activeServer.id).then(async (creds) => {
      if (cancelled) return;
      const loadedAuth = credsToAuth(creds);
      setAuth(loadedAuth);
      if (loadedAuth.identity && loadedAuth.password && !connectionsRef.current.has(activeServer.id)) await connectSavedServers();
    }).catch(() => setAuth(emptyAuth));
    fetchServerInfo(activeServer.url).then((info) => {
      if (cancelled) return;
      setServerInfo(info);
      setState((current) => ({ ...current, servers: current.servers.map((server) => server.id === activeServer.id ? { ...server, name: info.name || server.name, logo: info.logo ?? null } : server) }));
    }).catch((err) => { if (!cancelled) setStatus(tr(`Server-Info nicht erreichbar: ${cleanError(err)}`)); });
    return () => {
      cancelled = true;
      snapshotServerSession(activeServer.id);
      if (unsubscribeRef.current === unsubscribesRef.current.get(activeServer.id)) unsubscribeRef.current = null;
    };
  }, [activeServer?.id]);

  useEffect(() => {
    if (!nativeStateLoaded) return;
    void connectSavedServers();
  }, [nativeStateLoaded, state.servers]);

  useEffect(() => {
    if (!nativeStateLoaded || oidcCallbackHandledRef.current) return;
    if (window.location.pathname !== '/oidc/callback') return;
    oidcCallbackHandledRef.current = true;
    const handleOidcCallback = async () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const code = params.get('code')?.trim();
        const stateParam = params.get('state')?.trim();
        if (!code) throw new Error(tr('OIDC Code fehlt'));
        if (!stateParam) throw new Error(tr('OIDC State fehlt'));
        const stored = sessionStorage.getItem(`${SHARKORD_DESKTOP_OIDC_STATE_PREFIX}${stateParam}`);
        if (!stored) throw new Error(tr('OIDC State ist abgelaufen oder ungültig'));
        sessionStorage.removeItem(`${SHARKORD_DESKTOP_OIDC_STATE_PREFIX}${stateParam}`);
        const pending = JSON.parse(stored) as PendingOidcLogin;
        const provider = pending.provider;
        if (!provider.id) throw new Error(tr('OIDC Provider fehlt'));
        if (!state.servers.some((server) => server.id === pending.serverId)) throw new Error(tr('OIDC Server fehlt'));
        activeServerIdRef.current = pending.serverId;
        setState((current) => ({ ...current, activeServerId: pending.serverId }));
        setBusy(true);
        setStatus(tr('SSO Login läuft...'));
        cleanupServerSession(pending.serverId, false);
        const next = await loginWithOidcCodeAndJoin({ serverUrl: pending.serverUrl, provider: provider.id, code, redirectUri: pending.redirectUri, serverPassword: pending.serverPassword });
        await applyAuthenticatedConnection(pending.serverId, next, tr('SSO Login erfolgreich'));
        setStatus(tr('SSO Login erfolgreich'));
        setAuth({ ...emptyAuth, serverPassword: pending.serverPassword ?? '' });
        history.replaceState(null, '', '/');
      } catch (err) {
        setStatus(tr(`SSO Login fehlgeschlagen: ${cleanError(err)}`));
        history.replaceState(null, '', '/');
      } finally {
        setBusy(false);
      }
    };
    void handleOidcCallback();
  }, [nativeStateLoaded, state.servers]);

  async function refreshPluginComponentsForConnection(conn: SharkordConnection, pluginIdsInput: unknown, metadata = pluginMetadataRef.current) {
    const requestServerId = serverIdForConnection(conn);
    try {
      const rows = await processPluginComponents(conn, pluginIdsInput, metadata);
      if (!isActiveServerRequest(requestServerId)) return;
      setPluginSlots(groupPluginSlots(rows));
    } catch (err) {
      if (isActiveServerRequest(requestServerId)) setStatus(tr(`Plugin-Komponenten: ${cleanError(err)}`));
    }
  }

  function refreshRemoteMedia(reason: string, attempt = 0) {
    const engine = voiceEngineRef.current;
    if (!engine || !currentVoiceChannelIdRef.current) return;
    emitLiveDebug('voice.media.refresh.start', { reason, attempt });
    void engine.refreshExistingProducers()
      .then(() => emitLiveDebug('voice.media.refresh.ok', { reason, attempt }))
      .catch((err) => {
        const message = cleanError(err);
        emitLiveDebug('voice.media.refresh.error', { reason, attempt, error: message }, 'warn', message);
        setStatus(tr(`Remote Medien Refresh: ${message}`));
      });
    if (attempt < 2) window.setTimeout(() => refreshRemoteMedia(reason, attempt + 1), attempt === 0 ? 350 : 1500);
  }

  function wireSubscriptions(next: SharkordConnection, serverId = activeServer?.id) {
    if (serverId) {
      unsubscribesRef.current.get(serverId)?.();
      unsubscribesRef.current.delete(serverId);
    } else {
      unsubscribeRef.current?.();
      unsubscribeRef.current = null;
    }
    const isActiveSubscriptionServer = () => !serverId || serverId === activeServerIdRef.current;
    const activeSubscription = subscribeToCoreEvents(next, {
      onVoiceJoin: ({ channelId, userId, state }) => {
        if (!isActiveSubscriptionServer()) return;
        const safeState = normalizeVoiceState(state);
        emitLiveDebug('voice.realtime.join', { serverId, channelId, userId, own: userId === next.join.ownUserId, state: safeState });
        emitVoiceUiAudit('voice.realtime.join.beforeState', { serverId, channelId, userId, own: userId === next.join.ownUserId, state: safeState });
        addVoiceUser(channelId, userId, safeState);
        if (userId === next.join.ownUserId) {
          clearTransientVoiceOverlays('voice.realtime.ownJoin.clearOverlays');
          currentVoiceChannelIdRef.current = channelId;
          setCurrentVoiceChannelId(channelId);
          setSelectedVoiceId(channelId);
        } else if (currentVoiceChannelIdRef.current === channelId) {
          clearTransientVoiceOverlays('voice.realtime.remoteJoin.clearOverlays');
        }
        emitVoiceUiAudit('voice.realtime.join.afterState', { serverId, channelId, userId, own: userId === next.join.ownUserId });
        if (userId !== next.join.ownUserId) {
          playDesktopSound('remote_user_joined_voice_channel');
          if (safeState.webcamEnabled || safeState.sharingScreen) refreshRemoteMedia('voice.join.mediaFlag');
        }
      },
      onVoiceLeave: ({ channelId, userId }) => { if (!isActiveSubscriptionServer()) return; emitLiveDebug('voice.realtime.leave', { serverId, channelId, userId, own: userId === next.join.ownUserId }); removeVoiceUser(channelId, userId); voiceEngineRef.current?.removeRemoteUser(userId); if (userId === next.join.ownUserId && currentVoiceChannelIdRef.current === channelId) { currentVoiceChannelIdRef.current = null; setCurrentVoiceChannelId(null); } if (userId !== next.join.ownUserId) playDesktopSound('remote_user_left_voice_channel'); },
      onVoiceUpdateState: ({ channelId, userId, state }) => {
        if (!isActiveSubscriptionServer()) return;
        const safePatch = normalizeVoiceState(state);
        emitLiveDebug('voice.realtime.updateState', { serverId, channelId, userId, own: userId === next.join.ownUserId, state: safePatch });
        emitVoiceUiAudit('voice.realtime.updateState.beforeState', { serverId, channelId, userId, own: userId === next.join.ownUserId, state: safePatch });
        updateVoiceUser(channelId, userId, safePatch);
        emitVoiceUiAudit('voice.realtime.updateState.afterState', { serverId, channelId, userId, own: userId === next.join.ownUserId });
        if (userId !== next.join.ownUserId && (safePatch.webcamEnabled || safePatch.sharingScreen)) refreshRemoteMedia('voice.state.mediaFlag');
      },
      onVoiceNewProducer: (event) => {
        if (!isActiveSubscriptionServer()) return;
        emitLiveDebug('voice.realtime.newProducer', { serverId, channelId: event.channelId, remoteId: event.remoteId, kind: event.kind, activeChannelId: currentVoiceChannelIdRef.current, own: event.remoteId === next.join.ownUserId });
        emitVoiceUiAudit('voice.realtime.newProducer', { serverId, channelId: event.channelId, remoteId: event.remoteId, kind: event.kind, activeChannelId: currentVoiceChannelIdRef.current, own: event.remoteId === next.join.ownUserId });
        if (currentVoiceChannelIdRef.current !== event.channelId) return;
        if (event.remoteId === next.join.ownUserId) return;
        markMediaState(event, true);
        const engine = voiceEngineRef.current;
        if (!engine) { setStatus(tr('Remote Stream wartet: Medien-Engine noch nicht bereit')); emitLiveDebug('voice.consume.noEngine', { remoteId: event.remoteId, kind: event.kind }, 'warn'); return; }
        void engine.consumeProducer(event.remoteId, String(event.kind).toLowerCase() as import('./voiceEngine').StreamKind).catch((err) => { const message = cleanError(err); emitLiveDebug('voice.consume.error', { remoteId: event.remoteId, kind: event.kind, error: message }, 'error', message); setStatus(tr(`Voice consume: ${message}`)); });
      },
      onVoiceProducerClosed: (event) => { if (!isActiveSubscriptionServer()) return; emitLiveDebug('voice.realtime.producerClosed', { serverId, channelId: event.channelId, remoteId: event.remoteId, kind: event.kind, activeChannelId: currentVoiceChannelIdRef.current }); if (currentVoiceChannelIdRef.current !== event.channelId) return; unmarkSpeaking(event); markMediaState(event, false); voiceEngineRef.current?.removeRemoteProducer(event.remoteId, String(event.kind).toLowerCase() as import('./voiceEngine').StreamKind); },
      onVoiceAddExternalStream: ({ channelId, streamId, stream }) => { if (!isActiveSubscriptionServer()) return; setExternalStreamsMap((current) => ({ ...current, [channelId]: { ...(current[channelId] ?? {}), [streamId]: stream } })); },
      onVoiceUpdateExternalStream: ({ channelId, streamId, stream }) => { if (!isActiveSubscriptionServer()) return; setExternalStreamsMap((current) => ({ ...current, [channelId]: { ...(current[channelId] ?? {}), [streamId]: stream } })); },
      onVoiceRemoveExternalStream: ({ channelId, streamId }) => { if (!isActiveSubscriptionServer()) return; setExternalStreamsMap((current) => { const channel = { ...(current[channelId] ?? {}) }; delete channel[streamId]; return { ...current, [channelId]: channel }; }); },
      onVoiceSoundboard: ({ soundId }) => playDesktopSound(`soundboard_${soundId}` as const),
          onVoiceReaction: ({ userId, emoji, file, expiresAt }) => {
        if (!isActiveSubscriptionServer()) return;
        setVoiceReactionsMap((current) => ({ ...current, [userId]: { emoji, file, expiresAt } }));
        window.setTimeout(() => {
          setVoiceReactionsMap((current) => current[userId]?.expiresAt === expiresAt ? Object.fromEntries(Object.entries(current).filter(([id]) => Number(id) !== userId)) as VoiceReactionState : current);
        }, Math.max(0, expiresAt - Date.now()));
      },
      onMessageNew: (message) => { setMessagesForEvent(message, 'new', serverId); if (message.userId !== next.join.ownUserId) { const notificationKind = shouldRecordNotificationItem(message, next, serverId); if (notificationKind) { addNotificationCenterItem(message, notificationKind, next, serverId); try { if (typeof Notification !== 'undefined' && Notification.permission === 'granted') new Notification(tr('Neue Sharkord-Nachricht'), { body: textFromHtml(message.content) || tr('Neue Nachricht') }); } catch { /* noop */ } } if (shouldPlayNotificationSound(next)) playDesktopSound('message_received'); } },
      onMessageUpdate: (message) => setMessagesForEvent(message, 'update', serverId),
      onMessageDelete: ({ channelId, messageId }) => {
        if (!serverId) return;
        applyDeletedMessageEvent(serverId, channelId, messageId, next);
      },
      onMessageTyping: ({ channelId, userId }) => { if (!isActiveSubscriptionServer()) return; setTypingUsers((current) => ({ ...current, [channelId]: [...new Set([...(current[channelId] ?? []), userId])] })); },
      onThreadReplyCountUpdate: (event) => applyThreadReplyCountUpdate(event, serverId),
      onDmConversationOpen: () => { if (serverId) void refreshDirectMessagesForServer(serverId, next); },
      onUserJoin: (user) => { const onlineUser = markUserOnline(user); next.join.users = upsertListById(next.join.users ?? [], onlineUser); if (!isActiveSubscriptionServer()) return; upsertById(setLiveUsers, onlineUser); },
      onUserLeave: (userId) => { next.join.users = (next.join.users ?? []).map((user) => user.id === userId ? { ...user, status: 'offline' } : user); if (!isActiveSubscriptionServer()) return; setLiveUsers((current) => current.map((user) => user.id === userId ? { ...user, status: 'offline' } : user)); },
      onUserCreate: (user) => { next.join.users = upsertListById(next.join.users ?? [], user); if (!isActiveSubscriptionServer()) return; upsertById(setLiveUsers, user); emitAdminRealtime('users', serverId, 'create', user); },
      onUserUpdate: (user) => { next.join.users = upsertUserListPreservingPresence(next.join.users ?? [], user); if (!isActiveSubscriptionServer()) return; setLiveUsers((current) => upsertUserListPreservingPresence(current, user)); emitAdminRealtime('users', serverId, 'update', user); },
      onUserDelete: (event) => { next.join.users = (next.join.users ?? []).filter((user) => user.id !== event.userId); if (!isActiveSubscriptionServer()) return; setLiveUsers((current) => current.filter((user) => user.id !== event.userId)); emitAdminRealtime('users', serverId, 'delete', event); },
      onChannelCreate: (channel) => { if (!isActiveSubscriptionServer()) return; upsertById(setLiveChannels, channel); },
      onChannelUpdate: (channel) => { if (!isActiveSubscriptionServer()) return; upsertById(setLiveChannels, channel); },
      onChannelDelete: (channelId) => {
        if (serverId) {
          setDirectMessagesByServer((current) => ({
            ...current,
            [serverId]: (current[serverId] ?? []).filter((conversation) => conversation.channelId !== channelId)
          }));
          const activeSelection = selectedDirectMessageRef.current;
          if (activeViewRef.current === 'dms' && activeSelection?.serverId === serverId && activeSelection.channelId === channelId) {
            visibleMessagesSourceRef.current = null;
            selectedDirectMessageRef.current = null;
            setSelectedDirectMessage(null);
            setMessages([]);
            setReplyTarget(null);
            setThreadPanel(null);
          }
        }
        if (!isActiveSubscriptionServer()) return;
        setLiveChannels((current) => current.filter((channel) => channel.id !== channelId));
      },
      onReadStateUpdate: ({ channelId, count }) => { if (!isActiveSubscriptionServer()) return; setReadStates((current) => ({ ...current, [channelId]: Math.max(0, Number(count ?? 0)) })); },
      onReadStateDelta: ({ channelId, delta }) => { if (!isActiveSubscriptionServer()) return; setReadStates((current) => ({ ...current, [channelId]: Math.max(0, (current[channelId] ?? 0) + Number(delta ?? 0)) })); },
      onPluginLog: (entry) => { if (!isActiveSubscriptionServer()) return; setStatus(`Plugin-Log: ${entry.pluginId ?? 'Plugin'} ${entry.message ?? ''}`.trim()); },
      onPluginCommandsChange: (commands) => { if (!isActiveSubscriptionServer()) return; next.join.commands = commands; setPluginCommandsByPlugin(commands); emitAdminRealtime('plugins', serverId, 'commands', commands); },
      onPluginComponentsChange: (pluginIdsWithComponents) => { if (!isActiveSubscriptionServer()) return; next.join.pluginIdsWithComponents = pluginIdsWithComponents; emitAdminRealtime('plugins', serverId, 'components', pluginIdsWithComponents); void refreshPluginComponentsForConnection(next, pluginIdsWithComponents); },
      onPluginMetadataChange: (metadata) => { if (!isActiveSubscriptionServer()) return; next.join.pluginsMetadata = metadata; pluginMetadataRef.current = metadata; setPluginMetadata(metadata); emitAdminRealtime('plugins', serverId, 'metadata', metadata); void refreshPluginComponentsForConnection(next, next.join.pluginIdsWithComponents ?? [], metadata); },
      onChannelPermissionsUpdate: (payload) => { if (!isActiveSubscriptionServer()) return; emitChannelPermissionsRealtime(serverId, payload); },
      onRoleCreate: (role) => { if (!isActiveSubscriptionServer()) return; upsertById(setAdminRoles, role); emitAdminRealtime('roles', serverId, 'create', role); },
      onRoleUpdate: (role) => { if (!isActiveSubscriptionServer()) return; upsertById(setAdminRoles, role); emitAdminRealtime('roles', serverId, 'update', role); },
      onRoleDelete: (roleId) => { if (!isActiveSubscriptionServer()) return; setAdminRoles((current) => current.filter((role) => role.id !== roleId)); emitAdminRealtime('roles', serverId, 'delete', roleId); },
      onEmojiCreate: (emoji) => { if (!isActiveSubscriptionServer()) return; emitAdminRealtime('emojis', serverId, 'create', emoji); },
      onEmojiUpdate: (emoji) => { if (!isActiveSubscriptionServer()) return; emitAdminRealtime('emojis', serverId, 'update', emoji); },
      onEmojiDelete: (emojiId) => { if (!isActiveSubscriptionServer()) return; emitAdminRealtime('emojis', serverId, 'delete', emojiId); },
      onServerSettingsUpdate: (settings) => {
        next.join.publicSettings = { ...(next.join.publicSettings ?? {}), ...(settings ?? {}) };
        if (!isActiveSubscriptionServer()) return;
        setServerInfo((current) => current ? { ...current, name: settings.name ?? current.name, logo: settings.logo ?? current.logo } : current);
        setState((current) => ({ ...current, servers: current.servers.map((server) => server.id === serverId ? { ...server, name: settings.name || server.name, logo: settings.logo ?? server.logo ?? null } : server) }));
        emitAdminRealtime('serverSettings', serverId, 'update', settings);
      },
      onCategoryCreate: (category) => { if (!isActiveSubscriptionServer()) return; upsertById(setLiveCategories, category); },
      onCategoryUpdate: (category) => { if (!isActiveSubscriptionServer()) return; upsertById(setLiveCategories, category); },
      onCategoryDelete: (categoryId) => { if (!isActiveSubscriptionServer()) return; setLiveCategories((current) => current.filter((category) => category.id !== categoryId)); },
      onError: (label, err) => {
        if (!isActiveSubscriptionServer()) return;
        void reconnectServerAfterRealtimeAuthFailure(serverId, next, label, err).then((handled) => {
          if (!handled) setStatus(tr(`${label}: ${cleanError(err)}`));
        });
      }
    });
    if (serverId) {
      unsubscribesRef.current.set(serverId, activeSubscription);
      if (serverId === activeServerIdRef.current) unsubscribeRef.current = activeSubscription;
    } else {
      unsubscribeRef.current = activeSubscription;
    }
  }

  function applyThreadReplyCountUpdate(event: { channelId: number; messageId: number; replyCount: number }, eventServerId?: string) {
    if (eventServerId) {
      const snapshot = serverSessionSnapshotsRef.current.get(eventServerId);
      if (snapshot?.messages?.length) {
        serverSessionSnapshotsRef.current.set(eventServerId, {
          ...snapshot,
          messages: updateReplyCountInMessages(snapshot.messages, event.messageId, event.replyCount)
        });
      }
    }
    setThreadPanel((current) => current ? {
      ...current,
      parent: current.parent.id === event.messageId ? { ...current.parent, replyCount: event.replyCount } : current.parent,
      messages: updateReplyCountInMessages(current.messages, event.messageId, event.replyCount)
    } : current);
    const source = visibleMessagesSourceRef.current;
    const matchesChat = source?.view === 'chat' && activeViewRef.current === 'chat' && source.channelId === event.channelId && source.serverId === eventServerId && eventServerId === activeServerIdRef.current;
    const matchesDm = source?.view === 'dms' && activeViewRef.current === 'dms' && source.serverId === eventServerId && source.channelId === event.channelId;
    if (matchesChat || matchesDm) setMessages((current) => updateReplyCountInMessages(current, event.messageId, event.replyCount));
  }
  function applyDeletedMessageEvent(serverId: string, channelId: number, messageId: number, conn?: SharkordConnection) {
    const snapshot = serverSessionSnapshotsRef.current.get(serverId);
    if (snapshot?.messages?.some((message) => message.id === messageId || message.channelId === channelId)) {
      serverSessionSnapshotsRef.current.set(serverId, {
        ...snapshot,
        messages: snapshot.messages.filter((message) => message.id !== messageId)
      });
    }
    setThreadPanel((current) => current ? {
      ...current,
      messages: current.messages.filter((message) => message.id !== messageId),
      parent: current.parent.id === messageId ? { ...current.parent, content: tr('Nachricht gelöscht') } : current.parent
    } : current);
    const source = visibleMessagesSourceRef.current;
    const matchesChat = source?.view === 'chat' && activeViewRef.current === 'chat' && source.channelId === channelId && source.serverId === serverId && serverId === activeServerIdRef.current;
    const matchesDm = source?.view === 'dms' && activeViewRef.current === 'dms' && source.serverId === serverId && source.channelId === channelId;
    setMessages((current) => (matchesChat || matchesDm) ? current.filter((message) => message.id !== messageId) : current);
    if (conn) void refreshDirectMessagesForServer(serverId, conn);
  }
  function setMessagesForEvent(message: SharkordMessage, mode: 'new' | 'update', eventServerId?: string) {
    setMessages((current) => {
      const source = visibleMessagesSourceRef.current;
      const matchesChat = source?.view === 'chat' && activeViewRef.current === 'chat' && source.channelId === message.channelId && source.serverId === eventServerId && eventServerId === activeServerIdRef.current;
      const matchesDm = source?.view === 'dms' && activeViewRef.current === 'dms' && source.serverId === eventServerId && source.channelId === message.channelId;
      if (!matchesChat && !matchesDm) return current;
      const without = current.filter((item) => item.id !== message.id);
      const next = mode === 'new' ? [...without, message] : [...without, message];
      return next.sort((a, b) => a.createdAt - b.createdAt);
    });
  }
  function messageMatchesRoleMention(message: SharkordMessage, conn: SharkordConnection) {
    const ownUserRoleIds = new Set(conn.join.users.find((user) => user.id === conn.join.ownUserId)?.roleIds ?? []);
    if (!ownUserRoleIds.size) return false;
    if (conn.serverCapabilities.roleMentionFanout && message.mentionedRoleIds?.some((roleId) => ownUserRoleIds.has(roleId))) return true;
    const body = textFromHtml(message.content).toLowerCase();
    return adminRoles.some((role) => role.mentionable && ownUserRoleIds.has(role.id) && body.includes(`@&${role.name.toLowerCase()}`));
  }
  function messageMentionsOwnUser(message: SharkordMessage, conn: SharkordConnection) {
    const own = conn.join.users.find((user) => user.id === conn.join.ownUserId);
    const body = textFromHtml(message.content).toLowerCase();
    const needles = [own?.name, own?.identity, String(conn.join.ownUserId)].filter(Boolean).map((value) => String(value).toLowerCase());
    return needles.some((needle) => body.includes(`@${needle}`)) || messageMatchesRoleMention(message, conn);
  }
  function shouldPlayNotificationSound(conn: SharkordConnection) {
    return !conn.serverCapabilities.notificationSoundControls || notificationSettings.notificationSounds;
  }

  function shouldRecordNotificationItem(message: SharkordMessage, conn: SharkordConnection, eventServerId?: string): NotificationCenterKind | null {
    if (notificationCenterMuted || !eventServerId) return null;
    const channel = conn.join.channels.find((item) => item.id === message.channelId);
    const isDm = !!channel?.isDm;
    const isReply = !!message.parentMessageId;
    const isMention = messageMentionsOwnUser(message, conn);
    if (isDm && notificationSettings.dms) return 'dm';
    if (isMention && notificationSettings.mentions) return 'mention';
    if (isReply && notificationSettings.replies) return 'reply';
    if (notificationSettings.allMessages) return 'message';
    return null;
  }
  function addNotificationCenterItem(message: SharkordMessage, kind: NotificationCenterKind, conn: SharkordConnection, eventServerId?: string) {
    if (!eventServerId) return;
    const server = state.servers.find((item) => item.id === eventServerId);
    const channel = conn.join.channels.find((item) => item.id === message.channelId);
    const author = message.user || message.author || conn.join.users.find((user) => user.id === message.userId);
    const item: NotificationCenterItem = {
      id: `${eventServerId}:${message.channelId}:${message.id}`,
      kind,
      serverId: eventServerId,
      serverName: server?.name || conn.join.serverName || tr('Server'),
      channelId: message.channelId,
      channelName: channel?.isDm ? tr('Direktnachricht') : (channel?.name ? `#${channel.name}` : `#${message.channelId}`),
      messageId: message.id,
      authorId: message.userId,
      authorName: displayUserName(author),
      body: textFromHtml(message.content) || tr('Neue Nachricht'),
      createdAt: message.createdAt || Date.now(),
      read: false
    };
    setNotificationCenterItems((current) => [item, ...current.filter((existing) => existing.id !== item.id)].slice(0, 32));
  }
  function markNotificationCenterRead() { setNotificationCenterItems((current) => current.map((item) => ({ ...item, read: true }))); }
  function clearNotificationCenter() { setNotificationCenterItems([]); }
  async function openNotificationCenterItem(item: NotificationCenterItem) {
    setNotificationCenterItems((current) => current.map((row) => row.id === item.id ? { ...row, read: true } : row));
    const conn = connectionsRef.current.get(item.serverId);
    if (!conn) { setStatus(tr('Benachrichtigung kann nicht geöffnet werden: Server nicht verbunden')); return; }
    const dmEntry = directMessageEntries.find((entry) => entry.server.id === item.serverId && entry.channel.id === item.channelId);
    if (dmEntry) await loadDirectMessage(dmEntry);
    else {
      if (activeServer?.id !== item.serverId) setState((current) => ({ ...current, activeServerId: item.serverId }));
      await loadMessages(conn, item.channelId);
    }
    await onGlobalSearchJump(item.channelId, item.messageId);
    setNotificationCenterOpen(false);
  }
  function addVoiceUser(channelId: number, userId: number, nextState?: Partial<VoiceState> | null) {
    setVoiceMap((current) => ({ ...current, [channelId]: { users: { ...(current[channelId]?.users ?? {}), [userId]: normalizeVoiceState(nextState) } } }));
  }
  function updateVoiceUser(channelId: number, userId: number, patch?: Partial<VoiceState> | null) {
    setVoiceMap((current) => {
      const previous = normalizeVoiceState(current[channelId]?.users?.[userId]);
      return { ...current, [channelId]: { users: { ...(current[channelId]?.users ?? {}), [userId]: { ...previous, ...normalizeVoiceStatePatch(patch) } } } };
    });
  }
  function removeVoiceUser(channelId: number, userId: number) {
    setVoiceMap((current) => {
      const users = { ...(current[channelId]?.users ?? {}) };
      delete users[userId];
      return { ...current, [channelId]: { users } };
    });
    setSpeakingUserIds((current) => { const next = new Set(current); next.delete(userId); return next; });
  }
  function unmarkSpeaking(event: VoiceProducerEvent) {
    if (String(event.kind).toLowerCase() !== 'audio') return;
    setSpeakingUserIds((current) => { const next = new Set(current); next.delete(event.remoteId); return next; });
  }
  function markMediaState(event: VoiceProducerEvent, active: boolean) {
    const kind = String(event.kind).toLowerCase();
    if (kind === 'video' || kind === 'external_video') updateVoiceUser(event.channelId, event.remoteId, { webcamEnabled: active });
    if (kind === 'screen') updateVoiceUser(event.channelId, event.remoteId, { sharingScreen: active });
  }

  async function applyAuthenticatedConnection(serverId: string, next: SharkordConnection, statusMessage?: string) {
    const firstTextChannel = next.join.channels.filter(isTextChannel).sort(byPosition)[0] ?? null;
    connectionsRef.current.set(serverId, next);
    serverSessionSnapshotsRef.current.set(serverId, snapshotFromConnection(serverId, next));
    void refreshDirectMessagesForServer(serverId, next);
    connectionRef.current = next;
    setConnection(next);
    setLiveUsers(next.join.users ?? []);
    setLiveChannels(next.join.channels ?? []);
    setLiveCategories(next.join.categories ?? []);
    setAdminRoles(next.join.roles ?? []);
    setVoiceMap(next.join.voiceMap ?? {});
    setVoiceReactionsMap({});
    setExternalStreamsMap((next.join.externalStreamsMap ?? {}) as Record<number, Record<number, SharkordExternalStream>>);
    setReadStates(next.join.readStates ?? {});
    void refreshAdminRoles(next);
    setSelectedVoiceId(null);
    setCurrentVoiceChannelId(null);
    wireSubscriptions(next, serverId);
    setSelectedChannelId(firstTextChannel?.id ?? null);
    setStatus(statusMessage ?? tr(`Verbunden mit ${next.join.serverName}`));
    playDesktopSound('server_connected');
    setWelcomeProfileSetupOpen(shouldShowWelcomeProfileSetup(next));
    if (firstTextChannel) await loadMessages(next, firstTextChannel.id);
  }

  async function connectWithAuth(nextAuth: AuthState) {
    if (!activeServer) return;
    const serverId = activeServer.id;
    if (connectingServerIdsRef.current.has(serverId)) { setStatus(tr('Verbindung läuft bereits...')); return; }
    connectingServerIdsRef.current.add(serverId);
    setBusy(true); setStatus(connectionsRef.current.has(serverId) ? tr('Verbinde neu...') : tr('Verbinde...'));
    try {
      cleanupServerSession(serverId, false);
      connectingServerIdsRef.current.add(serverId);
      const loginResult = await loginAndJoin({ serverUrl: activeServer.url, ...nextAuth });
      const next = loginResult;
      const savedAuth: AuthState = { ...nextAuth, totpCode: '', appPassword: loginResult.appPassword || nextAuth.appPassword };
      if (savedAuth.identity || savedAuth.password || savedAuth.serverPassword || savedAuth.invite || savedAuth.appPassword) await API.SaveServerCredentials(serverId, authToCreds(savedAuth));
      setAuth(savedAuth);
      await applyAuthenticatedConnection(serverId, next);
    } catch (err) {
      const message = cleanError(err);
      if (!nextAuth.totpCode && isTotpRequiredError(message)) {
        setPendingTotpAuth(nextAuth);
        setTotpCodeInput('');
        setTotpError('');
        setStatus(tr('Two-factor code required'));
      } else {
        if (nextAuth.totpCode) setTotpError(message);
        setStatus(message);
      }
      playDesktopSound('server_disconnected');
    } finally { connectingServerIdsRef.current.delete(serverId); setBusy(false); }
  }
  async function connectNative(event?: FormEvent<HTMLFormElement>) { event?.preventDefault(); await connectWithAuth({ ...auth, totpCode: '' }); }
  async function submitTotpCode(event?: FormEvent<HTMLFormElement>) {
    event?.preventDefault();
    if (!pendingTotpAuth || !totpCodeInput.trim()) return;
    const nextAuth = { ...pendingTotpAuth, totpCode: totpCodeInput.trim() };
    setTotpError('');
    await connectWithAuth(nextAuth);
    if (connectionsRef.current.has(activeServer?.id ?? '')) {
      setPendingTotpAuth(null);
      setTotpCodeInput('');
    }
  }
  function cancelTotpCode() { setPendingTotpAuth(null); setTotpCodeInput(''); setTotpError(''); }
  async function loadMessages(conn: SharkordConnection | null, channelId: number) {
    const requestServerId = serverIdForConnection(conn);
    if (!conn || !requestServerId) return;
    if (isActiveServerRequest(requestServerId)) {
      const activeChannel = conn.join.channels.find(
        (channel) => channel.id === channelId
      );
      const activeVoiceTextChat =
        conn.serverCapabilities.voiceTextChatCoupling &&
        !!activeChannel &&
        isVoiceChannel(activeChannel);
      visibleMessagesSourceRef.current = null;
      setMessages([]);
      setBusy(true);
      setActiveView('chat');
      activeViewRef.current = 'chat';
      setSelectedVoiceId(activeVoiceTextChat ? channelId : null);
      setSelectedDirectMessage(null);
      selectedDirectMessageRef.current = null;
      setSelectedChannelId(channelId);
      selectedChannelIdRef.current = channelId;
    }
    try {
      const page = await getChannelMessages(conn, channelId, 50);
      const rows = [...page.messages].sort((a, b) => a.createdAt - b.createdAt);
      snapshotMessagesForServer(requestServerId, channelId, rows);
      if (!isActiveServerRequest(requestServerId)) return;
      visibleMessagesSourceRef.current = { view: 'chat', serverId: requestServerId, channelId };
      setMessages(rows);
      setSelectedChannelId(channelId);
      setSelectedDirectMessage(null);
      setReplyTarget(null);
      setThreadPanel(null);
      setTypingUsers((current) => ({ ...current, [channelId]: [] }));
      setReadStates((current) => ({ ...current, [channelId]: 0 }));
      void markChannelAsRead(conn, channelId).catch(() => undefined);
    }
    catch (err) { if (isActiveServerRequest(requestServerId)) setStatus(tr(`Nachrichten konnten nicht geladen werden: ${cleanError(err)}`)); }
    finally { if (isActiveServerRequest(requestServerId)) setBusy(false); }
  }

  async function loadDirectMessage(entry: DirectMessageEntry) {
    const conn = entry.connection;
    const selection = { serverId: entry.server.id, channelId: entry.channel.id };
    visibleMessagesSourceRef.current = null;
    setMessages([]);
    setBusy(true);
    setActiveView('dms');
    activeViewRef.current = 'dms';
    setSelectedVoiceId(null);
    setSelectedChannelId(null);
    selectedChannelIdRef.current = null;
    setSelectedDirectMessage(selection);
    selectedDirectMessageRef.current = selection;
    setReplyTarget(null);
    setThreadPanel(null);
    try {
      const page = await getChannelMessages(conn, entry.channel.id, 50);
      const activeSelection = selectedDirectMessageRef.current;
      const stillSelected = activeViewRef.current === 'dms' && activeSelection?.serverId === entry.server.id && activeSelection.channelId === entry.channel.id;
      if (!stillSelected) return;
      const rows = [...page.messages].sort((a, b) => a.createdAt - b.createdAt);
      visibleMessagesSourceRef.current = { view: 'dms', serverId: entry.server.id, channelId: entry.channel.id };
      setMessages(rows);
      setDirectMessagesByServer((current) => ({ ...current, [entry.server.id]: (current[entry.server.id] ?? []).map((conversation) => conversation.channelId === entry.channel.id ? { ...conversation, unreadCount: 0 } : conversation) }));
      void markChannelAsRead(conn, entry.channel.id).catch(() => undefined);
      setStatus(tr(`Direct Message · ${entry.server.name}`));
    } catch (err) {
      const activeSelection = selectedDirectMessageRef.current;
      if (activeViewRef.current === 'dms' && activeSelection?.serverId === entry.server.id && activeSelection.channelId === entry.channel.id) setStatus(tr(`Direktnachrichten konnten nicht geladen werden: ${cleanError(err)}`));
    } finally {
      const activeSelection = selectedDirectMessageRef.current;
      if (activeViewRef.current === 'dms' && activeSelection?.serverId === entry.server.id && activeSelection.channelId === entry.channel.id) setBusy(false);
    }
  }

  async function selectVoice(channel: SharkordChannel) {
    clearTransientVoiceOverlays('voice.select.clearOverlays');
    setSelectedVoiceId(channel.id);
    setSelectedChannelId(null);
    selectedChannelIdRef.current = null;
    visibleMessagesSourceRef.current = null;
    setMessages([]);
    setReplyTarget(null);
    setThreadPanel(null);
    emitVoiceUiAudit('voice.select.afterState', { channelId: channel.id, channelName: channel.name });
    if (!connection) return;
    await joinSelectedVoice(channel);
  }
  async function openVoiceTextChat(channel: SharkordChannel) {
    if (!connection) return;
    if (!isVoiceChannel(channel) || !connection.serverCapabilities.voiceTextChatCoupling) { setChannelActionStatus(tr('Voice-Textchat wird von diesem Server nicht unterstützt.')); return; }
    await loadMessages(connection, channel.id);
    setChannelActionStatus(tr(`Textchat geöffnet: #${channel.name}`));
  }
  async function initVoiceMediaForCurrentChannel(channel: SharkordChannel, routerRtpCapabilities: unknown) {
    if (!connection) throw new Error(tr('Nicht verbunden'));
    emitLiveDebug('voice.media.initForChannel.start', { channelId: channel.id, channelName: channel.name, hasRouterRtpCapabilities: !!routerRtpCapabilities });
    emitVoiceUiAudit('voice.media.initForChannel.start', { channelId: channel.id, channelName: channel.name, hasRouterRtpCapabilities: !!routerRtpCapabilities });
    const serverId = activeServer?.id;
    if (serverId) {
      voiceEnginesRef.current.get(serverId)?.close();
      voiceEnginesRef.current.delete(serverId);
    }
    voiceEngineRef.current = null; setVoiceMediaReady(false); setRemoteAudioStreams([]); setRemoteVideoStreams([]); setLocalAudioStream(null); setLocalVideoStream(null); setLocalScreenStream(null);
    const engine = new SharkordVoiceEngine(connection, audioSettings, {
      onRemoteAudioStreams: setRemoteAudioStreams,
      onRemoteVideoStreams: setRemoteVideoStreams,
      onLocalAudioStream: setLocalAudioStream,
      onLocalVideoStream: setLocalVideoStream,
      onLocalScreenStream: setLocalScreenStream,
      onStatus: (nextStatus) => { setStatus(nextStatus); emitLiveDebug('voice.status', { status: nextStatus }); },
      onDebug: (event, data, level, message) => emitLiveDebug(event, data, level, message),
      onLocalMediaEnded: (kind) => { emitLiveDebug('voice.localMediaEnded', { kind }, 'warn'); void onLocalMediaEnded(kind); }
    });
    voiceEngineRef.current = engine;
    if (serverId) voiceEnginesRef.current.set(serverId, engine);
    try {
      await engine.init(routerRtpCapabilities as never);
      if (!engine.isReadyToProduce()) throw new Error(tr('Producer transport fehlt'));
      setVoiceMediaReady(true);
      lastVoiceMediaErrorRef.current = '';
      engine.setMicMuted(voiceState.micMuted); engine.setSoundMuted(voiceState.soundMuted);
      setStatus(tr(`Voice verbunden: ${channel.name}`));
      emitLiveDebug('voice.media.initForChannel.ok', { channelId: channel.id });
      emitVoiceUiAudit('voice.media.initForChannel.ok', { channelId: channel.id });
    } catch (mediaError) {
      const message = cleanError(mediaError);
      lastVoiceMediaErrorRef.current = message;
      engine.close();
      if (serverId) voiceEnginesRef.current.delete(serverId);
      if (voiceEngineRef.current === engine) voiceEngineRef.current = null;
      setVoiceMediaReady(false);
      setStatus(tr(`Voice verbunden · Medien nicht bereit: ${message}`));
      emitLiveDebug('voice.media.initForChannel.error', { channelId: channel.id, error: message }, 'error', message);
      emitVoiceUiAudit('voice.media.initForChannel.error', { channelId: channel.id, error: message });
      throw mediaError;
    }
  }
  async function joinSelectedVoice(channel: SharkordChannel) {
    if (!connection) return;
    const cooldownRemainingMs = voiceJoinCooldownUntilRef.current - Date.now();
    if (cooldownRemainingMs > 0) {
      setStatus(tr(`Voice-Rate-Limit aktiv · bitte ${Math.ceil(cooldownRemainingMs / 1000)}s warten`));
      return;
    }
    if (voiceBusyRef.current) return;
    voiceBusyRef.current = true;
    setVoiceBusy(true);
    emitVoiceUiAudit('voice.join.before', { channelId: channel.id, channelName: channel.name });
    emitLiveDebug('voice.join.start', { channelId: channel.id, channelName: channel.name, voiceState, serverVoicePresence });
    const joinVoiceWithStaleRecovery = async (target: SharkordChannel) => {
      try {
        return await joinVoiceChannel(connection, target.id, voiceState) as { routerRtpCapabilities: unknown };
      } catch (joinError) {
        const message = cleanError(joinError);
        if (!message.includes('User already in a voice channel')) throw joinError;
        emitLiveDebug('voice.join.staleMembership', { channelId: target.id, error: message }, 'warn', message);
        setStatus(tr('Voice-Session aufräumen · Server meldet alte Voice-Mitgliedschaft'));
        await leaveVoiceChannel(connection).catch(() => undefined);
        removeVoiceUser(target.id, connection.join.ownUserId);
        return await joinVoiceChannel(connection, target.id, voiceState) as { routerRtpCapabilities: unknown };
      }
    };
    try {
      if (currentVoiceChannelId && currentVoiceChannelId !== channel.id) await leaveVoiceChannel(connection).catch(() => undefined);
      voiceRouterRtpCapabilitiesRef.current = null;
      if (activeServer) voiceRouterRtpCapabilitiesByServerRef.current.delete(activeServer.id);
      lastVoiceMediaErrorRef.current = '';
      const joinResult = await joinVoiceWithStaleRecovery(channel);
      emitLiveDebug('voice.join.ok', { channelId: channel.id, hasRouterRtpCapabilities: !!joinResult.routerRtpCapabilities });
      emitVoiceUiAudit('voice.join.afterServerOk', { channelId: channel.id, hasRouterRtpCapabilities: !!joinResult.routerRtpCapabilities });
      voiceRouterRtpCapabilitiesRef.current = joinResult.routerRtpCapabilities;
      if (activeServer) voiceRouterRtpCapabilitiesByServerRef.current.set(activeServer.id, joinResult.routerRtpCapabilities);
      currentVoiceChannelIdRef.current = channel.id;
      clearTransientVoiceOverlays('voice.join.ok.clearOverlays');
      setCurrentVoiceChannelId(channel.id); setSelectedVoiceId(channel.id); addVoiceUser(channel.id, connection.join.ownUserId, voiceState); setStatus(tr(`Voice beigetreten: ${channel.name} · Medien werden vorbereitet`));
      emitVoiceUiAudit('voice.join.afterLocalState', { channelId: channel.id });
      await initVoiceMediaForCurrentChannel(channel, joinResult.routerRtpCapabilities).catch(() => undefined);
      emitVoiceUiAudit('voice.join.afterMediaInit', { channelId: channel.id });
      playDesktopSound('own_user_joined_voice_channel');
    } catch (err) {
      const message = cleanError(err);
      lastVoiceMediaErrorRef.current = message;
      emitLiveDebug('voice.join.error', { channelId: channel.id, error: message }, 'error', message);
      emitVoiceUiAudit('voice.join.error', { channelId: channel.id, error: message });
      if (isRateLimitError(message)) {
        startVoiceJoinCooldown(60_000);
        setStatus(tr('Voice-Join pausiert: Rate-Limit aktiv. Bitte ca. 60 Sekunden warten, dann erneut versuchen.'));
      } else {
        setStatus(message.includes('User already in a voice channel') ? tr('Voice-Join blockiert: Server hält noch eine alte Voice-Session. Bitte andere Sharkord-Sessions schließen oder Server-VoiceRuntime neu starten.') : tr(`Voice-Join fehlgeschlagen: ${message}`));
      }
    }
    finally { voiceBusyRef.current = false; setVoiceBusy(false); }
  }
  async function leaveCurrentVoice() {
    if (!connection || !currentVoiceChannelId) return;
    setVoiceBusy(true);
    try {
      const old = currentVoiceChannelId;
      const serverId = activeServer?.id;
      currentVoiceChannelIdRef.current = null;
      voiceEngineRef.current?.close();
      if (serverId) {
        voiceEnginesRef.current.delete(serverId);
        voiceRouterRtpCapabilitiesByServerRef.current.delete(serverId);
      }
      voiceEngineRef.current = null; voiceRouterRtpCapabilitiesRef.current = null; lastVoiceMediaErrorRef.current = ''; setVoiceMediaReady(false); setRemoteAudioStreams([]); setRemoteVideoStreams([]); setLocalAudioStream(null); setLocalVideoStream(null); setLocalScreenStream(null); await leaveVoiceChannel(connection); removeVoiceUser(old, connection.join.ownUserId); setCurrentVoiceChannelId(null); setStatus(tr('Voice getrennt')); playDesktopSound('own_user_left_voice_channel'); emitLiveDebug('voice.leave.ok', { channelId: old });
    }
    catch (err) { const message = cleanError(err); emitLiveDebug('voice.leave.error', { error: message }, 'error', message); setStatus(tr(`Voice-Trennen fehlgeschlagen: ${message}`)); }
    finally { setVoiceBusy(false); }
  }
  async function prepareVoiceMediaIfNeeded() {
    if (voiceMediaReady && voiceEngineRef.current?.isReadyToProduce()) return true;
    if (!currentVoiceChannel) { setStatus(tr('Erst Voice beitreten')); return false; }
    const routerRtpCapabilities = voiceRouterRtpCapabilitiesRef.current;
    if (!routerRtpCapabilities) { setStatus(tr('Voice-Medien noch nicht bereit · Router-Capabilities fehlen, bitte Voice neu beitreten')); return false; }
    setVoiceMediaReady(false);
    setStatus(tr('Voice-Medien noch nicht bereit · Medien-Transport wird neu aufgebaut'));
    try {
      await initVoiceMediaForCurrentChannel(currentVoiceChannel, routerRtpCapabilities);
      return !!voiceEngineRef.current?.isReadyToProduce();
    } catch (err) {
      const message = cleanError(err) || lastVoiceMediaErrorRef.current || 'Unbekannter Medienfehler';
      lastVoiceMediaErrorRef.current = message;
      setStatus(tr(`Voice-Medien noch nicht bereit · ${message}`));
      return false;
    }
  }
  async function toggleMicMuted() {
    const next = { ...voiceState, micMuted: !voiceState.micMuted };
    setVoiceState(next); voiceEngineRef.current?.setMicMuted(next.micMuted); playDesktopSound(next.micMuted ? 'own_user_muted_mic' : 'own_user_unmuted_mic');
    if (connection && currentVoiceChannelId) { updateVoiceUser(currentVoiceChannelId, connection.join.ownUserId, { micMuted: next.micMuted }); await updateVoiceState(connection, { micMuted: next.micMuted }).catch((err) => setStatus(tr(`Mute fehlgeschlagen: ${cleanError(err)}`))); }
  }
  async function toggleSoundMuted() {
    const next = { soundMuted: !voiceState.soundMuted, micMuted: !voiceState.soundMuted ? true : voiceState.micMuted };
    setVoiceState(next); voiceEngineRef.current?.setMicMuted(next.micMuted); voiceEngineRef.current?.setSoundMuted(next.soundMuted); playDesktopSound(next.soundMuted ? 'own_user_muted_sound' : 'own_user_unmuted_sound');
    if (connection && currentVoiceChannelId) { updateVoiceUser(currentVoiceChannelId, connection.join.ownUserId, next); await updateVoiceState(connection, next).catch((err) => setStatus(tr(`Deafen fehlgeschlagen: ${cleanError(err)}`))); }
  }
  async function sendCurrentVoiceReaction(emoji: string) {
    if (!connection || !currentVoiceChannelId) { setStatus(tr('Erst Voice beitreten')); return; }
    if (!connection.serverCapabilities.voiceReactions) { setStatus(tr('Server unterstützt Voice-Reactions nicht.')); return; }
    try {
      const reactionValue = customEmojiReactionValue(emoji);
      await reactVoice(connection, reactionValue);
      const expiresAt = Date.now() + 3_000;
      setVoiceReactionsMap((current) => ({ ...current, [connection.join.ownUserId]: { emoji: reactionValue, expiresAt } }));
      window.setTimeout(() => {
        setVoiceReactionsMap((current) => current[connection.join.ownUserId]?.expiresAt === expiresAt ? Object.fromEntries(Object.entries(current).filter(([id]) => Number(id) !== connection.join.ownUserId)) as VoiceReactionState : current);
      }, 3_000);
    } catch (err) {
      setStatus(tr(`Voice-Reaction fehlgeschlagen: ${cleanError(err)}`));
    }
  }
  async function sendCurrentVoiceSoundboard(soundId: 'pop' | 'airhorn' | 'rimshot' | 'tada' | 'bonk') {
    if (!connection || !currentVoiceChannelId) { setStatus(tr('Erst Voice beitreten')); return; }
    if (!connection.serverCapabilities.voiceSoundboard) { setStatus(tr('Server unterstützt Soundboard nicht.')); return; }
    try {
      await playVoiceSoundboard(connection, soundId);
      playDesktopSound(`soundboard_${soundId}` as const);
    } catch (err) {
      setStatus(tr(`Soundboard fehlgeschlagen: ${cleanError(err)}`));
    }
  }
  async function recoverCurrentVoiceMedia() {
    if (!connection || !currentVoiceChannelId) { setStatus(tr('Erst Voice beitreten')); return; }
    if (!connection.serverCapabilities.voiceMediaRecovery) { setStatus(tr('Server unterstützt Voice-Recovery nicht.')); return; }
    try {
      const result = await recoverVoiceMedia(connection);
      if (result.consumerTransportReset) await voiceEngineRef.current?.recoverAfterServerMediaReset();
      const recoveredVideo = result.recoveredKinds.includes('video');
      const recoveredScreen = result.recoveredKinds.includes('screen') || result.recoveredKinds.includes('screen_audio');
      if (recoveredVideo) setVoiceState((current) => ({ ...current, webcamEnabled: false }));
      if (recoveredScreen) setVoiceState((current) => ({ ...current, sharingScreen: false }));
      if (result.recoveredKinds.length) updateVoiceUser(currentVoiceChannelId, connection.join.ownUserId, { webcamEnabled: recoveredVideo ? false : voiceState.webcamEnabled, sharingScreen: recoveredScreen ? false : voiceState.sharingScreen });
      setStatus(tr('Voice-Medien neu synchronisiert'));
    } catch (err) {
      setStatus(tr(`Voice-Recovery fehlgeschlagen: ${cleanError(err)}`));
    }
  }
  async function toggleWebcam() {
    if (!connection || !currentVoiceChannelId) { setStatus(tr('Erst Voice beitreten')); return; }
    emitLiveDebug('voice.webcam.toggle.start', { enabled: !!voiceState.webcamEnabled });
    if (!voiceMediaReady || !voiceEngineRef.current?.isReadyToProduce()) {
      if (!(await prepareVoiceMediaIfNeeded())) return;
    }
    const engine = voiceEngineRef.current;
    if (!engine) { setStatus(tr('Voice-Medien noch nicht bereit')); return; }
    const enabled = !!voiceState.webcamEnabled;
    try {
      if (enabled) {
        engine.stopWebcamStream();
        const next = { ...voiceState, webcamEnabled: false };
        setVoiceState(next); updateVoiceUser(currentVoiceChannelId, connection.join.ownUserId, { webcamEnabled: false });
        await updateVoiceState(connection, { webcamEnabled: false });
        emitLiveDebug('voice.webcam.toggle.ok', { enabled: false });
        setStatus(tr('Kamera aus'));
      } else {
        await engine.startWebcamStream();
        const next = { ...voiceState, webcamEnabled: true };
        setVoiceState(next); updateVoiceUser(currentVoiceChannelId, connection.join.ownUserId, { webcamEnabled: true });
        await updateVoiceState(connection, { webcamEnabled: true });
        emitLiveDebug('voice.webcam.toggle.ok', { enabled: true });
        setStatus(tr('Kamera aktiv'));
      }
    } catch (err) { const message = cleanError(err); emitLiveDebug('voice.webcam.toggle.error', { error: message }, 'error', message); setStatus(tr(`Kamera fehlgeschlagen: ${message}`)); }
  }
  async function toggleScreenShare() {
    if (!connection || !currentVoiceChannelId) { setStatus(tr('Erst Voice beitreten')); return; }
    emitLiveDebug('voice.screen.toggle.start', { enabled: !!voiceState.sharingScreen });
    const engine = voiceEngineRef.current;
    if (voiceState.sharingScreen) {
      if (!engine) { setStatus(tr('Voice-Medien noch nicht bereit')); return; }
      try {
        engine.stopScreenShareStream();
        const next = { ...voiceState, sharingScreen: false };
        setVoiceState(next); updateVoiceUser(currentVoiceChannelId, connection.join.ownUserId, { sharingScreen: false });
        await updateVoiceState(connection, { sharingScreen: false });
        emitLiveDebug('voice.screen.toggle.ok', { enabled: false });
        setStatus(tr('Bildschirmfreigabe beendet'));
      } catch (err) { const message = cleanError(err); emitLiveDebug('voice.screen.toggle.error', { error: message }, 'error', message); setStatus(tr(`Bildschirmfreigabe fehlgeschlagen: ${message}`)); }
      return;
    }
    setScreenShareSettingsOpen(true);
  }
  async function startScreenShareWithCurrentSettings() {
    if (!connection || !currentVoiceChannelId) { setStatus(tr('Erst Voice beitreten')); return; }
    setScreenShareSettingsOpen(false);
    emitLiveDebug('voice.screen.startFromSettings', { screenResolution: audioSettings.screenResolution, screenFps: audioSettings.screenFps, screenCodec: audioSettings.screenCodec, screenContentHint: audioSettings.screenContentHint, screenMaxBitrateMbps: audioSettings.screenMaxBitrateMbps, includeScreenAudio: audioSettings.includeScreenAudio });
    if (!voiceMediaReady || !voiceEngineRef.current?.isReadyToProduce()) {
      if (!(await prepareVoiceMediaIfNeeded())) return;
    }
    const engine = voiceEngineRef.current;
    if (!engine) { setStatus(tr('Voice-Medien noch nicht bereit')); return; }
    try {
      await engine.startScreenShareStream();
      const next = { ...voiceState, sharingScreen: true };
      setVoiceState(next); updateVoiceUser(currentVoiceChannelId, connection.join.ownUserId, { sharingScreen: true });
      await updateVoiceState(connection, { sharingScreen: true });
      emitLiveDebug('voice.screen.toggle.ok', { enabled: true });
      setStatus(tr('Bildschirmfreigabe aktiv'));
    } catch (err) { const message = cleanError(err); emitLiveDebug('voice.screen.toggle.error', { error: message }, 'error', message); setStatus(tr(`Bildschirmfreigabe fehlgeschlagen: ${message}`)); }
  }
  async function onLocalMediaEnded(kind: 'video' | 'screen') {
    if (!connection || !currentVoiceChannelId) return;
    if (kind === 'video') { setVoiceState((current) => ({ ...current, webcamEnabled: false })); updateVoiceUser(currentVoiceChannelId, connection.join.ownUserId, { webcamEnabled: false }); await updateVoiceState(connection, { webcamEnabled: false }).catch(() => undefined); }
    if (kind === 'screen') { setVoiceState((current) => ({ ...current, sharingScreen: false })); updateVoiceUser(currentVoiceChannelId, connection.join.ownUserId, { sharingScreen: false }); await updateVoiceState(connection, { sharingScreen: false }).catch(() => undefined); }
  }
  function messageActionContext(message: SharkordMessage) {
    const source = visibleMessagesSourceRef.current;
    const dmEntry = activeView === 'dms' ? selectedDirectMessageEntry : null;
    if (source?.view === 'dms' && dmEntry && source.serverId === dmEntry.server.id && source.channelId === dmEntry.channel.id && message.channelId === source.channelId) {
      return {
        conn: dmEntry.connection,
        channelId: dmEntry.channel.id,
        reload: () => {
          const current = visibleMessagesSourceRef.current;
          if (current?.view === 'dms' && current.serverId === dmEntry.server.id && current.channelId === dmEntry.channel.id) return loadDirectMessage(dmEntry);
          return Promise.resolve();
        },
        source
      };
    }
    if (source?.view === 'chat' && connection && selectedChannelId && source.serverId === activeServer?.id && source.channelId === selectedChannelId && message.channelId === source.channelId) {
      const serverId = activeServer.id;
      const channelId = selectedChannelId;
      const conn = connection;
      return {
        conn,
        channelId,
        reload: () => {
          const current = visibleMessagesSourceRef.current;
          if (current?.view === 'chat' && current.serverId === serverId && current.channelId === channelId && serverId === activeServerIdRef.current) return loadMessages(conn, channelId);
          return Promise.resolve();
        },
        source
      };
    }
    return null;
  }
  async function openThreadPanel(parent: SharkordMessage) {
    const ctx = messageActionContext(parent);
    if (!ctx) return;
    setThreadPanel({ parent, messages: [], status: tr('Thread wird geladen...'), loading: true });
    try {
      const page = await getThreadMessages(ctx.conn, parent.channelId, parent.id, 50);
      setThreadPanel({ parent, messages: [...page.messages].sort((a, b) => a.createdAt - b.createdAt), status: tr('Thread'), loading: false });
    } catch (err) {
      setThreadPanel({ parent, messages: [], status: tr(`Thread konnte nicht geladen werden: ${cleanError(err)}`), loading: false });
    }
  }
  async function sendThreadMessage(parent: SharkordMessage, plainText: string, files: SharkordTempFile[] = []): Promise<boolean> {
    const ctx = messageActionContext(parent);
    if (!ctx || (!plainText.trim() && files.length === 0)) return false;
    try {
      await sendChannelMessage(ctx.conn, parent.channelId, plainText.trim(), files, { parentMessageId: parent.id });
      playDesktopSound('message_sent');
      await ctx.reload();
      await openThreadPanel(parent);
      return true;
    } catch (err) { setStatus(tr(`Thread-Senden fehlgeschlagen: ${cleanError(err)}`)); return false; }
  }
  async function sendMessage(event: FormEvent<HTMLFormElement>, files: SharkordTempFile[] = []): Promise<boolean> {
    event.preventDefault();
    const text = composer.trim();
    const dmEntry = activeView === 'dms' ? selectedDirectMessageEntry : null;
    if (!text && files.length === 0) return false;
    setComposer('');
    if (dmEntry) {
      const conn = dmEntry.connection;
      const targetChannelId = dmEntry.channel.id;
      const source = visibleMessagesSourceRef.current;
      const sourceMatchesDm = source?.view === 'dms' && source.serverId === dmEntry.server.id && source.channelId === targetChannelId;
      if (!sourceMatchesDm) { setStatus(tr('Direktnachrichten werden geladen…')); setComposer(text); return false; }
      try {
        await sendChannelMessage(conn, targetChannelId, text, files, { parentMessageId: undefined });
        setReplyTarget(null);
        playDesktopSound('message_sent');
        const current = visibleMessagesSourceRef.current;
        if (current?.view === 'dms' && current.serverId === dmEntry.server.id && current.channelId === targetChannelId) await loadDirectMessage(dmEntry);
        return true;
      }
      catch (err) { setStatus(tr(`Senden fehlgeschlagen: ${cleanError(err)}`)); setComposer(text); return false; }
    }
    const targetChannelId = replyTarget?.channelId ?? selectedChannelId;
    const source = visibleMessagesSourceRef.current;
    if (!connection || !targetChannelId || source?.view !== 'chat' || source.serverId !== activeServer?.id || source.channelId !== targetChannelId) { setComposer(text); return false; }
    const conn = connection;
    const serverId = activeServer.id;
    try {
      await sendChannelMessage(conn, targetChannelId, text, files, { parentMessageId: replyTarget?.id });
      setReplyTarget(null);
      playDesktopSound('message_sent');
      const current = visibleMessagesSourceRef.current;
      if (current?.view === 'chat' && current.serverId === serverId && current.channelId === targetChannelId && serverId === activeServerIdRef.current) await loadMessages(conn, targetChannelId);
      return true;
    }
    catch (err) { setStatus(tr(`Senden fehlgeschlagen: ${cleanError(err)}`)); setComposer(text); return false; }
  }
  async function onEditMessage(message: SharkordMessage, plainText: string, files: SharkordTempFile[] = []) {
    const ctx = messageActionContext(message);
    if (!ctx) return;
    try {
      if (files.length > 0) await editMessage(ctx.conn, message.id, plainText, files);
      else await editMessage(ctx.conn, message.id, plainText);
      await ctx.reload(); setStatus(tr('Nachricht bearbeitet'));
    }
    catch (err) { setStatus(tr(`Bearbeiten fehlgeschlagen: ${cleanError(err)}`)); }
  }
  async function onDeleteMessage(message: SharkordMessage) {
    const ctx = messageActionContext(message);
    if (!ctx) return;
    setStatus(tr('Nachricht wird gelöscht…'));
    applyDeletedMessageEvent(ctx.source.serverId, message.channelId, message.id, ctx.conn);
    try {
      await deleteMessage(ctx.conn, message.id);
      await ctx.reload();
      setStatus(tr('Nachricht gelöscht'));
    } catch (err) {
      setStatus(tr(`Löschen fehlgeschlagen: ${cleanError(err)}`));
      await ctx.reload().catch(() => undefined);
    }
  }
  async function onTogglePin(message: SharkordMessage) {
    const ctx = messageActionContext(message);
    if (!ctx) return;
    if (ctx.source.view === 'dms' && !ctx.conn.serverCapabilities.directMessagePinning) {
      setStatus(tr('DM-Anpinnen wird von diesem Server nicht unterstützt'));
      return;
    }
    try { await toggleMessagePin(ctx.conn, message.id); await ctx.reload(); setStatus(tr('Pin-Status geändert')); }
    catch (err) { setStatus(tr(`Pin fehlgeschlagen: ${cleanError(err)}`)); }
  }
  async function onToggleReaction(message: SharkordMessage, emoji = '👍') {
    const ctx = messageActionContext(message);
    if (!ctx) return;
    try { await toggleReaction(ctx.conn, message.id, emoji); await ctx.reload(); setStatus(tr('Reaktion geändert')); }
    catch (err) { setStatus(tr(`Reaktion fehlgeschlagen: ${cleanError(err)}`)); }
  }
  function visibleMessageSourceContext(channelId?: number) {
    const source = visibleMessagesSourceRef.current;
    const dmEntry = activeView === 'dms' ? selectedDirectMessageEntry : null;
    if (source?.view === 'dms' && dmEntry && source.serverId === dmEntry.server.id && source.channelId === dmEntry.channel.id && (channelId == null || channelId === source.channelId)) return { source, conn: dmEntry.connection };
    if (source?.view === 'chat' && connection && source.serverId === activeServer?.id && source.serverId === activeServerIdRef.current && (channelId == null || channelId === source.channelId)) return { source, conn: connection };
    return null;
  }
  async function jumpToMessage(messageId: number) {
    const ctx = visibleMessageSourceContext();
    if (!ctx) return;
    const { source, conn } = ctx;
    try {
      const page = await getMessagePageAround(conn, source.channelId, messageId);
      const current = visibleMessagesSourceRef.current;
      if (!current || current.view !== source.view || current.serverId !== source.serverId || current.channelId !== source.channelId) return;
      const rows = [...page.messages].sort((a, b) => a.createdAt - b.createdAt);
      setMessages(rows);
      window.requestAnimationFrame(() => document.querySelector(`[data-message-id="${messageId}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }));
      setStatus(tr('Zur Nachricht gesprungen'));
    } catch (err) { setStatus(tr(`Springen fehlgeschlagen: ${cleanError(err)}`)); }
  }

  async function onGlobalSearchJump(channelId: number, messageId: number): Promise<boolean> {
    const visibleCtx = visibleMessageSourceContext(channelId);
    let source = visibleCtx?.source ?? null;
    let conn = visibleCtx?.conn ?? null;
    const targetServerId = activeServerIdRef.current ?? activeServer?.id ?? null;
    const targetChannel = connection?.join.channels.find((channel) => channel.id === channelId);
    if (!source && connection && targetServerId && targetChannel) {
      source = { view: 'chat', serverId: targetServerId, channelId };
      conn = connection;
      setActiveView('chat');
      activeViewRef.current = 'chat';
      setSelectedDirectMessage(null);
      selectedDirectMessageRef.current = null;
      setSelectedVoiceId(null);
      setSelectedChannelId(channelId);
      selectedChannelIdRef.current = channelId;
      setReplyTarget(null);
      setThreadPanel(null);
      visibleMessagesSourceRef.current = { view: 'chat', serverId: targetServerId, channelId };
      setMessages([]);
      setBusy(true);
    }
    if (!source || !conn) {
      setStatus(tr('Suchtreffer konnte nicht geöffnet werden: Channel nicht gefunden'));
      return false;
    }
    try {
      const page = await getMessagePageAround(conn, channelId, messageId);
      if (source.view === 'chat') {
        if (activeViewRef.current !== 'chat' || activeServerIdRef.current !== source.serverId || selectedChannelIdRef.current !== channelId) return false;
        setSelectedVoiceId(null);
        setSelectedChannelId(channelId);
      } else {
        const activeDirectMessage = selectedDirectMessageRef.current;
        if (!activeDirectMessage || activeViewRef.current !== 'dms' || activeDirectMessage.serverId !== source.serverId || activeDirectMessage.channelId !== channelId) return false;
      }
      visibleMessagesSourceRef.current = source;
      const rows = [...page.messages].sort((a, b) => a.createdAt - b.createdAt);
      setMessages(rows);
      setTypingUsers((current) => ({ ...current, [channelId]: [] }));
      setReadStates((current) => ({ ...current, [channelId]: 0 }));
      void markChannelAsRead(conn, channelId).catch(() => undefined);
      window.requestAnimationFrame(() => document.querySelector(`[data-message-id="${messageId}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }));
      setStatus(tr('Suchtreffer geöffnet'));
      return true;
    } catch (err) {
      setStatus(tr(`Suchtreffer konnte nicht geöffnet werden: ${cleanError(err)}`));
      return false;
    } finally {
      setBusy(false);
    }
  }

  function openServerMenu(event: React.MouseEvent<HTMLButtonElement>) {
    event.preventDefault();
    event.stopPropagation();
    const rect = event.currentTarget.getBoundingClientRect();
    const width = Math.min(260, window.innerWidth - 24);
    const left = Math.max(12, Math.min(rect.left, window.innerWidth - width - 12));
    const top = Math.max(12, Math.min(rect.bottom + 6, window.innerHeight - 12));
    setContextMenu(null);
    setUserProfilePopover(null);
    setServerDropdown((current) => current ? null : { left, top, width });
  }
  function openChannelMenu(event: React.MouseEvent, channel: SharkordChannel) {
    event.preventDefault();
    setContextMenu({ kind: 'channel', x: event.clientX, y: event.clientY, channel });
  }
  function openUserMenu(event: React.MouseEvent, user: SharkordUser) {
    event.preventDefault();
    if (isDeletedUserPlaceholder(user)) {
      setActionStatus(tr('Gelöschter Benutzer-Platzhalter kann nicht moderiert werden'));
      setContextMenu(null);
      return;
    }
    setContextMenu({ kind: 'user', x: event.clientX, y: event.clientY, user });
    void refreshAdminRoles();
  }
  function openUserProfilePopover(event: React.MouseEvent, user: SharkordUser, serverId = activeServer?.id) {
    event.preventDefault();
    event.stopPropagation();
    if (isDeletedUserPlaceholder(user)) {
      setActionStatus(tr('Gelöschter Benutzer-Platzhalter kann kein Profil anzeigen'));
      setUserProfilePopover(null);
      return;
    }
    setContextMenu(null);
    setUserProfilePopover({ x: event.clientX, y: event.clientY, user, serverId });
  }
  async function openDirectMessageForUser(server: SharkordServer, conn: SharkordConnection, user: SharkordUser) {
    if (user.id === conn.join.ownUserId || isDeletedUserPlaceholder(user)) return;
    try {
      setStatus(tr(`Direktnachricht mit ${displayUserName(user)} wird geöffnet…`));
      const { channelId } = await openDirectMessage(conn, user.id);
      await refreshDirectMessagesForServer(server.id, conn);
      const channel = conn.join.channels.find((item) => item.id === channelId) ?? { id: channelId, name: displayUserName(user), type: 'TEXT', categoryId: null, position: 0, isDm: true } as SharkordChannel;
      const entry = {
        server,
        connection: conn,
        channel: { ...channel, name: displayUserName(user), isDm: true },
        user,
        conversation: { channelId, userId: user.id, unreadCount: 0, lastMessageAt: Date.now() }
      } as DirectMessageEntry;
      await loadDirectMessage(entry);
    } catch (err) {
      setStatus(tr(`Direktnachricht öffnen fehlgeschlagen: ${cleanError(err)}`));
    }
  }
  async function openDirectMessageFromProfile(user: SharkordUser) {
    const profileServerId = userProfilePopover?.serverId ?? activeServer?.id;
    const conn = profileServerId ? connectionsRef.current.get(profileServerId) ?? connection : connection;
    const server = (profileServerId ? state.servers.find((item) => item.id === profileServerId) : null) ?? activeServer;
    if (!conn || !server) return;
    setUserProfilePopover(null);
    await openDirectMessageForUser(server, conn, user);
  }
  function openUserAdminFromProfile(user: SharkordUser) {
    if (userProfilePopover?.serverId && userProfilePopover.serverId !== activeServer?.id) {
      setActionStatus(tr('Benutzerverwaltung ist nur für den aktuell aktiven Server verfügbar'));
      return;
    }
    if (!userHasServerPermission(ownUser, adminRoles, ['MANAGE_USERS', 'ADMINISTRATOR'])) return;
    setAdminInitialTab('users');
    setAdminWorkbenchOpen(true);
    setUserProfilePopover(null);
    setActionStatus(`${t('profile.popover.manageUser')}: ${displayUserName(user)}`);
  }
  async function openDirectMessagesHome() {
    resetTransientUiForServerSwitch();
    setActiveView('dms');
    activeViewRef.current = 'dms';
    setSelectedChannelId(null);
    selectedChannelIdRef.current = null;
    setSelectedDirectMessage(null);
    selectedDirectMessageRef.current = null;
    visibleMessagesSourceRef.current = null;
    setMessages([]);
    setSelectedVoiceId(null);
    setReplyTarget(null);
    setThreadPanel(null);
    await refreshDirectMessages();
  }
  async function runAdminAction(label: string, action: () => Promise<void>) {
    if (!connection) { setActionStatus(tr('Erst verbinden')); return; }
    try { await action(); setActionStatus(tr(`${label}: OK`)); setContextMenu(null); }
    catch (err) { setActionStatus(tr(`${label}: ${cleanError(err)}`)); }
  }
  async function refreshAdminRoles(conn = connection) {
    if (!conn) return;
    try { setAdminRoles(await getRoles(conn)); }
    catch (err) { setActionStatus(tr(`Rollen laden: ${cleanError(err)}`)); }
  }
  async function loadInitialData(conn = connection) {
    if (!conn) return;
    await refreshAdminRoles(conn);
  }
  async function createServerCategory() {
    await runAdminAction(tr('Kategorie erstellen'), async () => {
      if (!connection) return;
      await createCategory(connection, prompt(tr('Kategorie-Name')) || tr('Neue Kategorie'));
    });
  }
  async function createServerChannel(type: 'TEXT' | 'VOICE' = 'TEXT') {
    await runAdminAction(tr(`${type}-Channel erstellen`), async () => {
      if (!connection) return;
      const categoryId = liveCategories[0]?.id;
      if (!categoryId) throw new Error(tr('Keine Kategorie vorhanden'));
      await createChannel(connection, { name: prompt(tr('Channel-Name')) || (type === 'VOICE' ? 'voice' : 'text'), type, categoryId });
    });
  }
  async function createServerInvite() {
    setAdminInitialTab('invites');
    setAdminWorkbenchOpen(true);
    setContextMenu(null);
    setActionStatus(tr('Einladungen geöffnet'));
  }
  async function editContextChannel(channel: SharkordChannel) {
    setContextMenu(null);
    if (!connection) return;
    setChannelActionStatus(tr(`Channel #${channel.name} Einstellungen werden geladen…`));
    try {
      const freshChannel = await getChannelDetail(connection, channel.id);
      setChannelSettingsOpen(freshChannel);
      setChannelActionStatus(tr(`Channel #${freshChannel.name} Einstellungen geöffnet`));
    } catch (err) {
      setChannelActionStatus(tr(`Channel-Einstellungen laden fehlgeschlagen: ${cleanError(err)}`));
    }
  }
  async function copyContextChannelLink(channel: SharkordChannel) {
    setContextMenu(null);
    if (!connection || !connection.serverCapabilities.channelLinks) { setChannelActionStatus(tr('Dieser Server unterstützt Channel-Links nicht.')); return; }
    const link = `sharkord://channel/${channel.id}`;
    try {
      await resolveChannelLink(connection, channel.id);
      await navigator.clipboard.writeText(link);
      setChannelActionStatus(tr(`Channel-Link kopiert: #${channel.name}`));
    } catch (err) {
      setChannelActionStatus(tr(`Channel-Link kopieren fehlgeschlagen: ${cleanError(err)}`));
    }
  }
  async function openChannelLinkTarget(channel: SharkordChannel) {
    setContextMenu(null);
    if (!connection || !connection.serverCapabilities.channelLinks) { setChannelActionStatus(tr('Dieser Server unterstützt Channel-Links nicht.')); return; }
    try {
      const target = await resolveChannelLink(connection, channel.id);
      const localChannel = liveChannels.find((item) => item.id === target.channelId) ?? { ...channel, id: target.channelId, name: target.name, type: target.type, categoryId: target.categoryId ?? channel.categoryId } as SharkordChannel;
      if (target.type === 'VOICE') await selectVoice(localChannel);
      else await loadMessages(connection, target.channelId);
      setChannelActionStatus(tr(`Channel-Link geöffnet: #${target.name}`));
    } catch (err) {
      setChannelActionStatus(tr(`Channel-Link öffnen fehlgeschlagen: ${cleanError(err)}`));
    }
  }
  function applyChannelSettingsUpdate(channel: SharkordChannel) {
    setLiveChannels((current) => current.map((item) => item.id === channel.id ? { ...item, ...channel } : item));
    setChannelSettingsOpen(channel);
  }
  function deleteContextChannel(channel: SharkordChannel) {
    setContextMenu(null);
    setPendingChannelDelete(channel);
    setChannelActionStatus(tr(`Channel #${channel.name} zum Löschen ausgewählt`));
  }
  function openCategoryMenu(event: React.MouseEvent, group: ChannelGroup) {
    if (group.id == null) return;
    event.preventDefault();
    const category = categories.find((item) => item.id === group.id);
    if (!category) return;
    setContextMenu({ kind: 'category', x: event.clientX, y: event.clientY, category, channelCount: group.channels.length });
  }
  async function editContextCategory(category: SharkordCategory) {
    setContextMenu(null);
    if (!connection) return;
    try {
      const freshCategory = await getCategoryDetail(connection, category.id);
      const name = prompt(tr('Kategorie-Name'), freshCategory.name)?.trim();
      if (!name || name === freshCategory.name) return;
      await runAdminAction(tr('Kategorie bearbeiten'), async () => {
        await updateCategory(connection, freshCategory.id, name);
        setLiveCategories((current) => current.map((item) => item.id === freshCategory.id ? { ...item, ...freshCategory, name } : item));
        await loadInitialData(connection);
        setChannelActionStatus(tr('Kategorie gespeichert'));
      });
    } catch (err) {
      setChannelActionStatus(tr(`Kategorie laden fehlgeschlagen: ${cleanError(err)}`));
    }
  }
  function deleteContextCategory(category: SharkordCategory, channelCount: number) {
    setContextMenu(null);
    setPendingCategoryDelete({ category, channelCount });
    setChannelActionStatus(tr(`Kategorie ${category.name} zum Löschen ausgewählt`));
  }
  async function confirmDeleteCategory() {
    if (!connection || !pendingCategoryDelete) return;
    const { category } = pendingCategoryDelete;
    setChannelActionStatus(tr(`Kategorie ${category.name} wird gelöscht…`));
    setActionStatus(tr('Kategorie löschen…'));
    try {
      await deleteCategory(connection, category.id);
      setLiveCategories((current) => current.filter((item) => item.id !== category.id));
      setLiveChannels((current) => current.filter((channel) => channel.categoryId !== category.id));
      setSelectedChannelId((current) => liveChannels.some((channel) => channel.id === current && channel.categoryId === category.id) ? null : current);
      setSelectedVoiceId((current) => liveChannels.some((channel) => channel.id === current && channel.categoryId === category.id) ? null : current);
      setMessages((current) => selectedChannel && selectedChannel.categoryId === category.id ? [] : current);
      await loadInitialData(connection);
      setPendingCategoryDelete(null);
      setChannelActionStatus(tr('Kategorie gelöscht'));
      setActionStatus(tr('Kategorie löschen: OK'));
    } catch (err) {
      const message = cleanError(err);
      setChannelActionStatus(tr(`Kategorie löschen fehlgeschlagen: ${message}`));
      setActionStatus(tr(`Kategorie löschen: ${message}`));
    }
  }
  async function confirmDeleteChannel() {
    if (!connection || !pendingChannelDelete) return;
    const channel = pendingChannelDelete;
    setChannelActionStatus(tr(`Channel #${channel.name} wird gelöscht…`));
    setActionStatus(tr('Channel löschen…'));
    try {
      await deleteChannel(connection, channel.id);
      setLiveChannels((current) => current.filter((item) => item.id !== channel.id));
      setSelectedChannelId((current) => current === channel.id ? null : current);
      setSelectedVoiceId((current) => current === channel.id ? null : current);
      setMessages((current) => selectedChannelId === channel.id ? [] : current);
      await loadInitialData(connection);
      setPendingChannelDelete(null);
      setChannelActionStatus(tr('Channel gelöscht'));
      setActionStatus(tr('Channel löschen: OK'));
    } catch (err) {
      const message = cleanError(err);
      setChannelActionStatus(tr(`Channel löschen fehlgeschlagen: ${message}`));
      setActionStatus(tr(`Channel löschen: ${message}`));
    }
  }
  function moderateContextUser(user: SharkordUser, action: 'kick' | 'ban' | 'unban' | 'delete') {
    if (isDeletedUserPlaceholder(user)) { setActionStatus(tr('Gelöschter Benutzer-Platzhalter kann nicht moderiert werden')); setContextMenu(null); return; }
    setContextMenu(null);
    setPendingAdminConfirm({ kind: 'moderate-user', user, action, reason: '', wipe: false });
  }
  async function disconnectContextVoiceUser(user: SharkordUser) {
    if (!connection || user.id === connection.join.ownUserId) return;
    setContextMenu(null);
    setPendingAdminConfirm({ kind: 'disconnect-voice-user', user });
  }
  async function stopContextUserVoiceMedia(user: SharkordUser, kind: 'video' | 'screen' | 'screen_audio') {
    if (!connection || user.id === connection.join.ownUserId) return;
    setContextMenu(null);
    await runAdminAction(kind === 'video' ? tr('Webcam stoppen') : tr('Screenshare stoppen'), async () => {
      await stopUserVoiceMedia(connection, user.id, kind);
      const sourceChannelId = findVoiceChannelIdForUser(voiceMap, user.id);
      if (sourceChannelId) {
        if (kind === 'video') updateVoiceUser(Number(sourceChannelId), user.id, { webcamEnabled: false });
        if (kind === 'screen' || kind === 'screen_audio') updateVoiceUser(Number(sourceChannelId), user.id, { sharingScreen: false });
      }
      voiceEngineRef.current?.removeRemoteProducer(user.id, kind as StreamKind);
      if (kind === 'screen') voiceEngineRef.current?.removeRemoteProducer(user.id, 'screen_audio' as StreamKind);
    });
  }
  async function confirmAdminAction(action: AdminConfirmAction) {
    setPendingAdminConfirm(null);
    if (action.kind === 'moderate-user') {
      const { user, action: moderationAction, reason, wipe } = action;
      await runAdminAction(moderationAction === 'delete' ? tr('User löschen') : `User ${moderationAction}`, async () => {
        if (connection) await moderateUser(connection, moderationAction, user.id, { reason: moderationAction === 'unban' ? undefined : reason.trim() || undefined, wipe });
      });
      return;
    }
    if (action.kind === 'disconnect-voice-user' && connection) {
      const { user } = action;
      await runAdminAction(tr('Voice trennen'), async () => {
        await disconnectVoiceUser(connection, user.id);
        const sourceChannelId = findVoiceChannelIdForUser(voiceMap, user.id);
        if (sourceChannelId) removeVoiceUser(Number(sourceChannelId), user.id);
      });
    }
  }
  async function toggleUserRole(user: SharkordUser, role: SharkordRole) {
    const hasRole = (user.roleIds ?? []).includes(role.id);
    await runAdminAction(hasRole ? tr('Rolle entfernen') : tr('Rolle hinzufügen'), async () => {
      if (!connection) return;
      if (hasRole) await removeRoleFromUser(connection, user.id, role.id);
      else await addRoleToUser(connection, user.id, role.id);
      const nextRoleIds = hasRole ? (user.roleIds ?? []).filter((id) => id !== role.id) : [...new Set([...(user.roleIds ?? []), role.id])];
      const patchUserRoles = (item: SharkordUser) => item.id === user.id ? { ...item, roleIds: nextRoleIds } : item;
      connection.join.users = (connection.join.users ?? []).map(patchUserRoles);
      setLiveUsers((current) => current.map(patchUserRoles));
      setContextMenu((current) => current?.kind === 'user' && current.user.id === user.id ? { ...current, user: patchUserRoles(current.user) } : current);
    });
  }
  function handleChannelDragStart(channel: SharkordChannel) {
    setDraggedChannelId(channel.id);
    setDraggedVoiceUserId(null);
    setDragOverChannelId(null);
    setChannelActionStatus(tr(`Channel #${channel.name} wird verschoben…`));
  }
  function handleVoiceUserDragStart(user: VoiceUser) {
    if (!connection?.serverCapabilities.voiceUserMove) return;
    if (user.id === connection.join.ownUserId) {
      setChannelActionStatus(tr('Eigenen Voice-Wechsel bitte per Voice beitreten ausführen'));
      return;
    }
    setDraggedVoiceUserId(user.id);
    setDraggedChannelId(null);
    setDragOverChannelId(null);
    setChannelActionStatus(tr(`${displayUserName(user)} wird verschoben…`));
  }
  async function handleVoiceUserDrop(target: SharkordChannel) {
    const userId = draggedVoiceUserId;
    setDraggedVoiceUserId(null);
    setDragOverChannelId(null);
    if (!connection || !userId || !isVoiceChannel(target)) return;
    const sourceChannelId = findVoiceChannelIdForUser(voiceMap, userId);
    if (sourceChannelId && Number(sourceChannelId) === target.id) return;
    const user = usersById.get(userId);
    try {
      await moveVoiceUser(connection, userId, target.id);
      setChannelActionStatus(tr(`${user ? displayUserName(user) : `User ${userId}`} verschoben nach ${target.name}`));
    } catch (err) {
      setChannelActionStatus(tr(`Voice verschieben fehlgeschlagen: ${cleanError(err)}`));
    }
  }
  async function handleChannelDrop(target: SharkordChannel, group: ChannelGroup) {
    const sourceId = draggedChannelId;
    setDraggedChannelId(null);
    setDraggedVoiceUserId(null);
    setDragOverChannelId(null);
    if (!connection || !sourceId || sourceId === target.id) return;
    const categoryId = group.id;
    if (categoryId == null) { setChannelActionStatus(tr('Channel verschieben: Kategorie fehlt')); return; }
    const sourceChannel = liveChannels.find((channel) => channel.id === sourceId);
    if (sourceChannel?.categoryId !== undefined && sourceChannel.categoryId !== categoryId && !connection.serverCapabilities.channelCrossCategoryMove) {
      setChannelActionStatus(tr('Dieser Server unterstützt Channels zwischen Kategorien verschieben nicht.'));
      return;
    }
    const ids = reorderIds(group.channels.map((channel) => channel.id), sourceId, target.id);
    const previous = liveChannels;
    const nextPositions = new Map(ids.map((id, index) => [id, index + 1]));
    setLiveChannels((current) => current.map((channel) => {
      if (nextPositions.has(channel.id)) return { ...channel, categoryId, position: nextPositions.get(channel.id)! };
      if (sourceChannel && channel.categoryId === sourceChannel.categoryId && channel.id !== sourceId) return { ...channel, position: Math.max(1, channel.position) };
      return channel;
    }));
    try {
      await reorderChannels(connection, categoryId, ids);
      await loadInitialData(connection);
      setChannelActionStatus(sourceChannel?.categoryId !== categoryId ? tr('Channel in Kategorie verschoben') : tr('Channel-Reihenfolge gespeichert'));
    } catch (err) {
      setLiveChannels(previous);
      setChannelActionStatus(tr(`Channel verschieben fehlgeschlagen: ${cleanError(err)}`));
    }
  }
  function handleCategoryDragStart(event: React.DragEvent, group: ChannelGroup) {
    if (group.id == null) return;
    const categoryId = group.id;
    event.dataTransfer.setData('application/x-sharkord-category-id', String(group.id));
    event.dataTransfer.effectAllowed = 'move';
    setDraggedCategoryId(categoryId);
    setDragOverCategoryId(null);
    setChannelActionStatus(tr(`Kategorie ${group.name} wird verschoben…`));
  }
  async function handleCategoryDrop(target: ChannelGroup) {
    const sourceId = draggedCategoryId;
    setDraggedCategoryId(null);
    setDragOverCategoryId(null);
    const targetId = target.id;
    if (!connection || !sourceId || targetId == null || sourceId === targetId) return;
    const ids = reorderIds(categories.map((category) => category.id), sourceId, targetId);
    const previous = liveCategories;
    const nextPositions = new Map(ids.map((id, index) => [id, index + 1]));
    setLiveCategories((current) => current.map((category) => nextPositions.has(category.id) ? { ...category, position: nextPositions.get(category.id)! } : category));
    try {
      await reorderCategories(connection, ids);
      await loadInitialData(connection);
      setChannelActionStatus(tr('Kategorie-Reihenfolge gespeichert'));
    } catch (err) {
      setLiveCategories(previous);
      setChannelActionStatus(tr(`Kategorie verschieben fehlgeschlagen: ${cleanError(err)}`));
    }
  }


  async function saveWelcomeProfileSetup(input: { name: string; bio: string; bannerColor: string; avatarFile: File | null }) {
    if (!connection) return;
    const trimmedName = input.name.trim();
    const trimmedBio = input.bio.trim();
    try {
      await updateOwnProfile(connection, { name: trimmedName, bio: trimmedBio, bannerColor: input.bannerColor });
      if (input.avatarFile) await changeOwnAvatar(connection, input.avatarFile);
      markWelcomeProfileSetupDone(connection);
      setWelcomeProfileSetupOpen(false);
      setLiveUsers((current) => current.map((user) => user.id === connection.join.ownUserId ? { ...user, name: trimmedName || user.name, bio: trimmedBio, bannerColor: input.bannerColor } : user));
      setStatus(tr('Profil eingerichtet'));
    } catch (err) {
      setStatus(tr(`Profil einrichten fehlgeschlagen: ${cleanError(err)}`));
      throw err;
    }
  }
  function openOwnProfile(serverId?: string | null) {
    setOwnProfileServerId(serverId ?? activeServer?.id ?? null);
    setOwnProfilePopupOpen(true);
  }
  function updateOwnUserPreview(input: { name?: string; bio?: string; bannerColor?: string; banner?: SharkordFile | null }) {
    const targetConnection = ownProfileConnection;
    if (!targetConnection) return;
    const updateUsers = (current: SharkordUser[]) => current.map((user) => {
      if (user.id !== targetConnection.join.ownUserId) return user;
      const next: SharkordUser = { ...user };
      if (input.name !== undefined) next.name = input.name.trim() || user.name;
      if (input.bio !== undefined) next.bio = input.bio.trim();
      if (input.bannerColor !== undefined) next.bannerColor = input.bannerColor;
      if (input.banner !== undefined) next.banner = input.banner;
      return next;
    });
    targetConnection.join.users = updateUsers(targetConnection.join.users);
    if (targetConnection === connection) setLiveUsers(updateUsers);
    else setDirectMessagesByServer((current) => ({ ...current }));
  }
  function skipWelcomeProfileSetup() {
    if (connection) markWelcomeProfileSetupDone(connection);
    setWelcomeProfileSetupOpen(false);
    setStatus(tr('Profil-Setup übersprungen'));
  }

  async function checkUpdates(info = appInfo, silent = false, channel = releaseChannel) {
    setUpdateStatus('checking');
    if (!silent) setUpdateMessage(tr(`Suche ${channel === 'beta' ? 'Beta' : 'Stable'} Release...`));
    try {
      const nextRelease = await API.GitHubRelease(channel); setRelease(nextRelease); const asset = compatibleAsset(info, nextRelease);
      if (info && nextRelease.version && semverGreater(nextRelease.version, info.version) && asset) { setUpdateStatus('available'); setStartupUpdateNoticeVisible(true); setUpdateMessage(tr(`Update ${info.version} → ${nextRelease.version} verfügbar (${nextRelease.channel || channel}, ${asset.name}, ${formatBytes(asset.size)})`)); }
      else { setStartupUpdateNoticeVisible(false); setUpdateStatus('current'); setUpdateMessage(nextRelease.version ? tr(`Aktuell: ${info?.version ?? tr('unbekannt')} · ${channel}: ${nextRelease.version}`) : tr('Kein passendes Release gefunden')); }
    } catch (err) { if (silent) setStartupUpdateNoticeVisible(false); setUpdateStatus('error'); setUpdateMessage(tr(`Update-Check fehlgeschlagen: ${cleanError(err)}`)); }
  }
  async function installSelectedUpdate() {
    if (!updateAsset || !updateAvailable) { setUpdateMessage(tr('Kein passendes neues Update ausgewählt.')); return; }
    try {
      setInstallingUpdate(true);
      if (connection && currentVoiceChannelId) {
        setUpdateMessage(tr('Verlasse Voice vor Update...'));
        await leaveCurrentVoice();
      }
      setUpdateMessage(tr(`Installiere ${release?.version} inplace...`));
      const result = await API.InstallUpdate(updateAsset);
      setUpdateMessage(tr(result));
    }
    catch (err) { setInstallingUpdate(false); setUpdateMessage(tr(`Installation fehlgeschlagen: ${cleanError(err)}`)); }
  }

  function setReleaseChannel(next: ReleaseChannel) {
    setRelease(null);
    setStartupUpdateNoticeVisible(false);
    setUpdateStatus('unknown');
    setUpdateMessage(tr('Release-Kanal geändert. Bitte erneut prüfen.'));
    setState((current) => ({ ...current, releaseChannel: next }));
  }
  function openUpdateSettings() {
    setStartupUpdateNoticeVisible(false);
    setSettingsInitialTab('updates');
    setActiveView('settings');
  }
  function setMainView(view: AppView) {
    if (view === 'settings') setSettingsInitialTab('appearance');
    setActiveView(view);
  }
  function setTheme(theme: ThemeMode) { setState((current) => ({ ...current, theme })); }
  function selectServer(serverId: string) {
    if (activeServer) snapshotServerSession(activeServer.id);
    resetTransientUiForServerSwitch();
    setMainView('chat');
    setState((current) => ({ ...current, activeServerId: serverId, servers: current.servers.map((server) => server.id === serverId ? { ...server, lastOpenedAt: Date.now() } : server) }));
  }
  async function removeActiveServer() {
    if (!activeServer) return;
    setPendingServerRemoval(activeServer);
    setChannelActionStatus(tr('Bereit'));
  }
  async function confirmServerRemoval() {
    if (!pendingServerRemoval) return;
    const serverId = pendingServerRemoval.id;
    cleanupServerSession(serverId, true);
    setState((current) => { const servers = current.servers.filter((server) => server.id !== serverId); if (servers.length === 0) allowEmptyServersSaveRef.current = true; return { ...current, servers, activeServerId: servers[0]?.id ?? null }; });
    setPendingServerRemoval(null);
    setStatus(tr('Server entfernt'));
    setChannelActionStatus(tr('Server entfernt'));
    void API.DeleteServerCredentials(serverId).catch((err) => setStatus(tr(`Server entfernt · Credentials nicht gelöscht: ${cleanError(err)}`)));
  }
  function openAddServerModal() {
    setError('');
    setModalOpen(true);
  }
  function closeAddServerModal() {
    setError('');
    setModalOpen(false);
  }
  function handleAddServerUrlChange(value: string) {
    const parsed = splitServerUrlAndInvite(value);
    setUrl(parsed.serverUrl || value);
    if (parsed.invite) setNewCreds({ ...newCreds, invite: parsed.invite });
  }
  async function submitServer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!url.trim()) {
      setError(tr('Bitte Server-URL eintragen, z. B. https://sharkord.example.tld'));
      return;
    }
    try {
      const server = createServer({ name, url, autoConnect: autoConnectChecked });
      const info = await fetchServerInfo(server.url).catch(() => null);
      const serverWithLogo: SharkordServer = { ...server, name: name.trim() ? server.name : (info?.name || server.name), logo: info?.logo ?? null };
      if (newCreds.identity || newCreds.password || newCreds.serverPassword || newCreds.invite) await API.SaveServerCredentials(serverWithLogo.id, authToCreds(newCreds));
      setState((current) => ({ ...current, servers: [...current.servers, serverWithLogo], activeServerId: serverWithLogo.id }));
      setName(''); setUrl(''); setAutoConnectChecked(true); setNewCreds(emptyAuth); setError(''); closeAddServerModal(); setAuth(newCreds); setMainView('chat');
    } catch (err) { setError(cleanError(err) || tr('Bitte gültige Sharkord-URL eintragen, z. B. https://sharkord.example.tld')); }
  }

  function openGlobalSearchFromPalette() {
    setMainView('chat');
    window.requestAnimationFrame(() => window.dispatchEvent(new CustomEvent('sharkord:open-global-search')));
  }
  const commandPaletteItems = useMemo<CommandPaletteItem[]>(() => {
    const serverItems = state.servers.map((server) => ({
      id: `server:${server.id}`,
      kind: 'server' as const,
      label: server.name,
      detail: tr('Server'),
      keywords: `${server.name} ${server.url} server`,
      action: () => selectServer(server.id)
    }));
    const textItems = activeServer ? textChannels.map((channel) => ({
      id: `text:${activeServer.id}:${channel.id}`,
      kind: 'text' as const,
      label: `#${channel.name}`,
      detail: `${activeServer.name} · ${tr('Text-Channel')}`,
      keywords: `${channel.name} ${activeServer.name} text channel`,
      action: () => { if (connection) void loadMessages(connection, channel.id); }
    })) : [];
    const voiceItems = activeServer ? voiceChannels.map((channel) => ({
      id: `voice:${activeServer.id}:${channel.id}`,
      kind: 'voice' as const,
      label: channel.name,
      detail: `${activeServer.name} · ${tr('Voice-Channel')}`,
      keywords: `${channel.name} ${activeServer.name} voice channel`,
      action: () => { void selectVoice(channel); }
    })) : [];
    const dmItems = directMessageEntries.map((entry) => ({
      id: `dm:${entry.server.id}:${entry.channel.id}`,
      kind: 'dm' as const,
      label: displayUserName(entry.user),
      detail: `${tr('Direktnachricht')} · ${entry.server.name}`,
      keywords: `${displayUserName(entry.user)} ${entry.user.identity ?? ''} ${entry.server.name} dm direct message`,
      action: () => { void loadDirectMessage(entry); }
    }));
    const actionItems: CommandPaletteItem[] = [
      { id: 'action:settings', kind: 'action', label: tr('Einstellungen'), detail: tr('App-Einstellungen öffnen'), keywords: 'settings preferences appearance', action: () => setMainView('settings') },
      { id: 'action:updates', kind: 'action', label: tr('Updates'), detail: tr('Update-Einstellungen öffnen'), keywords: 'updates release version', action: () => openUpdateSettings() },
      { id: 'action:search', kind: 'action', label: t('search.global.title'), detail: tr('Nachrichten- und Dateisuche öffnen'), keywords: 'search messages files find', action: () => openGlobalSearchFromPalette() }
    ];
    return [...serverItems, ...textItems, ...voiceItems, ...dmItems, ...actionItems];
  }, [state.servers, activeServer, textChannels, voiceChannels, directMessageEntries, connection]);
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setCommandPaletteQuery('');
        setCommandPaletteOpen(true);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  if (!activeServer) {
    return <main className={`appShell discordShell noServerShell ${activeView === 'settings' ? 'settingsMode' : ''}`}>
      <ServerRail servers={state.servers} activeServer={activeServer} onSelect={selectServer} onAdd={openAddServerModal} onSettings={() => setActiveView(activeView === 'settings' ? 'chat' : 'settings')} settingsActive={activeView === 'settings'} onHome={openDirectMessagesHome} homeActive={activeView === 'dms'} />
      {startupUpdateNoticeVisible && updateAvailable ? <StartupUpdateNotice appInfo={appInfo} release={release} asset={updateAsset} onOpenUpdates={openUpdateSettings} onDismiss={() => setStartupUpdateNoticeVisible(false)} /> : null}
      {activeView === 'settings'
        ? <SettingsPanel appInfo={appInfo} release={release} updateAsset={updateAsset} initialTab={settingsInitialTab} releaseChannel={releaseChannel} setReleaseChannel={setReleaseChannel} updateStatus={updateStatus} updateMessage={updateMessage} updateAvailable={updateAvailable} installingUpdate={installingUpdate} checkUpdates={() => void checkUpdates(appInfo, false, releaseChannel)} installSelectedUpdate={installSelectedUpdate} theme={state.theme} setTheme={setTheme} audioSettings={audioSettings} setAudioSettings={setAudioSettings} audioInputs={audioInputs} audioOutputs={audioOutputs} videoInputs={videoInputs} refreshMediaDeviceLists={refreshMediaDeviceListsForUi} connection={null} appState={state} setAppState={setState} streamAudioMutedUsers={streamAudioMutedUsers} setStreamAudioMutedUsers={setStreamAudioMutedUsers} notificationSettings={notificationSettings} setNotificationSettings={setNotificationSettings} uiSettings={uiSettings} setUiSettings={setUiSettings} adminRoles={adminRoles} />
        : <NoServersEmptyState onAdd={openAddServerModal} />}
      {pendingChannelDelete ? <ConfirmChannelDeleteDialog channel={pendingChannelDelete} status={channelActionStatus} onCancel={() => { setPendingChannelDelete(null); setChannelActionStatus(tr('Bereit')); }} onConfirm={() => void confirmDeleteChannel()} /> : null}
    {pendingCategoryDelete ? <ConfirmCategoryDeleteDialog category={pendingCategoryDelete.category} channelCount={pendingCategoryDelete.channelCount} status={channelActionStatus} onCancel={() => { setPendingCategoryDelete(null); setChannelActionStatus(tr('Bereit')); }} onConfirm={() => void confirmDeleteCategory()} /> : null}
    {pendingServerRemoval ? <ConfirmServerRemovalDialog server={pendingServerRemoval} status={channelActionStatus} onCancel={() => { setPendingServerRemoval(null); setChannelActionStatus(tr('Bereit')); }} onConfirm={() => void confirmServerRemoval()} /> : null}
    {pendingDirectMessageDelete ? <ConfirmDirectMessageDeleteDialog entry={pendingDirectMessageDelete} status={status} onCancel={() => { setPendingDirectMessageDelete(null); setStatus(tr('Bereit')); }} onConfirm={() => void confirmDeleteDirectMessageConversation()} /> : null}
    {pendingUnsupportedDirectMessageDelete ? <UnsupportedDirectMessageDeleteDialog entry={pendingUnsupportedDirectMessageDelete} onClose={() => { setPendingUnsupportedDirectMessageDelete(null); setStatus(tr('Bereit')); }} /> : null}
    {pendingAdminConfirm ? <AdminActionConfirmDialog action={pendingAdminConfirm} onCancel={() => setPendingAdminConfirm(null)} onConfirm={(action) => void confirmAdminAction(action)} /> : null}
    {pendingTotpAuth ? <TwoFactorCodeDialog code={totpCodeInput} setCode={setTotpCodeInput} error={totpError} busy={busy} onCancel={cancelTotpCode} onSubmit={submitTotpCode} /> : null}
    {commandPaletteOpen ? <CommandPaletteDialog items={commandPaletteItems} query={commandPaletteQuery} setQuery={setCommandPaletteQuery} onSelect={(item) => { setCommandPaletteOpen(false); item.action(); }} onClose={() => setCommandPaletteOpen(false)} /> : null}
    {modalOpen ? <AddServerModal name={name} setName={setName} url={url} setUrl={handleAddServerUrlChange} autoConnectChecked={autoConnectChecked} setAutoConnectChecked={setAutoConnectChecked} newCreds={newCreds} setNewCreds={setNewCreds} error={error} onClose={closeAddServerModal} onSubmit={submitServer} /> : null}
    </main>;
  }

  return <main className={`appShell discordShell ${activeView === 'settings' ? 'settingsMode' : ''}`}>
    <ServerRail servers={state.servers} activeServer={activeServer} onSelect={selectServer} onAdd={openAddServerModal} onHome={openDirectMessagesHome} homeActive={activeView === 'dms'} />
    {startupUpdateNoticeVisible && updateAvailable ? <StartupUpdateNotice appInfo={appInfo} release={release} asset={updateAsset} onOpenUpdates={openUpdateSettings} onDismiss={() => setStartupUpdateNoticeVisible(false)} /> : null}
    {activeView === 'dms'
      ? <DirectMessagesSidebar entries={directMessageEntries} selected={selectedDirectMessage} userSearchResults={directMessageSearchCandidates} ownUser={dmOwnUser} connection={dmAccountConnection} baseUrl={dmAccountConnection?.baseUrl || activeServer.url} auth={auth} voiceState={voiceState} onToggleMic={toggleMicMuted} onToggleSound={toggleSoundMuted} onOpenSettings={() => setMainView('settings')} onOpenOwnProfile={() => openOwnProfile(dmAccountServerId)} onSelect={(entry) => void loadDirectMessage(entry)} onDelete={(entry) => void deleteDirectMessageConversation(entry)} onStartUserDm={(result) => { if (result.existingEntry) void loadDirectMessage(result.existingEntry); else void openDirectMessageForUser(result.server, result.connection, result.user); }} onRefresh={() => void refreshDirectMessages()} status={status} />
      : <ChannelSidebar activeServer={activeServer} serverInfo={serverInfo} connection={connection} oidcConfig={oidcConfig} pluginSlots={pluginSlots} auth={auth} setAuth={setAuth} connectNative={connectNative} busy={busy} channelGroups={channelGroups} voiceUsersByChannelId={voiceUsersByChannelId} speakingUserIds={speakingUserIds} voiceReactionsMap={voiceReactionsMap} selectedChannelId={selectedChannelId} selectedVoiceId={selectedVoiceId} currentVoiceChannel={currentVoiceChannel} voiceState={voiceState} voiceBusy={voiceBusy || voiceJoinCooldownActive} onSelectText={(channelId) => loadMessages(connection, channelId)} onSelectVoice={selectVoice} onOpenVoiceTextChat={(channel) => void openVoiceTextChat(channel)} onChannelMenu={openChannelMenu} onCategoryMenu={openCategoryMenu} onVoiceUserMenu={openUserMenu} onUserProfile={openUserProfilePopover} onServerMenu={openServerMenu} serverDropdownOpen={!!serverDropdown} onLeaveVoice={leaveCurrentVoice} onToggleMic={toggleMicMuted} onToggleSound={toggleSoundMuted} onToggleVideo={toggleWebcam} onToggleScreen={toggleScreenShare} voiceReactionsEnabled={!!connection?.serverCapabilities.voiceReactions} onReactVoice={(emoji) => void sendCurrentVoiceReaction(emoji)} voiceSoundboardEnabled={!!connection?.serverCapabilities.voiceSoundboard} onSoundboardVoice={(soundId) => void sendCurrentVoiceSoundboard(soundId)} voiceMediaRecoveryEnabled={!!connection?.serverCapabilities.voiceMediaRecovery} onRecoverVoiceMedia={() => void recoverCurrentVoiceMedia()} onChannelDragStart={handleChannelDragStart} onChannelDrop={handleChannelDrop} onVoiceUserDragStart={handleVoiceUserDragStart} onVoiceUserDrop={handleVoiceUserDrop} voiceUserMoveEnabled={!!connection?.serverCapabilities.voiceUserMove} onCategoryDragStart={handleCategoryDragStart} onCategoryDrop={handleCategoryDrop} dragOverChannelId={dragOverChannelId} setDragOverChannelId={setDragOverChannelId} dragOverCategoryId={dragOverCategoryId} setDragOverCategoryId={setDragOverCategoryId} categoryCollapsedIds={categoryCollapsedIds} onToggleCategoryCollapsed={toggleCategoryCollapsed} status={status} channelActionStatus={channelActionStatus} ownUser={ownUser} ownUserId={connection?.join.ownUserId} activeView={activeView} setActiveView={setMainView} removeActiveServer={removeActiveServer} baseUrl={connection?.baseUrl || activeServer.url} readStates={readStates} onOpenOwnProfile={() => openOwnProfile(activeServer.id)} />}
    {activeView === 'settings'
      ? <SettingsPanel appInfo={appInfo} release={release} updateAsset={updateAsset} initialTab={settingsInitialTab} releaseChannel={releaseChannel} setReleaseChannel={setReleaseChannel} updateStatus={updateStatus} updateMessage={updateMessage} updateAvailable={updateAvailable} installingUpdate={installingUpdate} checkUpdates={() => void checkUpdates(appInfo, false, releaseChannel)} installSelectedUpdate={installSelectedUpdate} theme={state.theme} setTheme={setTheme} audioSettings={audioSettings} setAudioSettings={setAudioSettings} audioInputs={audioInputs} audioOutputs={audioOutputs} videoInputs={videoInputs} refreshMediaDeviceLists={refreshMediaDeviceListsForUi} connection={connection} appState={state} setAppState={setState} streamAudioMutedUsers={streamAudioMutedUsers} setStreamAudioMutedUsers={setStreamAudioMutedUsers} notificationSettings={notificationSettings} setNotificationSettings={setNotificationSettings} uiSettings={uiSettings} setUiSettings={setUiSettings} adminRoles={adminRoles} />
      : <MessageArea connection={selectedDirectMessageEntry?.connection ?? connection} messageSourceKey={`${activeView}:${activeView === 'dms' ? selectedDirectMessageEntry?.server.id ?? 'none' : activeServer.id}:${activeView === 'dms' ? selectedDirectMessageEntry?.channel.id ?? 'none' : selectedChannelId ?? 'none'}`} pluginSlots={activeView === 'dms' ? emptyPluginSlots() : pluginSlots} pluginCommandsByPlugin={activeView === 'dms' ? {} : pluginCommandsByPlugin} roles={activeView === 'dms' ? [] : adminRoles} setStatus={setStatus} selectedChannel={activeView === 'dms' ? selectedDirectMessageEntry?.channel ?? null : selectedChannel} selectedVoice={activeView === 'dms' ? null : selectedVoice} selectedVoiceUsers={activeView === 'dms' ? [] : selectedVoice ? voiceUsersByChannelId.get(selectedVoice.id) ?? [] : []} isSelectedVoiceJoined={activeView === 'dms' ? false : isSelectedVoiceJoined} serverVoicePresence={activeView === 'dms' ? false : serverVoicePresence} status={status} busy={busy} messages={messages} usersById={activeView === 'dms' ? selectedDirectMessageUsersById : usersById} typingUsers={activeView === 'dms' && selectedDirectMessageEntry ? typingUsers[selectedDirectMessageEntry.channel.id] ?? [] : selectedChannelId ? typingUsers[selectedChannelId] ?? [] : []} composer={composer} setComposer={setComposer} sendMessage={sendMessage} ownUserId={(activeView === 'dms' ? selectedDirectMessageEntry?.connection : connection)?.join.ownUserId} canManageMessages={activeView === 'chat' ? canManageMessages : selectedDirectMessageEntry?.server.id === activeServer.id ? canManageMessages : false} canToggleMessagePin={activeView !== 'dms' || !!selectedDirectMessageEntry?.connection.serverCapabilities.directMessagePinning} speakingUserIds={speakingUserIds} onSpeakingChange={setUserSpeaking} onEditMessage={onEditMessage} onDeleteMessage={onDeleteMessage} onTogglePin={onTogglePin} onToggleReaction={onToggleReaction} onJumpToMessage={jumpToMessage} onGlobalSearchJump={onGlobalSearchJump} onJoinVoice={activeView === 'dms' ? undefined : selectedVoice ? () => joinSelectedVoice(selectedVoice) : undefined} onLeaveVoice={leaveCurrentVoice} voiceBusy={voiceBusy || voiceJoinCooldownActive} voiceState={voiceState} onToggleMic={toggleMicMuted} onToggleSound={toggleSoundMuted} onToggleVideo={toggleWebcam} onToggleScreen={toggleScreenShare} localAudioStream={localAudioStream} localVideoStream={localVideoStream} localScreenStream={localScreenStream} remoteAudioStreams={remoteAudioStreams} remoteVideoStreams={remoteVideoStreams} activeServer={activeView === 'dms' ? selectedDirectMessageEntry?.server ?? activeServer : activeServer} routerRtpCapabilities={voiceRouterRtpCapabilitiesRef.current} streamAudioMutedUsers={streamAudioMutedUsers} onToggleStreamAudioMute={toggleStreamAudioMute} baseUrl={(activeView === 'dms' ? selectedDirectMessageEntry?.connection.baseUrl : connection?.baseUrl) || activeServer.url} membersOpen={activeView === 'dms' ? false : membersOpen} setMembersOpen={setMembersOpen} onUserMenu={openUserMenu} onUserProfile={(event, user) => openUserProfilePopover(event, user, activeView === 'dms' ? selectedDirectMessageEntry?.server.id : activeServer?.id)} replyTarget={activeView === 'dms' ? null : replyTarget} setReplyTarget={setReplyTarget} threadPanel={activeView === 'dms' ? null : threadPanel} onOpenThread={openThreadPanel} onCloseThread={() => setThreadPanel(null)} onSendThreadMessage={sendThreadMessage} notificationCenterItems={notificationCenterItems} notificationCenterOpen={notificationCenterOpen} setNotificationCenterOpen={setNotificationCenterOpen} notificationCenterMuted={notificationCenterMuted} setNotificationCenterMuted={setNotificationCenterMuted} onOpenNotificationItem={(item) => void openNotificationCenterItem(item)} onClearNotifications={clearNotificationCenter} onMarkNotificationsRead={markNotificationCenterRead} />}
    <RemoteAudioStreams streams={remoteAudioStreams} playbackId={audioSettings.playbackId} soundMuted={voiceState.soundMuted} activeServerId={activeServer.id} streamAudioMutedUsers={streamAudioMutedUsers} userVolumes={userVolumes} />
    {activeView === 'chat' && membersOpen ? <MembersPanel users={sortedUsers} visibleUsers={memberPanelDisplayUsers} roles={adminRoles} ownUserId={connection?.join.ownUserId} baseUrl={connection?.baseUrl || activeServer.url} onUserMenu={openUserMenu} onUserProfile={openUserProfilePopover} onClose={() => setMembersOpen(false)} /> : null}
    {channelSettingsOpen && connection ? <ChannelSettingsModal connection={connection} channel={channelSettingsOpen} roles={adminRoles} users={liveUsers} ownUser={ownUser} canManagePermissions={canManageChannelPermissions} permissionsRealtimeEvent={channelPermissionsRealtimeEvent} onClose={() => setChannelSettingsOpen(null)} onSaved={applyChannelSettingsUpdate} onStatus={(value) => { setChannelActionStatus(value); setActionStatus(value); }} /> : null}
    {pendingChannelDelete ? <ConfirmChannelDeleteDialog channel={pendingChannelDelete} status={channelActionStatus} onCancel={() => { setPendingChannelDelete(null); setChannelActionStatus(tr('Bereit')); }} onConfirm={() => void confirmDeleteChannel()} /> : null}
    {pendingCategoryDelete ? <ConfirmCategoryDeleteDialog category={pendingCategoryDelete.category} channelCount={pendingCategoryDelete.channelCount} status={channelActionStatus} onCancel={() => { setPendingCategoryDelete(null); setChannelActionStatus(tr('Bereit')); }} onConfirm={() => void confirmDeleteCategory()} /> : null}
    {pendingServerRemoval ? <ConfirmServerRemovalDialog server={pendingServerRemoval} status={channelActionStatus} onCancel={() => { setPendingServerRemoval(null); setChannelActionStatus(tr('Bereit')); }} onConfirm={() => void confirmServerRemoval()} /> : null}
    {pendingDirectMessageDelete ? <ConfirmDirectMessageDeleteDialog entry={pendingDirectMessageDelete} status={status} onCancel={() => { setPendingDirectMessageDelete(null); setStatus(tr('Bereit')); }} onConfirm={() => void confirmDeleteDirectMessageConversation()} /> : null}
    {pendingUnsupportedDirectMessageDelete ? <UnsupportedDirectMessageDeleteDialog entry={pendingUnsupportedDirectMessageDelete} onClose={() => { setPendingUnsupportedDirectMessageDelete(null); setStatus(tr('Bereit')); }} /> : null}
    {pendingAdminConfirm ? <AdminActionConfirmDialog action={pendingAdminConfirm} onCancel={() => setPendingAdminConfirm(null)} onConfirm={(action) => void confirmAdminAction(action)} /> : null}
    {pendingTotpAuth ? <TwoFactorCodeDialog code={totpCodeInput} setCode={setTotpCodeInput} error={totpError} busy={busy} onCancel={cancelTotpCode} onSubmit={submitTotpCode} /> : null}
    {commandPaletteOpen ? <CommandPaletteDialog items={commandPaletteItems} query={commandPaletteQuery} setQuery={setCommandPaletteQuery} onSelect={(item) => { setCommandPaletteOpen(false); item.action(); }} onClose={() => setCommandPaletteOpen(false)} /> : null}
    {modalOpen ? <AddServerModal name={name} setName={setName} url={url} setUrl={handleAddServerUrlChange} autoConnectChecked={autoConnectChecked} setAutoConnectChecked={setAutoConnectChecked} newCreds={newCreds} setNewCreds={setNewCreds} error={error} onClose={closeAddServerModal} onSubmit={submitServer} /> : null}
    {screenShareSettingsOpen ? <ScreenShareSettingsDialog audioSettings={audioSettings} setAudioSettings={setAudioSettings} onCancel={() => setScreenShareSettingsOpen(false)} onConfirm={startScreenShareWithCurrentSettings} /> : null}
    {welcomeProfileSetupOpen && connection ? <WelcomeProfileSetupDialog connection={connection} user={ownUser} baseUrl={connection.baseUrl} onSave={saveWelcomeProfileSetup} onSkip={skipWelcomeProfileSetup} /> : null}
    {ownProfilePopupOpen && ownProfileConnection ? <OwnProfilePopup connection={ownProfileConnection} user={ownProfileUser} serverInfo={ownProfileServerInfo} baseUrl={ownProfileConnection.baseUrl} onClose={() => { setOwnProfilePopupOpen(false); setOwnProfileServerId(null); }} onSaved={updateOwnUserPreview} onStatus={setStatus} /> : null}
    <UserProfilePopover popover={userProfilePopover} baseUrl={profilePopoverConnection?.baseUrl || profilePopoverServer?.url || activeServer.url} ownUserId={profilePopoverOwnUserId} directMessagesEnabled={profilePopoverDirectMessagesEnabled} canManageUser={profilePopoverCanManageUsers} onOpenDirectMessage={(user) => void openDirectMessageFromProfile(user)} onManageUser={openUserAdminFromProfile} onClose={() => setUserProfilePopover(null)} />
    <ServerDropdownMenu dropdown={serverDropdown} roles={adminRoles} connection={connection} categories={liveCategories} setDropdown={setServerDropdown} setStatus={setActionStatus} refreshRoles={() => refreshAdminRoles()} openServerSettings={() => { setAdminInitialTab('general'); setAdminWorkbenchOpen(true); setServerDropdown(null); }} createServerChannel={createServerChannel} createServerCategory={createServerCategory} createServerInvite={createServerInvite} />
    <AdminContextMenu menu={contextMenu} usersById={usersById} roles={adminRoles} connection={connection} voiceMap={voiceMap} categories={liveCategories} setMenu={setContextMenu} setStatus={setActionStatus} refreshRoles={() => refreshAdminRoles()} openServerSettings={() => { setAdminInitialTab('general'); setAdminWorkbenchOpen(true); setContextMenu(null); }} createServerChannel={createServerChannel} createServerCategory={createServerCategory} createServerInvite={createServerInvite} editContextChannel={editContextChannel} deleteContextChannel={deleteContextChannel} copyContextChannelLink={copyContextChannelLink} openChannelLinkTarget={openChannelLinkTarget} openVoiceTextChat={openVoiceTextChat} editContextCategory={editContextCategory} deleteContextCategory={deleteContextCategory} moderateContextUser={moderateContextUser} disconnectContextVoiceUser={disconnectContextVoiceUser} stopContextUserVoiceMedia={stopContextUserVoiceMedia} toggleUserRole={toggleUserRole} activeServer={activeServer} userVolumes={userVolumes} setUserVolume={setUserVolume} />
    {adminWorkbenchOpen && connection ? <AdminWorkbenchModal onClose={() => setAdminWorkbenchOpen(false)}><p className="adminStatus contextActionStatus">{actionStatus}</p><AdminWorkbench connection={connection} categories={liveCategories} channels={liveChannels} users={liveUsers} roles={adminRoles} setRoles={setAdminRoles} onUsersChanged={syncLiveUsersFromAdminRows} initialTab={adminInitialTab} readStates={readStates} externalStreamsMap={externalStreamsMap} pluginCommandsByPlugin={pluginCommandsByPlugin} realtimeEvent={adminRealtimeEvent} /></AdminWorkbenchModal> : null}
  </main>;
}




function ChannelSettingsModal({ connection, channel, roles, users, ownUser, canManagePermissions, permissionsRealtimeEvent, onClose, onSaved, onStatus }: { connection: SharkordConnection; channel: SharkordChannel; roles: SharkordRole[]; users: SharkordUser[]; ownUser: SharkordUser | null; canManagePermissions: boolean; permissionsRealtimeEvent?: ChannelPermissionsRealtimeEvent; onClose: () => void; onSaved: (channel: SharkordChannel) => void; onStatus: (value: string) => void }) {
  const [activeTab, setActiveTab] = useState<ChannelSettingsTab>('general');
  const [name, setName] = useState(channel.name);
  const [topic, setTopic] = useState(channel.topic ?? '');
  const [isPrivate, setIsPrivate] = useState(!!channel.private);
  const [overrides, setOverrides] = useState<ChannelPermissionOverride[]>([]);
  const [permissionsLoading, setPermissionsLoading] = useState(false);
  const [settingsStatus, setSettingsStatus] = useState(tr('Bereit'));
  const targets = useMemo(() => channelPermissionTargets(roles, users), [roles, users]);
  const defaultTarget = targets.find((target) => target.isDefault) ?? targets[0] ?? null;
  const [selectedTargetKey, setSelectedTargetKey] = useState(() => defaultTarget ? overrideKey(defaultTarget.targetType, defaultTarget.targetId) : '');
  const selectedTarget = targets.find((target) => overrideKey(target.targetType, target.targetId) === selectedTargetKey) ?? defaultTarget;
  const currentOverride = selectedTarget ? overrides.find((override) => override.targetType === selectedTarget.targetType && override.targetId === selectedTarget.targetId) : undefined;
  const [draftAllow, setDraftAllow] = useState<string[]>([]);
  const [draftDeny, setDraftDeny] = useState<string[]>([]);
  const guardAllowsPermissions = canManagePermissions || userHasChannelPermissionGuard(ownUser, roles);
  const permissionGuardHint = tr('Benötigt MANAGE_CHANNEL_PERMISSIONS, MANAGE_CHANNELS oder ADMINISTRATOR.');

  useEffect(() => {
    setName(channel.name);
    setTopic(channel.topic ?? '');
    setIsPrivate(!!channel.private);
  }, [channel]);

  useEffect(() => {
    if (!selectedTarget && targets[0]) setSelectedTargetKey(overrideKey(targets[0].targetType, targets[0].targetId));
  }, [selectedTarget, targets]);

  const refreshOverrides = useCallback(async () => {
    if (!guardAllowsPermissions) return;
    setPermissionsLoading(true);
    setSettingsStatus(tr('Channel-Berechtigungen werden geladen…'));
    try {
      const rows = normalisePermissionOverrides(await getChannelPermissions(connection, channel.id));
      setOverrides(rows);
      setSettingsStatus(rows.length ? tr(`${rows.length} Override(s) geladen`) : tr('Keine Overrides gesetzt'));
    } catch (err) {
      setSettingsStatus(cleanError(err));
    } finally {
      setPermissionsLoading(false);
    }
  }, [channel.id, connection, guardAllowsPermissions]);

  useEffect(() => {
    if (activeTab === 'permissions') void refreshOverrides();
  }, [activeTab, refreshOverrides]);

  useEffect(() => {
    if (!permissionsRealtimeEvent) return;
    if (permissionsRealtimeEvent.channelId != null && permissionsRealtimeEvent.channelId !== channel.id) return;
    if (activeTab === 'permissions') void refreshOverrides();
    else setSettingsStatus(tr('Channel-Berechtigungen wurden remote geändert'));
  }, [activeTab, channel.id, permissionsRealtimeEvent, refreshOverrides]);

  useEffect(() => {
    setDraftAllow(currentOverride?.allow ?? []);
    setDraftDeny(currentOverride?.deny ?? []);
  }, [currentOverride, selectedTargetKey]);

  const saveGeneral = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmedName = name.trim() || channel.name;
    const trimmedTopic = topic.trim();
    setSettingsStatus(tr('Channel wird gespeichert…'));
    try {
      await updateChannel(connection, { channelId: channel.id, name: trimmedName, topic: trimmedTopic || null, private: isPrivate });
      const nextChannel = { ...channel, name: trimmedName, topic: trimmedTopic || null, private: isPrivate };
      onSaved(nextChannel);
      setSettingsStatus(tr('Channel gespeichert'));
      onStatus(tr('Channel gespeichert'));
    } catch (err) {
      const message = tr(`Channel speichern fehlgeschlagen: ${cleanError(err)}`);
      setSettingsStatus(message);
      onStatus(message);
    }
  };

  const setPermission = (permission: string, state: PermissionState) => {
    const next = setPermissionState(draftAllow, draftDeny, permission, state);
    setDraftAllow(next.allow);
    setDraftDeny(next.deny);
  };

  const saveOverride = async () => {
    if (!selectedTarget || !guardAllowsPermissions) return;
    setSettingsStatus(tr('Override wird gespeichert…'));
    try {
      await updateChannelPermissions(connection, channel.id, selectedTarget.targetType, selectedTarget.targetId, draftAllow, draftDeny);
      await refreshOverrides();
      setSettingsStatus(tr('Override gespeichert'));
      onStatus(tr('Channel-Berechtigungen gespeichert'));
    } catch (err) {
      const message = tr(`Override speichern fehlgeschlagen: ${cleanError(err)}`);
      setSettingsStatus(message);
      onStatus(message);
    }
  };

  const deleteOverride = async () => {
    if (!selectedTarget || !guardAllowsPermissions) return;
    setSettingsStatus(tr('Override wird gelöscht…'));
    try {
      await deleteChannelPermissions(connection, channel.id, selectedTarget.targetType, selectedTarget.targetId);
      setDraftAllow([]);
      setDraftDeny([]);
      await refreshOverrides();
      setSettingsStatus(tr('Override gelöscht'));
      onStatus(tr('Channel-Berechtigungen gelöscht'));
    } catch (err) {
      const message = tr(`Override löschen fehlgeschlagen: ${cleanError(err)}`);
      setSettingsStatus(message);
      onStatus(message);
    }
  };

  const publicDefaultSendWarning = !isPrivate && selectedTarget?.targetType === 'role' && selectedTarget.isDefault && draftAllow.includes('SEND_MESSAGES');

  return <div className="modalBackdrop channelSettingsBackdrop" onMouseDown={onClose}><section className="channelSettingsModal" role="dialog" aria-modal="true" aria-label={tr('Channel-Einstellungen')} onMouseDown={(event) => event.stopPropagation()}>
    <header className="channelSettingsHeader"><div><h2>{tr('Channel-Einstellungen')}</h2><p>#{channel.name}</p></div><button type="button" onClick={onClose} aria-label={tr('Schließen')}>×</button></header>
    <nav className="channelSettingsTabs" aria-label={tr('Channel-Einstellungen Tabs')}><button type="button" className={activeTab === 'general' ? 'active' : ''} onClick={() => setActiveTab('general')}>{tr('Allgemein')}</button><button type="button" className={activeTab === 'permissions' ? 'active' : ''} disabled={!guardAllowsPermissions} title={!guardAllowsPermissions ? permissionGuardHint : undefined} onClick={() => setActiveTab('permissions')}>{tr('Berechtigungen')}</button></nav>
    {activeTab === 'general' ? <form className="channelSettingsGeneral" onSubmit={saveGeneral}><label>{tr('Channel-Name')}<input value={name} onChange={(event) => setName(event.target.value)} /></label><label>{tr('Thema')}<textarea value={topic} onChange={(event) => setTopic(event.target.value)} rows={3} /></label><label className="checkboxRow"><input type="checkbox" checked={isPrivate} onChange={(event) => setIsPrivate(event.target.checked)} />{tr('Privater Channel')}</label><div className="modalActions"><button type="button" className="secondary" onClick={onClose}>{tr('Abbrechen')}</button><button type="submit" className="primaryAction">{tr('Speichern')}</button></div></form> : null}
    {activeTab === 'permissions' ? <div className="channelPermissionsTab"><aside className="permissionTargetList" aria-label={tr('Override-Ziele')}>{targets.map((target) => { const key = overrideKey(target.targetType, target.targetId); const hasOverride = overrides.some((override) => override.targetType === target.targetType && override.targetId === target.targetId); return <button type="button" key={key} className={key === selectedTargetKey ? 'active' : ''} data-target-type={target.targetType} onClick={() => setSelectedTargetKey(key)}><span className="roleDot" style={{ background: target.color || (target.targetType === 'user' ? '#5865f2' : '#99aab5') }} />{target.targetType === 'role' ? '@' : ''}{target.label}{hasOverride ? <span className="overrideMarker">●</span> : null}</button>; })}</aside><section className="permissionEditorPanel">{!guardAllowsPermissions ? <p className="permissionGuardWarning">{permissionGuardHint}</p> : selectedTarget ? <><div className="permissionEditorHeader"><div><strong>{selectedTarget.label}</strong><span>{currentOverride ? tr('Bestehender Override') : tr('Neuen Override erstellen')}</span></div><button type="button" onClick={() => void refreshOverrides()} disabled={permissionsLoading}>{permissionsLoading ? tr('Lädt…') : tr('Neu laden')}</button></div>{publicDefaultSendWarning ? <p className="permissionWarning">{tr('Bei öffentlichen Channels kann die Default-Rolle mit SEND_MESSAGES für alle schreiben.')}</p> : null}<div className="permissionOverrideGrid" role="group" aria-label={tr('Channel-Berechtigungen')}>{CHANNEL_PERMISSION_OPTIONS.map((permission) => { const permissionState = permissionStateFor(permission, draftAllow, draftDeny); return <div className="permissionOverrideRow" key={permission}><span>{permission}</span><div className="permissionTriState" data-permission-state={permissionState} data-target-type={selectedTarget.targetType}><button type="button" className={permissionState === 'inherit' ? 'active' : ''} onClick={() => setPermission(permission, 'inherit')}>{tr('Vererben')}</button><button type="button" className={permissionState === 'allow' ? 'active allow' : 'allow'} onClick={() => setPermission(permission, 'allow')}>{tr('Erlauben')}</button><button type="button" className={permissionState === 'deny' ? 'active deny' : 'deny'} onClick={() => setPermission(permission, 'deny')}>{tr('Verweigern')}</button></div></div>; })}</div><div className="modalActions"><button type="button" className="dangerAction" disabled={!currentOverride && !draftAllow.length && !draftDeny.length} onClick={() => void deleteOverride()}>{tr('Override löschen')}</button><button type="button" className="primaryAction" onClick={() => void saveOverride()}>{tr('Override speichern')}</button></div></> : <p className="permissionGuardWarning">{tr('Keine Rollen oder Benutzer gefunden.')}</p>}</section></div> : null}
    <p className="adminStatus contextActionStatus">{settingsStatus}</p>
  </section></div>;
}

function ScreenShareSettingsDialog({ audioSettings, setAudioSettings, onCancel, onConfirm }: { audioSettings: AudioDeviceSettings; setAudioSettings: (settings: AudioDeviceSettings) => void; onCancel: () => void; onConfirm: () => void | Promise<void> }) {
  const updateScreen = (patch: Partial<AudioDeviceSettings>) => setAudioSettings({ ...audioSettings, ...patch });
  const resolutionOptions: Array<{ value: AudioDeviceSettings['screenResolution']; label: string }> = [
    { value: '480p', label: '480p' },
    { value: '720p', label: '720p' },
    { value: '1080p', label: 'Full HD (1080p)' },
    { value: '1440p', label: 'WQHD (1440p)' },
    { value: '2160p', label: '4K (2160p)' }
  ];
  return <div className="modalBackdrop" onMouseDown={onCancel}><div className="screenShareSettingsDialog confirmDialog" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={tr('Bildschirm teilen vorbereiten')}>
    <div className="screenShareDialogHeader"><h2>{tr('Bildschirm teilen vorbereiten')}</h2><p>{tr('Wähle Quelle, Qualität und Audio vor der Systemauswahl. Für War Thunder am besten Randloses Fenster nutzen, wenn es beim Alt-Tabben verschwindet.')}</p></div>
    <section className="screenShareSettingsGrid">
      <label className="screenShareField"><span>{tr('Quelle')}</span><select value={audioSettings.screenSourceMode} onChange={(event) => updateScreen({ screenSourceMode: event.target.value as AudioDeviceSettings['screenSourceMode'] })}><option value="window">{tr('Anwendung / Fenster')}</option><option value="screen">{tr('Gesamter Bildschirm')}</option></select></label>
      <label className="screenShareField"><span>{tr('Auflösung')}</span><select value={audioSettings.screenResolution} onChange={(event) => updateScreen({ screenResolution: event.target.value as AudioDeviceSettings['screenResolution'] })}>{resolutionOptions.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
      <label className="screenShareField"><span>{tr('Bildrate')}</span><select value={audioSettings.screenFps} onChange={(event) => updateScreen({ screenFps: Number(event.target.value) })}><option value={15}>15 fps</option><option value={30}>30 fps</option><option value={60}>60 fps</option></select></label>
      <label className="screenShareField"><span>{tr('Codec')}</span><select value={audioSettings.screenCodec} onChange={(event) => updateScreen({ screenCodec: event.target.value as AudioDeviceSettings['screenCodec'] })}><option value="auto">{tr('Automatisch')}</option><option value="vp8">VP8</option><option value="h264">H.264</option></select></label>
      <label className="screenShareField"><span>{tr('Optimierung')}</span><select value={audioSettings.screenContentHint} onChange={(event) => updateScreen({ screenContentHint: event.target.value as AudioDeviceSettings['screenContentHint'] })}><option value="motion">{tr('Gaming / Bewegung')}</option><option value="detail">{tr('Text / Details')}</option></select></label>
    </section>
    <section className="screenShareBitrateBlock" aria-label={tr('Maximale Bitrate')}><div className="screenShareBitrateHeader"><span>{tr('Maximale Bitrate')}</span><strong>{audioSettings.screenMaxBitrateMbps} Mbit/s</strong></div><div className="screenShareBitrateMain"><input type="range" min="1" max="30" step="1" value={audioSettings.screenMaxBitrateMbps} onChange={(event) => updateScreen({ screenMaxBitrateMbps: Number(event.target.value) })} /><span className="screenShareHint">{tr('1080p60 Gaming: 12–20 Mbit/s. Bei sehr viel Bewegung eher 20–30 Mbit/s.')}</span></div></section>
    <div className="screenShareToggleList"><label className="toggleRow"><input type="checkbox" checked={audioSettings.includeScreenAudio} onChange={(event) => updateScreen({ includeScreenAudio: event.target.checked })} /><span>{tr('Systemaudio übertragen')}</span><small>{tr('Im Windows-Picker muss „Audio teilen“ aktiviert sein.')}</small></label><label className="toggleRow"><input type="checkbox" checked={audioSettings.restrictOwnAudio} onChange={(event) => updateScreen({ restrictOwnAudio: event.target.checked })} /><span>{tr('Eigenes Audio einschränken')}</span></label><label className="toggleRow"><input type="checkbox" checked={audioSettings.suppressLocalAudioPlayback} onChange={(event) => updateScreen({ suppressLocalAudioPlayback: event.target.checked })} /><span>{tr('Lokale Audiowiedergabe unterdrücken')}</span></label></div>
    <div className="modalActions"><button type="button" className="secondary" onClick={onCancel}>{tr('Abbrechen')}</button><button type="button" className="primaryAction" onClick={() => void onConfirm()}>{tr('Teilen starten')}</button></div>
  </div></div>;
}

function InlineAudioStream({ stream }: { stream: MediaStream }) {
  const ref = useRef<HTMLAudioElement | null>(null);
  useEffect(() => { if (ref.current && ref.current.srcObject !== stream) ref.current.srcObject = stream; }, [stream]);
  return <audio ref={ref} autoPlay />;
}

function RemoteAudioStreams({ streams, playbackId, soundMuted, activeServerId, streamAudioMutedUsers, userVolumes }: { streams: RemoteAudioStream[]; playbackId?: string; soundMuted: boolean; activeServerId: string; streamAudioMutedUsers: StreamAudioMuteSettings; userVolumes: UserVolumeSettings }) {
  return <div className="remoteAudioStreams" aria-hidden="true">{streams.map((item) => <RemoteAudioElement key={`${item.remoteId}-${item.kind}`} item={item} playbackId={playbackId} volume={userVolumes[userVolumeKey(activeServerId, item.remoteId)] ?? 100} muted={soundMuted || (isStreamAudioKind(item.kind) && isStreamAudioMuted(streamAudioMutedUsers, activeServerId, item.remoteId))} />)}</div>;
}
function RemoteAudioElement({ item, playbackId, muted, volume }: { item: RemoteAudioStream; playbackId?: string; muted: boolean; volume: number }) {
  const ref = useRef<HTMLAudioElement | null>(null);
  useEffect(() => { if (!ref.current) return; if (ref.current.srcObject !== item.stream) ref.current.srcObject = item.stream; void applyAudioOutputDevice(ref.current, playbackId).catch(() => undefined); }, [item.stream, playbackId]);
  useEffect(() => { if (ref.current) ref.current.muted = muted; }, [muted]);
  useEffect(() => { if (ref.current) ref.current.volume = clampMediaElementVolume(volume); }, [volume]);
  return <audio ref={ref} autoPlay data-remote-id={item.remoteId} data-kind={item.kind} data-user-volume={volume} />;
}


function StartupUpdateNotice({ appInfo, release, asset, onOpenUpdates, onDismiss }: { appInfo: AppInfo | null; release: GitHubRelease | null; asset: ReleaseAsset | null; onOpenUpdates: () => void; onDismiss: () => void }) {
  if (!release?.version || !asset) return null;
  return <aside className="startupUpdateNotice" role="status" aria-live="polite">
    <div><strong>{tr(`Update ${appInfo?.version ?? 'dev'} → ${release.version} verfügbar`)}</strong><span>{tr('Neues Sharkord Desktop Release gefunden')} · {release.channel || 'stable'} · {asset.name} ({formatBytes(asset.size)})</span></div>
    <div className="startupUpdateNoticeActions"><button type="button" className="secondary" onClick={onDismiss}>{tr('Später')}</button><button type="button" onClick={onOpenUpdates}><Download size={16} />{tr('Update anzeigen')}</button></div>
  </aside>;
}

function NoServersEmptyState({ onAdd }: { onAdd: () => void }) {
  return <section className="noServersEmptyState"><div className="welcomeHero"><div className="heroIcon logoHero"><img className="heroLogo" src={sharkordLogo} alt="Sharkord" /></div><h1>Sharkord Desktop</h1><p>{tr('Noch kein Server hinterlegt. Füge deinen eigenen Sharkord-Server hinzu und speichere optional Credentials für Auto-Connect.')}</p><button className="primaryAction" onClick={onAdd}><Plus size={18} />{tr('Server hinzufügen')}</button></div></section>;
}

function ServerRail({ servers, activeServer, onSelect, onAdd, onSettings, settingsActive = false, onHome, homeActive = false }: { servers: SharkordServer[]; activeServer: SharkordServer | null; onSelect: (id: string) => void; onAdd: () => void; onSettings?: () => void; settingsActive?: boolean; onHome?: () => void; homeActive?: boolean }) {
  return <aside className="serverRail guildRail" aria-label={tr('Server')}>
    <button type="button" className={`brandMark homeGuild ${homeActive ? 'active' : ''}`} title={t('dm.sidebar.title')} aria-label={tr('Direktnachrichten öffnen')} onClick={onHome}><img className="brandLogo" src={sharkordLogo} alt="Sharkord" /></button>
    <div className="guildSeparator" />
    <div className="serverList guildList">{servers.map((server) => {
      const logoSrc = server.logo ? fileUrl(server.url, server.logo) : '';
      return <button key={server.id} className={`serverButton guildButton ${server.id === activeServer?.id ? 'active' : ''}`} style={{ '--server-color': server.color } as React.CSSProperties} onClick={() => onSelect(server.id)} title={`${server.name}${server.autoConnect ? ' · Auto-Connect' : ''}`} aria-label={`${server.name} ${tr('öffnen')}`}>{logoSrc ? <img className="serverLogo" src={logoSrc} alt="" /> : initials(server.name)}</button>;
    })}</div>
    <div className="railBottomActions">
      <button className="addServerButton guildAdd" onClick={onAdd} title={tr('Server hinzufügen')} aria-label={tr('Server hinzufügen')}><Plus size={24} /></button>
      {onSettings ? <button className={`railSettingsButton ${settingsActive ? 'active' : ''}`} onClick={onSettings} title={tr('Einstellungen')} aria-label={tr('Einstellungen')}><Settings size={20} /></button> : null}
    </div>
  </aside>;
}

function CommandPaletteDialog({ items, query, setQuery, onSelect, onClose }: { items: CommandPaletteItem[]; query: string; setQuery: (value: string) => void; onSelect: (item: CommandPaletteItem) => void; onClose: () => void }) {
  const [highlightedIndex, setHighlightedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const needle = query.trim().toLowerCase();
  const filteredItems = useMemo(() => {
    if (!needle) return items.slice(0, 80);
    return items.filter((item) => `${item.label} ${item.detail} ${item.keywords}`.toLowerCase().includes(needle)).slice(0, 80);
  }, [items, needle]);
  useEffect(() => { setHighlightedIndex(0); }, [needle, items]);
  useEffect(() => { inputRef.current?.focus(); }, []);
  const selectHighlighted = () => {
    const item = filteredItems[Math.min(highlightedIndex, Math.max(filteredItems.length - 1, 0))];
    if (item) onSelect(item);
  };
  const onKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === 'Escape') onClose();
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      setHighlightedIndex((index) => filteredItems.length ? (index + 1) % filteredItems.length : 0);
    }
    if (event.key === 'ArrowUp') {
      event.preventDefault();
      setHighlightedIndex((index) => filteredItems.length ? (index - 1 + filteredItems.length) % filteredItems.length : 0);
    }
    if (event.key === 'Enter') {
      event.preventDefault();
      selectHighlighted();
    }
  };
  const kindLabel = (kind: CommandPaletteItem['kind']) => kind === 'text' ? tr('Text') : kind === 'voice' ? tr('Voice') : kind === 'dm' ? tr('DM') : kind === 'server' ? tr('Server') : tr('Action');
  return <div className="modalBackdrop commandPaletteBackdrop" role="dialog" aria-modal="true" aria-label={tr('Command Palette')} onMouseDown={onClose}>
    <section className="commandPaletteDialog" onMouseDown={(event) => event.stopPropagation()} onKeyDown={onKeyDown}>
      <header><div><strong>{tr('Command Palette')}</strong><span>Ctrl/Cmd+K</span></div><button type="button" onClick={onClose} aria-label={tr('Command Palette schließen')}>×</button></header>
      <label className="commandPaletteSearch"><Search size={18} /><input ref={inputRef} value={query} onChange={(event) => setQuery(event.target.value)} placeholder={tr('Search servers, channels, DMs, actions')} aria-label={tr('Command Palette suchen')} autoFocus /></label>
      <div className="commandPaletteList" role="listbox" aria-label={tr('Command Palette Ergebnisse')}>
        {filteredItems.length ? filteredItems.map((item, index) => <button type="button" role="option" aria-selected={index === highlightedIndex} aria-label={`${item.label} · ${item.detail}`} key={item.id} className={`commandPaletteItem ${index === highlightedIndex ? 'active' : ''}`} onMouseEnter={() => setHighlightedIndex(index)} onClick={() => onSelect(item)}>
          <span className={`commandPaletteKind ${item.kind}`}>{kindLabel(item.kind)}</span><span><strong>{item.label}</strong><small>{item.detail}</small></span>
        </button>) : <div className="commandPaletteEmpty"><Search size={24} /><span>{tr('Keine Befehle gefunden')}</span></div>}
      </div>
    </section>
  </div>;
}

function AccountPanel({ ownUser, connection, baseUrl, auth, voiceState, settingsActive, onToggleMic, onToggleSound, onOpenSettings, onOpenOwnProfile }: { ownUser: SharkordUser | null; connection: SharkordConnection | null; baseUrl: string; auth: AuthState; voiceState: VoiceState; settingsActive: boolean; onToggleMic: () => void; onToggleSound: () => void; onOpenSettings: () => void; onOpenOwnProfile: () => void }) {
  return <div className="userPanel accountPanel"><button type="button" className="accountIdentityButton" onClick={onOpenOwnProfile} disabled={!connection} title={t('profile.edit.title')}><AvatarView user={ownUser} name={ownUser?.name || auth.identity || 'S'} baseUrl={baseUrl} className="smallAvatar" /><div className="userMeta"><strong>{ownUser?.name || auth.identity || tr('Nicht angemeldet')}</strong><span>{connection ? tr('Online') : tr('Offline')}</span></div></button><div className="accountControls"><button className={voiceState.micMuted ? 'toggled' : ''} title={voiceState.micMuted ? tr('Mikrofon aktivieren') : tr('Mikrofon stummschalten')} onClick={onToggleMic}>{voiceState.micMuted ? <MicOff size={16} /> : <Mic size={16} />}</button><button className={voiceState.soundMuted ? 'toggled' : ''} title={voiceState.soundMuted ? tr('Kopfhörer aktivieren') : tr('Kopfhörer stummschalten')} onClick={onToggleSound}>{voiceState.soundMuted ? <VolumeX size={16} /> : <Headphones size={16} />}</button><button className={settingsActive ? 'active' : ''} title={tr('Einstellungen')} onClick={onOpenSettings}><Settings size={16} /></button></div></div>;
}

function DirectMessagesSidebar({ entries, selected, userSearchResults, ownUser, connection, baseUrl, auth, voiceState, onToggleMic, onToggleSound, onOpenSettings, onOpenOwnProfile, onSelect, onDelete, onStartUserDm, onRefresh, status }: { entries: DirectMessageEntry[]; selected: DirectMessageSelection; userSearchResults: DirectMessageUserSearchResult[]; ownUser: SharkordUser | null; connection: SharkordConnection | null; baseUrl: string; auth: AuthState; voiceState: VoiceState; onToggleMic: () => void; onToggleSound: () => void; onOpenSettings: () => void; onOpenOwnProfile: () => void; onSelect: (entry: DirectMessageEntry) => void; onDelete: (entry: DirectMessageEntry) => void; onStartUserDm: (result: DirectMessageUserSearchResult) => void; onRefresh: () => void; status: string }) {
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const userSearchNeedle = userSearchQuery.trim().toLowerCase();
  const filteredUserSearchResults = useMemo(() => {
    if (!userSearchNeedle) return [];
    return userSearchResults.filter((result) => {
      const haystack = [displayUserName(result.user), result.user.identity, result.server.name].filter(Boolean).join(' ').toLowerCase();
      return haystack.includes(userSearchNeedle);
    }).slice(0, 8);
  }, [userSearchNeedle, userSearchResults]);
  const submitUserSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (filteredUserSearchResults[0]) onStartUserDm(filteredUserSearchResults[0]);
  };
  return <aside className="channelSidebar dmSidebar" aria-label={t('dm.sidebar.title')}>
    <div className="serverHeaderRow dmHeaderRow"><div className="serverHeaderButton dmHeaderTitle"><span>{t('dm.sidebar.title')}</span></div><button className="serverDeleteButton" type="button" onClick={onRefresh} title={tr('Aktualisieren')} aria-label={tr('Direktnachrichten aktualisieren')}><RefreshCw size={16} /></button></div>
    <form className="dmUserSearch" onSubmit={submitUserSearch}>
      <Search size={15} />
      <input value={userSearchQuery} onChange={(event) => setUserSearchQuery(event.target.value)} aria-label={tr('User für Direktnachricht suchen')} placeholder={t('dm.sidebar.searchPlaceholder')} />
      <button type="submit" disabled={!filteredUserSearchResults.length}>{tr('Start')}</button>
    </form>
    <div className="discordChannelList dmConversationList">
      {userSearchNeedle ? <section className="dmUserSearchResults" aria-label={tr('User-Suche')}>
        <div className="channelGroupTitle dmGroupTitle"><Search size={14} /><span className="categoryTitleText">{tr('User finden')}</span></div>
        {filteredUserSearchResults.length ? filteredUserSearchResults.map((result) => <button key={`${result.server.id}:${result.user.id}`} type="button" className="dmUserSearchResult" onClick={() => onStartUserDm(result)}>
          <AvatarView user={result.user} name={displayUserName(result.user)} baseUrl={result.connection.baseUrl} className="smallAvatar dmUserAvatar" />
          <span className="dmConversationMeta"><strong>{displayUserName(result.user)}</strong><small>{result.user.identity ? `@${result.user.identity} · ` : ''}{result.server.name}</small></span>
          <em>{result.existingEntry ? tr('Öffnen') : tr('DM starten')}</em>
        </button>) : <div className="dmSearchEmpty"><span>{tr('Keine User gefunden.')}</span></div>}
      </section> : null}
      <div className="channelGroupTitle dmGroupTitle"><AtSign size={14} /><span className="categoryTitleText">{tr('Alle Server')}</span></div>
      {entries.length ? entries.map((entry) => {
        const active = selected?.serverId === entry.server.id && selected.channelId === entry.channel.id;
        const unread = Number(entry.conversation.unreadCount || 0);
        const serverLogo = entry.server.logo ? fileUrl(entry.server.url, entry.server.logo) : '';
        return <div key={`${entry.server.id}:${entry.channel.id}`} className="dmConversationShell">
          <button type="button" className={`dmConversationRow ${active ? 'active' : ''}`} onClick={() => onSelect(entry)} aria-label={tr(`Direktnachricht mit ${displayUserName(entry.user)} auf ${entry.server.name}`)}>
            <AvatarView user={entry.user} name={displayUserName(entry.user)} baseUrl={entry.connection.baseUrl} className="smallAvatar dmUserAvatar" />
            <span className="dmConversationMeta"><strong>{displayUserName(entry.user)}</strong><small>{serverLogo ? <img src={serverLogo} alt="" /> : null}{entry.server.name} · {formatShortDate(entry.conversation.lastMessageAt)}</small></span>
            {unread > 0 ? <span className="dmUnreadBadge" aria-label={tr(`${unread} ungelesene Nachrichten`)}>{unread > 99 ? '99+' : unread}</span> : null}
          </button>
          <button type="button" className="dmConversationDeleteButton" onClick={(event) => { event.stopPropagation(); onDelete(entry); }} title={entry.connection.serverCapabilities.directMessageHide ? tr('Direktnachricht ausblenden') : tr('Direktnachricht ausblenden nicht unterstützt')} aria-label={tr(`Direktnachricht mit ${displayUserName(entry.user)} ausblenden`)}><Trash2 size={14} /></button>
        </div>;
      }) : <div className="dmEmptyState"><AtSign size={26} /><strong>{tr('Keine Direktnachrichten')}</strong><span>{tr('Suche oben nach einem User und starte eine DM. Alle Server laufen hier zusammen.')}</span></div>}
    </div>
    <div className="voiceStatusBar idle dmStatusBar"><AtSign size={16} /><div><strong>{t('dm.sidebar.center')}</strong><span>{tr(status)}</span></div></div>
    <AccountPanel ownUser={ownUser} connection={connection} baseUrl={baseUrl} auth={auth} voiceState={voiceState} settingsActive={false} onToggleMic={onToggleMic} onToggleSound={onToggleSound} onOpenSettings={onOpenSettings} onOpenOwnProfile={onOpenOwnProfile} />
  </aside>;
}

function ServerDropdownMenu({ dropdown, roles, connection, categories, setDropdown, setStatus, refreshRoles, openServerSettings, createServerChannel, createServerCategory, createServerInvite }: { dropdown: ServerDropdownState; roles: SharkordRole[]; connection: SharkordConnection | null; categories: SharkordCategory[]; setDropdown: (dropdown: ServerDropdownState) => void; setStatus: (value: string) => void; refreshRoles: () => void; openServerSettings: () => void; createServerChannel: (type?: 'TEXT' | 'VOICE') => void; createServerCategory: () => void; createServerInvite: () => void }) {
  useEffect(() => {
    if (!dropdown) return undefined;
    const close = () => setDropdown(null);
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') setDropdown(null); };
    const timer = window.setTimeout(() => {
      window.addEventListener('click', close);
      window.addEventListener('keydown', closeOnEscape);
    }, 0);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('click', close);
      window.removeEventListener('keydown', closeOnEscape);
    };
  }, [dropdown, setDropdown]);
  if (!dropdown) return null;
  const style = {
    left: dropdown.left,
    top: dropdown.top,
    width: dropdown.width,
    maxHeight: 'calc(100vh - 72px)',
    overflowY: 'auto'
  } as React.CSSProperties;
  const run = (action: () => void) => { setDropdown(null); action(); };
  return <div className="serverDropdownMenu" role="menu" style={style} onClick={(event) => event.stopPropagation()} onContextMenu={(event) => event.stopPropagation()}>
    <strong>{tr('Server')}</strong>
    <button className="contextMenuPrimary" role="menuitem" onClick={() => run(openServerSettings)}>{tr('Server-Einstellungen')}</button>
    <div className="contextMenuDivider" />
    <small>{tr('Erstellen')}</small>
    <button role="menuitem" onClick={() => run(() => createServerCategory())}>{tr('Kategorie erstellen')}</button>
    <button role="menuitem" onClick={() => run(() => createServerChannel('TEXT'))}>{tr('Text-Channel erstellen')}</button>
    <button role="menuitem" onClick={() => run(() => createServerChannel('VOICE'))}>{tr('Voice-Channel erstellen')}</button>
    <button role="menuitem" onClick={() => run(() => createServerInvite())}>{tr('Einladung erstellen')}</button>
    <div className="contextMenuDivider" />
    <small>{tr('Verwaltung')}</small>
    <button role="menuitem" onClick={() => run(() => { void refreshRoles(); setStatus(tr(`Rollen geladen: ${roles.length}`)); })}>{tr('Rollen aktualisieren')}</button>
    <div className="contextMenuDivider" />
    <small className="contextMenuInfo">{connection ? `${categories.length} ${tr('Kategorien')}` : tr('Erst verbinden')}</small>
  </div>;
}

function ChannelSidebar({ activeServer, serverInfo, connection, oidcConfig, pluginSlots, auth, setAuth, connectNative, busy, channelGroups, voiceUsersByChannelId, speakingUserIds, voiceReactionsMap, selectedChannelId, selectedVoiceId, currentVoiceChannel, voiceState, voiceBusy, voiceReactionsEnabled, onReactVoice, voiceSoundboardEnabled, onSoundboardVoice, voiceMediaRecoveryEnabled, onRecoverVoiceMedia, onSelectText, onSelectVoice, onOpenVoiceTextChat, onChannelMenu, onCategoryMenu, onVoiceUserMenu, onUserProfile, onServerMenu, serverDropdownOpen, onLeaveVoice, onToggleMic, onToggleSound, onToggleVideo, onToggleScreen, onChannelDragStart, onChannelDrop, onVoiceUserDragStart, onVoiceUserDrop, voiceUserMoveEnabled, onCategoryDragStart, onCategoryDrop, dragOverChannelId, setDragOverChannelId, dragOverCategoryId, setDragOverCategoryId, categoryCollapsedIds, onToggleCategoryCollapsed, status, channelActionStatus, ownUser, ownUserId, activeView, setActiveView, removeActiveServer, baseUrl, readStates, onOpenOwnProfile }: {
  activeServer: SharkordServer; serverInfo: SharkordServerInfo | null; connection: SharkordConnection | null; oidcConfig: OidcLoginConfig; pluginSlots: PluginSlotMap; auth: AuthState; setAuth: (value: AuthState) => void; connectNative: (event?: FormEvent<HTMLFormElement>) => void; busy: boolean; channelGroups: ChannelGroup[]; voiceUsersByChannelId: Map<number, VoiceUser[]>; speakingUserIds: Set<number>; voiceReactionsMap: VoiceReactionState; selectedChannelId: number | null; selectedVoiceId: number | null; currentVoiceChannel: SharkordChannel | null; voiceState: VoiceState; voiceBusy: boolean; voiceReactionsEnabled: boolean; onReactVoice: (emoji: string) => void; voiceSoundboardEnabled: boolean; onSoundboardVoice: (soundId: 'pop' | 'airhorn' | 'rimshot' | 'tada' | 'bonk') => void; voiceMediaRecoveryEnabled: boolean; onRecoverVoiceMedia: () => void; onSelectText: (channelId: number) => void; onSelectVoice: (channel: SharkordChannel) => void; onOpenVoiceTextChat: (channel: SharkordChannel) => void; onChannelMenu: (event: React.MouseEvent, channel: SharkordChannel) => void; onCategoryMenu: (event: React.MouseEvent, group: ChannelGroup) => void; onVoiceUserMenu: (event: React.MouseEvent, user: SharkordUser) => void; onUserProfile: (event: React.MouseEvent, user: SharkordUser) => void; onServerMenu: (event: React.MouseEvent<HTMLButtonElement>) => void; serverDropdownOpen: boolean; onLeaveVoice: () => void; onToggleMic: () => void; onToggleSound: () => void; onToggleVideo: () => void; onToggleScreen: () => void; onChannelDragStart: (channel: SharkordChannel) => void; onChannelDrop: (channel: SharkordChannel, group: ChannelGroup) => void; onVoiceUserDragStart: (user: VoiceUser) => void; onVoiceUserDrop: (channel: SharkordChannel) => void; voiceUserMoveEnabled: boolean; onCategoryDragStart: (event: React.DragEvent, group: ChannelGroup) => void; onCategoryDrop: (group: ChannelGroup) => void; dragOverChannelId: number | null; setDragOverChannelId: (channelId: number | null) => void; dragOverCategoryId: number | null; setDragOverCategoryId: (categoryId: number | null) => void; categoryCollapsedIds: Set<number>; onToggleCategoryCollapsed: (categoryId: number) => void; status: string; channelActionStatus: string; ownUser: SharkordUser | null; ownUserId?: number; activeView: AppView; setActiveView: (view: AppView) => void; removeActiveServer: () => void; baseUrl: string; readStates: Record<number, number>; onOpenOwnProfile: () => void;
}) {
  return <aside className="channelSidebar channelColumn" aria-label={tr('Channels')}>
    <div className="serverHeaderRow"><button className="serverHeaderButton" type="button" onClick={onServerMenu} onContextMenu={onServerMenu} aria-haspopup="menu" aria-expanded={serverDropdownOpen}><span>{serverInfo?.name || activeServer.name}{activeServer.autoConnect ? ' · Auto' : ''}</span><ChevronDown size={18} /></button><button className="serverDeleteButton" type="button" title={tr('Server löschen')} onClick={removeActiveServer}><Trash2 size={16} /></button></div>
    {!connection ? <ConnectPanel auth={auth} setAuth={setAuth} connection={connection} slots={pluginSlots.connect} onConnect={connectNative} busy={busy} allowNewUsers={serverInfo?.allowNewUsers} oidcConfig={oidcConfig} serverId={activeServer.id} serverUrl={activeServer?.url ?? ''} serverCapabilities={undefined} /> : <ChannelList channelGroups={channelGroups} voiceUsersByChannelId={voiceUsersByChannelId} speakingUserIds={speakingUserIds} voiceReactionsMap={voiceReactionsMap} selectedChannelId={selectedChannelId} selectedVoiceId={selectedVoiceId} currentVoiceChannelId={currentVoiceChannel?.id ?? null} onSelectText={onSelectText} onSelectVoice={onSelectVoice} onOpenVoiceTextChat={onOpenVoiceTextChat} onChannelMenu={onChannelMenu} onCategoryMenu={onCategoryMenu} onVoiceUserMenu={onVoiceUserMenu} onUserProfile={onUserProfile} onChannelDragStart={onChannelDragStart} onChannelDrop={onChannelDrop} onVoiceUserDragStart={onVoiceUserDragStart} onVoiceUserDrop={onVoiceUserDrop} voiceUserMoveEnabled={voiceUserMoveEnabled} onCategoryDragStart={onCategoryDragStart} onCategoryDrop={onCategoryDrop} dragOverChannelId={dragOverChannelId} setDragOverChannelId={setDragOverChannelId} dragOverCategoryId={dragOverCategoryId} setDragOverCategoryId={setDragOverCategoryId} categoryCollapsedIds={categoryCollapsedIds} onToggleCategoryCollapsed={onToggleCategoryCollapsed} ownUserId={ownUserId} baseUrl={baseUrl} readStates={readStates} />}
    {currentVoiceChannel ? <VoiceConnectionPanel activeServer={activeServer} serverInfo={serverInfo} connection={connection} currentVoiceChannel={currentVoiceChannel} voiceState={voiceState} voiceBusy={voiceBusy} voiceReactionsEnabled={voiceReactionsEnabled} onReactVoice={onReactVoice} voiceSoundboardEnabled={voiceSoundboardEnabled} onSoundboardVoice={onSoundboardVoice} voiceMediaRecoveryEnabled={voiceMediaRecoveryEnabled} onRecoverVoiceMedia={onRecoverVoiceMedia} onLeaveVoice={onLeaveVoice} onToggleVideo={onToggleVideo} onToggleScreen={onToggleScreen} /> : <div className="voiceStatusBar idle"><Volume2 size={16} /><div><strong>{connection ? tr('Voice bereit') : tr('Voice getrennt')}</strong><span>{channelActionStatus !== tr('Bereit') ? tr(channelActionStatus) : tr(status)}</span></div></div>}
    <AccountPanel ownUser={ownUser} connection={connection} baseUrl={baseUrl} auth={auth} voiceState={voiceState} settingsActive={activeView === 'settings'} onToggleMic={onToggleMic} onToggleSound={onToggleSound} onOpenSettings={() => setActiveView(activeView === 'settings' ? 'chat' : 'settings')} onOpenOwnProfile={onOpenOwnProfile} />
  </aside>;
}


function VoiceConnectionPanel({ activeServer, serverInfo, connection, currentVoiceChannel, voiceState, voiceBusy, voiceReactionsEnabled, onReactVoice, voiceSoundboardEnabled, onSoundboardVoice, voiceMediaRecoveryEnabled, onRecoverVoiceMedia, onLeaveVoice, onToggleVideo, onToggleScreen }: { activeServer: SharkordServer; serverInfo: SharkordServerInfo | null; connection: SharkordConnection | null; currentVoiceChannel: SharkordChannel; voiceState: VoiceState; voiceBusy: boolean; voiceReactionsEnabled: boolean; onReactVoice: (emoji: string) => void; voiceSoundboardEnabled: boolean; onSoundboardVoice: (soundId: 'pop' | 'airhorn' | 'rimshot' | 'tada' | 'bonk') => void; voiceMediaRecoveryEnabled: boolean; onRecoverVoiceMedia: () => void; onLeaveVoice: () => void; onToggleVideo: () => void; onToggleScreen: () => void }) {
  const [voiceActionsOpen, setVoiceActionsOpen] = useState(false);
  return <div className="discordVoicePanel">
    <div className="voicePanelHeader"><PhoneCall size={17} /><div><strong>{tr('Sprachchat verbunden')}</strong><span>{serverInfo?.name || activeServer.name} / {currentVoiceChannel.name}</span></div><button type="button" onClick={onLeaveVoice} disabled={voiceBusy} title={tr('Voice verlassen')}><PhoneOff size={17} /></button></div>
    <div className="voiceQuickActions compact">
      {(voiceReactionsEnabled || voiceSoundboardEnabled) ? <div className="voiceActionsMenuWrap"><button type="button" className={voiceActionsOpen ? 'active' : ''} title={tr('Reaktionen & Soundboard')} aria-label={tr('Reaktionen & Soundboard')} aria-expanded={voiceActionsOpen} onClick={() => setVoiceActionsOpen(!voiceActionsOpen)}><Smile size={18} /></button>{voiceActionsOpen ? <div className="voiceActionsPopover" role="menu" aria-label={tr('Reaktionen & Soundboard')}>{voiceReactionsEnabled ? ['👍', '❤️', '😂', '🎉', '😮'].map((emoji) => <button key={emoji} type="button" role="menuitem" title={`${tr('Voice-Reaction')} ${emoji}`} onClick={() => { onReactVoice(customEmojiReactionValue(emoji)); setVoiceActionsOpen(false); }} aria-label={`${tr('Voice-Reaction')} ${emoji}`}>{emoji}</button>) : null}{voiceSoundboardEnabled ? [{ id: 'pop', label: '✨' }, { id: 'airhorn', label: '📣' }, { id: 'rimshot', label: '🥁' }].map((sound) => <button key={sound.id} type="button" role="menuitem" title={`${tr('Soundboard')} ${sound.id}`} onClick={() => { onSoundboardVoice(sound.id as 'pop' | 'airhorn' | 'rimshot'); setVoiceActionsOpen(false); }} aria-label={`${tr('Soundboard')} ${sound.id}`}>{sound.label}</button>) : null}</div> : null}</div> : null}{voiceMediaRecoveryEnabled ? <button type="button" className="voiceRecoveryButton" title={tr('Voice-Recovery')} aria-label={tr('Voice-Recovery')} onClick={onRecoverVoiceMedia}><RefreshCw size={18} /></button> : null}
      <button type="button" className={voiceState.webcamEnabled ? 'active' : ''} title={voiceState.webcamEnabled ? tr('Kamera ausschalten') : tr('Kamera einschalten')} onClick={onToggleVideo}><Video size={18} /></button>
      <button type="button" className={voiceState.sharingScreen ? 'active' : ''} title={voiceState.sharingScreen ? tr('Freigabe beenden') : tr('Bildschirm teilen')} onClick={onToggleScreen}><Monitor size={18} /></button>
    </div>
  </div>;
}

function TwoFactorCodeDialog({ code, setCode, error, busy, onCancel, onSubmit }: { code: string; setCode: (value: string) => void; error: string; busy: boolean; onCancel: () => void; onSubmit: (event?: FormEvent<HTMLFormElement>) => void }) {
  return <div className="modalBackdrop twoFactorBackdrop" onMouseDown={onCancel}><form className="confirmDialog twoFactorCodeDialog" onMouseDown={(event) => event.stopPropagation()} onSubmit={onSubmit} role="dialog" aria-modal="true" aria-label={tr('Two-factor authentication')}>
    <h2>{tr('Two-factor authentication')}</h2>
    <p>{tr('Enter the 6-digit code from your authenticator app to finish login.')}</p>
    <label className="settingsField">{tr('Authenticator code')}<input className="settingsInput" value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, '').slice(0, 16))} inputMode="numeric" autoComplete="one-time-code" autoFocus placeholder="123456" /></label>
    {error ? <small className="loginInviteHint closedRegistrationHint">{tr(error)}</small> : null}
    <div className="modalActions"><button type="button" className="secondary" onClick={onCancel} disabled={busy}>{tr('Abbrechen')}</button><button type="submit" className="primaryAction" disabled={busy || !code.trim()}>{busy ? tr('Prüfe…') : tr('Verify & Connect')}</button></div>
  </form></div>;
}

function ConnectPanel({ auth, setAuth, connection, slots, onConnect, busy, allowNewUsers, oidcConfig, serverId, serverUrl, serverCapabilities }: { auth: AuthState; setAuth: (value: AuthState) => void; connection: SharkordConnection | null; slots: SharkordPluginSlotRender[]; onConnect: (event?: FormEvent<HTMLFormElement>) => void; busy: boolean; allowNewUsers?: boolean; oidcConfig: OidcLoginConfig; serverId: string; serverUrl: string; serverCapabilities?: SharkordConnection['serverCapabilities'] }) {
  const inviteCode = normalizeInviteInput(auth.invite);
  const supportsOidcLogin = (serverCapabilities?.oidcLogin ?? oidcConfig.enabled);
  const beginOidcLogin = (provider: OidcLoginConfig['providers'][number]) => {
    const redirectUri = `${window.location.origin}/oidc/callback`;
    const oidcState = crypto.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const pending: PendingOidcLogin = { serverId, serverUrl, provider: { id: provider.id, name: provider.name }, redirectUri, serverPassword: auth.serverPassword || undefined };
    sessionStorage.setItem(`${SHARKORD_DESKTOP_OIDC_STATE_PREFIX}${oidcState}`, JSON.stringify(pending));
    const authUrl = buildOidcAuthorizationUrl(serverUrl, provider, redirectUri, oidcState);
    window.location.assign(authUrl);
  };
  return <form className="connectPanel discordLogin" onSubmit={onConnect}>
    <div className="loginHint"><strong>{tr('Mit Sharkord verbinden')}</strong><span>{allowNewUsers === false ? tr('Registrierung eingeschränkt') : tr('Identity + Passwort wie im Webclient.')}</span></div>
    {supportsOidcLogin && oidcConfig.enabled && oidcConfig.providers.length > 0 ? <div className="oidcLoginOptions">{oidcConfig.providers.map((provider) => <button type="button" key={provider.id} className="oidcLoginButton" onClick={() => beginOidcLogin(provider)}>{tr('Mit SSO anmelden')} · {provider.name}</button>)}<small>{tr('Lokaler Breakglass-Login bleibt verfügbar')}</small></div> : null}
    <PluginSlotRenderer connection={connection} slot={'connect'} items={slots} context={{ surface: 'connect' }} onStatus={() => undefined} />
    <label>Identity<input value={auth.identity} onChange={(event) => setAuth({ ...auth, identity: event.target.value })} autoComplete="username" /></label>
    <label>{tr('Passwort')}<input value={auth.password} onChange={(event) => setAuth({ ...auth, password: event.target.value })} type="password" autoComplete="current-password" /></label>
    <label>{tr('Invite-Code optional')}<input value={auth.invite} onChange={(event) => setAuth({ ...auth, invite: event.target.value })} placeholder={tr('Invite-Code oder Invite-Link')} autoComplete="off" /></label>
    <label>{tr('Server-Passwort optional')}<input value={auth.serverPassword} onChange={(event) => setAuth({ ...auth, serverPassword: event.target.value })} type="password" /></label>
    {allowNewUsers === false && !inviteCode ? <p className="loginInviteHint closedRegistrationHint">{tr('Neue Registrierungen sind aktuell deaktiviert. Wenn du noch keinen Account hast, brauchst du eine Einladung von einem bestehenden Benutzer.')}</p> : null}
    {inviteCode && <p className="loginInviteHint invitedLoginHint"><strong>{tr('Du wurdest eingeladen')}</strong><span>{tr(`Invite-Code: ${inviteCode}`)}</span></p>}
    <button type="submit" disabled={busy || !auth.identity || !auth.password}><LogIn size={18} />{busy ? tr('Verbinde...') : tr('Verbinden')}</button>
    <small>{tr('Credentials können beim Server hinzufügen verschlüsselt gespeichert werden.')}</small>
  </form>;
}

function ChannelList({ channelGroups, voiceUsersByChannelId, speakingUserIds, voiceReactionsMap, selectedChannelId, selectedVoiceId, currentVoiceChannelId, onSelectText, onSelectVoice, onOpenVoiceTextChat, onChannelMenu, onCategoryMenu, onVoiceUserMenu, onUserProfile, onChannelDragStart, onChannelDrop, onVoiceUserDragStart, onVoiceUserDrop, voiceUserMoveEnabled, onCategoryDragStart, onCategoryDrop, dragOverChannelId, setDragOverChannelId, dragOverCategoryId, setDragOverCategoryId, categoryCollapsedIds, onToggleCategoryCollapsed, ownUserId, baseUrl, readStates }: { channelGroups: ChannelGroup[]; voiceUsersByChannelId: Map<number, VoiceUser[]>; speakingUserIds: Set<number>; voiceReactionsMap: VoiceReactionState; selectedChannelId: number | null; selectedVoiceId: number | null; currentVoiceChannelId: number | null; onSelectText: (channelId: number) => void; onSelectVoice: (channel: SharkordChannel) => void; onOpenVoiceTextChat: (channel: SharkordChannel) => void; onChannelMenu: (event: React.MouseEvent, channel: SharkordChannel) => void; onCategoryMenu: (event: React.MouseEvent, group: ChannelGroup) => void; onVoiceUserMenu: (event: React.MouseEvent, user: SharkordUser) => void; onUserProfile: (event: React.MouseEvent, user: SharkordUser) => void; onChannelDragStart: (channel: SharkordChannel) => void; onChannelDrop: (channel: SharkordChannel, group: ChannelGroup) => void; onVoiceUserDragStart: (user: VoiceUser) => void; onVoiceUserDrop: (channel: SharkordChannel) => void; voiceUserMoveEnabled: boolean; onCategoryDragStart: (event: React.DragEvent, group: ChannelGroup) => void; onCategoryDrop: (group: ChannelGroup) => void; dragOverChannelId: number | null; setDragOverChannelId: (channelId: number | null) => void; dragOverCategoryId: number | null; setDragOverCategoryId: (categoryId: number | null) => void; categoryCollapsedIds: Set<number>; onToggleCategoryCollapsed: (categoryId: number) => void; ownUserId?: number; baseUrl: string; readStates: Record<number, number> }) {
  const renderChannelButton = (channel: SharkordChannel, group: ChannelGroup) => {
    const voice = isVoiceChannel(channel);
    const dragOver = dragOverChannelId === channel.id;
    return <div key={channel.id} className={voice ? 'voiceChannelBlock' : undefined}>
      <button type="button" draggable className={`channelRow ${voice ? 'voiceChannel' : ''} ${channel.id === (voice ? selectedVoiceId : selectedChannelId) ? 'active' : ''} ${dragOver ? 'dragOver' : ''}`} onClick={() => voice ? onSelectVoice(channel) : onSelectText(channel.id)} onContextMenu={(event) => onChannelMenu(event, channel)} onDragStart={() => onChannelDragStart(channel)} onDragOver={(event) => { event.preventDefault(); event.dataTransfer.dropEffect = 'move'; setDragOverChannelId(channel.id); }} onDragLeave={() => setDragOverChannelId(null)} onDrop={(event) => { event.preventDefault(); const movingVoiceUser = voice && voiceUserMoveEnabled && Array.from(event.dataTransfer.types).includes('application/x-sharkord-voice-user-id'); movingVoiceUser ? onVoiceUserDrop(channel) : onChannelDrop(channel, group); }}><span className="dragHandle" aria-label={tr('Channel verschieben')}><GripVertical size={13} /></span>{voice ? <Volume2 size={17} /> : <Hash size={17} />}<span>{channel.name}</span>{(readStates[channel.id] ?? 0) > 0 ? <span className="unreadBadge" title={tr('Ungelesen')}>{Math.min(99, readStates[channel.id] ?? 0)}{(readStates[channel.id] ?? 0) > 99 ? '+' : ''}</span> : null}{voice && channel.id === currentVoiceChannelId ? <span className="voiceConnectedDot" title={tr('Verbunden')} aria-label={tr('Verbunden')}><PhoneCall size={13} /></span> : null}</button>{voice ? <div className="voiceUserList">{(voiceUsersByChannelId.get(channel.id) ?? []).map((voiceUser) => <VoiceUserRow key={voiceUser.id} user={voiceUser} own={voiceUser.id === ownUserId} speaking={speakingUserIds.has(voiceUser.id)} reaction={voiceReactionsMap[voiceUser.id]} baseUrl={baseUrl} draggable={voiceUserMoveEnabled && voiceUser.id !== ownUserId} onDragStart={onVoiceUserDragStart} onUserMenu={onVoiceUserMenu} onUserProfile={onUserProfile} />)}</div> : null}</div>;
  };
  return <div className="channelList discordChannelList">
    {channelGroups.map((group) => {
      const collapsed = group.id != null && categoryCollapsedIds.has(group.id);
      return <section key={`category-${group.id ?? 'none'}`} className={`channelCategory ${collapsed ? 'collapsed' : ''}`}>
        <ChannelCategory group={group} collapsed={collapsed} dragOver={group.id != null && dragOverCategoryId === group.id} onDragStart={onCategoryDragStart} onDrop={onCategoryDrop} onToggle={onToggleCategoryCollapsed} onContextMenu={(event) => onCategoryMenu(event, group)} setDragOverCategoryId={setDragOverCategoryId}>{group.name || 'CHANNELS'}</ChannelCategory>
        {collapsed ? null : group.channels.map((channel) => renderChannelButton(channel, group))}
      </section>;
    })}
  </div>;
}

function ChannelCategory({ group, collapsed, dragOver, onDragStart, onDrop, onToggle, onContextMenu, setDragOverCategoryId, children }: { group: ChannelGroup; collapsed: boolean; dragOver: boolean; onDragStart: (event: React.DragEvent, group: ChannelGroup) => void; onDrop: (group: ChannelGroup) => void; onToggle: (categoryId: number) => void; onContextMenu: (event: React.MouseEvent) => void; setDragOverCategoryId: (categoryId: number | null) => void; children: ReactNode }) { return <div className={`channelGroupTitle ${dragOver ? 'dragOver' : ''}`} draggable={group.id != null} onContextMenu={onContextMenu} onDragStart={(event) => onDragStart(event, group)} onDragOver={(event) => { if (group.id != null) { event.preventDefault(); event.dataTransfer.dropEffect = 'move'; setDragOverCategoryId(group.id); } }} onDragLeave={() => setDragOverCategoryId(null)} onDrop={(event) => { event.preventDefault(); setDragOverCategoryId(null); onDrop(group); }}><button type="button" className="categoryCollapseButton" onClick={() => { if (group.id != null) onToggle(group.id); }} aria-label={collapsed ? tr('Kategorie ausklappen') : tr('Kategorie einklappen')}>{collapsed ? <ChevronRight size={12} /> : <ChevronDown size={12} />}</button>{group.id != null ? <span className="categoryDragHandle" aria-label={tr('Kategorie verschieben')}><GripVertical size={12} /></span> : null}<span className="categoryTitleText">{children}</span>{group.id != null ? <MoreVertical size={13} className="categoryMenuHint" aria-hidden="true" /> : null}</div>; }
function VoiceUserRow({ user, own, speaking, reaction, baseUrl, draggable, onDragStart, onUserMenu, onUserProfile }: { user: VoiceUser; own: boolean; speaking: boolean; reaction?: { emoji: string; file?: SharkordFile | null; expiresAt: number }; baseUrl: string; draggable: boolean; onDragStart: (user: VoiceUser) => void; onUserMenu: (event: React.MouseEvent, user: SharkordUser) => void; onUserProfile: (event: React.MouseEvent, user: SharkordUser) => void }) { const userVoiceState = normalizeVoiceState(user.state); return <div className={`voiceUserRow ${speaking ? 'speaking' : ''} ${draggable ? 'moveEnabled' : ''}`} draggable={draggable} onDragStart={(event) => { if (!draggable) return; event.stopPropagation(); event.dataTransfer.setData('application/x-sharkord-voice-user-id', String(user.id)); event.dataTransfer.effectAllowed = 'move'; onDragStart(user); }} onClick={(event) => onUserProfile(event, user)} onContextMenu={(event) => onUserMenu(event, user)}><AvatarView user={user} name={user.name || user.identity || `User ${user.id}`} baseUrl={baseUrl} className="voiceUserAvatar" /><span><span className="speakingIndicator" aria-label={speaking ? tr('spricht') : tr('still')} />{user.name || user.identity || `User ${user.id}`}{own ? ` (${tr('du')})` : ''}</span>{reaction ? <span className="voiceReactionBadge" aria-label={`${tr('Voice-Reaction')} ${customEmojiReactionName(reaction.emoji)}`}>{reaction.file ? <img src={fileUrl(baseUrl, reaction.file)} alt={`:${customEmojiReactionName(reaction.emoji)}:`} /> : customEmojiReactionName(reaction.emoji)}</span> : null}<span className="voiceUserIcons">{userVoiceState.micMuted ? <MicOff size={12} /> : <Mic size={12} />}{userVoiceState.soundMuted ? <VolumeX size={12} /> : <Headphones size={12} />}{userVoiceState.webcamEnabled ? <Video size={12} /> : null}{userVoiceState.sharingScreen ? <Monitor size={12} /> : null}</span></div>; }

function MessageArea({ connection, messageSourceKey, pluginSlots, pluginCommandsByPlugin, roles, setStatus, selectedChannel, selectedVoice, selectedVoiceUsers, isSelectedVoiceJoined, serverVoicePresence, status, busy, messages, usersById, typingUsers, composer, setComposer, sendMessage, ownUserId, canManageMessages, canToggleMessagePin, speakingUserIds, onSpeakingChange, onEditMessage, onDeleteMessage, onTogglePin, onToggleReaction, onJumpToMessage, onGlobalSearchJump, onJoinVoice, onLeaveVoice, voiceBusy, voiceState, onToggleMic, onToggleSound, onToggleVideo, onToggleScreen, localAudioStream, localVideoStream, localScreenStream, remoteAudioStreams, remoteVideoStreams, activeServer, routerRtpCapabilities, streamAudioMutedUsers, onToggleStreamAudioMute, baseUrl, membersOpen, setMembersOpen, onUserMenu, onUserProfile, replyTarget, setReplyTarget, threadPanel, onOpenThread, onCloseThread, onSendThreadMessage, notificationCenterItems, notificationCenterOpen, setNotificationCenterOpen, notificationCenterMuted, setNotificationCenterMuted, onOpenNotificationItem, onClearNotifications, onMarkNotificationsRead }: { connection: SharkordConnection | null; messageSourceKey: string; pluginSlots: PluginSlotMap; pluginCommandsByPlugin: Record<string, SharkordPluginCommand[]>; roles: SharkordRole[]; setStatus: (value: string) => void; selectedChannel: SharkordChannel | null; selectedVoice: SharkordChannel | null; selectedVoiceUsers: VoiceUser[]; isSelectedVoiceJoined: boolean; serverVoicePresence: boolean; status: string; busy: boolean; messages: SharkordMessage[]; usersById: Map<number, SharkordUser>; typingUsers: number[]; composer: string; setComposer: (value: string) => void; sendMessage: (event: FormEvent<HTMLFormElement>, files?: SharkordTempFile[]) => Promise<boolean>; ownUserId?: number; canManageMessages: boolean; canToggleMessagePin: boolean; speakingUserIds: Set<number>; onSpeakingChange: (userId: number, speaking: boolean) => void; onEditMessage: (message: SharkordMessage, plainText: string, files?: SharkordTempFile[]) => void; onDeleteMessage: (message: SharkordMessage) => void; onTogglePin: (message: SharkordMessage) => void; onToggleReaction: (message: SharkordMessage, emoji?: string) => void; onJumpToMessage: (messageId: number) => void; onGlobalSearchJump: (channelId: number, messageId: number) => Promise<boolean>; onJoinVoice?: () => void; onLeaveVoice: () => void; voiceBusy: boolean; voiceState: VoiceState; onToggleMic: () => void; onToggleSound: () => void; onToggleVideo: () => void; onToggleScreen: () => void; localAudioStream: MediaStream | null; localVideoStream: MediaStream | null; localScreenStream: MediaStream | null; remoteAudioStreams: RemoteAudioStream[]; remoteVideoStreams: RemoteVideoStream[]; activeServer: SharkordServer | null; routerRtpCapabilities: unknown; streamAudioMutedUsers: StreamAudioMuteSettings; onToggleStreamAudioMute: (serverId: string, remoteId: number) => void; baseUrl: string; membersOpen: boolean; setMembersOpen: (open: boolean) => void; onUserMenu: (event: React.MouseEvent, user: SharkordUser) => void; onUserProfile: (event: React.MouseEvent, user: SharkordUser) => void; replyTarget: SharkordMessage | null; setReplyTarget: (message: SharkordMessage | null) => void; threadPanel: ThreadPanelState; onOpenThread: (message: SharkordMessage) => void; onCloseThread: () => void; onSendThreadMessage: (parent: SharkordMessage, plainText: string, files?: SharkordTempFile[]) => Promise<boolean>; notificationCenterItems: NotificationCenterItem[]; notificationCenterOpen: boolean; setNotificationCenterOpen: (open: boolean) => void; notificationCenterMuted: boolean; setNotificationCenterMuted: (muted: boolean) => void; onOpenNotificationItem: (item: NotificationCenterItem) => void; onClearNotifications: () => void; onMarkNotificationsRead: () => void }) {
  const title = selectedChannel?.name || selectedVoice?.name || (connection ? tr('Channel auswählen') : tr('Willkommen'));
  const typingNames = typingUsers.filter((id) => id !== ownUserId).map((id) => usersById.get(id)?.name || `User ${id}`).slice(0, 3);
  const remoteSpeechStreams = remoteAudioStreams.filter((item) => item.kind === 'audio');
  const [attachments, setAttachments] = useState<SharkordTempFile[]>([]);
  const [attachmentStatus, setAttachmentStatus] = useState('');
  const [emojiPickerOpen, setEmojiPickerOpen] = useState(false);
  const [pinnedMessagesOpen, setPinnedMessagesOpen] = useState(false);
  const [pinnedMessages, setPinnedMessages] = useState<SharkordMessage[]>([]);
  const [pinnedStatus, setPinnedStatus] = useState('');
  const [recentEmojis, setRecentEmojis] = useState<string[]>(() => loadRecentEmojis());
  const [uploadingAttachments, setUploadingAttachments] = useState(false);
  const [messageSearch, setMessageSearch] = useState('');
  const [mentionsOnly, setMentionsOnly] = useState(false);
  const [headerHelpOpen, setHeaderHelpOpen] = useState(false);
  const [globalSearchOpen, setGlobalSearchOpen] = useState(false);
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [globalSearchResults, setGlobalSearchResults] = useState<GlobalSearchMessageResult[]>([]);
  const [globalFileSearchResults, setGlobalFileSearchResults] = useState<GlobalSearchFileResult[]>([]);
  const [globalSearchCursor, setGlobalSearchCursor] = useState<number | string | null>(null);
  const [globalFileSearchCursor, setGlobalFileSearchCursor] = useState<number | string | null>(null);
  const [globalSearchStatus, setGlobalSearchStatus] = useState('');
  const [globalSearchLoading, setGlobalSearchLoading] = useState(false);
  const [storageOpen, setStorageOpen] = useState(false);
  const [storageFiles, setStorageFiles] = useState<SharkordFile[]>([]);
  const [storageLoading, setStorageLoading] = useState(false);
  const [storageStatus, setStorageStatus] = useState('');
  const [storageQuery, setStorageQuery] = useState('');
  const [deletingStorageFileId, setDeletingStorageFileId] = useState<number | null>(null);
  const [attachmentLightbox, setAttachmentLightbox] = useState<AttachmentLightboxItem | null>(null);
  const [selectedPluginCommand, setSelectedPluginCommand] = useState<SharkordPluginCommand | null>(null);
  const [pluginCommandArgValues, setPluginCommandArgValues] = useState<Record<string, string>>({});
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const richComposerRef = useRef<HTMLDivElement | null>(null);
  const messageScrollerRef = useRef<HTMLDivElement | null>(null);
  const messageSourceKeyRef = useRef(messageSourceKey);
  messageSourceKeyRef.current = messageSourceKey;
  const [editTarget, setEditTarget] = useState<SharkordMessage | null>(null);
  useEffect(() => {
    messageSourceKeyRef.current = messageSourceKey;
    setAttachments([]);
    setAttachmentStatus('');
    setEditTarget(null);
    setSelectedPluginCommand(null);
    setPluginCommandArgValues({});
    setEmojiPickerOpen(false);
    setAttachmentLightbox(null);
  }, [messageSourceKey]);
  const emojiChoices = [...recentEmojis, '😀', '😂', '😍', '👍', '🎉', '❤️', '🔥', '😅', '😎', '😢', '🙌', '✅', '🤔', '😴', '🚀'].filter((emoji, index, array) => array.indexOf(emoji) === index);
  const allMentionUsers = Array.from(usersById.values()).sort((a, b) => displayUserName(a).localeCompare(displayUserName(b))).slice(0, 80);
  const canEditAttachments = connection ? connection.serverCapabilities.messageEditAttachments : false;
  const canMentionRoles = connection ? connection.serverCapabilities.roleMentions : false;
  const mentionableRoles = roles.filter((role) => role.mentionable).sort((a, b) => a.name.localeCompare(b.name)).slice(0, 80);
  const ownUser = ownUserId ? usersById.get(ownUserId) : undefined;
  const searchTerm = messageSearch.trim().toLowerCase();
  const storageSearchTerm = storageQuery.trim().toLowerCase();
  const mentionNeedles = [ownUser?.name, ownUser?.identity, ownUserId ? String(ownUserId) : ''].filter(Boolean).map((value) => String(value).toLowerCase());
  const messageMatchesMention = (message: SharkordMessage) => {
    if (!mentionNeedles.length) return false;
    const body = textFromHtml(message.content).toLowerCase();
    return mentionNeedles.some((needle) => body.includes(`@${needle}`));
  };
  const messageMatchesSearch = (message: SharkordMessage) => {
    if (!searchTerm) return true;
    const author = displayUserName(message.user || message.author || usersById.get(message.userId)).toLowerCase();
    return textFromHtml(message.content).toLowerCase().includes(searchTerm) || author.includes(searchTerm);
  };
  const visibleMessages = messages.filter((message) => messageMatchesSearch(message) && (!mentionsOnly || messageMatchesMention(message)));
  const pluginSlotContext: PluginSlotContext = {
    surface: selectedChannel ? 'text-channel' : selectedVoice ? 'voice-channel' : 'empty',
    channelId: selectedChannel?.id ?? null,
    voiceChannelId: selectedVoice?.id ?? null,
    serverId: activeServer?.id ?? null,
    ownUserId: ownUserId ?? null
  };
  const roleMentionMatch = composer.match(/(?:^|\s)@&([^@\s]*)$/);
  const roleMentionQuery = roleMentionMatch?.[1]?.toLowerCase() ?? '';
  const roleMentionSuggestions = canMentionRoles && roleMentionMatch ? mentionableRoles.filter((role) => !roleMentionQuery || role.name.toLowerCase().includes(roleMentionQuery)).slice(0, 8) : [];
  const mentionMatch = roleMentionMatch ? null : composer.match(/(?:^|\s)@([^@\s]*)$/);
  const mentionQuery = mentionMatch?.[1]?.toLowerCase() ?? '';
  const mentionSuggestions = mentionMatch ? allMentionUsers.filter((user) => {
    const name = displayUserName(user).toLowerCase();
    const identity = (user.identity || '').toLowerCase();
    return !mentionQuery || name.includes(mentionQuery) || identity.includes(mentionQuery);
  }).slice(0, 8) : [];
  const pluginCommands = useMemo(() => Object.entries(pluginCommandsByPlugin).flatMap(([pluginId, commands]) => commands.map((command) => ({ ...command, pluginId: command.pluginId ?? pluginId }))), [pluginCommandsByPlugin]);
  const slashCommandMatch = composer.match(/^\/([^\s]*)/);
  const slashCommandQuery = slashCommandMatch?.[1]?.toLowerCase() ?? '';
  const pluginCommandSuggestions = slashCommandMatch ? pluginCommands.filter((command) => {
    const label = pluginCommandLabel(command).toLowerCase();
    return !slashCommandQuery || label.includes(slashCommandQuery) || command.name.toLowerCase().includes(slashCommandQuery) || (command.pluginId ?? '').toLowerCase().includes(slashCommandQuery);
  }).slice(0, 8) : [];
  const attachmentLabel = (file: SharkordTempFile) => file.originalName || file.name || `${tr('Datei')} ${file.id}`;
  const storageFileLabel = (file: SharkordFile) => file.originalName || file.name || `${tr('Datei')} ${file.id}`;
  const filteredStorageFiles = storageFiles.filter((file) => {
    if (!storageSearchTerm) return true;
    const haystack = [storageFileLabel(file), file.extension, file.mimeType].filter(Boolean).join(' ').toLowerCase();
    return haystack.includes(storageSearchTerm);
  });
  const storageUsedBytes = storageFiles.reduce((sum, file) => sum + (file.size ?? 0), 0);
  const openFilePicker = () => fileInputRef.current?.click();
  const openImagePicker = () => imageInputRef.current?.click();
  const lastTypingSignalRef = useRef(0);
  function notifyTyping() {
    if (!connection || !selectedChannel) return;
    const now = Date.now();
    if (now - lastTypingSignalRef.current < 3_000) return;
    lastTypingSignalRef.current = now;
    void signalTyping(connection, selectedChannel.id, replyTarget?.id ?? null).catch(() => undefined);
  }
  async function removeAttachment(file: SharkordTempFile) {
    setAttachments((current) => current.filter((item) => item.id !== file.id));
    if (!connection) return;
    try {
      await deleteTemporaryFile(connection, file.id);
      setAttachmentStatus(tr('Anhang entfernt.'));
    } catch (err) {
      setAttachmentStatus(tr(`Anhang entfernt · temporäre Datei konnte nicht gelöscht werden: ${cleanError(err)}`));
    }
  }
  const uploadComposerFiles = async (list: FileList | null, imageOnly = false) => {
    const picked = Array.from(list ?? []);
    if (!picked.length) return;
    const uploadConnection = connection;
    const uploadSourceKey = messageSourceKeyRef.current;
    if (!uploadConnection) { setAttachmentStatus(tr('Upload nicht möglich: nicht verbunden.')); return; }
    const files = imageOnly ? picked.filter((file) => file.type.startsWith('image/')) : picked;
    if (imageOnly && files.length !== picked.length) setAttachmentStatus(tr('Nur Bilddateien wurden übernommen.'));
    if (!files.length) { setAttachmentStatus(tr('Keine gültige Datei ausgewählt.')); return; }
    setUploadingAttachments(true);
    setAttachmentStatus(tr(`${files.length} Datei(en) werden hochgeladen...`));
    try {
      const uploaded: SharkordTempFile[] = [];
      for (const file of files) uploaded.push(await uploadTemporaryFile(uploadConnection, file));
      if (messageSourceKeyRef.current !== uploadSourceKey) {
        await Promise.all(uploaded.map((file) => deleteTemporaryFile(uploadConnection, file.id).catch(() => undefined)));
        return;
      }
      setAttachments((current) => [...current, ...uploaded]);
      setAttachmentStatus(tr(`${uploaded.length} Datei(en) angehängt.`));
    } catch (err) {
      setAttachmentStatus(tr(`Upload fehlgeschlagen: ${cleanError(err)}`));
    } finally {
      setUploadingAttachments(false);
    }
  };

  const rememberEmoji = (emoji: string) => {
    const next = [emoji, ...recentEmojis.filter((item) => item !== emoji)].slice(0, 32);
    setRecentEmojis(next);
    saveRecentEmojis(next);
  };
  const insertEmoji = (emoji: string) => { rememberEmoji(emoji); setComposer(`${composer}${emoji}`); setEmojiPickerOpen(false); };
  const loadPinnedMessagesPopover = async () => {
    if (!connection || !selectedChannel) return;
    setPinnedMessagesOpen(true);
    setPinnedStatus(tr('Angepinnte Nachrichten werden geladen…'));
    try {
      const rows = await getPinnedMessages(connection, selectedChannel.id);
      setPinnedMessages(rows);
      setPinnedStatus(rows.length ? tr(`${rows.length} angepinnte Nachricht(en)`) : tr('Keine angepinnten Nachrichten'));
    } catch (err) {
      setPinnedStatus(tr(`Pins konnten nicht geladen werden: ${cleanError(err)}`));
    }
  };
  const insertMention = (user: SharkordUser) => {
    const mention = `@${displayUserName(user)} `;
    setComposer(mentionMatch ? composer.replace(/@([^@\s]*)$/, mention) : `${composer}${mention}`);
  };
  const insertRoleMention = (role: SharkordRole) => {
    const mention = `@&${role.name} `;
    setComposer(roleMentionMatch ? composer.replace(/@&([^@\s]*)$/, mention) : `${composer}${mention}`);
  };
  const selectPluginCommand = (command: SharkordPluginCommand) => {
    if (command.args?.length) {
      setSelectedPluginCommand(command);
      setPluginCommandArgValues(Object.fromEntries(command.args.map((arg) => [arg.name, arg.default === undefined ? '' : String(arg.default)])));
      setRichComposerText(`/${pluginCommandLabel(command)}`);
      window.requestAnimationFrame(() => document.querySelector<HTMLInputElement | HTMLSelectElement>('.pluginCommandArgField input, .pluginCommandArgField select')?.focus());
      return;
    }
    setSelectedPluginCommand(null);
    setPluginCommandArgValues({});
    setRichComposerText(`/${pluginCommandLabel(command)} `);
    window.requestAnimationFrame(() => richComposerRef.current?.focus());
  };
  const parsePluginCommandArgs = (command: SharkordPluginCommand, raw: string): Record<string, unknown> => {
    const args: Record<string, unknown> = {};
    const tokens = raw.match(/"[^"]*"|'[^']*'|\S+/g)?.map((token) => token.replace(/^("|')|("|')$/g, '')) ?? [];
    const positional = [...tokens];
    tokens.forEach((token) => {
      const eq = token.indexOf('=');
      if (eq <= 0) return;
      const key = token.slice(0, eq);
      const value = token.slice(eq + 1);
      args[key] = coercePluginCommandArg(value, command.args?.find((arg) => arg.name === key)?.type);
      const index = positional.indexOf(token);
      if (index >= 0) positional.splice(index, 1);
    });
    command.args?.forEach((arg, index) => {
      if (args[arg.name] !== undefined) return;
      const value = positional[index];
      if (value !== undefined) args[arg.name] = coercePluginCommandArg(value, arg.type);
      else if (arg.default !== undefined) args[arg.name] = arg.default;
    });
    if (!command.args?.length && raw.trim()) args.text = raw.trim();
    return args;
  };
  const buildPluginCommandArgsFromValues = (command: SharkordPluginCommand): Record<string, unknown> => {
    const args: Record<string, unknown> = {};
    command.args?.forEach((arg) => {
      const raw = pluginCommandArgValues[arg.name];
      if (raw !== undefined && raw !== '') args[arg.name] = coercePluginCommandArg(raw, arg.type);
      else if (arg.default !== undefined) args[arg.name] = arg.default;
    });
    return args;
  };
  const executeSelectedPluginCommand = async () => {
    if (!connection || !selectedPluginCommand) return false;
    if (!selectedPluginCommand.pluginId) { setStatus(tr('Plugin-Befehl nicht gefunden')); return true; }
    const missingArg = selectedPluginCommand.args?.find((arg) => arg.required && !String(pluginCommandArgValues[arg.name] ?? '').trim());
    if (missingArg) { setStatus(tr(`Pflichtfeld fehlt: ${missingArg.name}`)); return false; }
    try {
      setStatus(tr(`Plugin-Befehl /${pluginCommandLabel(selectedPluginCommand)} wird ausgeführt...`));
      const result = await executePluginCommand(connection, selectedPluginCommand.pluginId, selectedPluginCommand.name, buildPluginCommandArgsFromValues(selectedPluginCommand));
      setStatus(`${tr(`Plugin-Befehl /${pluginCommandLabel(selectedPluginCommand)} ausgeführt`)}${result ? ` · ${JSON.stringify(result).slice(0, 120)}` : ''}`);
      return true;
    } catch (err) {
      setStatus(tr(`Plugin-Befehl fehlgeschlagen: ${cleanError(err)}`));
      return false;
    }
  };
  const executeComposerPluginCommand = async () => {
    if (!connection) return false;
    if (selectedPluginCommand) return executeSelectedPluginCommand();
    const raw = composer.trim();
    if (!raw.startsWith('/')) return false;
    const [token = '', ...rest] = raw.slice(1).split(/\s+/);
    const command = pluginCommands.find((item) => pluginCommandLabel(item).toLowerCase() === token.toLowerCase() || item.name.toLowerCase() === token.toLowerCase());
    if (!command?.pluginId) { setStatus(tr('Plugin-Befehl nicht gefunden')); return true; }
    try {
      setStatus(tr(`Plugin-Befehl /${pluginCommandLabel(command)} wird ausgeführt...`));
      const result = await executePluginCommand(connection, command.pluginId, command.name, parsePluginCommandArgs(command, rest.join(' ')));
      setStatus(`${tr(`Plugin-Befehl /${pluginCommandLabel(command)} ausgeführt`)}${result ? ` · ${JSON.stringify(result).slice(0, 120)}` : ''}`);
      return true;
    } catch (err) {
      setStatus(tr(`Plugin-Befehl fehlgeschlagen: ${cleanError(err)}`));
      return false;
    }
  };
  const setRichComposerText = (value: string) => {
    setComposer(value);
    if (richComposerRef.current && richComposerRef.current.textContent !== value) richComposerRef.current.textContent = value;
  };
  const formatComposer = (format: 'bold' | 'italic' | 'code') => {
    const wrap = format === 'bold' ? '**' : format === 'italic' ? '*' : '`';
    const selection = window.getSelection();
    const selected = selection?.toString() || '';
    document.execCommand('insertText', false, `${wrap}${selected || tr('Text')}${wrap}`);
    const next = richComposerRef.current?.textContent ?? '';
    setComposer(next);
    notifyTyping();
  };
  // Legacy textarea source guard equivalent: onChange={(event) => { setComposer(event.target.value); notifyTyping(); }}
  const handleRichComposerInput = () => {
    const value = richComposerRef.current?.textContent ?? '';
    setComposer(value);
    if (selectedPluginCommand && value.trim() !== `/${pluginCommandLabel(selectedPluginCommand)}`) {
      setSelectedPluginCommand(null);
      setPluginCommandArgValues({});
    }
    notifyTyping();
  };
  const handleRichComposerPaste = (event: React.ClipboardEvent<HTMLDivElement>) => {
    event.preventDefault();
    const html = event.clipboardData.getData('text/html');
    const text = html ? textFromHtml(html) : event.clipboardData.getData('text/plain');
    document.execCommand('insertText', false, text);
    window.requestAnimationFrame(() => handleRichComposerInput());
  };
  const handleRichComposerKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'Enter' && !event.shiftKey && !event.altKey && !event.ctrlKey && !event.metaKey) {
      event.preventDefault();
      event.currentTarget.closest('form')?.requestSubmit();
      return;
    }
    if (event.key === 'ArrowUp' && !composer.trim() && ownUserId) {
      const lastOwnMessage = [...messages].reverse().find((message) => message.userId === ownUserId && !message.parentMessageId);
      if (lastOwnMessage) { event.preventDefault(); setEditTarget(lastOwnMessage); setComposer(textFromHtml(lastOwnMessage.content)); if (richComposerRef.current) richComposerRef.current.textContent = textFromHtml(lastOwnMessage.content); }
    }
  };
  useEffect(() => {
    if (richComposerRef.current && richComposerRef.current.textContent !== composer) richComposerRef.current.textContent = composer;
  }, [composer]);
  const handleComposerSubmit = async (event: FormEvent<HTMLFormElement>) => {
    if (selectedPluginCommand || composer.trim().startsWith('/')) {
      event.preventDefault();
      if (await executeComposerPluginCommand()) { setSelectedPluginCommand(null); setPluginCommandArgValues({}); setRichComposerText(''); setEmojiPickerOpen(false); }
      return;
    }
    if (editTarget && (composer.trim() || attachments.length > 0)) {
      event.preventDefault();
      if (attachments.length > 0 && !canEditAttachments) {
        setAttachmentStatus(tr('Server unterstützt Anhänge beim Bearbeiten nicht.'));
        return;
      }
      onEditMessage(editTarget, composer.trim(), attachments.length > 0 ? attachments : undefined);
      setAttachments([]);
      setAttachmentStatus('');
      setEditTarget(null);
      setRichComposerText('');
      return;
    }
    const success = await sendMessage(event, attachments);
    if (success) { setAttachments([]); setAttachmentStatus(tr('')); setEmojiPickerOpen(false); setEditTarget(null); setRichComposerText(''); }
  };

  useEffect(() => {
    const openGlobalSearch = () => setGlobalSearchOpen(true);
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setGlobalSearchOpen(false);
    };
    window.addEventListener('sharkord:open-global-search', openGlobalSearch);
    window.addEventListener('keydown', onKeyDown);
    return () => {
      window.removeEventListener('sharkord:open-global-search', openGlobalSearch);
      window.removeEventListener('keydown', onKeyDown);
    };
  }, []);
  const runGlobalSearch = async (append = false) => {
    const query = globalSearchQuery.trim();
    if (!connection) { setGlobalSearchStatus(tr('Nicht verbunden.')); return; }
    if (query.length < 2) { setGlobalSearchStatus(tr('Mindestens 2 Zeichen eingeben.')); return; }
    setGlobalSearchLoading(true);
    setGlobalSearchStatus(t('search.global.running'));
    try {
      const searchPage = await globalSearchMessages(connection, { query, cursor: append ? globalSearchCursor : null, limit: 25 });
      const files = searchPage.files ?? [];
      setGlobalSearchResults((current) => append ? [...current, ...searchPage.messages] : searchPage.messages);
      setGlobalFileSearchResults((current) => append ? [...current, ...files] : files);
      setGlobalSearchCursor(searchPage.nextCursor);
      setGlobalFileSearchCursor(searchPage.nextCursor);
      const count = (append ? globalSearchResults.length : 0) + searchPage.messages.length + (append ? globalFileSearchResults.length : 0) + files.length;
      setGlobalSearchStatus(count ? tr(`${count} Treffer geladen.`) : tr('Keine Treffer.'));
    } catch (err) {
      setGlobalSearchStatus(`${t('search.global.failed')}: ${cleanError(err)}`);
    } finally {
      setGlobalSearchLoading(false);
    }
  };
  const openGlobalSearchResult = async (message: GlobalSearchMessageResult) => {
    const opened = await onGlobalSearchJump(message.channelId, message.id);
    if (opened) setGlobalSearchOpen(false);
  };
  const resetGlobalSearch = () => {
    setGlobalSearchResults([]);
    setGlobalFileSearchResults([]);
    setGlobalSearchCursor(null);
    setGlobalFileSearchCursor(null);
    setGlobalSearchStatus('');
  };

  const loadUserStorage = async () => {
    if (!connection) { setStorageStatus(tr('Nicht verbunden.')); return; }
    setStorageOpen(true);
    setStorageLoading(true);
    setStorageStatus(tr('Dateien werden geladen...'));
    try {
      const files = await getOwnStorageFiles(connection);
      setStorageFiles(files.sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0)));
      setStorageStatus(files.length ? tr(`${files.length} Datei(en) geladen.`) : tr('Noch keine hochgeladenen Dateien.'));
    } catch (err) {
      setStorageStatus(tr(`Speicher konnte nicht geladen werden: ${cleanError(err)}. Der Server erlaubt diese Liste ggf. nur Nutzern mit MANAGE_USERS.`));
    } finally {
      setStorageLoading(false);
    }
  };
  const removeStorageFile = async (file: SharkordFile) => {
    if (!connection) return;
    const label = storageFileLabel(file);
    const ok = window.confirm(tr(`Datei "${label}" wirklich löschen? Sie verschwindet auch aus Nachrichten.`));
    if (!ok) return;
    setDeletingStorageFileId(file.id);
    setStorageStatus(tr(`${label} wird gelöscht...`));
    try {
      await deleteStoredFile(connection, file.id);
      setStorageFiles((current) => current.filter((item) => item.id !== file.id));
      setStorageStatus(tr(`${label} gelöscht.`));
    } catch (err) {
      setStorageStatus(tr(`Löschen fehlgeschlagen: ${cleanError(err)}`));
    } finally {
      setDeletingStorageFileId(null);
    }
  };
  return <section className={`messagePane discordMain ${!membersOpen ? 'membersCollapsed' : ''}`}>
    <header className="channelTopBar messagePaneHeader"><div className="channelIdentity">{selectedVoice ? <Mic size={20} /> : selectedChannel ? <Hash size={22} /> : <WifiOff size={20} />}<strong>{title}</strong>{selectedChannel ? <span className="topicDivider" /> : null}<span className="channelTopic">{selectedVoice ? (isSelectedVoiceJoined ? tr('Voice verbunden') : serverVoicePresence ? tr('Server meldet alte Voice-Session · erneut beitreten') : tr('Zum Beitreten Voice-Kanal anklicken')) : selectedChannel ? (mentionsOnly ? tr('Nur Erwähnungen') : notificationCenterMuted ? tr('Benachrichtigungen stumm') : 'Sharkord native tRPC channel') : status}</span></div><div className="channelTools"><PluginSlotRenderer connection={connection} slot={'topbar'} items={pluginSlots.topbar} context={pluginSlotContext} onStatus={setGlobalSearchStatus} /><button type="button" className={`channelToolButton notificationCenterButton ${notificationCenterOpen ? 'active' : ''}`} onClick={() => setNotificationCenterOpen(!notificationCenterOpen)} title={tr('Benachrichtigungszentrum')} aria-label={tr('Benachrichtigungszentrum')} aria-expanded={notificationCenterOpen}><Bell size={18} />{notificationCenterItems.filter((item) => !item.read).length ? <span className="notificationCenterBadge">{Math.min(99, notificationCenterItems.filter((item) => !item.read).length)}</span> : null}</button><button type="button" className={`channelToolButton ${notificationCenterMuted ? 'active' : ''}`} onClick={() => setNotificationCenterMuted(!notificationCenterMuted)} title={notificationCenterMuted ? tr('Benachrichtigungen einschalten') : tr('Benachrichtigungen stummschalten')} aria-label={tr('Benachrichtigungen umschalten')} aria-pressed={notificationCenterMuted}>{notificationCenterMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}</button><button type="button" className={`channelToolButton ${mentionsOnly ? 'active' : ''}`} onClick={() => setMentionsOnly(!mentionsOnly)} title={tr('Nur Erwähnungen anzeigen')} aria-label={tr('Nur Erwähnungen anzeigen')} aria-pressed={mentionsOnly}><AtSign size={18} /></button><button type="button" className="channelToolButton" onClick={() => void loadPinnedMessagesPopover()} aria-label={tr('Angepinnte Nachrichten')}><Pin size={18} /></button><button type="button" className={`memberPanelToggle ${membersOpen ? 'active' : ''}`} onClick={() => setMembersOpen(!membersOpen)} title={membersOpen ? tr('Memberliste ausblenden') : tr('Memberliste anzeigen')} aria-label={membersOpen ? tr('Memberliste ausblenden') : tr('Memberliste anzeigen')}><Users size={18} /></button><button type="button" className={`channelToolButton ${globalSearchOpen ? 'active' : ''}`} onClick={() => setGlobalSearchOpen(true)} title={`${t('search.global.title')} (Ctrl+K)`} aria-label={t('search.global.title')} aria-expanded={globalSearchOpen}><Search size={18} /></button><label className="searchBox" aria-label={tr('Nachrichten suchen')}><Search size={14} /><input value={messageSearch} onChange={(event) => setMessageSearch(event.target.value)} placeholder={tr('Suchen')} /></label><button type="button" className={`channelToolButton ${storageOpen ? 'active' : ''}`} onClick={() => void loadUserStorage()} title={tr('Speicher öffnen')} aria-label={tr('Speicher öffnen')} aria-expanded={storageOpen}><HardDrive size={18} /></button><div className="headerHelpWrap"><button type="button" className={`channelToolButton ${headerHelpOpen ? 'active' : ''}`} onClick={() => setHeaderHelpOpen(!headerHelpOpen)} title={tr('Hilfe anzeigen')} aria-label={tr('Hilfe anzeigen')} aria-expanded={headerHelpOpen}><HelpCircle size={18} /></button>{headerHelpOpen ? <div className="channelHelpPopover"><strong>{tr('Chat-Hilfe')}</strong><span><b>{tr('Suche')}</b> {tr('filtert Nachrichten und Autoren.')}</span><span><b>@</b> {tr('zeigt nur deine Erwähnungen.')}</span><span><b>{tr('Festplatte')}</b> {tr('öffnet deine hochgeladenen Dateien.')}</span><span><b>@Name</b> {tr('im Eingabefeld öffnet Erwähnungen.')}</span></div> : null}</div></div></header>
    {notificationCenterOpen ? <NotificationCenter items={notificationCenterItems} muted={notificationCenterMuted} onOpenItem={onOpenNotificationItem} onClear={onClearNotifications} onMarkRead={onMarkNotificationsRead} onClose={() => setNotificationCenterOpen(false)} /> : null}

    {globalSearchOpen ? <GlobalSearchDialog open={globalSearchOpen} query={globalSearchQuery} setQuery={(value) => { setGlobalSearchQuery(value); resetGlobalSearch(); }} messageResults={globalSearchResults} fileResults={globalFileSearchResults} status={globalSearchStatus} loading={globalSearchLoading} hasMore={!!(globalSearchCursor || globalFileSearchCursor)} onSearch={() => void runGlobalSearch(false)} onLoadMore={() => void runGlobalSearch(true)} onClose={() => setGlobalSearchOpen(false)} onOpenMessage={openGlobalSearchResult} baseUrl={baseUrl} channels={activeServer ? [] : []} /> : null}
    {pinnedMessagesOpen ? <div className="pinnedMessagesPopover" role="dialog" aria-label={tr('Angepinnte Nachrichten')}><header><strong>{tr('Angepinnte Nachrichten')}</strong><button type="button" onClick={() => setPinnedMessagesOpen(false)}>×</button></header><small>{tr(pinnedStatus)}</small>{pinnedMessages.map((message) => <article key={message.id} className="pinnedMessageRow"><span>{textFromHtml(message.content) || `${tr('Nachricht')} ${message.id}`}</span><button type="button" onClick={() => { onJumpToMessage(message.id); setPinnedMessagesOpen(false); }}>{tr('Springen')}</button></article>)}</div> : null}
    {storageOpen ? <div className="modalBackdrop userStorageBackdrop" role="dialog" aria-modal="true" aria-label={tr('Meine Dateien')} onClick={() => setStorageOpen(false)}>
      <section className="userStorageModal" onClick={(event) => event.stopPropagation()}>
        <header><div><strong>{tr('Meine Dateien')}</strong><span>{storageFiles.length} {tr('Datei(en)')} · {formatFileSize(storageUsedBytes)}</span></div><button type="button" onClick={() => setStorageOpen(false)} aria-label={tr('Speicher schließen')}>×</button></header>
        <label className="userStorageSearch"><Search size={15} /><input value={storageQuery} onChange={(event) => setStorageQuery(event.target.value)} placeholder={tr('Dateien suchen')} /></label>
        <div className="userStorageActions"><button type="button" onClick={() => void loadUserStorage()} disabled={storageLoading}>{tr('Aktualisieren')}</button><small>{tr(storageStatus)}</small></div>
        <div className="userStorageGrid">
          {filteredStorageFiles.length ? filteredStorageFiles.map((file) => {
            const href = fileUrl(baseUrl, file);
            const label = storageFileLabel(file);
            const isImage = isImageAttachment(file, label);
            const mime = attachmentMime(file);
            return <article className="userStorageFileCard" key={file.id}>
              <button type="button" className="userStoragePreview" onClick={() => setAttachmentLightbox({ file, href, label, isImage })} aria-label={`${label} ${tr('anzeigen')}`}>{isImage && href ? <img src={href} alt="" loading="lazy" /> : <HardDrive size={26} />}</button>
              <div><strong title={label}>{label}</strong><span>{file.extension || mime || tr('Datei')} · {formatFileSize(file.size)}</span><span>{formatTimestamp(file.createdAt)}</span></div>
              <div className="userStorageFileActions"><a href={href} target="_blank" rel="noreferrer">{tr('Datei öffnen')}</a><a href={href} download={label} rel="noreferrer">{tr('Herunterladen')}</a><button type="button" onClick={() => void copyAttachmentUrl(href)} disabled={!href}>{tr('URL kopieren')}</button><button type="button" className="danger" onClick={() => void removeStorageFile(file)} disabled={deletingStorageFileId === file.id}>{tr('Datei löschen')}</button></div>
            </article>;
          }) : <div className="userStorageEmpty"><HardDrive size={30} /><strong>{tr('Keine Dateien')}</strong><span>{storageLoading ? tr('Lade Speicher...') : storageQuery ? tr('Keine Treffer.') : tr('Noch nichts hochgeladen.')}</span></div>}
        </div>
      </section>
    </div> : null}
    <AttachmentLightbox item={attachmentLightbox} onClose={() => setAttachmentLightbox(null)} />
    <div className="messagesList messageScroller" ref={messageScrollerRef}>
      <PluginSlotRenderer connection={connection} slot={'content-wrapper'} items={pluginSlots['content-wrapper']} context={pluginSlotContext} onStatus={setGlobalSearchStatus} variant="panel" />
      {!connection ? <div className="welcomeHero nativeEmpty"><div className="heroIcon logoHero"><img className="heroLogo" src={sharkordLogo} alt="Sharkord" /></div><h2>{tr('Willkommen bei Sharkord Desktop')}</h2><p>{tr('Server wählen, Login speichern, dann zwischen Servern, Channels und Members arbeiten — ohne iframe.')}</p></div> : null}
      {connection && selectedVoice ? <VoiceGridView channel={selectedVoice} joined={isSelectedVoiceJoined} serverVoicePresence={serverVoicePresence} users={selectedVoiceUsers} speakingUserIds={speakingUserIds} ownUserId={ownUserId} server={activeServer} routerRtpCapabilities={routerRtpCapabilities} onJoin={onJoinVoice} busy={voiceBusy} voiceState={voiceState} onToggleMic={onToggleMic} onToggleSound={onToggleSound} onToggleVideo={onToggleVideo} onToggleScreen={onToggleScreen} onLeaveVoice={onLeaveVoice} localVideoStream={localVideoStream} localScreenStream={localScreenStream} remoteVideoStreams={remoteVideoStreams} streamAudioMutedUsers={streamAudioMutedUsers} onToggleStreamAudioMute={onToggleStreamAudioMute} usersById={usersById} baseUrl={baseUrl} onUserMenu={onUserMenu} onUserProfile={onUserProfile} /> : null}
      {connection && selectedChannel && messages.length === 0 ? <div className="welcomeHero nativeEmpty"><div className="heroIcon"><Hash size={28} /></div><h2>{tr('Willkommen in')} #{selectedChannel.name}</h2><p>{busy ? tr('Lade Nachrichten...') : tr('Das ist der Anfang dieses Channels.')}</p></div> : null}
      {connection && selectedChannel && messages.length > 0 && visibleMessages.length === 0 ? <div className="welcomeHero nativeEmpty"><div className="heroIcon"><Search size={28} /></div><h2>{tr('Keine Treffer')}</h2><p>{tr('Suche oder Erwähnungsfilter ändern.')}</p></div> : null}
      {visibleMessages.map((message) => <MessageBubble key={message.id} message={message} usersById={usersById} own={message.userId === ownUserId} canDelete={message.userId === ownUserId || canManageMessages} canToggleMessagePin={canToggleMessagePin} baseUrl={baseUrl} onEdit={onEditMessage} onDelete={onDeleteMessage} onTogglePin={onTogglePin} onToggleReaction={onToggleReaction} onUserProfile={onUserProfile} onReply={setReplyTarget} onOpenThread={onOpenThread} />)}
    </div>
    {ownUserId && localAudioStream ? <AudioSpeakingWatcher key={`local-${ownUserId}`} userId={ownUserId} stream={localAudioStream} disabled={voiceState.micMuted || voiceState.soundMuted} onChange={onSpeakingChange} /> : null}
    {remoteSpeechStreams.map((item) => <AudioSpeakingWatcher key={`${item.remoteId}-${item.kind}`} userId={item.remoteId} stream={item.stream} disabled={voiceState.soundMuted || (!!activeServer && isStreamAudioKind(item.kind) && isStreamAudioMuted(streamAudioMutedUsers, activeServer.id, item.remoteId))} onChange={onSpeakingChange} />)}
    {typingNames.length ? <div className="typingIndicator">{typingNames.join(', ')} {tr('schreibt...')}</div> : null}
    {threadPanel ? <ThreadPanel panel={threadPanel} usersById={usersById} ownUserId={ownUserId} canManageMessages={canManageMessages} baseUrl={baseUrl} onClose={onCloseThread} onSend={onSendThreadMessage} onEdit={onEditMessage} onDelete={onDeleteMessage} onToggleReaction={onToggleReaction} onTogglePin={onTogglePin} onUserProfile={onUserProfile} /> : null}
    {selectedChannel ? <form className="messageComposer discordComposer" onSubmit={handleComposerSubmit}>
      <input ref={fileInputRef} className="composerFileInput" type="file" multiple onChange={(event) => void uploadComposerFiles(event.currentTarget.files)} />
      <input ref={imageInputRef} className="composerFileInput" type="file" multiple accept="image/*" onChange={(event) => void uploadComposerFiles(event.currentTarget.files, true)} />
      <button type="button" className="composerIcon" onClick={openFilePicker} disabled={!connection || busy || uploadingAttachments || (!!editTarget && !canEditAttachments)} title={tr('Datei anhängen')} aria-label={tr('Datei anhängen')}><Plus size={20} /></button>
      <div className="composerInputStack">
        {replyTarget ? <div className="replyPreview"><span>{tr('Antwort an')} {displayUserName(replyTarget.user || replyTarget.author || usersById.get(replyTarget.userId))}: {textFromHtml(replyTarget.content)}</span><button type="button" onClick={() => setReplyTarget(null)} aria-label={tr('Antwort abbrechen')}>×</button></div> : null}
        {editTarget ? <div className="replyPreview editPreview"><span>{tr('Nachricht bearbeiten')}: {textFromHtml(editTarget.content)}</span>{editTarget?.files?.length ? <small>{tr('Bestehende Anhänge')}: {editTarget.files.map(attachmentLabel).join(', ')}</small> : null}<button type="button" onClick={() => { setEditTarget(null); setAttachments([]); setRichComposerText(''); }} aria-label={tr('Bearbeiten abbrechen')}>×</button></div> : null}
        {attachments.length || attachmentStatus ? <div className="composerAttachmentTray">{attachments.map((file) => <span className="composerAttachmentChip" key={String(file.id)} title={attachmentLabel(file)}>{attachmentLabel(file)}<button type="button" onClick={() => void removeAttachment(file)} aria-label={`${attachmentLabel(file)} ${tr('entfernen')}`}>×</button></span>)}{attachmentStatus ? <small>{attachmentStatus}</small> : null}</div> : null}
        <div className="richComposerToolbar" aria-label={tr('Formatierung')}><button type="button" onClick={() => formatComposer('bold')} aria-label={tr('Fett')}>B</button><button type="button" onClick={() => formatComposer('italic')} aria-label={tr('Kursiv')}><em>I</em></button><button type="button" onClick={() => formatComposer('code')} aria-label={tr('Code')}>{'{}'}</button><span className="pluginCommandHint">/ {tr('Plugin-Befehl')}</span></div>
        {selectedPluginCommand?.args?.length ? <div className="pluginCommandBuilder" aria-label={tr('Plugin-Befehl Argumente')}>
          <div className="pluginCommandBuilderHeader"><strong>/{pluginCommandLabel(selectedPluginCommand)}</strong><button type="button" onClick={() => { setSelectedPluginCommand(null); setPluginCommandArgValues({}); setRichComposerText(''); }} aria-label={tr('Plugin-Befehl abbrechen')}>×</button></div>
          <div className="pluginCommandArgGrid">
            {selectedPluginCommand.args.map((arg) => <label className="pluginCommandArgField" key={arg.name}><span>{arg.name}{arg.required ? ' *' : ''}</span>{arg.type === 'boolean' ? <select value={pluginCommandArgValues[arg.name] ?? ''} onChange={(event) => setPluginCommandArgValues((current) => ({ ...current, [arg.name]: event.target.value }))}><option value="">-</option><option value="true">true</option><option value="false">false</option></select> : <input type={arg.type === 'number' ? 'number' : 'text'} value={pluginCommandArgValues[arg.name] ?? ''} placeholder={arg.required ? tr('Pflichtfeld') : tr('Optional')} onChange={(event) => setPluginCommandArgValues((current) => ({ ...current, [arg.name]: event.target.value }))} />}{arg.description ? <small>{arg.description}</small> : null}</label>)}
          </div>
        </div> : null}
        {!selectedPluginCommand && pluginCommandSuggestions.length ? <div className="pluginCommandMenu"><strong>{tr('Plugin-Befehle')}</strong>{pluginCommandSuggestions.map((command) => <button type="button" className="pluginCommandItem" key={`${command.pluginId}:${command.name}`} data-plugin-id={command.pluginId} onMouseDown={(event) => { event.preventDefault(); selectPluginCommand(command); }}><span>/{pluginCommandLabel(command)}</span><small>{command.description || command.args?.map((arg) => `${arg.name}${arg.required ? '*' : ''}`).join(' ') || tr('Plugin-Befehl ausführen')}</small></button>)}</div> : !selectedPluginCommand && composer.trim().startsWith('/') ? <div className="pluginCommandMenu"><strong>{tr('Plugin-Befehle')}</strong><span>{tr('Kein passender Plugin-Befehl')}</span></div> : null}
        <div ref={richComposerRef} className="richComposerInput" contentEditable={!busy && !!connection} role="textbox" aria-multiline="true" aria-label={`${tr('Nachricht an')} #${selectedChannel.name}`} data-placeholder={`${tr('Nachricht an')} #${selectedChannel.name}`} onInput={handleRichComposerInput} onPaste={handleRichComposerPaste} onKeyDown={handleRichComposerKeyDown} />
        {mentionSuggestions.length ? <div className="composerMentionMenu">{mentionSuggestions.map((user) => <button type="button" key={user.id} onClick={() => insertMention(user)}><AvatarView user={user} name={displayUserName(user)} baseUrl={baseUrl} className="mentionAvatar" /><span>@{displayUserName(user)}</span></button>)}</div> : null}
        {roleMentionSuggestions.length ? <div className="composerRoleMentionMenu composerMentionMenu"><strong>{tr('Rollen erwähnen')}</strong>{roleMentionSuggestions.map((role) => <button type="button" key={role.id} onClick={() => insertRoleMention(role)}><span className="roleMentionDot" style={{ backgroundColor: role.color || '#8b949e' }} /> <span>@&{role.name}</span></button>)}</div> : roleMentionMatch && !canMentionRoles ? <div className="composerRoleMentionMenu composerMentionMenu"><span>{tr('Dieser Server unterstützt Rollen-Erwähnungen nicht.')}</span></div> : null}
      </div>
      <div className="composerTools">
        <PluginSlotRenderer connection={connection} slot={'chat-actions'} items={pluginSlots['chat-actions']} context={pluginSlotContext} onStatus={setGlobalSearchStatus} />
        <button type="button" className="composerToolButton" onClick={openImagePicker} disabled={!connection || busy || uploadingAttachments || (!!editTarget && !canEditAttachments)} title={tr('Bild anhängen')} aria-label={tr('Bild anhängen')}><ImageIcon size={18} /></button>
        <div className="composerEmojiWrap"><button type="button" className="composerToolButton" onClick={() => setEmojiPickerOpen(!emojiPickerOpen)} disabled={!connection || busy} title={tr('Emoji auswählen')} aria-label={tr('Emoji einfügen')}><Smile size={18} /></button>{emojiPickerOpen ? <div className="composerEmojiMenu emojiPickerPopover"><strong className="emojiPickerTitle">{tr('Emoji auswählen')}</strong>{emojiChoices.map((emoji) => <button type="button" key={emoji} onClick={() => insertEmoji(emoji)}>{emoji}</button>)}</div> : null}</div>
      </div>
      <button className="sendButton" type="submit" disabled={!connection || (!composer.trim() && attachments.length === 0) || busy || uploadingAttachments}><Send size={18} /></button>
    </form> : null}
  </section>;
}

function PluginSlotRenderer({ connection, slot, items, context, onStatus, variant = 'buttons' }: { connection: SharkordConnection | null; slot: PluginSlotId; items: SharkordPluginSlotRender[]; context: PluginSlotContext; onStatus: (status: string) => void; variant?: 'buttons' | 'panel' }) {
  const [runningKey, setRunningKey] = useState<string | null>(null);
  const [localStatus, setLocalStatus] = useState('');
  const visibleItems = useMemo(() => [...items].filter((item) => item.enabled !== false).sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || (a.label || a.title || a.actionName || '').localeCompare(b.label || b.title || b.actionName || '')), [items]);
  if (!visibleItems.length) return null;
  const runSlotAction = async (item: SharkordPluginSlotRender) => {
    const label = item.label || item.title || item.actionName || item.pluginId;
    if (!connection || !item.actionName) { const message = tr(`Plugin-Slot ${label}: nicht ausführbar`); setLocalStatus(message); onStatus(message); return; }
    const key = `${item.pluginId}:${item.slot}:${item.actionName}`;
    setRunningKey(key);
    setLocalStatus(tr(`${label}…`));
    try {
      const result = await executePluginSlotAction(connection, item, context);
      const message = `${tr(`Plugin-Slot ${label}: OK`)}${result ? ` · ${JSON.stringify(result).slice(0, 80)}` : ''}`;
      setLocalStatus(message);
      onStatus(message);
    } catch (err) {
      const message = tr(`Plugin-Slot ${label}: ${cleanError(err)}`);
      setLocalStatus(message);
      onStatus(message);
    } finally {
      setRunningKey(null);
    }
  };
  return <div className={`pluginSlotRenderer pluginSlot-${slot} ${variant === 'panel' ? 'pluginSlotPanel' : ''}`} data-slot={slot} aria-label={`Plugin slot ${slot}`}>
    {variant === 'panel' ? <strong className="pluginSlotPanelTitle">{tr('Plugin-Erweiterungen')}</strong> : null}
    <div className="pluginSlotItems">{visibleItems.map((item) => {
      const label = item.label || item.title || item.actionName || item.pluginId;
      const key = `${item.pluginId}:${item.slot}:${item.actionName ?? item.componentSlot ?? label}:${item.componentIndex ?? 0}`;
      const Component = item.component;
      if (Component) return <div className="pluginSlotComponent" key={key} title={item.description || label}><Component /></div>;
      const disabled = !connection || !item.actionName || runningKey === key || item.enabled === false;
      return <button type="button" className="pluginSlotButton" key={key} onClick={() => void runSlotAction(item)} disabled={disabled} title={item.description || label}>
        {item.icon ? <span className="pluginSlotIcon" aria-hidden="true">{item.icon}</span> : null}<span>{label}</span>
      </button>;
    })}</div>
    {localStatus && variant === 'panel' ? <small className="pluginSlotStatus">{localStatus}</small> : null}
  </div>;
}

function NotificationCenter({ items, muted, onOpenItem, onClear, onMarkRead, onClose }: { items: NotificationCenterItem[]; muted: boolean; onOpenItem: (item: NotificationCenterItem) => void; onClear: () => void; onMarkRead: () => void; onClose: () => void }) {
  const unreadCount = items.filter((item) => !item.read).length;
  const kindLabel = (kind: NotificationCenterKind) => kind === 'dm' ? 'DM' : kind === 'mention' ? tr('Mention') : kind === 'reply' ? tr('Reply') : tr('Nachricht');
  return <div className="notificationCenterPopover" role="dialog" aria-label={tr('Benachrichtigungszentrum')}>
    <header><div><strong>{tr('Benachrichtigungszentrum')}</strong><span>{muted ? tr('Benachrichtigungen stumm') : unreadCount ? tr(`${unreadCount} ungelesen`) : tr('Keine ungelesenen Benachrichtigungen')}</span></div><button type="button" onClick={onClose} aria-label={tr('Schließen')}>×</button></header>
    <div className="notificationCenterActions"><button type="button" onClick={onMarkRead} disabled={!items.length}>{tr('Alle als gelesen markieren')}</button><button type="button" onClick={onClear} disabled={!items.length}>{tr('Benachrichtigungen leeren')}</button></div>
    {items.length ? <div className="notificationCenterList">{items.map((item) => <button type="button" key={item.id} className={`notificationCenterItem ${item.read ? 'read' : 'unread'}`} onClick={() => onOpenItem(item)}><span className="notificationCenterMeta"><b>{kindLabel(item.kind)}</b><small>{item.serverName} · {item.channelName}</small></span><strong>{item.authorName}</strong><span>{item.body}</span></button>)}</div> : <p className="notificationCenterEmpty">{tr('Noch keine Benachrichtigungen.')}</p>}
  </div>;
}

function GlobalSearchDialog({ open, query, setQuery, messageResults, fileResults, status, loading, hasMore, onSearch, onLoadMore, onClose, onOpenMessage, baseUrl }: { open: boolean; query: string; setQuery: (value: string) => void; messageResults: GlobalSearchMessageResult[]; fileResults: GlobalSearchFileResult[]; status: string; loading: boolean; hasMore: boolean; onSearch: () => void; onLoadMore: () => void; onClose: () => void; onOpenMessage: (message: GlobalSearchMessageResult) => void; baseUrl: string; channels?: SharkordChannel[] }) {
  const submitSearch = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); onSearch(); };
  const fileLabel = (file: GlobalSearchFileResult) => file.originalName || file.name || `${tr('Datei')} ${file.id}`;
  if (!open) return null;
  return <div className="modalBackdrop globalSearchBackdrop" role="dialog" aria-modal="true" aria-label={t('search.global.title')} onMouseDown={onClose}>
    <section className="globalSearchDialog" onMouseDown={(event) => event.stopPropagation()}>
      <header><div><strong>{t('search.global.title')}</strong><span>{t('search.global.description')} · Ctrl+K</span></div><button type="button" onClick={onClose} aria-label={tr('Suche schließen')}>×</button></header>
      <form className="globalSearchForm" onSubmit={submitSearch}><Search size={18} /><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder={tr('Nachrichten oder Dateien suchen')} /><button type="submit" disabled={loading || query.trim().length < 2}>{loading ? tr('Sucht...') : tr('Suchen')}</button></form>
      <small className="globalSearchStatus">{status ? tr(status) : tr('Suchbegriff eingeben, Enter drücken.')}</small>
      <div className="globalSearchResults">
        <section><h3>{tr('Nachrichten')}</h3>{messageResults.length ? messageResults.map((message) => {
          const author = displayUserName(message.user || message.author);
          const channelName = message.channel?.name || `#${message.channelId}`;
          return <button type="button" className="globalSearchResultRow" key={`message-${message.channelId}-${message.id}`} onClick={() => onOpenMessage(message)}><Hash size={16} /><span><strong>{channelName}</strong><small>{author ? `${author} · ` : ''}{formatTimestamp(message.createdAt)}</small><em>{message.excerpt || textFromHtml(message.content) || `${tr('Nachricht')} ${message.id}`}</em></span></button>;
        }) : <div className="globalSearchEmpty"><Search size={24} /><span>{loading ? tr('Nachrichten werden gesucht...') : tr('Keine Nachrichten-Treffer')}</span></div>}</section>
        <section><h3>{tr('Dateien')}</h3>{fileResults.length ? fileResults.map((file) => {
          const href = fileUrl(baseUrl, file);
          return <article className="globalSearchFileRow" key={`file-${file.id}`}><HardDrive size={17} /><span><strong>{fileLabel(file)}</strong><small>{formatFileSize(file.size)} · {formatTimestamp(file.createdAt)}</small></span>{href ? <a href={href} target="_blank" rel="noreferrer">{tr('Öffnen')}</a> : null}</article>;
        }) : <div className="globalSearchEmpty"><HardDrive size={24} /><span>{loading ? tr('Dateien werden gesucht...') : tr('Keine Datei-Treffer')}</span></div>}</section>
      </div>
      <footer><button type="button" className="secondary" onClick={onClose}>{tr('Schließen')}</button><button type="button" onClick={onLoadMore} disabled={loading || !hasMore}>{tr('Mehr laden')}</button></footer>
    </section>
  </div>;
}

function WelcomeProfileSetupDialog({ connection, user, baseUrl, onSave, onSkip }: { connection: SharkordConnection; user: SharkordUser | null; baseUrl: string; onSave: (input: { name: string; bio: string; bannerColor: string; avatarFile: File | null }) => Promise<void>; onSkip: () => void }) {
  const [name, setName] = useState(user?.name || user?.identity || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [bannerColor, setBannerColor] = useState('#5865f2');
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const avatarFileName = avatarFile?.name ?? '';
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!name.trim()) { setError(tr('Name fehlt.')); return; }
    setSaving(true); setError('');
    try { await onSave({ name, bio, bannerColor, avatarFile }); }
    catch (err) { setError(cleanError(err)); }
    finally { setSaving(false); }
  };
  return <div className="modalBackdrop welcomeProfileBackdrop" role="dialog" aria-modal="true" aria-label={tr('Profil einrichten')}>
    <form className="welcomeProfileSetupDialog welcome-profile-setup" onSubmit={submit}>
      <header><div><strong>{tr('Willkommen bei Sharkord')}</strong><span>{tr('Richte dein Profil für diesen Server ein.')}</span></div></header>
      <section className="welcomeProfilePreview" style={{ '--profile-banner': bannerColor } as React.CSSProperties}><div className="welcomeProfileBanner" /><AvatarView user={user ?? undefined} name={name || connection.join.serverName} baseUrl={baseUrl} className="profileSetupAvatar" /><strong>{name || tr('Dein Name')}</strong><span>{bio || tr('Kurze Bio optional')}</span>{avatarFileName ? <small>{tr('Neuer Avatar')}: {avatarFileName}</small> : null}</section>
      <label>{tr('Anzeigename')}<input value={name} onChange={(event) => setName(event.target.value)} maxLength={80} autoFocus /></label>
      <label>{tr('Bio')}<textarea value={bio} onChange={(event) => setBio(event.target.value)} maxLength={280} rows={3} /></label>
      <label>{tr('Bannerfarbe')}<input type="color" value={bannerColor} onChange={(event) => setBannerColor(event.target.value)} /></label>
      <label>{tr('Avatar optional')}<input type="file" accept="image/*" onChange={(event) => setAvatarFile(event.currentTarget.files?.[0] ?? null)} /></label>
      {error ? <p className="formError" role="alert">{tr(error)}</p> : null}
      <footer><button type="button" className="secondary" onClick={onSkip} disabled={saving}>{tr('Später')}</button><button type="submit" className="primaryAction" disabled={saving || !name.trim()}>{saving ? tr('Speichert...') : tr('Profil speichern')}</button></footer>
    </form>
  </div>;
}

function AudioSpeakingWatcher({ userId, stream, disabled, onChange }: { userId: number; stream: MediaStream; disabled?: boolean; onChange: (userId: number, speaking: boolean) => void }) {
  const lastSpeakingRef = useRef(false);
  useEffect(() => {
    if (disabled) {
      lastSpeakingRef.current = false;
      onChange(userId, false);
      return;
    }
    const AudioContextCtor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextCtor) return;
    let raf = 0;
    let context: AudioContext | null = null;
    let source: MediaStreamAudioSourceNode | null = null;
    let analyser: AnalyserNode | null = null;
    let data: Uint8Array<ArrayBuffer>;
    try {
      if (!stream.getAudioTracks().length) throw new Error('Missing audio track for speaking activity');
      context = new AudioContextCtor();
      void context.resume().catch(() => undefined);
      source = context.createMediaStreamSource(stream);
      analyser = context.createAnalyser();
      analyser.fftSize = 512;
      analyser.smoothingTimeConstant = 0.65;
      source.connect(analyser);
      data = new Uint8Array(analyser.fftSize);
    } catch (err) {
      console.warn('voice.speakingWatcher.disabled', err);
      lastSpeakingRef.current = false;
      onChange(userId, false);
      void context?.close().catch(() => undefined);
      return;
    }
    const tick = () => {
      if (!analyser) return;
      analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (const value of data) { const centered = value - 128; sum += centered * centered; }
      const normalizedLevel = Math.sqrt(sum / data.length);
      const speaking = normalizedLevel > SPEAKING_THRESHOLD;
      if (lastSpeakingRef.current !== speaking) {
        lastSpeakingRef.current = speaking;
        onChange(userId, speaking);
      }
      raf = window.requestAnimationFrame(tick);
    };
    tick();
    return () => {
      window.cancelAnimationFrame(raf);
      try { source?.disconnect(); } catch { /* best-effort cleanup */ }
      try { analyser?.disconnect(); } catch { /* best-effort cleanup */ }
      void context?.close().catch(() => undefined);
      lastSpeakingRef.current = false;
      onChange(userId, false);
    };
  }, [disabled, onChange, stream, userId]);
  return null;
}

function VoiceGridView({ channel, joined, serverVoicePresence, users, speakingUserIds, ownUserId, server, routerRtpCapabilities, onJoin, busy, voiceState, onToggleMic, onToggleSound, onToggleVideo, onToggleScreen, onLeaveVoice, localVideoStream, localScreenStream, remoteVideoStreams, streamAudioMutedUsers, onToggleStreamAudioMute, usersById, baseUrl, onUserMenu, onUserProfile }: { channel: SharkordChannel; joined: boolean; serverVoicePresence: boolean; users: VoiceUser[]; speakingUserIds: Set<number>; ownUserId?: number; server: SharkordServer | null; routerRtpCapabilities: unknown; onJoin?: () => void; busy: boolean; voiceState: VoiceState; onToggleMic: () => void; onToggleSound: () => void; onToggleVideo: () => void; onToggleScreen: () => void; onLeaveVoice: () => void; localVideoStream: MediaStream | null; localScreenStream: MediaStream | null; remoteVideoStreams: RemoteVideoStream[]; streamAudioMutedUsers: StreamAudioMuteSettings; onToggleStreamAudioMute: (serverId: string, remoteId: number) => void; usersById: Map<number, SharkordUser>; baseUrl: string; onUserMenu: (event: React.MouseEvent, user: SharkordUser) => void; onUserProfile: (event: React.MouseEvent, user: SharkordUser) => void }) {
  const [voicePreviewSettings, setVoicePreviewSettings] = useState<VoicePreviewSettings>(() => loadVoicePreviewSettings());
  const { showOwnVideoPreview, showOwnScreenPreview } = voicePreviewSettings;
  const updateVoicePreviewSettings = (patch: Partial<VoicePreviewSettings>) => {
    setVoicePreviewSettings((current) => {
      const next = { ...current, ...patch };
      saveVoicePreviewSettings(next);
      return next;
    });
  };
  const [hideCallMembers, setHideCallMembers] = useState(false);
  const [hideCameraStreams, setHideCameraStreams] = useState(false);
  const [focusedScreenKey, setFocusedScreenKey] = useState<string | null>(null);
  const [watchedScreenKeys, setWatchedScreenKeys] = useState<Set<string>>(() => new Set());
  const [voiceOptionsMenuOpen, setVoiceOptionsMenuOpen] = useState(false);
  const [voiceControlsCollapsed, setVoiceControlsCollapsed] = useState(false);
  const [streamPopoutError, setStreamPopoutError] = useState('');
  const ownVoiceUser = ownUserId != null ? usersById.get(ownUserId) : undefined;
  const visibleVoiceUsers: VoiceUser[] = joined && ownVoiceUser && !isDeletedUserPlaceholder(ownVoiceUser) && !users.some((user) => user.id === ownVoiceUser.id)
    ? [{ ...ownVoiceUser, state: normalizeVoiceState(voiceState) }, ...users]
    : users;
  const liveRemoteScreenStreams = remoteVideoStreams.filter((item) => item.kind === 'screen' && visibleVoiceUsers.some((user) => user.id === item.remoteId && normalizeVoiceState(user.state).sharingScreen));
  const remoteScreenOwnerIds = new Set(liveRemoteScreenStreams.map((item) => item.remoteId));
  const visibleLocalVideoStream = showOwnVideoPreview && !hideCameraStreams ? localVideoStream : null;
  const visibleLocalScreenStream = showOwnScreenPreview ? localScreenStream : null;
  const openScreenPopout = async (items: StreamPopupItem[], title: string) => {
    if (!items.length) return;
    setStreamPopoutError(tr(''));
    if (!server || !routerRtpCapabilities) { setStreamPopoutError(tr('Popout nicht bereit: Voice-Medien fehlen. Bitte Voice neu beitreten.')); return; }
    try {
      await Promise.all(items.map((item) => API.OpenStreamPopoutWindow({
        serverId: server.id,
        serverUrl: server.url,
        channelId: channel.id,
        remoteId: item.remoteId,
        kind: item.kind,
        title: item.label,
        routerRtpCapabilities: JSON.stringify(routerRtpCapabilities)
      })));
    } catch (err) {
      setStreamPopoutError(tr(`Popout: ${cleanError(err)}`));
    }
  };
  const screenCards = [
    ...(visibleLocalScreenStream && ownUserId ? [{ key: `screen-${ownUserId}`, label: tr('Dein Bildschirm'), stream: visibleLocalScreenStream, remoteId: ownUserId, kind: 'screen' as StreamKind, own: true, watched: true }] : []),
    ...liveRemoteScreenStreams.map((item) => ({ key: `screen-${item.remoteId}`, label: `${usersById.get(item.remoteId)?.name || `User ${item.remoteId}`} · ${tr('Bildschirm')}`, stream: item.stream, remoteId: item.remoteId, kind: item.kind, own: false, watched: watchedScreenKeys.has(`screen-${item.remoteId}`) }))
  ];
  const validScreenKeys = new Set(screenCards.map((item) => item.key));
  const validScreenKeySignature = [...validScreenKeys].join('|');
  useEffect(() => {
    setWatchedScreenKeys((current) => {
      const next = new Set([...current].filter((key) => validScreenKeys.has(key)));
      return next.size === current.size ? current : next;
    });
    setFocusedScreenKey((current) => current && validScreenKeys.has(current) ? current : null);
  }, [validScreenKeySignature]);
  const screenPopupItems: StreamPopupItem[] = screenCards.filter((item) => item.watched).map((item) => ({ ...item, muted: item.own, mirror: false }));
  const focusedScreen = focusedScreenKey ? screenCards.find((item) => item.key === focusedScreenKey && item.watched) ?? null : null;
  const orderedScreenCards = focusedScreen ? [focusedScreen, ...screenCards.filter((item) => item.key !== focusedScreen.key)] : screenCards;
  const visibleScreenCards = focusedScreen ? [focusedScreen] : orderedScreenCards;
  const runVoiceOption = (action: () => void) => { action(); setVoiceOptionsMenuOpen(false); };
  const streamAudioMenuItems = liveRemoteScreenStreams.map((item) => {
    const key = server ? streamAudioMuteKey(server.id, item.remoteId) : '';
    const muted = !!(server && isStreamAudioMuted(streamAudioMutedUsers, server.id, item.remoteId));
    return { item, key, muted, label: usersById.get(item.remoteId)?.name || `User ${item.remoteId}` };
  });
  const participantCards = (hideCallMembers || focusedScreen) ? [] : visibleVoiceUsers.flatMap((user) => {
    const own = user.id === ownUserId;
    const videoStream = hideCameraStreams ? null : own ? visibleLocalVideoStream : remoteVideoStreams.find((item) => item.remoteId === user.id && (item.kind === 'video' || item.kind === 'external_video' || String(item.kind) === 'webcam'))?.stream ?? null;
    const userVoiceState = normalizeVoiceState(user.state);
    const mediaHint = !hideCameraStreams && userVoiceState.webcamEnabled && !videoStream ? tr('Kamera aktiv · Stream lädt…') : '';
    return [<VoiceUserCard key={user.id} user={user} own={own} speaking={speakingUserIds.has(user.id)} videoStream={videoStream} mediaHint={mediaHint} baseUrl={baseUrl} onUserMenu={onUserMenu} onUserProfile={onUserProfile} />];
  });
  const pendingScreenUsers = focusedScreen ? [] : visibleVoiceUsers.filter((user) => normalizeVoiceState(user.state).sharingScreen && user.id !== ownUserId && !remoteScreenOwnerIds.has(user.id));
  const streamOnlyCardCount = visibleScreenCards.length + pendingScreenUsers.length;
  const totalCards = participantCards.length + streamOnlyCardCount;
  const shouldShowEmptyVoiceCard = !hideCallMembers && !visibleScreenCards.length && !pendingScreenUsers.length && !participantCards.length;
  const gridClasses = ['voiceGrid', focusedScreenKey ? 'hasFocusedScreen' : '', hideCallMembers ? 'streamsOnly' : '', hideCallMembers && streamOnlyCardCount === 1 ? 'singleStream' : ''].filter(Boolean).join(' ');
  return <div className="voiceCallSurface">
    {!joined ? <div className="voiceJoinCard"><div className="voicePreviewIcon"><Mic size={30} /></div><h2>{channel.name}</h2><p>{serverVoicePresence ? tr('Server meldet dich noch im Voice. Erneut beitreten räumt die Session auf.') : tr('Voice-Kanal')}</p><button type="button" onClick={onJoin} disabled={busy}><Volume2 size={18} />{busy ? tr('Verbinde...') : tr('Voice beitreten')}</button></div> : null}
    {joined ? <div className={gridClasses} style={{ '--voice-card-count': Math.max(1, totalCards) } as React.CSSProperties}>{participantCards}{shouldShowEmptyVoiceCard ? <div className="voiceEmptyCard"><Mic size={28} /><span>{tr('Keine Teilnehmer')}</span></div> : null}{hideCallMembers && streamOnlyCardCount === 0 ? <div className="streamsOnlyEmptyState"><Monitor size={30} /><strong>{tr('Keine aktiven Streams')}</strong><span>{tr('Callmember sind ausgeblendet.')}</span></div> : null}{visibleScreenCards.map((item) => <figure className={`voiceScreenShareCard ${item.key === focusedScreenKey ? 'focused' : ''} ${!item.watched ? 'notWatching' : ''}`} key={item.key} onClick={() => item.watched ? setFocusedScreenKey(item.key === focusedScreenKey ? null : item.key) : undefined} title={item.watched ? (item.key === focusedScreenKey ? tr('Stream-Fokus lösen') : tr('Stream fokussieren')) : tr('Stream verfügbar')} aria-label={item.watched ? (item.key === focusedScreenKey ? tr('Stream-Fokus lösen') : tr('Stream fokussieren')) : tr('Stream verfügbar')} aria-pressed={item.watched && item.key === focusedScreenKey}>{item.watched ? <VideoTile label={item.label} stream={item.stream} muted={item.own} screen={true} /> : <div className="voiceStreamWatchCard"><Monitor size={34} /><strong>{item.label}</strong><span>{tr('Bildschirmübertragung verfügbar')}</span><button type="button" onClick={(event) => { event.stopPropagation(); setWatchedScreenKeys((current) => new Set(current).add(item.key)); }}>{tr('Stream ansehen')}</button></div>}</figure>)}{pendingScreenUsers.map((user) => <figure className="voiceScreenShareCard pending" key={`pending-screen-${user.id}`}><div className="voiceMediaPending"><Monitor size={32} /><strong>{user.name || user.identity || `User ${user.id}`} {tr('teilt Bildschirm')}</strong><span>{tr('Stream noch nicht empfangen')}</span></div></figure>)}</div> : null}
    {joined ? <div className={`voiceControlsDock ${voiceControlsCollapsed ? 'collapsed' : ''}`}>
      <button type="button" className="voiceControlsCollapseButton" onClick={() => setVoiceControlsCollapsed(!voiceControlsCollapsed)} title={voiceControlsCollapsed ? tr('Call-Leiste ausklappen') : tr('Call-Leiste einklappen')} aria-label={voiceControlsCollapsed ? tr('Call-Leiste ausklappen') : tr('Call-Leiste einklappen')}><ChevronDown size={18} /></button>
      <div className="voiceControlsBar">
        <button type="button" className={voiceState.micMuted ? 'danger active' : ''} onClick={onToggleMic} title={voiceState.micMuted ? 'Unmute' : 'Mute'}>{voiceState.micMuted ? <MicOff size={22} /> : <Mic size={22} />}</button>
        <button type="button" className={voiceState.soundMuted ? 'danger active' : ''} onClick={onToggleSound} title={voiceState.soundMuted ? 'Undeafen' : 'Deafen'}>{voiceState.soundMuted ? <VolumeX size={22} /> : <Headphones size={22} />}</button>
        <button type="button" className={`voiceMediaToggle camera ${voiceState.webcamEnabled ? 'active' : ''}`} onClick={onToggleVideo} title={voiceState.webcamEnabled ? tr('Kamera aus') : tr('Kamera')}><Video size={22} /></button>
        <button type="button" className={`voiceMediaToggle screen ${voiceState.sharingScreen ? 'active' : ''}`} onClick={onToggleScreen} title={voiceState.sharingScreen ? tr('Freigabe beenden') : tr('Bildschirm teilen')}><Monitor size={22} /></button>
        <div className="voiceOptionsMenuWrap"><button type="button" className={`voiceControlsMenuButton ${voiceOptionsMenuOpen ? 'active' : ''}`} onClick={() => setVoiceOptionsMenuOpen(!voiceOptionsMenuOpen)} title={tr('Stream-Optionen')} aria-label={tr('Stream-Optionen')}><MoreVertical size={22} /></button>{voiceOptionsMenuOpen ? <div className="voiceOptionsMenu" role="menu">
          <button type="button" className={hideCallMembers ? 'active' : ''} onClick={() => runVoiceOption(() => setHideCallMembers(!hideCallMembers))} title={tr('Callmember ausblenden')}><Users size={15} />{hideCallMembers ? tr('Callmember anzeigen') : tr('Nur Streams anzeigen')}</button>
          <button type="button" className={hideCameraStreams ? 'active' : ''} onClick={() => runVoiceOption(() => setHideCameraStreams(!hideCameraStreams))}><Video size={15} />{tr('Kameras ausblenden')}</button>
          {localVideoStream ? <button type="button" className={!showOwnVideoPreview ? 'active' : ''} onClick={() => runVoiceOption(() => updateVoicePreviewSettings({ showOwnVideoPreview: !showOwnVideoPreview }))}><Video size={15} />{showOwnVideoPreview ? tr('Eigene Kamera ausblenden') : tr('Eigene Kamera anzeigen')}</button> : null}
          {localScreenStream ? <button type="button" className={!showOwnScreenPreview ? 'active' : ''} onClick={() => runVoiceOption(() => updateVoicePreviewSettings({ showOwnScreenPreview: !showOwnScreenPreview }))}><Monitor size={15} />{showOwnScreenPreview ? tr('Eigenen Bildschirm ausblenden') : tr('Eigenen Bildschirm anzeigen')}</button> : null}
          {streamAudioMenuItems.map(({ item, muted, label }) => <button type="button" key={`stream-audio-${item.remoteId}`} className={muted ? 'active' : ''} onClick={() => server && runVoiceOption(() => onToggleStreamAudioMute(server.id, item.remoteId))}>{muted ? <VolumeX size={15} /> : <Volume2 size={15} />}{label}: {muted ? tr('Stream-Ton einschalten') : tr('Stream-Ton stummschalten')}</button>)}
          <button type="button" onClick={() => runVoiceOption(() => openScreenPopout(screenPopupItems, `${channel.name} · ${tr('Bildschirmübertragungen')}`))} disabled={!screenPopupItems.length}><Monitor size={15} />{tr('Bildschirmübertragungen als Popup')}</button>
          <button type="button" onClick={() => runVoiceOption(() => screenPopupItems.forEach((item) => openScreenPopout([item], item.label)))} disabled={!screenPopupItems.length}><Monitor size={15} />{tr('Alle Streams einzeln')}</button>
        </div> : null}</div>
        <button type="button" className="hangup" onClick={onLeaveVoice} disabled={busy} title={tr('Trennen')}><PhoneOff size={22} /></button>
      </div>
    </div> : null}
    {streamPopoutError ? <div className="streamPopoutError" role="alert">{streamPopoutError}</div> : null}
  </div>;
}
function VoiceUserCard({ user, own, speaking, videoStream, mediaHint, baseUrl, onUserMenu, onUserProfile }: { user: VoiceUser; own: boolean; speaking: boolean; videoStream: MediaStream | null; mediaHint?: string; baseUrl: string; onUserMenu: (event: React.MouseEvent, user: SharkordUser) => void; onUserProfile: (event: React.MouseEvent, user: SharkordUser) => void }) {
  const displayName = user.name || user.identity || `User ${user.id}`;
  const userVoiceState = normalizeVoiceState(user.state);
  return <article className={`voiceUserCard ${speaking ? 'speaking' : ''}`} onClick={(event) => onUserProfile(event, user)} onContextMenu={(event) => onUserMenu(event, user)}>{videoStream ? <VideoTile label={displayName} stream={videoStream} muted={own} mirror={own} /> : <div className="voiceAvatarStage"><AvatarView user={user} name={displayName} baseUrl={baseUrl} className="voiceCardAvatar" />{mediaHint ? <span className="voiceMediaHint"><Video size={14} />{mediaHint}</span> : null}</div>}<div className="voiceCardOverlay"><span>{displayName}{own ? ` (${tr('du')})` : ''}</span><div>{speaking ? <span className="speakingIndicator" aria-label={tr('spricht')} /> : null}{userVoiceState.micMuted ? <MicOff size={14} /> : <Mic size={14} />}{userVoiceState.soundMuted ? <VolumeX size={14} /> : null}{userVoiceState.webcamEnabled ? <Video size={14} /> : null}{userVoiceState.sharingScreen ? <Monitor size={14} /> : null}</div></div></article>;
}
function VideoTile({ label, stream, muted = false, mirror = false, screen = false }: { label: string; stream: MediaStream; muted?: boolean; mirror?: boolean; screen?: boolean }) {
  const ref = useRef<HTMLVideoElement | null>(null);
  const [trackState, setTrackState] = useState(() => {
    const track = stream.getVideoTracks()[0];
    return track?.readyState === 'live' ? (track.muted ? 'muted' : 'live') : (track?.readyState ?? 'missing');
  });
  const [videoTileError, setVideoTileError] = useState('');
  useEffect(() => {
    const video = ref.current;
    const track = stream.getVideoTracks()[0];
    let cancelled = false;
    const nextTrackState = () => track?.readyState === 'live' ? (track.muted ? 'muted' : 'live') : (track?.readyState ?? 'missing');
    const updateTrackState = () => setTrackState(nextTrackState());
    updateTrackState();
    setVideoTileError('');
    track?.addEventListener?.('ended', updateTrackState);
    track?.addEventListener?.('mute', updateTrackState);
    track?.addEventListener?.('unmute', updateTrackState);
    if (video) {
      video.pause();
      if (video.srcObject !== stream) {
        video.srcObject = null;
        video.load();
      }
    }
    if (video && track?.readyState === 'live') {
      video.srcObject = stream;
      void video.play().catch((error) => { if (!cancelled) setVideoTileError(cleanError(error)); });
    }
    return () => {
      cancelled = true;
      track?.removeEventListener?.('ended', updateTrackState);
      track?.removeEventListener?.('mute', updateTrackState);
      track?.removeEventListener?.('unmute', updateTrackState);
      if (video?.srcObject === stream) {
        video.pause();
        video.srcObject = null;
        video.load();
      }
    };
  }, [stream]);
  const mediaEnded = trackState !== 'live' && trackState !== 'muted';
  return <figure className={`videoTile ${screen ? 'screenTile' : ''} ${mirror ? 'mirror' : ''} ${mediaEnded ? 'voiceMediaEnded' : ''}`} data-track-state={trackState}><video ref={ref} autoPlay playsInline muted={muted} />{mediaEnded ? <div className="voiceMediaEndedOverlay"><Video size={30} /><strong>{tr('Stream beendet')}</strong><span>{trackState}</span></div> : null}{videoTileError ? <span className="videoTileError">Video: {videoTileError}</span> : null}<figcaption>{label}</figcaption></figure>;
}

function MembersPanel({ users, visibleUsers, roles, ownUserId, baseUrl, onUserMenu, onUserProfile, onClose }: { users: SharkordUser[]; visibleUsers?: SharkordUser[]; roles: SharkordRole[]; ownUserId?: number; baseUrl: string; onUserMenu: (event: React.MouseEvent, user: SharkordUser) => void; onUserProfile: (event: React.MouseEvent, user: SharkordUser) => void; onClose: () => void }) {
  const panelUsers = visibleUsers ?? users;
  const groups = groupMembersByPresenceAndRole(panelUsers, roles, ownUserId);
  return <aside className="membersPanel memberColumn" aria-label={tr('Memberliste')}><div className="membersHeader"><Users size={16} /><span>Members</span><button type="button" className="memberCollapseButton" onClick={onClose} title={tr('Memberliste einklappen')} aria-label={tr('Memberliste einklappen')}>×</button></div>{groups.map((group) => <MemberGroup key={group.key} title={`${group.title} — ${group.users.length}`} users={group.users} ownUserId={ownUserId} baseUrl={baseUrl} onUserMenu={onUserMenu} onUserProfile={onUserProfile} />)}</aside>;
}
function MemberGroup({ title, users, ownUserId, baseUrl, onUserMenu, onUserProfile }: { title: string; users: SharkordUser[]; ownUserId?: number; baseUrl: string; onUserMenu: (event: React.MouseEvent, user: SharkordUser) => void; onUserProfile: (event: React.MouseEvent, user: SharkordUser) => void }) { return <section className="memberGroup"><strong>{title}</strong>{users.map((user) => <div className="memberRow" key={user.id} onClick={(event) => onUserProfile(event, user)} onContextMenu={(event) => onUserMenu(event, user)}><span className={`presence ${memberPresenceStatus(user, ownUserId)}`} /><AvatarView user={user} name={displayUserName(user)} baseUrl={baseUrl} className="memberAvatar" /><span>{displayUserName(user)}{user.id === ownUserId ? ` (${tr('du')})` : ''}</span></div>)}</section>; }

const MESSAGE_URL_RE = /(https?:\/\/[^\s<>()]+)/g;
function RichMessageContent({ html, usersById }: { html: string; usersById: Map<number, SharkordUser> }) {
  const nodes = useMemo(() => richMessageNodes(html, usersById), [html, usersById]);
  if (!nodes.length) return null;
  return <p className="messageTextRich">{nodes}</p>;
}
function richMessageNodes(html: string, usersById: Map<number, SharkordUser>): ReactNode[] {
  if (typeof DOMParser === 'undefined') return renderPlainTextTokens(textFromHtml(html), 'fallback');
  const doc = new DOMParser().parseFromString(`<div>${html}</div>`, 'text/html');
  const root = doc.body.firstElementChild ?? doc.body;
  return Array.from(root.childNodes).flatMap((node, index) => renderMessageDomNode(node, `rich-${index}`, usersById)).filter(Boolean);
}
function renderMessageDomNode(node: ChildNode, key: string, usersById: Map<number, SharkordUser>): ReactNode[] {
  if (node.nodeType === 3) return renderPlainTextTokens(node.textContent ?? '', key);
  if (node.nodeType !== 1) return [];
  const element = node as HTMLElement;
  const tag = element.tagName.toLowerCase();
  if (tag === 'script' || tag === 'style') return [];
  if (tag === 'br') return [<br key={key} />];
  const children = Array.from(element.childNodes).flatMap((child, index) => renderMessageDomNode(child, `${key}-${index}`, usersById));
  if (tag === 'a') {
    const href = sanitizeMessageHref(element.getAttribute('href') || '');
    if (!href) return children;
    return [<a key={key} className="messageLink" href={href} target="_blank" rel="noreferrer">{children.length ? children : href}</a>];
  }
  const className = element.getAttribute('class') || '';
  if (className.includes('roleMention') || element.hasAttribute('data-role-id')) {
    const label = (element.textContent || '').trim();
    return [<span key={key} className="messageMention roleMention">{label || '@&role'}</span>];
  }
  if (className.includes('mention') || element.hasAttribute('data-user-id')) {
    const id = Number(element.getAttribute('data-user-id') || element.getAttribute('data-userid') || '');
    const user = Number.isFinite(id) ? usersById.get(id) : undefined;
    const label = user ? `@${displayUserName(user)}` : (element.textContent || '').trim();
    return [<span key={key} className="messageMention">{label || '@mention'}</span>];
  }
  if (tag === 'strong' || tag === 'b') return [<strong key={key}>{children}</strong>];
  if (tag === 'em' || tag === 'i') return [<em key={key}>{children}</em>];
  if (tag === 'code') return [<code key={key}>{children}</code>];
  if (['p', 'div', 'li', 'blockquote', 'pre'].includes(tag)) return [...children, <br key={`${key}-br`} />];
  return children;
}
function renderPlainTextTokens(text: string, keyPrefix: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  text.split('\n').forEach((line, lineIndex) => {
    if (lineIndex > 0) nodes.push(<br key={`${keyPrefix}-nl-${lineIndex}`} />);
    let lastIndex = 0;
    line.replace(MESSAGE_URL_RE, (url, _match, offset) => {
      if (offset > lastIndex) nodes.push(...renderMentionTokens(line.slice(lastIndex, offset), `${keyPrefix}-${lineIndex}-${lastIndex}`));
      const href = sanitizeMessageHref(url);
      nodes.push(href ? <a key={`${keyPrefix}-url-${lineIndex}-${offset}`} className="messageLink" href={href} target="_blank" rel="noreferrer">{url}</a> : url);
      lastIndex = offset + url.length;
      return url;
    });
    if (lastIndex < line.length) nodes.push(...renderMentionTokens(line.slice(lastIndex), `${keyPrefix}-${lineIndex}-${lastIndex}`));
  });
  return nodes;
}
function renderMentionTokens(text: string, keyPrefix: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  let lastIndex = 0;
  text.replace(/(^|[\s(])@&([A-Za-z0-9_. -]{1,80})/g, (match, prefix, name, offset) => {
    if (offset > lastIndex) nodes.push(text.slice(lastIndex, offset));
    if (prefix) nodes.push(prefix);
    nodes.push(<span key={`${keyPrefix}-role-mention-${offset}`} className="messageMention roleMention">@&{name.trim()}</span>);
    lastIndex = offset + match.length;
    return match;
  });
  const remaining = text.slice(lastIndex);
  const plainPrefix = text.slice(0, lastIndex);
  if (remaining) {
    let nestedLastIndex = 0;
    remaining.replace(/(^|[\s(])@([A-Za-z0-9_.-]{1,80})/g, (match, prefix, name, offset) => {
      const absoluteOffset = plainPrefix.length + offset;
      if (offset > nestedLastIndex) nodes.push(remaining.slice(nestedLastIndex, offset));
      if (prefix) nodes.push(prefix);
      nodes.push(<span key={`${keyPrefix}-mention-${absoluteOffset}`} className="messageMention">@{name}</span>);
      nestedLastIndex = offset + match.length;
      return match;
    });
    if (nestedLastIndex < remaining.length) nodes.push(remaining.slice(nestedLastIndex));
  }
  return nodes;
}
function sanitizeMessageHref(raw: string) {
  const href = raw.trim();
  if (!href) return '';
  try {
    const parsed = new URL(href, window.location.origin);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:' || parsed.protocol === 'mailto:') return href;
  } catch { return ''; }
  return '';
}
function firstMessageUrl(html: string) {
  return textFromHtml(html).match(MESSAGE_URL_RE)?.[0] ?? '';
}
function LinkEmbedPreview({ html }: { html: string }) {
  const url = firstMessageUrl(html);
  if (!url) return null;
  let host = url;
  try { host = new URL(url).host; } catch { /* noop */ }
  return <a className="messageLinkEmbed" href={url} target="_blank" rel="noreferrer"><span>{host}</span><strong>{url}</strong><small>{tr('Link öffnen')}</small></a>;
}
function AttachmentLightbox({ item, onClose }: { item: AttachmentLightboxItem | null; onClose: () => void }) {
  useEffect(() => {
    if (!item) return undefined;
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [item, onClose]);
  if (!item) return null;
  const { file, href, label, isImage } = item;
  const mime = item.mime || attachmentMime(file) || file.extension || tr('Datei');
  const hasHref = !!href;
  return <div className="attachmentLightboxBackdrop" role="dialog" aria-modal="true" aria-label={`${tr('Anhang anzeigen')}: ${label}`} onMouseDown={onClose}>
    <section className="attachmentLightboxPanel" onMouseDown={(event) => event.stopPropagation()}>
      <header><div><strong>{label}</strong><span>{mime} · {formatFileSize(file.size)}</span></div><button type="button" className="attachmentLightboxClose" onClick={onClose} aria-label={tr('Schließen')}>×</button></header>
      <div className="attachmentLightboxPreview">{isImage && href ? <img src={href} alt={label} /> : <div className="attachmentLightboxFileCard"><HardDrive size={42} /><strong>{label}</strong><span>{tr('Für diesen Dateityp ist keine Vorschau verfügbar.')}</span></div>}</div>
      <footer className="attachmentLightboxActions"><a className="attachmentOpenButton" href={hasHref ? href : undefined} target="_blank" rel="noreferrer" aria-disabled={!hasHref} tabIndex={hasHref ? undefined : -1}>{tr('Datei öffnen')}</a><a className="attachmentDownloadButton" href={hasHref ? href : undefined} download={label} rel="noreferrer" aria-disabled={!hasHref} tabIndex={hasHref ? undefined : -1}>{tr('Herunterladen')}</a><button type="button" className="attachmentCopyButton" onClick={() => void copyAttachmentUrl(href)} disabled={!hasHref}>{tr('URL kopieren')}</button><button type="button" onClick={onClose}>{tr('Schließen')}</button></footer>
    </section>
  </div>;
}
function MessageFileCards({ files, baseUrl, onOpenLightbox }: { files: SharkordFile[]; baseUrl: string; onOpenLightbox: (item: AttachmentLightboxItem) => void }) {
  return <div className="messageFileTray messageFileCards">{files.map((file) => {
    const href = fileUrl(baseUrl, file);
    const label = attachmentLabel(file);
    const mime = attachmentMime(file);
    const isImage = isImageAttachment(file, label);
    return <article className={`messageFileCard ${isImage ? 'mediaImage' : ''}`} key={file.id}>
      <button type="button" className="messageFilePreview" onClick={() => onOpenLightbox({ file, href, label, isImage, mime })} aria-label={`${label} ${tr('anzeigen')}`}>{isImage && href ? <img src={href} alt="" loading="lazy" /> : <HardDrive size={22} />}</button>
      <div className="messageFileMeta"><strong title={label}>{label}</strong><span>{mime || file.extension || tr('Datei')} · {formatFileSize(file.size)}</span></div>
      <div className="messageFileActions"><a className="attachmentOpenButton" href={href} target="_blank" rel="noreferrer">{tr('Datei öffnen')}</a><a className="messageFileDownload attachmentDownloadButton" href={href} download={label} rel="noreferrer" aria-label={`${label} ${tr('herunterladen')}`}><Download size={15} />{tr('Herunterladen')}</a><button type="button" className="attachmentCopyButton" onClick={() => void copyAttachmentUrl(href)} disabled={!href}>{tr('URL kopieren')}</button></div>
    </article>;
  })}</div>;
}
function renderReactionEmoji(emoji: string, file?: SharkordFile | null, baseUrl = '') {
  if (file) return <img className="reactionEmojiImage" src={fileUrl(baseUrl, file)} alt={`:${customEmojiReactionName(emoji)}:`} />;
  const emojiName = customEmojiReactionName(emoji);
  const codepoints = [...emojiName];
  const looksNativeEmoji = codepoints.length <= 4 && /\p{Extended_Pictographic}/u.test(emojiName);
  return <span className={looksNativeEmoji ? 'reactionEmojiGlyph' : 'reactionEmojiTextFallback'} aria-label={`:${emojiName}:`}>{looksNativeEmoji ? emojiName : `:${emojiName}:`}</span>;
}

function MessageBubble({ message, usersById, own, canDelete, canToggleMessagePin, baseUrl, onEdit, onDelete, onTogglePin, onToggleReaction, onUserProfile, onReply, onOpenThread }: { message: SharkordMessage; usersById: Map<number, SharkordUser>; own: boolean; canDelete: boolean; canToggleMessagePin: boolean; baseUrl: string; onEdit: (message: SharkordMessage, plainText: string) => void; onDelete: (message: SharkordMessage) => void; onTogglePin: (message: SharkordMessage) => void; onToggleReaction: (message: SharkordMessage, emoji?: string) => void; onUserProfile: (event: React.MouseEvent, user: SharkordUser) => void; onReply: (message: SharkordMessage) => void; onOpenThread: (message: SharkordMessage) => void }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(textFromHtml(message.content));
  const [attachmentLightbox, setAttachmentLightbox] = useState<AttachmentLightboxItem | null>(null);
  const [reactionPickerOpen, setReactionPickerOpen] = useState(false);
  const messageReactionChoices = ['👍', '❤️', '😂', '🎉', '😮', '🔥', '✅', '🚀'];
  const authorUser = message.user || message.author || usersById.get(message.userId) || null;
  const author = authorUser?.name || authorUser?.identity || `User ${message.userId}`;
  const canEdit = own || message.editable;
  const saveEdit = () => { const next = draft.trim(); if (!next) return; setEditing(false); onEdit(message, next); };
  const replyCount = Number(message.replyCount ?? 0);
  const messageText = textFromHtml(message.content);
  return <article data-message-id={message.id} className={`messageBubble discordMessage ${own ? 'own' : ''} ${reactionPickerOpen ? 'reactionPickerOpen' : ''}`}>
    <button type="button" className="messageAuthorButton messageAvatarButton" onClick={(event) => authorUser ? onUserProfile(event, authorUser) : undefined} disabled={!authorUser}><AvatarView user={authorUser} name={author} baseUrl={baseUrl} className="messageAvatar" /></button>
    <div className="messageBody"><div className="messageMeta"><button type="button" className="messageAuthorName" onClick={(event) => authorUser ? onUserProfile(event, authorUser) : undefined} disabled={!authorUser}>{author}</button><time>{new Date(message.createdAt).toLocaleString()}{message.editedAt || message.updatedAt ? ` · ${tr('bearbeitet')}` : ''}</time>{message.pinned ? <span className="pinnedBadge">Pinned</span> : null}</div>
      {message.parentMessage ? <div className="messageReplyContext">↩ {displayUserName(message.parentMessage.user || message.parentMessage.author || usersById.get(message.parentMessage.userId))}: {textFromHtml(message.parentMessage.content)}</div> : null}
      {editing ? <form className="inlineEdit" onSubmit={(event) => { event.preventDefault(); saveEdit(); }}><input value={draft} onChange={(event) => setDraft(event.target.value)} autoFocus /><button type="submit">{tr('Speichern')}</button><button type="button" className="secondary" onClick={() => setEditing(false)}>{tr('Abbrechen')}</button></form> : messageText ? <RichMessageContent html={message.content} usersById={usersById} /> : null}
      {!editing ? <LinkEmbedPreview html={message.content} /> : null}
      {message.files?.length ? <MessageFileCards files={message.files} baseUrl={baseUrl} onOpenLightbox={setAttachmentLightbox} /> : null}
      <AttachmentLightbox item={attachmentLightbox} onClose={() => setAttachmentLightbox(null)} />
      {replyCount ? <button type="button" className="threadCountButton" onClick={() => onOpenThread(message)}>{replyCount} {tr('Antworten')}</button> : null}
      {message.reactions?.length ? <div className="reactionBar">{message.reactions.map((reaction) => <button key={reaction.emoji} type="button" onClick={() => onToggleReaction(message, reaction.emoji)}>{renderReactionEmoji(reaction.emoji, reaction.file, baseUrl)} {reaction.count ?? ''}</button>)}</div> : null}
      <div className="messageActions"><button type="button" title={tr('Antworten')} onClick={() => onReply(message)}>↩</button><button type="button" title={tr('Thread öffnen')} onClick={() => onOpenThread(message)}>{replyCount || '#'}</button><span className={`messageReactionMenuWrap ${reactionPickerOpen ? 'open' : ''}`}><button type="button" title={tr('Reagieren')} aria-expanded={reactionPickerOpen} onClick={() => setReactionPickerOpen(!reactionPickerOpen)}><Smile size={15} /></button>{reactionPickerOpen ? <span className="messageReactionPicker" role="menu" aria-label={tr('Reaktion auswählen')}>{messageReactionChoices.map((emoji) => <button key={emoji} type="button" role="menuitem" onClick={() => { onToggleReaction(message, emoji); setReactionPickerOpen(false); }}>{emoji}</button>)}</span> : null}</span>{canToggleMessagePin ? <button type="button" title={message.pinned ? tr('Pin entfernen') : tr('Anpinnen')} onClick={() => onTogglePin(message)}>{message.pinned ? <PinOff size={15} /> : <Pin size={15} />}</button> : null}{canEdit ? <button type="button" title={tr('Bearbeiten')} onClick={() => { setDraft(textFromHtml(message.content)); setEditing(true); }}><Pencil size={15} /></button> : null}{canDelete ? <button type="button" title={tr('Löschen')} onClick={() => onDelete(message)}><Trash2 size={15} /></button> : null}</div>
    </div>
  </article>;
}

function ThreadPanel({ panel, usersById, ownUserId, canManageMessages, baseUrl, onClose, onSend, onEdit, onDelete, onToggleReaction, onTogglePin, onUserProfile }: { panel: NonNullable<ThreadPanelState>; usersById: Map<number, SharkordUser>; ownUserId?: number; canManageMessages: boolean; baseUrl: string; onClose: () => void; onSend: (parent: SharkordMessage, plainText: string, files?: SharkordTempFile[]) => Promise<boolean>; onEdit: (message: SharkordMessage, plainText: string) => void; onDelete: (message: SharkordMessage) => void; onToggleReaction: (message: SharkordMessage, emoji?: string) => void; onTogglePin: (message: SharkordMessage) => void; onUserProfile: (event: React.MouseEvent, user: SharkordUser) => void }) {
  const [draft, setDraft] = useState('');
  const parentAuthor = displayUserName(panel.parent.user || panel.parent.author || usersById.get(panel.parent.userId));
  const submit = async (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); const text = draft.trim(); if (!text) return; if (await onSend(panel.parent, text)) setDraft(''); };
  return <aside className="threadPanel" aria-label={tr('Thread')}>
    <header><div><strong>{tr('Thread')}</strong><span>{parentAuthor}</span></div><button type="button" onClick={onClose} aria-label={tr('Thread schließen')}>×</button></header>
    <div className="threadParentPreview"><small>{tr('Originalnachricht')}</small><p>{textFromHtml(panel.parent.content)}</p></div>
    <div className="threadMessages">{panel.loading ? <div className="threadStatus">{panel.status}</div> : panel.messages.length ? panel.messages.map((message) => <MessageBubble key={message.id} message={message} usersById={usersById} own={message.userId === ownUserId} canDelete={message.userId === ownUserId || canManageMessages} canToggleMessagePin={true} baseUrl={baseUrl} onEdit={onEdit} onDelete={onDelete} onTogglePin={onTogglePin} onToggleReaction={onToggleReaction} onUserProfile={onUserProfile} onReply={() => undefined} onOpenThread={() => undefined} />) : <div className="threadStatus">{panel.status || tr('Noch keine Antworten')}</div>}</div>
    <form className="threadComposer" onSubmit={submit}><textarea value={draft} onChange={(event) => setDraft(event.target.value)} placeholder={tr('Im Thread antworten')} rows={2} /><button type="submit" disabled={!draft.trim()}>{tr('Senden')}</button></form>
  </aside>;
}

function AvatarView({ user, name, baseUrl, className }: { user?: SharkordUser | null; name: string; baseUrl: string; className: string }) {
  const src = baseUrl ? fileUrl(baseUrl, user?.avatar) : '';
  return <div className={className}>{src ? <img className="avatarImage" src={src} alt={name} /> : avatarInitial(name)}</div>;
}

function UserProfilePopover({ popover, baseUrl, ownUserId, directMessagesEnabled, canManageUser, onOpenDirectMessage, onManageUser, onClose }: { popover: UserProfilePopoverState; baseUrl: string; ownUserId?: number; directMessagesEnabled: boolean; canManageUser: boolean; onOpenDirectMessage: (user: SharkordUser) => void; onManageUser: (user: SharkordUser) => void; onClose: () => void }) {
  useEffect(() => {
    if (!popover) return undefined;
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [popover, onClose]);
  if (!popover) return null;
  const { user } = popover;
  const name = user.name || user.identity || `User ${user.id}`;
  const bannerColor = user.bannerColor || '#5865f2';
  const bannerSrc = baseUrl ? fileUrl(baseUrl, user.banner) : '';
  const memberSince = formatShortDate(user.createdAt);
  const profilePopoverMargin = 12;
  const profilePopoverWidth = 320;
  const profilePopoverHeight = 420;
  const style = {
    left: Math.max(profilePopoverMargin, Math.min(popover.x, window.innerWidth - profilePopoverWidth - profilePopoverMargin)),
    top: Math.max(profilePopoverMargin, Math.min(popover.y, window.innerHeight - profilePopoverHeight - profilePopoverMargin)),
    maxHeight: 'calc(100vh - 24px)',
    overflowY: 'auto'
  } as React.CSSProperties;
  return <div className="userProfilePopoverBackdrop" onClick={onClose} onContextMenu={(event) => event.preventDefault()}><section className="userProfilePopover" style={style} role="dialog" aria-modal="false" aria-label={tr('Profil anzeigen')} onClick={(event) => event.stopPropagation()}>
    <button type="button" className="userProfileClose" onClick={onClose} aria-label={tr('Schließen')}>×</button>
    <div className="userProfileBanner" style={{ '--profile-banner': bannerColor } as React.CSSProperties}>{bannerSrc ? <img src={bannerSrc} alt="" /> : null}</div>
    <div className="userProfileHeader"><AvatarView user={user} name={name} baseUrl={baseUrl} className="userProfileAvatar" /><div className="userProfileName"><strong>{name}</strong><span>{user.identity ? `@${user.identity}` : `ID ${user.id}`}</span></div></div>
    <div className="userProfileMeta"><span>{tr('Status')}: {tr(user.status || 'online')}</span><span>{t('profile.popover.memberSince')}: {memberSince}</span>{user.roleIds?.length ? <span>{tr('Rollen')}: {user.roleIds.length}</span> : null}</div>
    <div className="userProfileActions">
      {directMessagesEnabled && user.id !== ownUserId ? <button type="button" className="profileActionButton primary" onClick={() => onOpenDirectMessage(user)}><AtSign size={16} />{t('profile.popover.sendMessage')}</button> : null}
      {canManageUser ? <button type="button" className="profileActionButton" onClick={() => onManageUser(user)}><Settings size={16} />{t('profile.popover.manageUser')}</button> : null}
    </div>
    <div className="userProfileBio"><small>{tr('Bio')}</small><p>{user.bio || t('profile.popover.noBio')}</p></div>
  </section></div>;
}

function SettingsPanel({ appInfo, release, updateAsset, initialTab, releaseChannel, setReleaseChannel, updateStatus, updateMessage, updateAvailable, installingUpdate, checkUpdates, installSelectedUpdate, theme, setTheme, audioSettings, setAudioSettings, audioInputs, audioOutputs, videoInputs, refreshMediaDeviceLists, connection, appState, setAppState, streamAudioMutedUsers, setStreamAudioMutedUsers, notificationSettings, setNotificationSettings, uiSettings, setUiSettings, adminRoles }: { appInfo: AppInfo | null; release: GitHubRelease | null; updateAsset: ReleaseAsset | null; initialTab: SettingsTab; releaseChannel: ReleaseChannel; setReleaseChannel: (channel: ReleaseChannel) => void; updateStatus: string; updateMessage: string; updateAvailable: boolean; installingUpdate: boolean; checkUpdates: () => void; installSelectedUpdate: () => void; theme: ThemeMode; setTheme: (theme: ThemeMode) => void; audioSettings: AudioDeviceSettings; setAudioSettings: (settings: AudioDeviceSettings) => void; audioInputs: MediaDeviceInfo[]; audioOutputs: MediaDeviceInfo[]; videoInputs: MediaDeviceInfo[]; refreshMediaDeviceLists: () => Promise<{ inputs: MediaDeviceInfo[]; outputs: MediaDeviceInfo[]; videos: MediaDeviceInfo[] }>; connection: SharkordConnection | null; appState: StoredState; setAppState: React.Dispatch<React.SetStateAction<StoredState>>; streamAudioMutedUsers: StreamAudioMuteSettings; setStreamAudioMutedUsers: React.Dispatch<React.SetStateAction<StreamAudioMuteSettings>>; notificationSettings: NotificationSettings; setNotificationSettings: React.Dispatch<React.SetStateAction<NotificationSettings>>; uiSettings: AppUiSettings; setUiSettings: React.Dispatch<React.SetStateAction<AppUiSettings>>; adminRoles: SharkordRole[] }) {
  const [settingsTab, setSettingsTab] = useState<SettingsTab>(initialTab);
  useEffect(() => setSettingsTab(initialTab), [initialTab]);
  const [locale, setLocaleState] = useState<Locale>(() => getLocale());
  const updateLocale = (nextLocale: Locale) => { setLocale(nextLocale); setLocaleState(nextLocale); queueMicrotask(() => translateVisiblePhrases()); };
  const updateAudio = (patch: Partial<AudioDeviceSettings>) => setAudioSettings({ ...audioSettings, ...patch });
  const updateUiSetting = (patch: Partial<AppUiSettings>) => setUiSettings((current) => ({ ...current, ...patch, fontSize: patch.fontSize != null ? clampAppFontSize(patch.fontSize) : current.fontSize }));
  const updateChecksum = updateAsset?.sha256;
  const updateFeedSource = release?.feedUrl || tr('GitHub Release API');
  const updateSafetyCopy = tr('Rollback: Wenn das Update nicht startet, installiere die vorherige Version manuell von der Release-Seite. Manuelle Installation überschreibt nur die App, nicht deine lokalen Server oder Einstellungen.');
  const noiseMode = audioSettings.voiceIsolationEnabled ? 'voiceIsolation' : (audioSettings.denoiseEnabled ? 'local' : (audioSettings.noiseSuppression ? 'browser' : 'none'));
  const [mikrofonTestStream, setMikrofonTestStream] = useState<MediaStream | null>(null);
  const [webcamTestStream, setWebcamTestStream] = useState<MediaStream | null>(null);
  const [micTestLevel, setMicTestLevel] = useState(0);
  const [mediaTestStatus, setMediaTestStatus] = useState(tr('Bereit'));
  const autoUnlockAttemptedRef = useRef(false);
  const playbackDeviceOptions = ensureAudioSettingStillSelectable(audioOutputs, audioSettings.playbackId, tr('Lautsprecher'));
  const microphoneDeviceOptions = ensureAudioSettingStillSelectable(audioInputs, audioSettings.microphoneId, tr('Mikrofon'));
  const webcamDeviceOptions = ensureAudioSettingStillSelectable(videoInputs, audioSettings.webcamId, tr('Webcam'));
  const hotSwapSupported = !!connection?.serverCapabilities.voiceDeviceHotSwap;
  const connectedWithoutHotSwap = !!connection && !hotSwapSupported;
  const [importExportStatus, setImportExportStatus] = useState(tr('Bereit'));
  const [includeUserData, setIncludeUserData] = useState(false);
  const [exportUserDataConfirmOpen, setExportUserDataConfirmOpen] = useState(false);
  const runSettingsExport = async (withUserData: boolean) => {
    try {
      const payload = createSettingsExport({ state: appState, audioSettings, streamAudioMuted: streamAudioMutedUsers, appVersion: appInfo?.version ?? 'dev' });
      const filename = `sharkord-desktop-settings-${new Date().toISOString().slice(0,10)}.json`;
      setImportExportStatus(tr('Export: Speicherort auswählen…'));
      const savedPath = await saveSettingsExportFile(filename);
      if (!savedPath) {
        setImportExportStatus(tr('Export abgebrochen'));
        return;
      }
      await API.WriteSettingsExportJSON(savedPath, JSON.stringify(payload, null, 2), withUserData);
      setImportExportStatus(tr(`Export gespeichert · ${payload.state.servers.length} Server${withUserData ? ` · ${tr('mit Nutzerdaten/Zugangsdaten')}` : ''}`));
    } catch (err) {
      setImportExportStatus(tr(`Export fehlgeschlagen: ${cleanError(err)}`));
    }
  };
  const confirmExportWithUserData = () => {
    setExportUserDataConfirmOpen(false);
    void runSettingsExport(true);
  };
  const exportSettings = async () => {
    if (includeUserData) {
      setExportUserDataConfirmOpen(true);
      return;
    }
    await runSettingsExport(false);
  };
  const importSettingsFile = async () => {
    try {
      setImportExportStatus(tr('Import: Datei auswählen…'));
      const importPath = await openSettingsImportFile();
      if (!importPath) {
        setImportExportStatus(tr('Import: keine Datei ausgewählt'));
        return;
      }
      const importFileName = importPath.split(/[\\/]/).pop() || tr('ausgewählte Datei');
      const imported = parseSettingsImport(await API.ReadSettingsImportJSON(importPath));
      const nextState = imported.state;
      const nextAudioSettings = { ...defaultAudioDeviceSettings, ...imported.audioSettings };
      const credentialEntries = Object.entries(imported.credentialsByServerId ?? {});
      if (!await confirmSettingsImport(tr(`Import ersetzt lokale Serverliste und Einstellungen durch ${nextState.servers.length} Server aus ${importFileName}. Fortfahren?`))) {
        setImportExportStatus(tr('Import abgebrochen'));
        return;
      }
      if (credentialEntries.length && !await confirmSettingsImport(tr(`Diese Datei enthält ${credentialEntries.length} Nutzerdaten/Zugangsdaten. Diese werden in den lokalen sicheren Speicher importiert. Fortfahren?`), tr('Nutzerdaten importieren'), tr('Nutzerdaten importieren'))) {
        setImportExportStatus(tr('Import der Nutzerdaten/Zugangsdaten abgebrochen'));
        return;
      }
      saveState(nextState);
      await API.SaveAppState({ ...nextState, allowEmptyServers: true } as unknown as Parameters<typeof API.SaveAppState>[0]);
      for (const [serverId, creds] of Object.entries(imported.credentialsByServerId ?? {})) await API.SaveServerCredentials(serverId, creds);
      setAppState(nextState);
      saveAudioDeviceSettings(nextAudioSettings);
      setAudioSettings(nextAudioSettings);
      localStorage.setItem(STREAM_AUDIO_MUTE_STORAGE_KEY, JSON.stringify(imported.streamAudioMuted));
      setStreamAudioMutedUsers(imported.streamAudioMuted);
      setTheme(nextState.theme);
      setImportExportStatus(tr(`Import abgeschlossen · ${nextState.servers.length} Server${credentialEntries.length ? ` · ${credentialEntries.length} ${tr('Nutzerdaten/Zugangsdaten importiert')}` : ` · ${tr('Zugangsdaten bitte bei Bedarf neu eingeben')}`}`));
    } catch (err) {
      setImportExportStatus(cleanError(err) || tr('Ungültige Import-Datei'));
    }
  };
  const micTestAudioContext = useRef<AudioContext | null>(null);
  const micTestRaf = useRef<number | null>(null);
  const resolutionOptions: Array<{ value: AudioDeviceSettings['videoResolution']; label: string }> = [
    { value: '480p', label: '480p' },
    { value: '720p', label: '720p' },
    { value: '1080p', label: 'Full HD (1080p)' },
    { value: '1440p', label: 'WQHD (1440p)' },
    { value: '2160p', label: '4K (2160p)' }
  ];
  const autoUnlockMediaDeviceLists = useCallback(async () => {
    if (autoUnlockAttemptedRef.current) {
      await refreshMediaDeviceLists();
      return;
    }
    autoUnlockAttemptedRef.current = true;
    setMediaTestStatus(tr('Mediengeräte werden automatisch erkannt…'));
    const errors: string[] = [];
    try { await requestMediaDeviceAccess('microphone'); }
    catch (err) { errors.push(`${tr('Mikrofon')}: ${cleanError(err)}`); }
    try { await requestMediaDeviceAccess('camera'); }
    catch (err) { errors.push(`${tr('Kamera')}: ${cleanError(err)}`); }
    const { inputs, outputs, videos } = await refreshMediaDeviceLists();
    setMediaTestStatus(errors.length ? `${tr('Geräteliste aktualisiert')} · ${errors.join(' · ')}` : `${tr('Geräte erkannt')} · ${inputs.length} ${tr('Eingänge')} · ${outputs.length} ${tr('Ausgänge')} · ${videos.length} ${tr('Kameras')}`);
  }, [refreshMediaDeviceLists, tr]);
  useEffect(() => {
    if (settingsTab !== 'audioVideo') return;
    void autoUnlockMediaDeviceLists().catch((err) => setMediaTestStatus(`${tr('Mediengeräte automatisch erkennen')}: ${cleanError(err)}`));
  }, [settingsTab, autoUnlockMediaDeviceLists, tr]);
  const stopMikrofonTest = useCallback(() => {
    if (micTestRaf.current != null) cancelAnimationFrame(micTestRaf.current);
    micTestRaf.current = null;
    mikrofonTestStream?.getTracks().forEach((track) => track.stop());
    setMikrofonTestStream(null);
    setMicTestLevel(0);
    void micTestAudioContext.current?.close().catch(() => undefined);
    micTestAudioContext.current = null;
    setMediaTestStatus(tr('Mikrofon-Test gestoppt'));
  }, [mikrofonTestStream]);
  const startMikrofonTest = useCallback(async () => {
    stopMikrofonTest();
    const hasSpecificMic = !!audioSettings.microphoneId && audioSettings.microphoneId !== 'default';
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { deviceId: hasSpecificMic ? { exact: audioSettings.microphoneId } : undefined, echoCancellation: audioSettings.echoCancellation, noiseSuppression: audioSettings.noiseSuppression, autoGainControl: audioSettings.autoGainControl, channelCount: 1, sampleRate: { ideal: 48000 } }, video: false });
    await refreshMediaDeviceLists();
    setMikrofonTestStream(stream);
    const AudioContextCtor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextCtor) { setMediaTestStatus(tr('Mikrofon-Test läuft · Pegelanzeige nicht verfügbar')); return; }
    const context = new AudioContextCtor();
    await context.resume();
    micTestAudioContext.current = context;
    const analyser = context.createAnalyser();
    analyser.fftSize = 256;
    const source = context.createMediaStreamSource(stream);
    const gainNode = context.createGain();
    gainNode.gain.value = audioSettings.microphoneGain;
    source.connect(gainNode).connect(analyser);
    const data = new Uint8Array(analyser.frequencyBinCount);
    const measure = () => {
      analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (const value of data) { const centered = value - 128; sum += centered * centered; }
      setMicTestLevel(Math.min(100, Math.round(Math.sqrt(sum / data.length) * 3)));
      micTestRaf.current = requestAnimationFrame(measure);
    };
    measure();
    setMediaTestStatus(tr('Mikrofon-Test läuft'));
  }, [audioSettings, refreshMediaDeviceLists, stopMikrofonTest]);
  const stopWebcamPreview = useCallback(() => {
    webcamTestStream?.getTracks().forEach((track) => track.stop());
    setWebcamTestStream(null);
    setMediaTestStatus(tr('Webcam-Vorschau gestoppt'));
  }, [webcamTestStream]);
  const startWebcamPreview = useCallback(async () => {
    stopWebcamPreview();
    const size = resolutionToSize(audioSettings.videoResolution);
    const hasSpecificWebcam = !!audioSettings.webcamId && audioSettings.webcamId !== 'default';
    const stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: { deviceId: hasSpecificWebcam ? { exact: audioSettings.webcamId } : undefined, width: { ideal: size.width }, height: { ideal: size.height }, frameRate: { ideal: audioSettings.videoFps, max: audioSettings.videoFps } } });
    await refreshMediaDeviceLists();
    setWebcamTestStream(stream);
    setMediaTestStatus(tr('Webcam-Vorschau läuft'));
  }, [audioSettings, refreshMediaDeviceLists, stopWebcamPreview]);
  const startMicrophoneTest = startMikrofonTest;
  const stopMicrophoneTest = stopMikrofonTest;
  useEffect(() => () => { if (micTestRaf.current != null) cancelAnimationFrame(micTestRaf.current); mikrofonTestStream?.getTracks().forEach((track) => track.stop()); webcamTestStream?.getTracks().forEach((track) => track.stop()); void micTestAudioContext.current?.close().catch(() => undefined); }, [mikrofonTestStream, webcamTestStream]);
  return <section className="settingsPanel discordSettings">
    <div className="settingsNav" role="tablist" aria-label={tr('Einstellungen')}>
      <button role="tab" aria-selected={settingsTab === 'appearance'} className={settingsTab === 'appearance' ? 'selected' : ''} onClick={() => setSettingsTab('appearance')}>{t('settings.appearance', locale)}</button>
      <button role="tab" aria-selected={settingsTab === 'updates'} className={settingsTab === 'updates' ? 'selected' : ''} onClick={() => setSettingsTab('updates')}>{t('settings.updates', locale)}</button>
      <button role="tab" aria-selected={settingsTab === 'audioVideo'} className={settingsTab === 'audioVideo' ? 'selected' : ''} onClick={() => setSettingsTab('audioVideo')}>{t('settings.audioVideo', locale)}</button>
      <button role="tab" aria-selected={settingsTab === 'notifications'} className={settingsTab === 'notifications' ? 'selected' : ''} onClick={() => setSettingsTab('notifications')}>{t('settings.notifications', locale)}</button>
      <button role="tab" aria-selected={settingsTab === 'importExport'} className={settingsTab === 'importExport' ? 'selected' : ''} onClick={() => setSettingsTab('importExport')}>{t('settings.importExport', locale)}</button>
    </div>
    <div className="settingsContent">
      {settingsTab === 'appearance' ? <section className="settingsCard"><h2>{tr('Darstellung & Barrierefreiheit')}</h2><p>{tr('Native Desktop-Shell mit Sharkord-Branding.')}</p><div className="settingsControlRow themeControlRow"><div className="themeSwitch settingsTheme" aria-label={tr('Theme auswählen')}><button className={theme === 'dark' ? 'selected' : ''} onClick={() => setTheme('dark')}><Moon size={16} />{tr('Dark')}</button><button className={theme === 'light' ? 'selected' : ''} onClick={() => setTheme('light')}><Sun size={16} />{tr('Light')}</button></div><label className="languageSelector"><span>{t('settings.language', locale)}</span><select className="settingsSelect languageSelect" value={locale} onChange={(event) => updateLocale(event.target.value as Locale)}><option value="de">{locale === 'en' ? 'German' : 'Deutsch'}</option><option value="en">English</option></select></label></div><div className="appearanceQuickSettings"><label className="toggleRow"><input type="checkbox" checked={uiSettings.compactMode} onChange={(event) => updateUiSetting({ compactMode: event.target.checked })} /><span>{tr('Kompakter Modus')}</span><small>{tr('Dichtere Listen und kleinere Abstände.')}</small></label><label className="rangeRow"><span>{tr('Schriftgröße')}</span><input type="range" min="85" max="125" step="5" value={uiSettings.fontSize} onChange={(event) => updateUiSetting({ fontSize: Number(event.target.value) })} /><strong>{uiSettings.fontSize}%</strong></label><label className="toggleRow"><input type="checkbox" checked={uiSettings.reducedMotion} onChange={(event) => updateUiSetting({ reducedMotion: event.target.checked })} /><span>{tr('Reduzierte Bewegung')}</span><small>{tr('Minimiert Animationen und Übergänge.')}</small></label><label className="toggleRow"><input type="checkbox" checked={uiSettings.highContrast} onChange={(event) => updateUiSetting({ highContrast: event.target.checked })} /><span>{tr('Hoher Kontrast')}</span><small>{tr('Verstärkt Fokus, Text und Kartenränder.')}</small></label><label className="toggleRow"><input type="checkbox" checked={uiSettings.diagnosticLoggingEnabled} onChange={(event) => updateUiSetting({ diagnosticLoggingEnabled: event.target.checked })} /><span>{tr('Lokale Diagnose-Logs schreiben')}</span><small>{tr('Schreibt redigierte Diagnoseereignisse lokal in die App-Konfiguration. Aus = keine neuen Diagnose-Logeinträge.')}</small></label></div></section> : null}
      {settingsTab === 'updates' ? <section className={`settingsCard updatePanel ${updateStatus}`} aria-label={tr('Updates')}>
        <div className="updatePanelHeader">
          <div className="updatePanelTitle"><h2>{tr('Updates')}</h2><strong>Sharkord Desktop</strong><span>{updateMessage}</span></div>
          <div className="updateMetaGrid" aria-label={tr('Release-Info')}>
            <small className="updateMeta">{tr('Installiert')}: v{appInfo?.version ?? 'dev'}</small>
            <small className="updateMeta">{tr('Kanal')}: {releaseChannel}</small>
            {release?.tagName ? <small className="updateMeta">{tr('Online')}: {release.tagName}</small> : null}
          </div>
        </div>
        <div className="updateControls">
          <label className="releaseChannelSelector"><span>{tr('Release-Kanal')}</span><select value={releaseChannel} onChange={(event) => setReleaseChannel(event.target.value as ReleaseChannel)} disabled={installingUpdate}><option value="stable">{tr('Stable · main')}</option><option value="beta">{tr('Beta · beta')}</option></select></label>
          <div className="updateActions"><button type="button" className="secondary" onClick={checkUpdates} disabled={updateStatus === 'checking' || installingUpdate}><RefreshCw size={16} />{tr('Prüfen')}</button><button type="button" onClick={installSelectedUpdate} disabled={!updateAvailable || installingUpdate}><Download size={16} />{installingUpdate ? tr('Installiere...') : tr('Inplace installieren')}</button></div>
        </div>
        {updateAsset ? <small className="updateAssetLine">{tr('Paket')}: {updateAsset.name} · {formatFileSize(updateAsset.size)}</small> : null}
        <div className="updateVerificationPanel" aria-label={tr('Update-Verifizierung')}>
          <span className="updateFeedSource">{tr('Quelle')}: {updateFeedSource}{release?.feedUrl ? ' · latest.json' : ''}</span>
          <span className="updateChecksum">{updateChecksum ? `${tr('Checksum')}: ${updateChecksum}` : tr('Checksum wird per latest.json geprüft, wenn vorhanden')}</span>
          <p>{updateSafetyCopy}</p>
        </div>
        <div className="updateChangelog" aria-label={tr('Release-Changelog')}><div className="updateChangelogHeader"><strong>{tr('Release-Changelog')}</strong>{release?.htmlUrl ? <a href={release.htmlUrl} target="_blank" rel="noreferrer">{tr('Release öffnen')}</a> : null}</div><pre>{formatReleaseChangelog(release?.changelog)}</pre></div>
      </section> : null}
      {settingsTab === 'audioVideo' ? <section className="settingsCard audioVideoSettings">
        <div><h2>{tr('Audio & Video')}</h2><p>{tr('Geräte, Mikrofonverarbeitung, Webcam und Bildschirmfreigabe.')}</p><small>{mediaTestStatus}</small></div>
        {connection ? <div className="settingsNotice">{hotSwapSupported ? tr('Geräte-Hot-Swap aktiv: Mikrofon- und Kamerawechsel werden ohne Voice-Rejoin übernommen.') : connectedWithoutHotSwap ? tr('Dieser Server unterstützt Geräte-Hot-Swap ohne Voice-Rejoin nicht. Änderungen wirken beim nächsten Join bzw. Neustart des jeweiligen Mediums.') : tr('Änderungen wirken beim nächsten Join bzw. Neustart des jeweiligen Mediums.')}</div> : null}
        <div className="mediaDeviceActions"><button type="button" className="secondary" onClick={() => void refreshMediaDeviceLists().then(({ inputs, outputs, videos }) => setMediaTestStatus(`${tr('Geräte aktualisiert')} · ${inputs.length} ${tr('Eingänge')} · ${outputs.length} ${tr('Ausgänge')} · ${videos.length} ${tr('Kameras')}`)).catch((err) => setMediaTestStatus(`${tr('Geräte aktualisieren')}: ${cleanError(err)}`))}>{tr('Geräte aktualisieren')}</button></div>
        <div className="avSettingsGrid">
          <section className="avSettingsBlock"><h3>{tr('Audio')}</h3>
            <label>{tr('Wiedergabe')}<select value={audioSettings.playbackId ?? 'default'} onChange={(event) => updateAudio({ playbackId: event.target.value })}><option value="default">{tr('Standard')}</option>{playbackDeviceOptions.map((device) => <option key={device.deviceId} value={device.deviceId}>{device.label}</option>)}</select></label>
            <label>{tr('Mikrofon')}<select value={audioSettings.microphoneId ?? 'default'} onChange={(event) => updateAudio({ microphoneId: event.target.value })}><option value="default">{tr('Standard')}</option>{microphoneDeviceOptions.map((device) => <option key={device.deviceId} value={device.deviceId}>{device.label}</option>)}</select></label>
            <label className="rangeRow"><span>{tr('Mikrofon-Eingangspegel')}</span><input type="range" min="0" max="2" step="0.05" value={audioSettings.microphoneGain} onChange={(event) => updateAudio({ microphoneGain: Number(event.target.value) })} /><strong>{Math.round(audioSettings.microphoneGain * 100)}%</strong></label>
            <label>{tr('Sprachfilter')}<select value={noiseMode} onChange={(event) => updateAudio({ noiseSuppression: event.target.value === 'browser' || event.target.value === 'voiceIsolation', autoGainControl: event.target.value === 'voiceIsolation' ? true : audioSettings.autoGainControl, echoCancellation: event.target.value === 'voiceIsolation' ? true : audioSettings.echoCancellation, denoiseEnabled: event.target.value === 'local' || event.target.value === 'voiceIsolation', voiceIsolationEnabled: event.target.value === 'voiceIsolation', noiseGate: event.target.value === 'voiceIsolation' ? true : audioSettings.noiseGate })}><option value="voiceIsolation">{tr('Sprachisolierung')}</option><option value="local">{tr('Lokale Rauschunterdrückung')}</option><option value="browser">{tr('Browser-Rauschunterdrückung')}</option><option value="none">{tr('Aus')}</option></select></label>
            <label className="rangeRow voiceIsolationIntensityRow"><span>{tr('Sprachfilter-Stärke')}</span><input type="range" min="0" max="100" step="1" value={audioSettings.voiceIsolationIntensity} onChange={(event) => updateAudio({ voiceIsolationIntensity: Number(event.target.value) })} disabled={!audioSettings.voiceIsolationEnabled} /><strong>{audioSettings.voiceIsolationIntensity}%</strong><small>{tr('Sanfter = weniger abgeschnitten, stärker = weniger Tastatur.')}</small></label>
            <label className="toggleRow"><input type="checkbox" checked={audioSettings.echoCancellation} onChange={(event) => updateAudio({ echoCancellation: event.target.checked })} /><span>{tr('Echounterdrückung')}</span></label>
            <label className="toggleRow"><input type="checkbox" checked={audioSettings.autoGainControl} onChange={(event) => updateAudio({ autoGainControl: event.target.checked })} /><span>{tr('Automatische Verstärkung')}</span></label>
            <label className="toggleRow"><input type="checkbox" checked={audioSettings.noiseGate} onChange={(event) => updateAudio({ noiseGate: event.target.checked })} /><span>{tr('Sprachaktivierung')}</span></label>
            <div className="micTestRow"><button type="button" className="secondary" onClick={() => mikrofonTestStream ? stopMicrophoneTest() : void startMicrophoneTest().catch((err) => setMediaTestStatus(tr(`Mikrofon-Test: ${cleanError(err)}`)))}>{mikrofonTestStream ? tr('Test stoppen') : tr('Test starten')}</button><span>{tr('Mikrofon testen')}</span></div>
            <div className="levelMeter" aria-label={tr('Mikrofon-Pegel')}><span>-70 dB</span><div><i style={{ width: `${micTestLevel}%` }} /></div><span>0 dB</span></div>
          </section>
          <section className="avSettingsBlock"><h3>{tr('Webcam')}</h3>
            <label>{tr('Webcam')}<select value={audioSettings.webcamId ?? 'default'} onChange={(event) => updateAudio({ webcamId: event.target.value })}><option value="default">{tr('Standard-Webcam')}</option>{webcamDeviceOptions.map((device) => <option key={device.deviceId} value={device.deviceId}>{device.label}</option>)}</select></label>
            <div className="avPreviewBox">{webcamTestStream ? <VideoTile label={tr('Webcam-Vorschau')} stream={webcamTestStream} muted={true} mirror={audioSettings.mirrorOwnVideo} /> : <button type="button" className="secondary" onClick={() => void startWebcamPreview().catch((err) => setMediaTestStatus(tr(`Webcam-Vorschau: ${cleanError(err)}`)))}>{tr('Webcam-Vorschau starten')}</button>}{webcamTestStream ? <button type="button" className="secondary" onClick={stopWebcamPreview}>{tr('Webcam-Vorschau stoppen')}</button> : null}</div>
            <div className="avInlineFields"><label>{tr('Auflösung')}<select value={audioSettings.videoResolution} onChange={(event) => updateAudio({ videoResolution: event.target.value as AudioDeviceSettings['videoResolution'] })}>{resolutionOptions.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label><label>{tr('Bildrate')}<select value={audioSettings.videoFps} onChange={(event) => updateAudio({ videoFps: Number(event.target.value) })}><option value={15}>15 fps</option><option value={30}>30 fps</option><option value={60}>60 fps</option></select></label></div>
            <label className="toggleRow"><input type="checkbox" checked={audioSettings.mirrorOwnVideo} onChange={(event) => updateAudio({ mirrorOwnVideo: event.target.checked })} /><span>{tr('Eigenes Video spiegeln')}</span></label>
            <label className="toggleRow disabled"><input type="checkbox" checked={audioSettings.simulcastEnabled} disabled onChange={(event) => updateAudio({ simulcastEnabled: event.target.checked })} /><span>{tr('Simulcast')}</span><small>{tr('Simulcast ist auf diesem Server deaktiviert.')}</small></label>
          </section>
          <section className="avSettingsBlock wide"><h3>{tr('Bildschirmfreigabe')}</h3>
            <div className="avInlineFields"><label>{tr('Quelle')}<select value={audioSettings.screenSourceMode} onChange={(event) => updateAudio({ screenSourceMode: event.target.value as AudioDeviceSettings['screenSourceMode'] })}><option value="window">{tr('Anwendung / Fenster')}</option><option value="screen">{tr('Gesamter Bildschirm')}</option></select></label><label>{tr('Auflösung')}<select value={audioSettings.screenResolution} onChange={(event) => updateAudio({ screenResolution: event.target.value as AudioDeviceSettings['screenResolution'] })}>{resolutionOptions.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label><label>{tr('Bildrate')}<select value={audioSettings.screenFps} onChange={(event) => updateAudio({ screenFps: Number(event.target.value) })}><option value={15}>15 fps</option><option value={30}>30 fps</option><option value={60}>60 fps</option></select></label><label>{tr('Codec')}<select value={audioSettings.screenCodec} onChange={(event) => updateAudio({ screenCodec: event.target.value as AudioDeviceSettings['screenCodec'] })}><option value="auto">{tr('Automatisch')}</option><option value="vp8">VP8</option><option value="h264">H.264</option></select></label><label>{tr('Optimierung')}<select value={audioSettings.screenContentHint} onChange={(event) => updateAudio({ screenContentHint: event.target.value as AudioDeviceSettings['screenContentHint'] })}><option value="motion">{tr('Gaming / Bewegung')}</option><option value="detail">{tr('Text / Details')}</option></select></label></div>
            <label className="rangeRow"><span>{tr('Maximale Bitrate')}</span><input type="range" min="1" max="30" step="1" value={audioSettings.screenMaxBitrateMbps} onChange={(event) => updateAudio({ screenMaxBitrateMbps: Number(event.target.value) })} /><strong>{audioSettings.screenMaxBitrateMbps} Mbit/s</strong><small>{tr('Gaming 1080p60: 12–20 Mbit/s')}</small></label>
            <label className="toggleRow"><input type="checkbox" checked={audioSettings.includeScreenAudio} onChange={(event) => updateAudio({ includeScreenAudio: event.target.checked })} /><span>{tr('Systemaudio übertragen')}</span><small>{tr('Im Windows-Picker muss „Audio teilen“ aktiviert sein.')}</small></label>
            <label className="toggleRow"><input type="checkbox" checked={audioSettings.restrictOwnAudio} onChange={(event) => updateAudio({ restrictOwnAudio: event.target.checked })} /><span>{tr('Eigenes Audio einschränken')}</span><small>{tr('Sharkord-Audio aus der aufgenommenen Bildschirmfreigabe ausschließen.')}</small></label>
            <label className="toggleRow"><input type="checkbox" checked={audioSettings.suppressLocalAudioPlayback} onChange={(event) => updateAudio({ suppressLocalAudioPlayback: event.target.checked })} /><span>{tr('Lokale Audiowiedergabe unterdrücken')}</span><small>{tr('Audio aus Tab/App nicht zusätzlich auf deinem eigenen Ausgabegerät abspielen.')}</small></label>
            <small>{tr('Diese Screen-Sharing-Einstellungen sind best effort; Plattform und Browser/WebView können abweichen.')}</small>
          </section>
        </div>
      </section> : null}
      {settingsTab === 'notifications' ? <NotificationParitySettings notificationSettings={notificationSettings} setNotificationSettings={setNotificationSettings} onStatus={setImportExportStatus} /> : null}
      {settingsTab === 'importExport' ? <ImportExportSettings status={importExportStatus} appState={appState} audioSettings={audioSettings} streamAudioMutedUsers={streamAudioMutedUsers} includeUserData={includeUserData} setIncludeUserData={setIncludeUserData} onExport={exportSettings} onImport={importSettingsFile} /> : null}
    </div>
    {exportUserDataConfirmOpen ? <ExportUserDataConfirmDialog onCancel={() => setExportUserDataConfirmOpen(false)} onConfirm={confirmExportWithUserData} /> : null}
  </section>;
}





function OwnProfilePopup({ connection, user, serverInfo, baseUrl, onClose, onSaved, onStatus }: { connection: SharkordConnection; user: SharkordUser | null; serverInfo?: SharkordServerInfo | null; baseUrl: string; onClose: () => void; onSaved: (input: { name?: string; bio?: string; bannerColor?: string; banner?: SharkordFile | null; statusOverride?: string | null; statusMessage?: string | null }) => void; onStatus: (status: string) => void }) {
  const [name, setName] = useState(user?.name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [bannerColor, setBannerColor] = useState(user?.bannerColor || '#5865f2');
  const [statusOverride, setStatusOverride] = useState(user?.statusOverride || '');
  const [statusMessage, setStatusMessage] = useState(user?.statusMessage || '');
  const [bannerPreviewUrl, setBannerPreviewUrl] = useState('');
  const [passwords, setPasswords] = useState({ currentPassword: '', newPassword: '', confirmNewPassword: '' });
  const [mfaStatus, setMfaStatus] = useState<MfaStatus>({ enabled: false });
  const [totpSetup, setTotpSetup] = useState<TotpSetupResponse | null>(null);
  const [totpQrCodeUrl, setTotpQrCodeUrl] = useState('');
  const [mfaForm, setMfaForm] = useState({ setupCode: '', disablePassword: '', disableCode: '', recoveryPassword: '', recoveryCode: '' });
  const [recoveryCodes, setRecoveryCodes] = useState<string[]>([]);
  const [mfaLoading, setMfaLoading] = useState(false);
  const [appPasswords, setAppPasswords] = useState<AppPasswordSummary[]>([]);
  const [appPasswordsLoading, setAppPasswordsLoading] = useState(false);
  const [status, setStatus] = useState(tr('Bereit'));
  const supportsAccountSecurity = supportsKanuracerAccountSecurity(connection, serverInfo);
  const avatarInputRef = useRef<HTMLInputElement | null>(null);
  const bannerInputRef = useRef<HTMLInputElement | null>(null);
  useEffect(() => { setName(user?.name || ''); setBio(user?.bio || ''); setBannerColor(user?.bannerColor || '#5865f2'); setStatusOverride(user?.statusOverride || ''); setStatusMessage(user?.statusMessage || ''); setBannerPreviewUrl(''); }, [user?.id, user?.name, user?.bio, user?.bannerColor, user?.banner?.name, user?.statusOverride, user?.statusMessage]);
  const refreshAppPasswords = useCallback(async () => {
    if (!supportsAccountSecurity) { setAppPasswords([]); setAppPasswordsLoading(false); return; }
    setAppPasswordsLoading(true);
    try { setAppPasswords(await getOwnAppPasswords(connection)); }
    catch (err) { setStatus(`${tr('App-Passwörter laden fehlgeschlagen')}: ${cleanError(err)}`); }
    finally { setAppPasswordsLoading(false); }
  }, [connection, supportsAccountSecurity]);
  const refreshMfaStatus = useCallback(async () => {
    if (!supportsAccountSecurity) { setMfaStatus({ enabled: false }); setMfaLoading(false); return; }
    setMfaLoading(true);
    try { setMfaStatus(await getOwnMfaStatus(connection)); }
    catch (err) { setStatus(`${tr('TOTP-Status laden fehlgeschlagen')}: ${cleanError(err)}`); }
    finally { setMfaLoading(false); }
  }, [connection, supportsAccountSecurity]);
  useEffect(() => {
    if (!supportsAccountSecurity) { setTotpSetup(null); setTotpQrCodeUrl(''); setRecoveryCodes([]); setMfaForm({ setupCode: '', disablePassword: '', disableCode: '', recoveryPassword: '', recoveryCode: '' }); }
    void refreshAppPasswords();
    void refreshMfaStatus();
  }, [refreshAppPasswords, refreshMfaStatus, supportsAccountSecurity]);
  useEffect(() => {
    let active = true;
    if (!totpSetup?.otpauthUrl) {
      setTotpQrCodeUrl('');
      return () => { active = false; };
    }
    QRCode.toString(totpSetup.otpauthUrl, { type: 'svg', errorCorrectionLevel: 'M', margin: 2, width: 192, color: { dark: '#111827', light: '#ffffff' } })
      .then((svg) => { if (active) setTotpQrCodeUrl(`data:image/svg+xml;utf8,${encodeURIComponent(svg)}`); })
      .catch(() => { if (active) setTotpQrCodeUrl(''); });
    return () => { active = false; };
  }, [totpSetup?.otpauthUrl]);
  const formatAppPasswordTime = (value: number | null) => value ? new Date(value).toLocaleString() : tr('Nie');
  const revokeAppPassword = async (entry: AppPasswordSummary) => {
    if (entry.revokedAt) return;
    if (!window.confirm(`${tr('App-Passwort widerrufen?')} ${entry.name}\n${tr('Dieses Gerät muss danach erneut mit Passwort und 2FA verbunden werden.')}`)) return;
    await run(tr('App-Passwort widerrufen'), async () => { await revokeOwnAppPassword(connection, entry.id); await refreshAppPasswords(); });
  };
  const run = async (label: string, action: () => Promise<void>) => {
    try { setStatus(tr(`${label}…`)); await action(); setStatus(tr(`${label}: OK`)); onStatus(tr(`${label}: OK`)); }
    catch (err) { const message = tr(`${label}: ${cleanError(err)}`); setStatus(message); onStatus(message); }
  };
  const startTotpSetup = async () => {
    setMfaLoading(true);
    try {
      await run(tr('TOTP-Setup starten'), async () => {
        const setup = await startOwnTotpSetup(connection);
        setTotpSetup(setup);
        setMfaStatus({ enabled: false });
        await refreshAppPasswords();
      });
    } finally { setMfaLoading(false); }
  };
  const enableTotp = async () => {
    setMfaLoading(true);
    try {
      await run(tr('TOTP aktivieren'), async () => {
        const result = await enableOwnTotp(connection, mfaForm.setupCode.trim()) as unknown as { recoveryCodes?: string[] };
        setRecoveryCodes(result.recoveryCodes ?? []);
        setTotpSetup(null);
        setMfaStatus({ enabled: true });
        setMfaForm({ setupCode: '', disablePassword: '', disableCode: '', recoveryPassword: '', recoveryCode: '' });
        await refreshAppPasswords();
      });
    } finally { setMfaLoading(false); }
  };
  const disableTotp = async () => {
    setMfaLoading(true);
    try {
      await run(tr('TOTP deaktivieren'), async () => {
        await disableOwnTotp(connection, { password: mfaForm.disablePassword, code: mfaForm.disableCode.trim() || undefined });
        setTotpSetup(null);
        setMfaStatus({ enabled: false });
        setMfaForm({ setupCode: '', disablePassword: '', disableCode: '', recoveryPassword: '', recoveryCode: '' });
        setRecoveryCodes([]);
        await refreshAppPasswords();
      });
    } finally { setMfaLoading(false); }
  };
  const regenerateRecoveryCodes = async () => {
    setMfaLoading(true);
    try {
      await run(tr('Recovery-Codes neu erstellen'), async () => {
        const nextCodes = await regenerateOwnRecoveryCodes(connection, { password: mfaForm.recoveryPassword, code: mfaForm.recoveryCode.trim() || undefined });
        setRecoveryCodes(nextCodes);
        setMfaForm({ ...mfaForm, recoveryPassword: '', recoveryCode: '' });
        await refreshMfaStatus();
      });
    } finally { setMfaLoading(false); }
  };
  const firstFile = (event: React.ChangeEvent<HTMLInputElement>) => { const file = event.currentTarget.files?.[0]; event.currentTarget.value = ''; return file; };
  const bannerSrc = bannerPreviewUrl || (baseUrl ? fileUrl(baseUrl, user?.banner) : '');
  const previewBannerFile = (file: File) => {
    if (typeof FileReader === 'undefined') return;
    const reader = new FileReader();
    reader.onload = () => { if (typeof reader.result === 'string') setBannerPreviewUrl(reader.result); };
    reader.readAsDataURL(file);
  };
  const handleBannerUpload = (file: File) => {
    previewBannerFile(file);
    void run(tr('Banner Upload'), () => changeOwnBanner(connection, file));
  };
  const removeBanner = () => void run(tr('Banner entfernen'), async () => { await changeOwnBanner(connection); setBannerPreviewUrl(''); onSaved({ banner: null }); });
  return <div className="modalBackdrop ownProfileBackdrop" onMouseDown={onClose}><div className="ownProfileDialog ownProfilePopup" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={t('profile.edit.title')}>
    <header><div><h2>{t('profile.edit.title')}</h2><span>{t('profile.edit.description')}</span></div><button type="button" className="modalCloseButton" onClick={onClose} aria-label={tr('Schließen')}>×</button></header>
    <input ref={avatarInputRef} type="file" accept="image/*" hidden onChange={(event) => { const file = firstFile(event); if (file) void run(tr('Avatar Upload'), () => changeOwnAvatar(connection, file)); }} />
    <input ref={bannerInputRef} type="file" accept="image/*" hidden onChange={(event) => { const file = firstFile(event); if (file) handleBannerUpload(file); }} />
    <div className="ownProfilePreview" style={{ '--profile-banner': bannerColor } as React.CSSProperties}><div className="welcomeProfileBanner">{bannerSrc ? <img src={bannerSrc} alt="" /> : null}</div><AvatarView user={user} name={name || user?.identity || `User ${user?.id ?? ''}`} baseUrl={baseUrl} className="profileSetupAvatar ownProfileAvatar" /><strong>{name || user?.identity || tr('Nicht angemeldet')}</strong><span>{statusMessage || bio || t('profile.popover.noBio')}</span></div>
    <div className="parityGrid settingsFormGrid profileFormGrid ownProfileGrid"><article className="parityActionCard"><h3><Camera size={16} /> {t('profile.avatarBanner')}</h3><div className="settingsButtonRow"><button type="button" className="settingsActionButton primary" onClick={() => avatarInputRef.current?.click()}>{tr('Avatar wählen')}</button><button type="button" className="settingsActionButton primary" onClick={() => bannerInputRef.current?.click()}>{tr('Banner wählen')}</button><button type="button" className="settingsActionButton danger" onClick={() => void run(tr('Avatar entfernen'), () => changeOwnAvatar(connection))}>{tr('Avatar entfernen')}</button><button type="button" className="settingsActionButton danger" onClick={removeBanner}>{tr('Banner entfernen')}</button></div></article>
    <article className="parityActionCard"><h3><Users size={16} /> {tr('Profil')}</h3><label className="settingsField">{tr('Name')}<input className="settingsInput" value={name} onChange={(event) => setName(event.target.value)} /></label><label className="settingsField">{tr('Bio')}<textarea className="settingsTextarea" value={bio} onChange={(event) => setBio(event.target.value)} maxLength={160} /></label>{connection.serverCapabilities.customUserStatus ? <><label className="settingsField">{tr('Online status')}<select className="settingsSelect" value={statusOverride} onChange={(event) => setStatusOverride(event.target.value)}><option value="">{tr('Auto')}</option><option value="online">{tr('Online')}</option><option value="idle">{tr('Idle')}</option><option value="offline">{tr('Invisible')}</option></select></label><label className="settingsField">{tr('Status message')}<input className="settingsInput" value={statusMessage} onChange={(event) => setStatusMessage(event.target.value)} maxLength={80} /></label></> : null}<label className="settingsField settingsColorField">{tr('Bannerfarbe')}<span className="settingsColorControl"><input type="color" value={bannerColor} onChange={(event) => setBannerColor(event.target.value)} /><span>{bannerColor}</span></span></label><button type="button" className="settingsActionButton primary" onClick={() => void run(tr('Profil speichern'), async () => { const trimmedName = name.trim(); const trimmedBio = bio.trim(); const trimmedStatusMessage = statusMessage.trim(); await updateOwnProfile(connection, { name: trimmedName, bio: trimmedBio, bannerColor, statusOverride: statusOverride || null, statusMessage: trimmedStatusMessage || null }); onSaved({ name: trimmedName, bio: trimmedBio, bannerColor, statusOverride: statusOverride || null, statusMessage: trimmedStatusMessage || null }); })} disabled={!name.trim()}>{tr('Profil speichern')}</button></article>
    <article className="parityActionCard"><h3><KeyRound size={16} /> {t('profile.passwordChange')}</h3><label className="settingsField">{tr('Aktuelles Passwort')}<input className="settingsInput" type="password" value={passwords.currentPassword} onChange={(event) => setPasswords({ ...passwords, currentPassword: event.target.value })} /></label><label className="settingsField">{tr('Neues Passwort')}<input className="settingsInput" type="password" value={passwords.newPassword} onChange={(event) => setPasswords({ ...passwords, newPassword: event.target.value })} /></label><label className="settingsField">{tr('Bestätigen')}<input className="settingsInput" type="password" value={passwords.confirmNewPassword} onChange={(event) => setPasswords({ ...passwords, confirmNewPassword: event.target.value })} /></label><button type="button" className="settingsActionButton primary" onClick={() => void run(tr('Passwort ändern'), () => updateOwnPassword(connection, passwords))} disabled={!passwords.currentPassword || !passwords.newPassword}>{tr('Passwort ändern')}</button></article>
    {supportsAccountSecurity ? <article className="parityActionCard totpSetup"><h3><KeyRound size={16} /> {tr('Two-factor authentication')}</h3><p>{mfaStatus.enabled ? tr('Authenticator app protection is enabled for this account.') : tr('Add an authenticator app to protect this account with TOTP codes.')}</p><div className="settingsButtonRow"><button type="button" className="settingsActionButton secondary" onClick={() => void refreshMfaStatus()} disabled={mfaLoading}><RefreshCw size={14} />{mfaLoading ? tr('Lade…') : tr('Status aktualisieren')}</button><button type="button" className="settingsActionButton primary" onClick={() => void startTotpSetup()} disabled={mfaLoading}>{mfaStatus.enabled ? tr('TOTP neu einrichten') : tr('TOTP einrichten')}</button></div>{totpSetup ? <div className="totpSetupBox"><div className="totpQrCodeCard">{totpQrCodeUrl ? <img className="totpQrCodeImage" src={totpQrCodeUrl} alt={tr('QR code for authenticator app setup')} width={192} height={192} /> : <span>{tr('QR code is being generated…')}</span>}</div><label className="settingsField">{tr('Authenticator app URI')}<input className="settingsInput" readOnly value={totpSetup.otpauthUrl} onFocus={(event) => event.currentTarget.select()} /></label><label className="settingsField">{tr('Secret')}<input className="settingsInput" readOnly value={totpSetup.secret} onFocus={(event) => event.currentTarget.select()} /></label><label className="settingsField">{tr('Authenticator code')}<input className="settingsInput" inputMode="numeric" autoComplete="one-time-code" value={mfaForm.setupCode} onChange={(event) => setMfaForm({ ...mfaForm, setupCode: event.target.value.replace(/\D/g, '').slice(0, 16) })} placeholder="123456" /></label><button type="button" className="settingsActionButton primary" onClick={() => void enableTotp()} disabled={mfaLoading || !mfaForm.setupCode.trim()}>{tr('TOTP aktivieren')}</button></div> : null}<label className="settingsField">{tr('Aktuelles Passwort')}<input className="settingsInput" type="password" value={mfaForm.disablePassword} onChange={(event) => setMfaForm({ ...mfaForm, disablePassword: event.target.value })} /></label><label className="settingsField">{tr('Authenticator code')}<input className="settingsInput" inputMode="numeric" autoComplete="one-time-code" value={mfaForm.disableCode} onChange={(event) => setMfaForm({ ...mfaForm, disableCode: event.target.value.replace(/\D/g, '').slice(0, 16) })} placeholder={mfaStatus.enabled ? '123456' : tr('optional')} /></label><button type="button" className="settingsActionButton danger" onClick={() => void disableTotp()} disabled={mfaLoading || !mfaForm.disablePassword}>{tr('TOTP deaktivieren')}</button></article> : null}
    {supportsAccountSecurity ? <article className="parityActionCard recoveryCodesPanel"><h3><KeyRound size={16} /> {tr('Recovery-Codes')}</h3><p>{tr(`Verbleibende Recovery-Codes: ${mfaStatus.recoveryCodesRemaining ?? 0}. Codes nur sicher speichern; sie werden nur einmal angezeigt.`)}</p>{recoveryCodes.length ? <div className="recoveryCodeGrid" aria-label={tr('Recovery-Codes')}>{recoveryCodes.map((code) => <code key={code}>{code}</code>)}</div> : null}<label className="settingsField">{tr('Aktuelles Passwort')}<input className="settingsInput" type="password" value={mfaForm.recoveryPassword} onChange={(event) => setMfaForm({ ...mfaForm, recoveryPassword: event.target.value })} /></label><label className="settingsField">{tr('Authenticator code')}<input className="settingsInput" inputMode="numeric" autoComplete="one-time-code" value={mfaForm.recoveryCode} onChange={(event) => setMfaForm({ ...mfaForm, recoveryCode: event.target.value.replace(/\D/g, '').slice(0, 16) })} placeholder="123456" /></label><button type="button" className="settingsActionButton secondary" onClick={() => void regenerateRecoveryCodes()} disabled={mfaLoading || !mfaStatus.enabled || !mfaForm.recoveryPassword}>{tr('Recovery-Codes neu erstellen')}</button></article> : null}
    {supportsAccountSecurity ? <article className="parityActionCard appPasswordList"><h3><KeyRound size={16} /> {tr('App-Passwörter')}</h3><p>{tr('Gemerkte Desktop-Geräte nutzen diese widerrufbaren Tokens nach erfolgreicher Passwort- und 2FA-Anmeldung. Tokens werden lokal im sicheren Speicher abgelegt und auf dem Server nur gehasht gespeichert.')}</p><div className="settingsButtonRow"><button type="button" className="settingsActionButton secondary" onClick={() => void refreshAppPasswords()} disabled={appPasswordsLoading}><RefreshCw size={14} />{appPasswordsLoading ? tr('Lade…') : tr('Aktualisieren')}</button></div><div className="appPasswordRows">{appPasswords.length ? appPasswords.map((entry) => <div className="appPasswordRow" key={entry.id}><div className="appPasswordRowMeta"><strong>{entry.name}</strong><small>{tr('Erstellt')}: {formatAppPasswordTime(entry.createdAt)} · {tr('Zuletzt genutzt')}: {formatAppPasswordTime(entry.lastUsedAt)}{entry.revokedAt ? ` · ${tr('Widerrufen')}: ${formatAppPasswordTime(entry.revokedAt)}` : ''}</small></div><button type="button" className="settingsActionButton danger" aria-label={`${tr('App-Passwort widerrufen')}: ${entry.name}`} onClick={() => void revokeAppPassword(entry)} disabled={!!entry.revokedAt}>{entry.revokedAt ? tr('Widerrufen') : tr('Widerrufen')}</button></div>) : <small>{tr('Keine App-Passwörter für dieses Konto.')}</small>}</div></article> : null}</div>
    <footer><span className="globalSearchStatus">{status}</span><button type="button" className="primaryAction" onClick={onClose}>{tr('Fertig')}</button></footer>
  </div></div>;
}

function NotificationParitySettings({ notificationSettings, setNotificationSettings, onStatus }: { notificationSettings: NotificationSettings; setNotificationSettings: React.Dispatch<React.SetStateAction<NotificationSettings>>; onStatus: (status: string) => void }) {
  const toggle = async (key: keyof NotificationSettings, value: boolean) => {
    if (value) {
      const browserPermission = typeof Notification !== 'undefined' && Notification.requestPermission ? await Notification.requestPermission() : 'unsupported';
      const desktopPermission = await requestDesktopNotificationPermission();
      onStatus(tr(`Benachrichtigungen: Browser ${browserPermission} · Desktop ${desktopPermission}`));
    }
    setNotificationSettings((current) => ({ ...current, [key]: value }));
  };
  return <section className="settingsCard notificationSettings"><h2>{t('notifications.title')}</h2><p>{t('notifications.description')}</p>{(['allMessages','mentions','dms','replies'] as const).map((key) => <label className="toggleRow" key={key}><input type="checkbox" checked={notificationSettings[key]} onChange={(event) => void toggle(key, event.target.checked)} /><span>{key === 'allMessages' ? tr('Alle Nachrichten') : key === 'mentions' ? 'Mentions' : key === 'dms' ? 'Direct Messages' : 'Replies'}</span></label>)}<label className="toggleRow notificationSoundsToggle"><input type="checkbox" checked={notificationSettings.notificationSounds} onChange={(event) => setNotificationSettings((current) => ({ ...current, notificationSounds: event.target.checked }))} /><span>{tr('Notification sounds')}</span></label></section>;
}

function ParitySprintSettings({ connection, readStates, externalStreamsMap, pluginCommandsByPlugin, onStatus }: { connection: SharkordConnection | null; readStates: Record<number, number>; externalStreamsMap: Record<number, Record<number, SharkordExternalStream>>; pluginCommandsByPlugin: Record<string, SharkordPluginCommand[]>; onStatus: (status: string) => void }) {
  const [pluginId, setPluginId] = useState('');
  const [commandName, setCommandName] = useState('');
  const [actionName, setActionName] = useState('');
  const [settingKey, setSettingKey] = useState('');
  const [settingValue, setSettingValue] = useState('');
  const [pluginCommands, setPluginCommands] = useState<SharkordPluginCommand[]>([]);
  const [pluginLogs, setPluginLogs] = useState<SharkordPluginLog[]>([]);
  const [pluginSettings, setPluginSettings] = useState<SharkordPluginSetting[]>([]);
  const [consumerQuality, setLocalConsumerQuality] = useState<StreamQualitySetting>({ mode: 'auto' });
  const [unreadThreadItems, setUnreadThreadItems] = useState<UnreadThreadItem[]>([]);
  const run = async (label: string, action: () => Promise<unknown>) => {
    if (!connection) { onStatus(tr(`${label}: nicht verbunden`)); return; }
    try { const result = await action(); onStatus(`${label}: OK${result ? ` · ${JSON.stringify(result).slice(0, 120)}` : ''}`); } catch (err) { onStatus(tr(`${label}: ${cleanError(err)}`)); }
  };
  const commandsFromJoin = useCallback((selectedPluginId?: string): SharkordPluginCommand[] => Object.entries(pluginCommandsByPlugin).flatMap(([id, commands]) => (selectedPluginId && id !== selectedPluginId ? [] : (commands ?? []).map((command) => ({ ...command, pluginId: command.pluginId ?? id })))), [pluginCommandsByPlugin]);
  useEffect(() => setPluginCommands(commandsFromJoin(pluginId || undefined)), [commandsFromJoin, pluginId]);
  const externalCount = Object.values(externalStreamsMap).reduce((sum, streams) => sum + Object.keys(streams ?? {}).length, 0);
  const unreadCount = Object.values(readStates).reduce((sum, count) => sum + count, 0);
  const loadUnreadThreads = async () => run(tr('Thread-Antworten'), async () => {
    if (!connection?.serverCapabilities.threadInbox) throw new Error(tr('Dieser Server unterstützt Thread-Antworten nicht.'));
    const threads = await getUnreadThreads(connection, 20);
    setUnreadThreadItems(threads.items);
    return `${threads.totalUnreadReplies} replies`;
  });
  return <section className="settingsCard paritySprintSettings"><div><h2>{t('parity.title')}</h2><p>{t('parity.description')}</p></div>
    <div className="parityStats"><span className="unreadBadge">{tr('Ungelesen')} {unreadCount}</span><span className="externalStreamCard">{tr('Externe Streams')} {externalCount}</span><span className="floatingPopoutCard">{tr('Popout Architektur: native Fenster + Floating-Popout')}</span></div>
    <div className="parityGrid settingsFormGrid"><article className="parityActionCard threadRepliesPanel"><h3>Thread-Antworten</h3>{connection && connection.serverCapabilities.threadInbox ? <><p>{tr('Ungelesene Thread-Antworten serverseitig aggregieren.')}</p><button type="button" className="settingsActionButton secondary" onClick={() => void loadUnreadThreads()}>{tr('Thread-Antworten laden')}</button><div className="pluginChipList">{unreadThreadItems.slice(0, 8).map((item) => <span className="pluginCommandChip" key={`${item.channelId}-${item.parentMessageId}`}>#{item.channelId} · {item.unreadReplyCount} {tr('Replies')}</span>)}</div></> : <p>{tr('Dieser Server unterstützt Thread-Antworten nicht.')}</p>}</article><article className="parityActionCard pluginCommandsPanel"><h3>{t('parity.pluginCommands')}</h3><label className="settingsField">{tr('Plugin-ID')}<input className="settingsInput" value={pluginId} onChange={(event) => setPluginId(event.target.value)} /></label><label className="settingsField">{tr('Befehl')}<input className="settingsInput" value={commandName} onChange={(event) => setCommandName(event.target.value)} /></label><div className="settingsButtonRow"><button type="button" className="settingsActionButton secondary" onClick={() => void run(tr('Plugin-Befehle laden'), async () => { const rows = commandsFromJoin(pluginId || undefined); setPluginCommands(rows); return rows.length; })}>{tr('Plugin-Befehle laden')}</button><button type="button" className="settingsActionButton primary" onClick={() => void run(tr('Plugin-Befehl ausführen'), () => executePluginCommand(connection!, pluginId, commandName, {}))} disabled={!pluginId || !commandName}><Play size={14} />{tr('Ausführen')}</button></div><div className="pluginChipList">{pluginCommands.slice(0, 8).map((cmd) => <span className="pluginCommandChip" key={`${cmd.pluginId}-${cmd.name}`}>{cmd.pluginId ? `${cmd.pluginId}/` : ''}{cmd.name}</span>)}</div></article>
    <article className="parityActionCard"><h3>{t('parity.pluginLogsSettings')}</h3><label className="settingsField">{tr('Aktion')}<input className="settingsInput" value={actionName} onChange={(event) => setActionName(event.target.value)} /></label><div className="settingsButtonRow"><button type="button" className="settingsActionButton primary" onClick={() => void run(tr('Plugin-Aktion'), () => executePluginAction(connection!, pluginId, actionName, {}))} disabled={!pluginId || !actionName}>{tr('Action ausführen')}</button><button type="button" className="settingsActionButton secondary" onClick={() => void run(tr('Plugin-Logs'), async () => { const rows = await getPluginLogs(connection!, pluginId); setPluginLogs(rows); return rows.length; })} disabled={!pluginId}>{tr('Logs')}</button><button type="button" className="settingsActionButton secondary" onClick={() => void run(tr('Plugin-Einstellungen'), async () => { const rows = await getPluginSettings(connection!, pluginId); setPluginSettings(rows); return rows.length; })} disabled={!pluginId}>{tr('Einstellungen')}</button></div><label className="settingsField">{tr('Einstellungsschlüssel')}<input className="settingsInput" value={settingKey} onChange={(event) => setSettingKey(event.target.value)} /></label><label className="settingsField">{tr('Wert')}<input className="settingsInput" value={settingValue} onChange={(event) => setSettingValue(event.target.value)} /></label><button type="button" className="settingsActionButton secondary" onClick={() => void run(tr('Plugin-Setting speichern'), () => updatePluginSetting(connection!, pluginId, settingKey, settingValue))} disabled={!pluginId || !settingKey}>{tr('Speichern')}</button><div className="pluginStatusPills"><small className="pluginLogsDialog">{tr('Plugin-Logs')}: {pluginLogs.length}</small><small className="pluginSettingsDialog">{tr('Einstellungen')}: {pluginSettings.length}</small></div></article>
    <article className="parityActionCard"><h3>{t('parity.consumerQuality')}</h3><label className="settingsField">{tr('Remote-ID')}<input className="settingsInput qualityRemoteInput" inputMode="numeric" pattern="[0-9]*" onChange={(event) => onStatus(tr(`Remote-ID gewählt: ${event.target.value}`))} /></label><label className="settingsField">{tr('Qualität')}<select className="settingsSelect qualitySelect" onChange={(event) => setLocalConsumerQuality(event.target.value === 'auto' ? { mode: 'auto' } : { mode: 'layer', spatialLayer: Number(event.target.value) })}><option value="auto">{tr('Automatisch')}</option><option value="2">1080p / {tr('höchste Schicht')}</option><option value="1">720p</option><option value="0">360p</option></select></label><button type="button" className="settingsActionButton primary" onClick={() => void run(tr('Qualität setzen'), () => setConsumerQuality(connection!, Number((document.querySelector('.paritySprintSettings .qualityRemoteInput') as HTMLInputElement | null)?.value || 0), 'screen', consumerQuality))}>{tr('Qualität setzen')}</button></article>
    <article className="parityActionCard"><h3>{t('parity.externalStreamsPopout')}</h3>{Object.entries(externalStreamsMap).flatMap(([channelId, streams]) => Object.entries(streams ?? {}).map(([streamId, stream]) => <div className="externalStreamCard" key={`${channelId}-${streamId}`}><strong>{stream.title}</strong><span>{stream.pluginId} · {stream.tracks?.video ? tr('Video') : ''} {stream.tracks?.audio ? tr('Audio') : ''}</span></div>))}<p>{tr('Popout-Architektur nutzt native Stream-Popout-Fenster und Floating-Popout statt Browser-window.open.')}</p></article></div>
  </section>;
}

function ExportUserDataConfirmDialog({ onCancel, onConfirm }: { onCancel: () => void; onConfirm: () => void }) {
  return <div className="modalBackdrop" onMouseDown={onCancel}><div className="confirmDialog exportUserDataConfirmDialog" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={tr('Nutzerdaten wirklich exportieren?')}><h2>{tr('Nutzerdaten wirklich exportieren?')}</h2><p>{tr('Gespeicherte Login-/Server-Zugangsdaten werden sensibel und lesbar in die JSON-Datei geschrieben. Speichere die Datei nur an einem sicheren Ort und teile sie nicht.')}</p><div className="modalActions"><button type="button" className="secondary" onClick={onCancel}>{tr('Abbrechen')}</button><button type="button" className="dangerAction" onClick={onConfirm}>{tr('Fortfahren und Speicherort wählen')}</button></div></div></div>;
}

function ImportExportSettings({ status, appState, audioSettings, streamAudioMutedUsers, includeUserData, setIncludeUserData, onExport, onImport }: { status: string; appState: StoredState; audioSettings: AudioDeviceSettings; streamAudioMutedUsers: StreamAudioMuteSettings; includeUserData: boolean; setIncludeUserData: (value: boolean) => void; onExport: () => void | Promise<void>; onImport: () => void | Promise<void> }) {
  return <section className="settingsCard importExportSettings">
    <div><h2>{tr('Import/Export')}</h2><p>{tr('Übertrage Serverliste und globale Einstellungen auf andere Geräte. Zugangsdaten werden nur exportiert, wenn du die Nutzerdaten-Tickbox aktivierst.')}</p><small>{tr(status)}</small></div>
    <div className="importExportSummary" aria-label={tr('Export-Inhalt')}>
      <span><strong>{appState.servers.length}</strong>{tr('Server')}</span>
      <span><strong>{appState.theme === 'light' ? 'Light' : 'Dark'}</strong>{tr('Design')}</span>
      <span><strong>{audioSettings.videoResolution}</strong>{tr('Video')}</span>
      <span><strong>{Object.keys(streamAudioMutedUsers).length}</strong>{tr('Stream-Audio-Stummschaltungen')}</span>
    </div>
    <label className="checkboxRow exportUserDataToggle"><input type="checkbox" checked={includeUserData} onChange={(event) => setIncludeUserData(event.target.checked)} />{tr('Nutzerdaten einschließen')} <small>{tr('enthält gespeicherte Login-/Server-Zugangsdaten im JSON; nur sicher speichern')}</small></label>
    <div className="importExportGrid">
      <article><h3>{tr('Export')}</h3><p>{tr('Öffnet einen nativen Speichern-unter-Dialog und erstellt eine portable JSON-Datei mit Servern, Design, Audio-/Video-Einstellungen und Stream-Audio-Stummschaltungen.')}</p><div className="importExportActions"><button type="button" className="settingsTransferButton primary" onClick={() => void onExport()}>{tr('Einstellungen exportieren')}</button></div></article>
      <article><h3>{tr('Import')}</h3><p>{tr('Import ersetzt die lokale Serverliste und globale Einstellungen. Enthaltene Nutzerdaten/Zugangsdaten werden nur nach zusätzlicher Bestätigung in den sicheren lokalen Speicher übernommen.')}</p><div className="importExportActions"><button type="button" className="settingsTransferButton secondary" onClick={() => void onImport()}>{tr('JSON importieren')}</button></div></article>
    </div>
  </section>;
}

type AdminTab = 'general' | 'roles' | 'emojis' | 'storage' | 'users' | 'security' | 'invites' | 'plugins' | 'parity';
type PluginSubTab = 'installed' | 'marketplace';
function AdminWorkbench({ connection, categories, channels, users, roles, setRoles, onUsersChanged, initialTab = 'general', readStates, externalStreamsMap, pluginCommandsByPlugin, realtimeEvent }: { connection: SharkordConnection; categories: SharkordCategory[]; channels: SharkordChannel[]; users: SharkordUser[]; roles: SharkordRole[]; setRoles: React.Dispatch<React.SetStateAction<SharkordRole[]>> | (() => void); onUsersChanged?: (users: SharkordUser[]) => void; initialTab?: AdminTab; readStates: Record<number, number>; externalStreamsMap: Record<number, Record<number, SharkordExternalStream>>; pluginCommandsByPlugin: Record<string, SharkordPluginCommand[]>; realtimeEvent?: AdminRealtimeEvent }) {
  const [adminTab, setAdminTab] = useState<AdminTab>(initialTab);
  const [adminStatus, setAdminStatus] = useState(tr('Bereit'));
  const [settings, setSettings] = useState<Partial<SharkordServerSettings>>({});
  const [storageDiskMetrics, setStorageDiskMetrics] = useState<SharkordDiskMetrics | null>(null);
  const [serverSettingsDirty, setServerSettingsDirty] = useState(false);
  const [serverSettingsSaving, setServerSettingsSaving] = useState(false);
  const [serverSettingsFeedback, setServerSettingsFeedback] = useState(tr('Keine Änderungen'));
  const [adminUsers, setAdminUsers] = useState<SharkordUser[]>(users);
  const [dirtyRoleIds, setDirtyRoleIds] = useState<Set<number>>(() => new Set());
  const [pendingRoleAction, setPendingRoleAction] = useState<RoleAction | null>(null);
  const [userSearch, setUserSearch] = useState('');
  const [adminUserInfoState, setAdminUserInfoState] = useState<AdminUserInfoState>(null);
  const adminUserInfo = adminUserInfoState?.info ?? null;
  const adminUserInfoLoading = !!adminUserInfoState?.loading;
  const [inviteSearch, setInviteSearch] = useState('');
  const [invites, setInvites] = useState<SharkordInvite[]>([]);
  const [ipSecurityRules, setIpSecurityRules] = useState<SharkordIpSecurityRule[]>([]);
  const [ipSecurityEvents, setIpSecurityEvents] = useState<SharkordIpSecurityEvent[]>([]);
  const [ipRuleRange, setIpRuleRange] = useState('');
  const [ipRuleReason, setIpRuleReason] = useState('');
  const [emojis, setEmojis] = useState<SharkordEmoji[]>([]);
  const [plugins, setPlugins] = useState<SharkordPluginInfo[]>([]);
  const [pluginSlots, setPluginSlots] = useState<SharkordPluginSlotRender[]>([]);
  const [marketplacePlugins, setMarketplacePlugins] = useState<SharkordMarketplaceEntry[]>([]);
  const [pluginSubTab, setPluginSubTab] = useState<PluginSubTab>('installed');
  const [pluginSearch, setPluginSearch] = useState('');
  const [webhooks, setWebhooks] = useState<IncomingWebhookSummary[]>([]);
  const [webhookName, setWebhookName] = useState('');
  const [webhookChannelId, setWebhookChannelId] = useState('');
  const [newWebhookToken, setNewWebhookToken] = useState('');
  const [retentionPreviewState, setRetentionPreviewState] = useState<Awaited<ReturnType<typeof previewRetention>> | null>(null);
  const [inviteDialogOpen, setInviteDialogOpen] = useState(false);
  const [inviteDraft, setInviteDraft] = useState(() => createInviteDraft());
  const emojiFileInputRef = useRef<HTMLInputElement | null>(null);
  const logoInputRef = useRef<HTMLInputElement | null>(null);
  const [secretToken, setSecretToken] = useState('');
  const [serverUpdateInfo, setServerUpdateInfo] = useState<Awaited<ReturnType<typeof getServerUpdate>> | null>(null);
  const [serverUpdateStatus, setServerUpdateStatus] = useState(tr('Bereit'));
  const [serverUpdateBusy, setServerUpdateBusy] = useState(false);
  const showServerCapabilityControls = connection.serverCapabilities.serverSelfUpdate || connection.serverCapabilities.ownerToken;
  const serverModeLabel = connection.serverCapabilities.flavor === 'original' ? tr('Original Sharkord') : connection.serverCapabilities.flavor === 'kanuracer' ? tr('Kanuracer') : tr('Unbekannt');
  const serverModeDescription = connection.serverCapabilities.flavor === 'original' ? tr('Original Sharkord: Standard-Routen aktiv, Fork-Erweiterungen ausgeblendet.') : connection.serverCapabilities.flavor === 'kanuracer' ? tr('Kanuracer: Desktop-Erweiterungen verfügbar.') : tr('Server-Capabilities unbekannt.');
  const submitSecretToken = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!connection.serverCapabilities.ownerToken) { setServerUpdateStatus(tr('Owner-Token wird von diesem Server nicht unterstützt.')); return; }
    if (!secretToken.trim()) { setServerUpdateStatus(tr('Server-Owner-Token fehlt.')); return; }
    setServerUpdateBusy(true);
    setServerUpdateStatus(tr('Server-Owner-Token wird angewendet…'));
    try {
      await useSecretToken(connection, secretToken.trim());
      setSecretToken('');
      setServerUpdateStatus(tr('Server-Owner-Token angewendet'));
    } catch (err) {
      setServerUpdateStatus(tr(`Server-Owner-Token fehlgeschlagen: ${cleanError(err)}`));
    } finally {
      setServerUpdateBusy(false);
    }
  };
  const checkServerUpdate = async () => {
    if (!connection.serverCapabilities.serverSelfUpdate) { setServerUpdateStatus(tr('Server-Update wird von diesem Server nicht unterstützt.')); return; }
    setServerUpdateBusy(true);
    setServerUpdateStatus(tr('Server-Update wird geprüft…'));
    try {
      const info = await getServerUpdate(connection);
      setServerUpdateInfo(info);
      setServerUpdateStatus(info.hasUpdate ? tr(`Server-Update verfügbar${info.latestVersion ? `: ${info.latestVersion}` : ''}`) : tr('Server ist aktuell'));
    } catch (err) {
      setServerUpdateStatus(tr(`Server-Update prüfen fehlgeschlagen: ${cleanError(err)}`));
    } finally {
      setServerUpdateBusy(false);
    }
  };
  const runServerUpdate = async () => {
    if (!connection.serverCapabilities.serverSelfUpdate) { setServerUpdateStatus(tr('Server-Update wird von diesem Server nicht unterstützt.')); return; }
    setServerUpdateBusy(true);
    setServerUpdateStatus(tr('Server wird aktualisiert…'));
    try {
      await updateServer(connection);
      setServerUpdateStatus(tr('Server-Update gestartet'));
      const info = await getServerUpdate(connection).catch(() => null);
      if (info) setServerUpdateInfo(info);
    } catch (err) {
      setServerUpdateStatus(tr(`Server aktualisieren fehlgeschlagen: ${cleanError(err)}`));
    } finally {
      setServerUpdateBusy(false);
    }
  };
  const roleUpdater = setRoles as React.Dispatch<React.SetStateAction<SharkordRole[]>>;

  const runAdmin = async (label: string, action: () => Promise<void>) => { try { await action(); setAdminStatus(tr(`${label}: OK`)); } catch (err) { setAdminStatus(tr(`${label}: ${cleanError(err)}`)); } };
  const refreshPlugins = useCallback(async () => {
    try { setPlugins(await getPlugins(connection)); }
    catch (err) { setAdminStatus(tr(`Plugins laden: ${cleanError(err)}`)); }
  }, [connection]);
  const refreshPluginSlots = useCallback(async () => {
    try { setPluginSlots(await processPluginComponents(connection, connection.join.pluginIdsWithComponents ?? [], connection.join.pluginsMetadata ?? [])); }
    catch (err) { setAdminStatus(tr(`Plugin-Komponenten laden: ${cleanError(err)}`)); setPluginSlots([]); }
  }, [connection]);
  const refreshMarketplace = useCallback(async () => {
    try { setMarketplacePlugins(await getMarketplacePlugins()); }
    catch (err) { setAdminStatus(tr(`Marketplace laden: ${cleanError(err)}`)); }
  }, []);
  const refreshAdmin = useCallback(async () => {
    const [settingsResult, storageResult, rolesResult, usersResult, invitesResult, emojisResult, securityRulesResult, securityEventsResult, webhooksResult, retentionResult] = await Promise.allSettled([
      getServerSettings(connection),
      getStorageSettings(connection),
      getRoles(connection),
      getAdminUsers(connection),
      getInvites(connection),
      getEmojis(connection),
      connection.serverCapabilities.securityIpRules ? getIpSecurityRules(connection) : Promise.resolve([]),
      connection.serverCapabilities.securityIpRules ? getIpSecurityEvents(connection) : Promise.resolve([]),
      connection.serverCapabilities.incomingWebhooks ? listIncomingWebhooks(connection) : Promise.resolve([]),
      connection.serverCapabilities.retentionPolicies ? previewRetention(connection) : Promise.resolve(null)
    ] as const);
    const adminLoadWarnings: string[] = [];
    const collectAdminWarning = (label: string, result: PromiseSettledResult<unknown>, required = false) => { if (required && result.status === 'rejected') adminLoadWarnings.push(`${label}: ${cleanError(result.reason)}`); };
    if (settingsResult.status === 'fulfilled') { setSettings((current) => ({ ...current, ...settingsResult.value })); setServerSettingsDirty(false); setServerSettingsFeedback(tr('Admin-Daten geladen')); }
    if (storageResult.status === 'fulfilled') { setSettings((current) => ({ ...current, ...storageResult.value.storageSettings })); setStorageDiskMetrics(storageResult.value.diskMetrics ?? null); }
    if (rolesResult.status === 'fulfilled') { setDirtyRoleIds(new Set()); roleUpdater(rolesResult.value); }
    if (usersResult.status === 'fulfilled') { const visibleUsers = usersResult.value.filter((user) => !isDeletedUserPlaceholder(user)); setAdminUsers(visibleUsers); onUsersChanged?.(visibleUsers); }
    if (invitesResult.status === 'fulfilled') setInvites(invitesResult.value);
    if (emojisResult.status === 'fulfilled') setEmojis(emojisResult.value);
    if (securityRulesResult.status === 'fulfilled') setIpSecurityRules(securityRulesResult.value);
    if (securityEventsResult.status === 'fulfilled') setIpSecurityEvents(securityEventsResult.value);
    if (webhooksResult.status === 'fulfilled') setWebhooks(webhooksResult.value);
    if (retentionResult.status === 'fulfilled') setRetentionPreviewState(retentionResult.value);
    collectAdminWarning(tr('Übersicht'), settingsResult, true);
    collectAdminWarning(tr('Speicher'), storageResult, true);
    collectAdminWarning(tr('Rollen'), rolesResult, true);
    collectAdminWarning(tr('Benutzer'), usersResult, true);
    collectAdminWarning(tr('Einladungen'), invitesResult);
    collectAdminWarning(tr('Emojis'), emojisResult);
    if (connection.serverCapabilities.securityIpRules) collectAdminWarning(tr('IP-Sicherheit'), securityRulesResult);
    if (connection.serverCapabilities.securityIpRules) collectAdminWarning(tr('Security-Events'), securityEventsResult);
    if (connection.serverCapabilities.incomingWebhooks) collectAdminWarning(tr('Incoming Webhooks'), webhooksResult);
    if (connection.serverCapabilities.retentionPolicies) collectAdminWarning(tr('Retention Policies'), retentionResult);
    setAdminStatus(adminLoadWarnings.length ? tr(`Admin-Daten teilweise geladen: ${adminLoadWarnings.join(' · ')}`) : tr('Admin-Daten geladen'));
    void refreshPlugins();
    void refreshPluginSlots();
    void refreshMarketplace();
  }, [connection, onUsersChanged, roleUpdater, refreshMarketplace, refreshPluginSlots, refreshPlugins]);
  useEffect(() => { setAdminTab(initialTab); }, [initialTab]);
  useEffect(() => { void refreshAdmin(); }, [refreshAdmin]);
  // Keep the admin user table on admin/user-management data. The live member list
  // carries volatile presence status and can update many times per second during
  // realtime/voice activity; mirroring it here makes the Status/Created/Login
  // badge row visibly flicker between presence/account values.
  useEffect(() => {
    if (!realtimeEvent) return;
    if (realtimeEvent.kind === 'users') {
      if (realtimeEvent.action === 'delete') {
        const deletedId = Number((realtimeEvent.payload as { userId?: number })?.userId ?? 0);
        if (deletedId) setAdminUsers((current) => current.filter((user) => user.id !== deletedId));
      } else if (realtimeEvent.payload && typeof realtimeEvent.payload === 'object' && 'id' in realtimeEvent.payload) {
        const user = realtimeEvent.payload as SharkordUser;
        setAdminUsers((current) => upsertListById(current, user).filter((item) => !isDeletedUserPlaceholder(item)));
      } else {
        void getAdminUsers(connection).then((rows) => setAdminUsers(rows.filter((user) => !isDeletedUserPlaceholder(user)))).catch((err) => setAdminStatus(tr(`Benutzer aktualisieren: ${cleanError(err)}`)));
      }
      setAdminStatus(tr('Benutzer per Realtime aktualisiert'));
    }
    if (realtimeEvent.kind === 'roles') {
      if (dirtyRoleIds.size === 0) {
        void getRoles(connection).then((nextRoles) => { roleUpdater(nextRoles); setAdminStatus(tr('Rollen per Realtime aktualisiert')); }).catch((err) => setAdminStatus(tr(`Rollen aktualisieren: ${cleanError(err)}`)));
      } else {
        setAdminStatus(tr('Rollen per Realtime aktualisiert; lokale ungespeicherte Änderungen behalten'));
      }
    }
    if (realtimeEvent.kind === 'emojis') {
      if (realtimeEvent.action === 'delete') {
        setEmojis((current) => current.filter((emoji) => emoji.id !== Number(realtimeEvent.payload)));
      } else if (realtimeEvent.payload && typeof realtimeEvent.payload === 'object' && 'id' in realtimeEvent.payload) {
        setEmojis((current) => upsertListById(current, realtimeEvent.payload as SharkordEmoji));
      } else {
        void getEmojis(connection).then(setEmojis).catch((err) => setAdminStatus(tr(`Emojis aktualisieren: ${cleanError(err)}`)));
      }
      setAdminStatus(tr('Emojis per Realtime aktualisiert'));
    }
    if (realtimeEvent.kind === 'serverSettings') {
      if (!serverSettingsDirty) void getServerSettings(connection).then((nextSettings) => { setSettings(nextSettings); setServerSettingsFeedback(tr('Server-Einstellungen per Realtime aktualisiert')); }).catch((err) => setAdminStatus(tr(`Server-Einstellungen aktualisieren: ${cleanError(err)}`)));
      else setServerSettingsFeedback(tr('Remote-Änderung empfangen; lokale Änderungen nicht überschrieben'));
    }
    if (realtimeEvent.kind === 'plugins') {
      void refreshPlugins();
      void refreshPluginSlots();
      setAdminStatus(tr('Plugins per Realtime aktualisiert'));
    }
  }, [connection, dirtyRoleIds.size, refreshPluginSlots, refreshPlugins, realtimeEvent, serverSettingsDirty]);

  const updateServerSettings = (patch: Partial<SharkordServerSettings>) => { setSettings((current) => ({ ...current, ...patch })); setServerSettingsDirty(true); setServerSettingsFeedback(tr('Nicht gespeicherte Änderungen')); };
  const saveSettings = async () => {
    setServerSettingsSaving(true);
    setServerSettingsFeedback(tr('Speichere…'));
    await runAdmin(tr('Server-Einstellungen speichern'), async () => {
      await saveServerSettings(connection, settings);
      setSettings(await getServerSettings(connection));
      if (connection.serverCapabilities.retentionPolicies) setRetentionPreviewState(await previewRetention(connection));
      setServerSettingsDirty(false);
      setServerSettingsFeedback(tr('Änderungen gespeichert'));
    });
    setServerSettingsSaving(false);
  };
  const textChannels = channels.filter((channel) => channel.type === 'TEXT' && !channel.isDm);
  const createWebhook = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!connection.serverCapabilities.incomingWebhooks) { setAdminStatus(tr('Dieser Server unterstützt Incoming Webhooks nicht.')); return; }
    const channelId = Number(webhookChannelId || textChannels[0]?.id || 0);
    void runAdmin(tr('Incoming Webhook erstellen'), async () => {
      const created = await createIncomingWebhook(connection, { name: webhookName.trim() || tr('Neuer Webhook'), channelId });
      setNewWebhookToken(created.token);
      setWebhookName('');
      setWebhookChannelId('');
      setWebhooks(await listIncomingWebhooks(connection));
    });
  };
  const removeWebhook = (webhookId: number) => runAdmin(tr('Incoming Webhook löschen'), async () => { await deleteIncomingWebhook(connection, webhookId); setWebhooks(await listIncomingWebhooks(connection)); });
  const refreshRetention = () => {
    if (!connection.serverCapabilities.retentionPolicies) { setAdminStatus(tr('Dieser Server unterstützt Retention Policies nicht.')); return; }
    void runAdmin(tr('Retention Preview'), async () => { setRetentionPreviewState(await previewRetention(connection)); });
  };
  const runRetention = (dryRun: boolean) => {
    if (!connection.serverCapabilities.retentionPolicies) { setAdminStatus(tr('Dieser Server unterstützt Retention Policies nicht.')); return; }
    void runAdmin(dryRun ? tr('Retention Trockenlauf') : tr('Retention Cleanup'), async () => { await runRetentionCleanup(connection, dryRun); setRetentionPreviewState(await previewRetention(connection)); });
  };

  const addCategory = () => runAdmin(tr('Kategorie erstellen'), async () => { await createCategory(connection, prompt(tr('Kategorie-Name')) || tr('Neue Kategorie')); });
  const renameCategory = (category: SharkordCategory) => runAdmin(tr('Kategorie umbenennen'), async () => { const freshCategory = await getCategoryDetail(connection, category.id); const name = prompt(tr('Kategorie-Name'), freshCategory.name)?.trim() || freshCategory.name; if (name === freshCategory.name) return; await updateCategory(connection, freshCategory.id, name); });
  const removeCategory = (category: SharkordCategory) => runAdmin(tr('Kategorie löschen'), async () => { if (window.confirm(tr(`${category.name} löschen?`))) await deleteCategory(connection, category.id); });
  const addChannel = (type: 'TEXT' | 'VOICE') => runAdmin(tr('Channel erstellen'), async () => { await createChannel(connection, { name: prompt(tr('Channel-Name')) || (type === 'VOICE' ? 'voice' : 'text'), type, categoryId: categories[0]?.id ?? 0 }); });
  const renameChannel = (channel: SharkordChannel) => runAdmin(tr('Channel bearbeiten'), async () => { const freshChannel = await getChannelDetail(connection, channel.id); await updateChannel(connection, { channelId: freshChannel.id, name: prompt(tr('Channel-Name'), freshChannel.name)?.trim() || freshChannel.name, topic: freshChannel.topic ?? null, private: !!freshChannel.private }); });
  const removeChannel = (channel: SharkordChannel) => runAdmin(tr('Channel löschen'), async () => { if (window.confirm(tr(`#${channel.name} löschen?`))) await deleteChannel(connection, channel.id); });

  const addRole = () => runAdmin(tr('Rolle erstellen'), async () => { await createRole(connection); setDirtyRoleIds(new Set()); roleUpdater(await getRoles(connection)); });
  const patchRole = (role: SharkordRole, patch: Partial<SharkordRole>) => { setDirtyRoleIds((current) => new Set(current).add(role.id)); roleUpdater((current) => current.map((item) => item.id === role.id ? { ...item, ...patch } : item)); };
  const saveRole = (role: SharkordRole) => runAdmin(tr('Rolle speichern'), async () => { const currentRole = roles.find((item) => item.id === role.id) ?? role; await updateRole(connection, normalizeRoleForSave(currentRole)); roleUpdater(await getRoles(connection)); setDirtyRoleIds((current) => { const next = new Set(current); next.delete(role.id); return next; }); });
  const editRole = (role: SharkordRole) => setPendingRoleAction({ kind: 'edit', role, name: role.name, color: role.color || '#99aab5' });
  const removeRole = (role: SharkordRole) => setPendingRoleAction({ kind: 'delete', role });
  const confirmRoleAction = (action: RoleAction) => {
    setPendingRoleAction(null);
    void runAdmin(action.kind === 'edit' ? tr('Rolle bearbeiten') : tr('Rolle löschen'), async () => {
      if (action.kind === 'edit') {
        await updateRole(connection, normalizeRoleForSave({ ...action.role, name: action.name.trim() || action.role.name, color: action.color || action.role.color || '#99aab5' }));
      } else {
        if (action.role.isDefault || action.role.isPersistent) throw new Error(tr('Standard- oder persistente Rollen können nicht gelöscht werden.'));
        await deleteRole(connection, action.role.id);
      }
      setDirtyRoleIds((current) => { const next = new Set(current); next.delete(action.role.id); return next; });
      roleUpdater(await getRoles(connection));
    });
  };
  const makeDefaultRole = (role: SharkordRole) => runAdmin(tr('Default-Rolle setzen'), async () => { await setDefaultRole(connection, role.id); setDirtyRoleIds(new Set()); roleUpdater(await getRoles(connection)); });
  const toggleRolePermission = (role: SharkordRole, permission: string) => { const permissions = new Set(role.permissions ?? []); permissions.has(permission) ? permissions.delete(permission) : permissions.add(permission); patchRole(role, { permissions: [...permissions] }); };
  const updateRoleStorageGb = (role: SharkordRole, value: string) => patchRole(role, { storageSpaceQuota: gbInputToBytes(value) });

  const moderateAdminUser = (user: SharkordUser, action: 'kick' | 'ban' | 'unban' | 'delete') => runAdmin(tr(`Benutzer ${action}`), async () => {
    if (isDeletedUserPlaceholder(user)) { setAdminStatus(tr('Gelöschter Benutzer-Platzhalter kann nicht moderiert werden')); return; }
    const userLabel = user.name || user.identity || `User ${user.id}`;
    if (!window.confirm(tr(`${action} ${userLabel}?`))) return;
    if (action === 'delete') {
      const wipe = window.confirm(tr(`Daten dieses Benutzers endgültig löschen?\n\nOK = Benutzer + Daten löschen\nAbbrechen = Benutzer ohne Daten-Wipe löschen`));
      await moderateUser(connection, action, user.id, { wipe });
    } else {
      const reason = action === 'unban' ? undefined : prompt(tr('Grund optional')) || undefined;
      await moderateUser(connection, action, user.id, { reason });
    }
    const nextUsers = await getAdminUsers(connection);
    setAdminUsers(nextUsers.filter((item) => !isDeletedUserPlaceholder(item)));
    onUsersChanged?.(nextUsers.filter((item) => !isDeletedUserPlaceholder(item)));
  });
  const toggleAdminUserRole = (user: SharkordUser, role: SharkordRole) => runAdmin(tr('Benutzerrolle ändern'), async () => { if (isDeletedUserPlaceholder(user)) { setAdminStatus(tr('Gelöschter Benutzer-Platzhalter kann nicht moderiert werden')); return; } const active = (user.roleIds ?? []).includes(role.id); if (active) await removeRoleFromUser(connection, user.id, role.id); else await addRoleToUser(connection, user.id, role.id); const nextUsers = await getAdminUsers(connection); const visibleUsers = nextUsers.filter((item) => !isDeletedUserPlaceholder(item)); setAdminUsers(visibleUsers); onUsersChanged?.(visibleUsers); });
  const openAdminUserInfo = (user: SharkordUser) => runAdmin(tr('Benutzerdetails laden'), async () => { setAdminUserInfoState({ userId: user.id, info: null, loading: true }); try { const info = await getUserInfo(connection, user.id); setAdminUserInfoState({ userId: user.id, info, loading: false }); } catch (error) { setAdminUserInfoState(null); throw error; } });
  const deleteAdminUserFile = (file: SharkordFile) => runAdmin(tr('Datei löschen'), async () => { if (file.id == null) throw new Error(tr('Datei-ID fehlt')); if (!window.confirm(tr(`${file.originalName || file.name} löschen?`))) return; await deleteStoredFile(connection, file.id); if (adminUserInfoState?.userId) setAdminUserInfoState({ userId: adminUserInfoState.userId, info: await getUserInfo(connection, adminUserInfoState.userId), loading: false }); });

  const addInvite = () => { setInviteDraft(createInviteDraft()); setInviteDialogOpen(true); };
  const removeInvite = (invite: SharkordInvite) => runAdmin(tr('Einladung löschen'), async () => { if (invite.id == null) throw new Error(tr('Einladungs-ID fehlt')); await deleteInvite(connection, invite.id); setInvites(await getInvites(connection)); });
  const copyInviteCode = (invite: SharkordInvite) => runAdmin(tr('Einladung kopieren'), async () => { await navigator.clipboard.writeText(invite.code); });
  const inviteStatus = (invite: SharkordInvite) => invite.expiresAt && invite.expiresAt < Date.now() ? tr('Abgelaufen') : invite.maxUses && (invite.uses ?? 0) >= invite.maxUses ? tr('Ausgeschöpft') : tr('Aktiv');
  const submitInvite = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    void runAdmin(tr('Einladung erstellen'), async () => {
      await createInvite(connection, { code: inviteDraft.code.trim() || undefined, maxUses: Math.max(0, Number(inviteDraft.maxUses) || 0), expiresAt: inviteDraft.expiresAt ? new Date(inviteDraft.expiresAt).getTime() : null, roleId: inviteDraft.roleId === 'default' ? undefined : Number(inviteDraft.roleId) });
      setInvites(await getInvites(connection));
      setInviteDialogOpen(false);
    });
  };

  const refreshIpSecurity = () => {
    if (!connection.serverCapabilities.securityIpRules) { setAdminStatus(tr('Dieser Server unterstützt IP-Sicherheit nicht.')); return; }
    void runAdmin(tr('IP-Sicherheit laden'), async () => {
      const [rules, events] = await Promise.all([getIpSecurityRules(connection), getIpSecurityEvents(connection)]);
      setIpSecurityRules(rules);
      setIpSecurityEvents(events);
    });
  };
  const createIpRule = (kind: 'allowlist' | 'blocklist') => {
    const ipRange = ipRuleRange.trim();
    if (!connection.serverCapabilities.securityIpRules) { setAdminStatus(tr('Dieser Server unterstützt IP-Sicherheit nicht.')); return; }
    if (!ipRange) { setAdminStatus(tr('IP / CIDR / Wildcard fehlt')); return; }
    void runAdmin(kind === 'allowlist' ? tr('IP erlauben') : tr('IP blockieren'), async () => {
      const input = { ipRange, reason: ipRuleReason.trim() || undefined };
      if (kind === 'allowlist') await addIpAllowlist(connection, input);
      else await addIpBlock(connection, input);
      setIpRuleRange('');
      setIpRuleReason('');
      setIpSecurityRules(await getIpSecurityRules(connection));
      setIpSecurityEvents(await getIpSecurityEvents(connection));
    });
  };
  const removeIpRule = (rule: SharkordIpSecurityRule) => runAdmin(tr('IP-Regel entfernen'), async () => { await removeIpSecurityRule(connection, rule.id); setIpSecurityRules(await getIpSecurityRules(connection)); setIpSecurityEvents(await getIpSecurityEvents(connection)); });
  const unblockIpRule = (rule: SharkordIpSecurityRule) => runAdmin(tr('IP entblocken'), async () => { await unblockIp(connection, rule.ipRange); setIpSecurityRules(await getIpSecurityRules(connection)); setIpSecurityEvents(await getIpSecurityEvents(connection)); });

  const renameEmoji = (emoji: SharkordEmoji) => runAdmin(tr('Emoji umbenennen'), async () => { await updateEmoji(connection, emoji.id, prompt(tr('Emoji-Name'), emoji.name) || emoji.name); setEmojis(await getEmojis(connection)); });
  const removeEmoji = (emoji: SharkordEmoji) => runAdmin(tr('Emoji löschen'), async () => { if (window.confirm(tr(`${emoji.name} löschen?`))) await deleteEmoji(connection, emoji.id); setEmojis(await getEmojis(connection)); });
  const handleEmojiUpload = (event: React.ChangeEvent<HTMLInputElement>) => runAdmin(tr('Emoji hochladen'), async () => { const file = event.target.files?.[0]; if (!file) return; await uploadEmoji(connection, file, file.name.replace(/\.[^.]+$/, '')); setEmojis(await getEmojis(connection)); event.target.value = ''; });
  const handleServerLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => runAdmin(tr('Server-Logo Upload'), async () => { const file = event.target.files?.[0]; event.target.value = ''; if (!file) return; await changeServerLogo(connection, file); setSettings(await getServerSettings(connection)); });

  const toggleInstalledPlugin = (plugin: SharkordPluginInfo) => runAdmin(tr('Plugin umschalten'), async () => { await togglePlugin(connection, plugin.id, !plugin.enabled); await refreshPlugins(); });
  const deleteInstalledPlugin = (plugin: SharkordPluginInfo) => runAdmin(tr('Plugin entfernen'), async () => { if (window.confirm(tr(`${plugin.name} entfernen?`))) { await removePlugin(connection, plugin.id); await refreshPlugins(); } });
  const installMarketplacePlugin = (entry: SharkordMarketplaceEntry) => runAdmin(tr('Plugin installieren'), async () => { await installPlugin(connection, entry.plugin.id, pluginVersion(entry)); await refreshPlugins(); });
  const updateInstalledPlugin = (entry: SharkordMarketplaceEntry) => runAdmin(tr('Plugin aktualisieren'), async () => { await updatePlugin(connection, entry.plugin.id, pluginVersion(entry)); await refreshPlugins(); });

  const textAdminChannels = channels.filter((channel) => channel.type !== 'VOICE');
  const voiceAdminChannels = channels.filter((channel) => channel.type === 'VOICE');
  const renderAdminChannel = (channel: SharkordChannel) => <div className="adminListRow" key={channel.id}><div className="adminRowMain"><strong>{channel.type === 'VOICE' ? '🔊' : '#'} {channel.name}</strong><span><span className="adminBadge">{channel.type}</span>{channel.private ? <span className="adminBadge warning">Privat</span> : null}</span></div><div className="adminRowActions"><button onClick={() => renameChannel(channel)}>{tr('Bearbeiten')}</button><button className="danger" onClick={() => removeChannel(channel)}>{tr('Löschen')}</button></div></div>;
  const filteredAdminUsers = adminUsers.filter((user) => !isDeletedUserPlaceholder(user) && `${user.name ?? ''} ${user.identity ?? ''}`.toLowerCase().includes(userSearch.toLowerCase().trim()));
  const filteredInvites = invites.filter((invite) => `${invite.code} ${invite.role?.name ?? ''} ${invite.creator?.name ?? ''}`.toLowerCase().includes(inviteSearch.toLowerCase().trim()));
  const installedPluginIds = new Set(plugins.map((plugin) => plugin.id));
  const pluginSlotsByPlugin = useMemo(() => pluginSlots.reduce((map, slotItem) => {
    const rows = map.get(slotItem.pluginId) ?? [];
    rows.push(slotItem);
    map.set(slotItem.pluginId, rows);
    return map;
  }, new Map<string, SharkordPluginSlotRender[]>()), [pluginSlots]);
  const filteredMarketplacePlugins = marketplacePlugins.filter((entry) => `${entry.plugin.name} ${entry.plugin.description} ${entry.plugin.author}`.toLowerCase().includes(pluginSearch.toLowerCase().trim()));
  const allowedIpRules = ipSecurityRules.filter((rule) => rule.kind === 'allowlist' || rule.kind === 'allow');
  const blockedIpRules = ipSecurityRules.filter((rule) => rule.kind === 'blocklist' || rule.kind === 'block');
  const tabLabels: Record<AdminTab, string> = { general: tr('Übersicht'), roles: tr('Rollen'), emojis: tr('Emojis'), storage: tr('Speicher'), users: tr('Benutzer'), security: tr('IP-Sicherheit'), invites: tr('Einladungen'), plugins: tr('Plugins'), parity: tr('Parität') };
  const storageUsagePercent = storageDiskMetrics?.totalSpace ? Math.min((storageDiskMetrics.usedSpace / storageDiskMetrics.totalSpace) * 100, 100).toFixed(1) : '0.0';
  const storageOverviewMetrics = storageDiskMetrics ? [
    { label: tr('Gesamtspeicher'), value: formatStorageSize(storageDiskMetrics.totalSpace) },
    { label: tr('Freier Speicher'), value: formatStorageSize(storageDiskMetrics.freeSpace) },
    { label: tr('System belegt'), value: formatStorageSize(storageDiskMetrics.usedSpace) },
    { label: tr('Sharkord belegt'), value: formatStorageSize(storageDiskMetrics.sharkordUsedSpace) }
  ] : [
    { label: tr('Gesamtspeicher'), value: tr('nicht verfügbar') },
    { label: tr('Freier Speicher'), value: tr('nicht verfügbar') },
    { label: tr('System belegt'), value: tr('nicht verfügbar') },
    { label: tr('Sharkord belegt'), value: tr('nicht verfügbar') }
  ];

  const settingsFooter = <div className="serverSettingsFooter"><span className={`serverSettingsFeedback ${serverSettingsDirty ? 'dirty' : ''}`}>{serverSettingsFeedback}</span><button type="button" className="primaryAction serverSettingsSaveButton" onClick={() => void saveSettings()} disabled={serverSettingsSaving || !serverSettingsDirty}>{serverSettingsSaving ? tr('Speichere…') : tr('Server-Einstellungen speichern')}</button></div>;

  return <section className="settingsCard adminPanel">{adminTab === 'general' ? <><div className="adminPanelHeader"><div><h2>{tr('Übersicht')}</h2></div><button className="adminSecondaryAction" onClick={() => void refreshAdmin()}>{tr('Neu laden')}</button></div><div className="adminDashboard"><span><strong>{categories.length}</strong>{tr('Kategorien')}</span><span><strong>{channels.length}</strong>{tr('Channels')}</span><span><strong>{roles.length}</strong>{tr('Rollen')}</span><span><strong>{adminUsers.length}</strong>{tr('Benutzer')}</span><span><strong>{invites.length}</strong>{tr('Einladungen')}</span><span><strong>{emojis.length}</strong>{tr('Emojis')}</span><span><strong>{plugins.length}</strong>{tr('Plugins')}</span></div></> : null}<div className="adminTabs" role="tablist">{(['general','roles','emojis','storage','users','security','invites','plugins','parity'] as AdminTab[]).map((tab) => <button key={tab} role="tab" aria-selected={adminTab === tab} className={adminTab === tab ? 'selected' : ''} onClick={() => setAdminTab(tab)}>{tabLabels[tab]}</button>)}</div><p className="adminStatus">{adminStatus}</p>
    {adminTab === 'general' ? <div className="adminSettings serverSettingsForm">
      <section className="adminSettingsGroup"><h3>{tr('Server-Informationen')}</h3><input ref={logoInputRef} type="file" accept="image/*" hidden onChange={handleServerLogoUpload} /><article className="parityActionCard serverLogoGeneralCard"><h3><ImageIcon size={16} /> {t('profile.serverLogo')}</h3>{settings.logo ? <img className="serverLogoPreview" src={fileUrl(connection.baseUrl, settings.logo)} alt="" /> : <span className="adminBadge">{tr('Kein Logo gesetzt')}</span>}<div className="settingsButtonRow"><button type="button" className="settingsActionButton primary" onClick={() => logoInputRef.current?.click()} disabled={!connection}>{tr('Server-Logo Upload')}</button><button type="button" className="settingsActionButton danger" onClick={() => void runAdmin(tr('Server-Logo entfernen'), async () => { await changeServerLogo(connection); setSettings(await getServerSettings(connection)); })} disabled={!connection || !settings.logo}>{tr('Logo entfernen')}</button></div></article><div className="serverModeStatus"><span className="adminBadge">{tr('Server-Modus')}: {serverModeLabel}</span><small>{serverModeDescription}</small></div>{showServerCapabilityControls ? <div className="serverUpdatePanel" aria-label={tr('Server-Update')}><div className="updateChangelogHeader"><strong>{tr('Server-Update')}</strong><span>{serverUpdateStatus}</span></div>{connection.serverCapabilities.ownerToken ? <form className="serverTokenForm" onSubmit={submitSecretToken}><label><span>{tr('Server-Owner-Token')}</span><input type="password" value={secretToken} onChange={(event) => setSecretToken(event.target.value)} autoComplete="off" placeholder={tr('Server-Owner-Token')} disabled={serverUpdateBusy} /></label><button type="submit" className="secondary" disabled={serverUpdateBusy || !secretToken.trim()}><KeyRound size={16} />{tr('Token anwenden')}</button></form> : null}{connection.serverCapabilities.serverSelfUpdate ? <div className="updateActions"><button type="button" className="secondary" onClick={() => void checkServerUpdate()} disabled={serverUpdateBusy}><RefreshCw size={16} />{tr('Server-Update prüfen')}</button><button type="button" onClick={() => void runServerUpdate()} disabled={serverUpdateBusy || serverUpdateInfo?.canUpdate === false}><Download size={16} />{tr('Server aktualisieren')}</button></div> : null}{serverUpdateInfo ? <small className="updateAssetLine">{tr('Server')}: {serverUpdateInfo.currentVersion ?? tr('unbekannt')} → {serverUpdateInfo.latestVersion ?? tr('unbekannt')}{serverUpdateInfo.hasUpdate === false ? ` · ${tr('kein Update')}` : ''}</small> : null}</div> : null}<label>{tr('Name')}<input value={settings.name ?? ''} onChange={(event) => updateServerSettings({ name: event.target.value })} maxLength={24} /></label><label>{tr('Beschreibung')}<input value={settings.description ?? ''} onChange={(event) => updateServerSettings({ description: event.target.value })} maxLength={128} /></label><label>{tr('Server-Passwort')}<input type="password" value={settings.password ?? ''} placeholder={tr('Leer lassen für kein Passwort')} onChange={(event) => updateServerSettings({ password: event.target.value || null })} maxLength={32} /></label><label className="checkboxRow"><input type="checkbox" checked={!!settings.onlyAskForPasswordOnFirstJoin} onChange={(event) => updateServerSettings({ onlyAskForPasswordOnFirstJoin: event.target.checked })} />{tr('Nur beim ersten Beitritt nach Passwort fragen')}</label><label className="checkboxRow"><input type="checkbox" checked={!!settings.allowNewUsers} onChange={(event) => updateServerSettings({ allowNewUsers: event.target.checked })} />{tr('Neue Benutzer erlauben')}</label><label className="checkboxRow"><input type="checkbox" checked={!!settings.directMessagesEnabled} onChange={(event) => updateServerSettings({ directMessagesEnabled: event.target.checked })} />{tr('Direktnachrichten erlauben')}</label><label className="checkboxRow"><input type="checkbox" checked={!!settings.enablePlugins} onChange={(event) => updateServerSettings({ enablePlugins: event.target.checked })} />{tr('Plugins aktivieren')}</label><label className="checkboxRow"><input type="checkbox" checked={!!settings.webRtcSimulcastEnabled} onChange={(event) => updateServerSettings({ webRtcSimulcastEnabled: event.target.checked })} />{tr('WebRTC Simulcast aktivieren')}</label><label className="checkboxRow"><input type="checkbox" checked={!!settings.enableSearch} onChange={(event) => updateServerSettings({ enableSearch: event.target.checked })} />{tr('Suche aktivieren')}</label><label className="checkboxRow"><input type="checkbox" checked={!!settings.showWelcomeDialog} onChange={(event) => updateServerSettings({ showWelcomeDialog: event.target.checked })} />{tr('Willkommensdialog anzeigen')}</label></section>
      <section className="adminSection"><div className="adminSectionHeader"><div><h3>{tr('Channel-Verwaltung')}</h3><p>{tr('Kontextmenüs bleiben primär, hier nur kompakte Übersicht.')}</p></div><div className="adminToolbar"><button className="adminPrimaryAction" onClick={addCategory}>+ {tr('Kategorie')}</button><button onClick={() => addChannel('TEXT')}>+ {tr('Text')}</button><button onClick={() => addChannel('VOICE')}>+ {tr('Voice')}</button></div></div><div className="adminList adminChannelList"><div className="adminListTitle">{tr('Kategorien')}</div>{categories.map((category) => <div className="adminListRow" key={category.id}><div className="adminRowMain"><strong>{category.name}</strong><span>{channels.filter((channel) => channel.categoryId === category.id).length} {tr('Channels')}</span></div><div className="adminRowActions"><button onClick={() => renameCategory(category)}>{tr('Umbenennen')}</button><button className="danger" onClick={() => removeCategory(category)}>{tr('Löschen')}</button></div></div>)}<div className="adminListTitle">{tr('Text-Channels')}</div>{textAdminChannels.length ? textAdminChannels.map(renderAdminChannel) : <div className="adminEmptyState">{tr('Keine Text-Channels vorhanden.')}</div>}<div className="adminListTitle">{tr('Voice-Channels')}</div>{voiceAdminChannels.length ? voiceAdminChannels.map(renderAdminChannel) : <div className="adminEmptyState">{tr('Keine Voice-Channels vorhanden.')}</div>}</div></section>
    </div> : null}
    {adminTab === 'storage' ? <div className="adminSettings serverSettingsForm"><section className="adminSettingsGroup"><h3>{tr('Speicher')}</h3><div className="storageOverviewGrid" aria-label={tr('Storage Übersicht')}>{storageOverviewMetrics.map((metric) => <div className="storageOverviewCard" key={metric.label}><span>{metric.label}</span><strong>{metric.value}</strong></div>)}</div><div className="storageUsageBlock"><div><strong>{tr('Speicherbelegung')}</strong><span>{storageUsagePercent}% {tr('verwendet')}</span></div><div className="storageUsageBar"><i style={{ width: `${storageUsagePercent}%` }} /></div></div><label className="checkboxRow"><input type="checkbox" checked={!!settings.storageUploadEnabled} onChange={(event) => updateServerSettings({ storageUploadEnabled: event.target.checked })} />{tr('Uploads erlauben')}</label><label className="checkboxRow"><input type="checkbox" checked={!!settings.storageFileSharingInDirectMessages} onChange={(event) => updateServerSettings({ storageFileSharingInDirectMessages: event.target.checked })} />{tr('Dateien in Direktnachrichten erlauben')}</label><div className="adminSettingsGrid"><label>{tr('Gesamtes Speicherlimit')} <small>{tr('GB, 0 = unbegrenzt')}</small><input type="number" min={0} step={0.001} value={bytesToGbValue(settings.storageQuota)} onChange={(event) => updateServerSettings({ storageQuota: gbInputToBytes(event.target.value) })} /></label><label>{tr('Maximale Dateigröße')} <small>{tr('GB, 0 = unbegrenzt')}</small><input type="number" min={0} step={0.001} value={bytesToGbValue(settings.storageUploadMaxFileSize)} onChange={(event) => updateServerSettings({ storageUploadMaxFileSize: gbInputToBytes(event.target.value) })} /></label><label>{tr('Maximale Avatargröße')} <small>GB</small><input type="number" min={0} step={0.001} value={bytesToGbValue(settings.storageMaxAvatarSize)} onChange={(event) => updateServerSettings({ storageMaxAvatarSize: gbInputToBytes(event.target.value) })} /></label><label>{tr('Maximale Bannergröße')} <small>GB</small><input type="number" min={0} step={0.001} value={bytesToGbValue(settings.storageMaxBannerSize)} onChange={(event) => updateServerSettings({ storageMaxBannerSize: gbInputToBytes(event.target.value) })} /></label><label>{tr('Maximale Dateien pro Nachricht')}<input type="number" min={0} step={1} value={settings.storageMaxFilesPerMessage ?? 0} onChange={(event) => updateServerSettings({ storageMaxFilesPerMessage: Number(event.target.value) })} /></label><label>{tr('Speicherlimit pro Benutzer')} <small>{tr('GB, 0 = unbegrenzt')}</small><input type="number" min={0} step={0.001} value={bytesToGbValue(settings.storageSpaceQuotaByUser)} onChange={(event) => updateServerSettings({ storageSpaceQuotaByUser: gbInputToBytes(event.target.value) })} /></label></div><label>{tr('Aktion bei vollem Speicher')}<select value={settings.storageOverflowAction ?? 'PREVENT_UPLOADS'} onChange={(event) => updateServerSettings({ storageOverflowAction: event.target.value })}><option value="PREVENT_UPLOADS">{tr('Neue Uploads verhindern')}</option><option value="DELETE_OLD_FILES">{tr('Alte Dateien löschen')}</option></select></label><label className="checkboxRow"><input type="checkbox" checked={!!settings.storageSignedUrlsEnabled} onChange={(event) => updateServerSettings({ storageSignedUrlsEnabled: event.target.checked })} />{tr('Signierte URLs aktivieren')}</label><label>{tr('Ablauf signierter URLs / Signed URL TTL')} <small>{tr('Minuten')}</small><input type="number" min={0} step={1} value={ttlSecondsToMinutesValue(settings.storageSignedUrlsTtlSeconds)} onChange={(event) => updateServerSettings({ storageSignedUrlsTtlSeconds: minutesInputToTtlSeconds(event.target.value) })} /></label><div className="adminPresetRow"><button type="button" onClick={() => updateServerSettings({ storageSignedUrlsTtlSeconds: minutesInputToTtlSeconds('1') })}>{tr('1 Minute')}</button><button type="button" onClick={() => updateServerSettings({ storageSignedUrlsTtlSeconds: minutesInputToTtlSeconds('15') })}>{tr('15 Minuten')}</button><button type="button" onClick={() => updateServerSettings({ storageSignedUrlsTtlSeconds: minutesInputToTtlSeconds('60') })}>{tr('60 Minuten')}</button><button type="button" onClick={() => updateServerSettings({ storageSignedUrlsTtlSeconds: minutesInputToTtlSeconds('1440') })}>{tr('24 Stunden')}</button></div><label className="checkboxRow"><input type="checkbox" checked={!!settings.storageImageOptimizationEnabled} onChange={(event) => updateServerSettings({ storageImageOptimizationEnabled: event.target.checked })} />{tr('Bildoptimierung aktivieren')}</label><label className="rangeRow"><span>{tr('Bildqualität')}</span><input type="range" min={1} max={100} value={settings.storageImageOptimizationQuality ?? 80} onChange={(event) => updateServerSettings({ storageImageOptimizationQuality: Number(event.target.value) })} /><strong>{settings.storageImageOptimizationQuality ?? 80}%</strong></label></section>{settingsFooter}</div> : null}

    {adminTab === 'parity' ? <ParitySprintSettings connection={connection} readStates={readStates} externalStreamsMap={externalStreamsMap} pluginCommandsByPlugin={pluginCommandsByPlugin} onStatus={setAdminStatus} /> : null}
    {adminTab === 'general' ? <div className="adminSection"><div className="adminSectionHeader"><div><h3>{tr('Incoming Webhooks')}</h3><p>{connection.serverCapabilities.incomingWebhooks ? tr('Fork-only Webhooks erzeugen externe Nachrichten für Text-Channels.') : tr('Dieser Server unterstützt Incoming Webhooks nicht.')}</p></div><button className="adminSecondaryAction" onClick={() => void (connection.serverCapabilities.incomingWebhooks ? listIncomingWebhooks(connection).then(setWebhooks).catch((err) => setAdminStatus(tr(`Incoming Webhooks laden: ${cleanError(err)}`))) : setAdminStatus(tr('Dieser Server unterstützt Incoming Webhooks nicht.')))}>{tr('Neu laden')}</button></div>{connection.serverCapabilities.incomingWebhooks ? <><form className="settingsInlineForm" onSubmit={createWebhook}><input value={webhookName} onChange={(event) => setWebhookName(event.target.value)} placeholder={tr('Webhook-Name')} maxLength={64} /><select value={webhookChannelId} onChange={(event) => setWebhookChannelId(event.target.value)}>{textChannels.map((channel) => <option key={channel.id} value={channel.id}>#{channel.name}</option>)}</select><button type="submit" className="adminPrimaryAction" disabled={!textChannels.length}>+ {tr('Webhook')}</button></form>{newWebhookToken ? <p className="adminStatus forkSecretLine">{tr('Webhook-Token nur jetzt kopieren')}: <code>{newWebhookToken}</code></p> : null}<div className="adminList">{webhooks.length ? webhooks.map((webhook) => <div className="adminListRow" key={webhook.id}><div className="adminRowMain"><strong>{webhook.name}</strong><span>#{channels.find((channel) => channel.id === webhook.channelId)?.name ?? webhook.channelId} · {tr('zuletzt')}: {formatTimestamp(webhook.lastUsedAt)}</span></div><div className="adminRowActions"><button className="danger" onClick={() => void removeWebhook(webhook.id)}>{tr('Löschen')}</button></div></div>) : <div className="adminEmptyState">{tr('Keine Incoming Webhooks vorhanden.')}</div>}</div></> : <div className="adminEmptyState">{tr('Dieser Server unterstützt Incoming Webhooks nicht.')}</div>}</div> : null}
    {adminTab === 'general' ? <div className="adminSection"><div className="adminSectionHeader"><div><h3>{tr('Retention Policies')}</h3><p>{connection.serverCapabilities.retentionPolicies ? tr('Fork-only Cleanup für alte Nachrichten und verwaiste Medien.') : tr('Dieser Server unterstützt Retention Policies nicht.')}</p></div><div className="adminToolbar"><button onClick={refreshRetention}>{tr('Preview')}</button><button onClick={() => runRetention(true)}>{tr('Trockenlauf')}</button><button className="danger" onClick={() => runRetention(false)}>{tr('Cleanup starten')}</button></div></div>{connection.serverCapabilities.retentionPolicies ? <div className="adminSettings serverSettingsForm"><label className="checkboxRow"><input type="checkbox" checked={!!settings.retentionCleanupEnabled} onChange={(event) => updateServerSettings({ retentionCleanupEnabled: event.target.checked })} />{tr('Retention Cleanup aktivieren')}</label><label>{tr('Nachrichten löschen nach Tagen')}<input type="number" min={0} max={3650} value={settings.messageRetentionDays ?? 0} onChange={(event) => updateServerSettings({ messageRetentionDays: Number(event.target.value) })} /></label><label>{tr('Verwaiste Medien löschen nach Tagen')}<input type="number" min={0} max={3650} value={settings.mediaRetentionDays ?? 0} onChange={(event) => updateServerSettings({ mediaRetentionDays: Number(event.target.value) })} /></label><div className="storageOverviewGrid"><div className="storageOverviewCard"><span>{tr('Nachrichten im Cleanup')}</span><strong>{retentionPreviewState?.messagesToDelete ?? 0}</strong></div><div className="storageOverviewCard"><span>{tr('Dateien im Cleanup')}</span><strong>{retentionPreviewState?.filesToDelete ?? 0}</strong></div></div></div> : <div className="adminEmptyState">{tr('Dieser Server unterstützt Retention Policies nicht.')}</div>}</div> : null}
    {adminTab === 'general' ? settingsFooter : null}
    {adminTab === 'roles' ? <div className="adminSection"><div className="adminSectionHeader"><div><h3>{tr('Rollen')}</h3><p>{tr('Rollen-Berechtigungen, Speicherlimit-Override, Standardrolle und Löschen.')}</p></div><button className="adminPrimaryAction" onClick={addRole}>+ {tr('Rolle erstellen')}</button></div><div className="adminList roleEditorList">{roles.map((role) => <div className="adminListRow roleEditorRow" key={role.id}><div className="adminRowMain"><strong><span className="roleDot" style={{ background: role.color || '#99aab5' }} />{role.name}</strong><span>{role.isDefault ? <span className="adminBadge success">{tr('Standard')}</span> : <span className="adminBadge">{tr('Rolle')}</span>}{role.isPersistent ? <span className="adminBadge">{tr('Persistent')}</span> : null}{dirtyRoleIds.has(role.id) ? <span className="adminBadge warning">{tr('Ungespeichert')}</span> : null}</span><div className="roleInlineEditor"><label>{tr('Name')}<input value={role.name} onChange={(event) => patchRole(role, { name: event.target.value })} /></label><label>{tr('Farbe')}<input type="color" value={role.color || '#99aab5'} onChange={(event) => patchRole(role, { color: event.target.value })} /></label><label className="checkboxRow"><input type="checkbox" checked={!!role.storageQuotaOverrideEnabled} onChange={(event) => patchRole(role, { storageQuotaOverrideEnabled: event.target.checked })} />{tr('Speicherlimit überschreiben')}</label><label className="checkboxRow"><input type="checkbox" checked={!!role.mentionable} onChange={(event) => patchRole(role, { mentionable: event.target.checked })} />{tr('Erwähnbar')}</label><label>{tr('Rollengewichtung')}<small>{tr('0 = oben, größere Zahlen = weiter unten')}</small><input type="number" min={0} step={1} value={normalizeRoleWeight(role.weight, role.id)} onChange={(event) => patchRole(role, { weight: normalizeRoleWeight(event.target.value, role.id) })} /></label><label>{tr('Speicherlimit überschreiben (GB)')}<input type="number" min={0} step={0.001} disabled={!role.storageQuotaOverrideEnabled} value={bytesToGbValue(role.storageSpaceQuota)} onChange={(event) => updateRoleStorageGb(role, event.target.value)} /></label></div><div className="permissionGrid" aria-label={tr('Rollen-Berechtigungen')}>{SERVER_PERMISSION_OPTIONS.map((permission) => { const copy = permissionCopy(permission); return <label key={permission} className="permissionToggle" title={permission}><input type="checkbox" checked={(role.permissions ?? []).includes(permission)} onChange={() => toggleRolePermission(role, permission)} /><span className="permissionToggleText"><strong>{copy.label}</strong><small>{copy.description}</small></span></label>; })}</div></div><div className="adminRowActions"><button onClick={() => editRole(role)}>{tr('Prompt bearbeiten')}</button><button onClick={() => saveRole(role)}>{tr('Speichern')}</button>{role.isDefault ? <span className="adminMutedAction">{tr('Standard')}</span> : <button onClick={() => makeDefaultRole(role)}>{tr('Als Standard')}</button>}<button className="danger" disabled={role.isPersistent || role.isDefault} onClick={() => removeRole(role)}>{tr('Löschen')}</button></div></div>)}</div></div> : null}
    {adminTab === 'emojis' ? <div className="adminSection"><div className="adminSectionHeader"><div><h3>{tr('Emojis')}</h3><p>{tr('Server-Emojis hochladen, umbenennen und löschen.')}</p></div><div><input ref={emojiFileInputRef} type="file" accept="image/*" className="hiddenFileInput" onChange={handleEmojiUpload} /><button className="adminPrimaryAction" onClick={() => emojiFileInputRef.current?.click()}>{tr('Emoji hochladen')}</button></div></div><div className="adminList">{emojis.length ? emojis.map((emoji) => <div className="adminListRow" key={emoji.id}><div className="adminRowMain"><strong>{emoji.file ? <img className="adminEmojiPreview" src={fileUrl(connection.baseUrl, emoji.file)} alt="" /> : null}{emoji.name}</strong><span>{tr('Emoji · Erstellt:')} {formatShortDate(emoji.createdAt)}</span></div><div className="adminRowActions"><button onClick={() => renameEmoji(emoji)}>{tr('Umbenennen')}</button><button className="danger" onClick={() => removeEmoji(emoji)}>{tr('Löschen')}</button></div></div>) : <div className="adminEmptyState">{tr('Keine Emojis vorhanden.')}</div>}</div></div> : null}
    {adminTab === 'users' ? <div className="adminSection"><div className="adminSectionHeader"><div><h3>{tr('Benutzer')}</h3><p>{tr('Suche, Rollen, Status und Moderation wie im Webclient gebündelt.')}</p></div><span className="adminBadge">{filteredAdminUsers.length}/{adminUsers.length} {tr('Benutzer')}</span></div><input className="adminSearch" value={userSearch} onChange={(event) => setUserSearch(event.target.value)} placeholder={tr('Benutzer suchen…')} /><div className="adminList adminUsersList">{filteredAdminUsers.map((user) => <div className="adminListRow adminUserRow" key={user.id}><div className="adminRowMain adminUserMain"><strong>{user.name || user.identity || `User ${user.id}`}</strong><span className="adminUserMeta"><span className={user.banned ? 'adminBadge dangerBadge' : 'adminBadge success'}>{tr('Status')}: {adminAccountStatusLabel(user)}</span><span className="adminBadge">{tr('Erstellt')}: {formatShortDate(user.createdAt)}</span><span className="adminBadge">{tr('Letzter Login')}: {formatShortDate(user.lastLoginAt)}</span></span><div className="adminUserRoles"><strong>{tr('Rollen:')}</strong><div className="roleChipWrap">{roles.map((role) => { const active = (user.roleIds ?? []).includes(role.id); return <button key={role.id} type="button" className={`roleChip ${active ? 'selected' : ''}`} onClick={() => toggleAdminUserRole(user, role)}><span className="roleDot" style={{ background: role.color || '#99aab5' }} />{active ? '✓ ' : ''}{role.name}</button>; })}</div></div></div><div className="adminRowActions adminUserActions"><button onClick={() => void openAdminUserInfo(user)} disabled={adminUserInfoLoading}>{tr('Details')}</button><button onClick={() => moderateAdminUser(user, 'kick')}>{tr('Kick')}</button>{user.banned ? <button onClick={() => moderateAdminUser(user, 'unban')}>{tr('Unban')}</button> : <button onClick={() => moderateAdminUser(user, 'ban')}>{tr('Ban')}</button>}<button className="danger" onClick={() => moderateAdminUser(user, 'delete')}>{tr('Löschen')}</button></div></div>)}</div></div> : null}
    {adminTab === 'security' ? <div className="adminSection"><div className="adminSectionHeader"><div><h3>{tr('IP-Sicherheit')}</h3><p>{connection.serverCapabilities.securityIpRules ? tr('Allowlist, Blocklist, Unblock und Security-Events verwalten. CIDR und Wildcard wie 172.16.0.% werden unterstützt.') : tr('Dieser Server unterstützt IP-Sicherheit nicht.')}</p></div><button className="adminSecondaryAction" onClick={refreshIpSecurity}>{tr('Neu laden')}</button></div>{connection.serverCapabilities.securityIpRules ? <><div className="settingsInlineForm"><input value={ipRuleRange} onChange={(event) => setIpRuleRange(event.target.value)} placeholder="172.16.0.%" aria-label={tr('IP / CIDR / Wildcard')} /><input value={ipRuleReason} onChange={(event) => setIpRuleReason(event.target.value)} placeholder={tr('Grund optional')} aria-label={tr('Grund optional')} /><button className="adminPrimaryAction" onClick={() => createIpRule('allowlist')} disabled={!ipRuleRange.trim()}>{tr('Allowlist')}</button><button className="danger" onClick={() => createIpRule('blocklist')} disabled={!ipRuleRange.trim()}>{tr('Blockieren')}</button></div><div className="adminListTitle">{tr('Allowlist / vertrauenswürdige IPs')}</div><div className="adminList">{allowedIpRules.length ? allowedIpRules.map((rule) => <div className="adminListRow" key={rule.id}><div className="adminRowMain"><strong className="inviteCode">{rule.ipRange}</strong><span><span className="adminBadge success">{tr('Allowlist')}</span><span className="adminBadge">{rule.reason || tr('Kein Grund')}</span><span className="adminBadge">{tr('Erstellt')}: {formatTimestamp(rule.createdAt)}</span><span className="adminBadge">{tr('Läuft ab')}: {formatTimestamp(rule.expiresAt)}</span></span></div><div className="adminRowActions"><button className="danger" onClick={() => void removeIpRule(rule)}>{tr('Entfernen')}</button></div></div>) : <div className="adminEmptyState">{tr('Keine allowlisted IPs.')}</div>}</div><div className="adminListTitle">{tr('Blockierte IPs')}</div><div className="adminList">{blockedIpRules.length ? blockedIpRules.map((rule) => <div className="adminListRow" key={rule.id}><div className="adminRowMain"><strong className="inviteCode">{rule.ipRange}</strong><span><span className="adminBadge dangerBadge">{tr('Blockiert')}</span><span className="adminBadge">{rule.reason || tr('Kein Grund')}</span><span className="adminBadge">{tr('Erstellt')}: {formatTimestamp(rule.createdAt)}</span><span className="adminBadge">{tr('Läuft ab')}: {formatTimestamp(rule.expiresAt)}</span></span></div><div className="adminRowActions"><button onClick={() => void unblockIpRule(rule)}>{tr('Unblock')}</button><button className="danger" onClick={() => void removeIpRule(rule)}>{tr('Entfernen')}</button></div></div>) : <div className="adminEmptyState">{tr('Keine blockierten IPs.')}</div>}</div><div className="adminListTitle">{tr('Security-Events')}</div><div className="adminList">{ipSecurityEvents.length ? ipSecurityEvents.slice(0, 50).map((event) => <div className="adminListRow" key={event.id}><div className="adminRowMain"><strong className="inviteCode">{event.ip}</strong><span><span className="adminBadge">{event.event}</span><span className="adminBadge">{event.identity || tr('anonym')}</span><span className="adminBadge">{event.reason || tr('Kein Grund')}</span><span className="adminBadge">{formatTimestamp(event.createdAt)}</span></span></div></div>) : <div className="adminEmptyState">{tr('Keine Security-Events.')}</div>}</div></> : <div className="adminEmptyState">{tr('Dieser Server unterstützt IP-Sicherheit nicht.')}</div>}</div> : null}
    {adminTab === 'invites' ? <div className="adminSection"><div className="adminSectionHeader"><div><h3>{tr('Einladungen')}</h3><p>{tr('Suchen, Kopieren, Rolle, Ersteller, Nutzungen, Ablauf, Erstellung, Status und Aktionen.')}</p></div><button className="adminPrimaryAction" onClick={addInvite}>+ {tr('Einladung erstellen')}</button></div><input className="adminSearch" value={inviteSearch} onChange={(event) => setInviteSearch(event.target.value)} placeholder={tr('Einladung suchen…')} /><div className="adminList">{filteredInvites.length ? filteredInvites.map((invite) => { const roleName = invite.role?.name ?? roles.find((role) => role.id === invite.roleId)?.name ?? tr('Standard'); const creatorName = invite.creator?.name ?? adminUsers.find((user) => user.id === invite.creatorId)?.name ?? tr('Unbekannt'); return <div className="adminListRow" key={invite.id ?? invite.code}><div className="adminRowMain"><strong className="inviteCode">{invite.code}</strong><span><span className="adminBadge">{tr('Rolle')}: {roleName}</span><span className="adminBadge">{tr('Ersteller')}: {creatorName}</span><span className="adminBadge">{invite.uses ?? 0}/{invite.maxUses ?? '∞'} {tr('Nutzungen')}</span><span className="adminBadge">{tr('Läuft ab')}: {invite.expiresAt ? formatShortDate(invite.expiresAt) : tr('läuft nie ab')}</span><span className="adminBadge">{tr('Erstellt')}: {formatShortDate(invite.createdAt)}</span><span className="adminBadge success">{tr('Status')}: {tr(inviteStatus(invite))}</span></span></div><div className="adminRowActions"><button onClick={() => copyInviteCode(invite)}>{tr('Einladung kopieren')}</button><button className="danger" onClick={() => removeInvite(invite)}>{tr('Löschen')}</button></div></div>; }) : <div className="adminEmptyState">{tr('Keine Einladungen vorhanden.')}</div>}</div></div> : null}
    {adminTab === 'plugins' ? <div className="adminSection pluginWorkbench"><div className="adminSectionHeader"><div><h3>{tr('Plugins')}</h3><p>{tr('Installiert, Marketplace, Logs, Befehle und Einstellungen.')}</p></div><div className="adminSegmentedControl"><button className={`adminSegmentButton ${pluginSubTab === 'installed' ? 'selected' : ''}`} onClick={() => setPluginSubTab('installed')}>{tr('Installiert')}</button><button className={`adminSegmentButton ${pluginSubTab === 'marketplace' ? 'selected' : ''}`} onClick={() => setPluginSubTab('marketplace')}>{tr('Marketplace')}</button></div></div><input className="adminSearch" value={pluginSearch} onChange={(event) => setPluginSearch(event.target.value)} placeholder={tr('Plugin suchen…')} />{pluginSubTab === 'installed' ? <div className="adminList">{plugins.length ? plugins.map((plugin) => <div className="adminListRow pluginRow" key={plugin.id}><div className="adminRowMain"><strong>{plugin.name}</strong><span><span className={plugin.enabled ? 'adminBadge success' : 'adminBadge'}>{plugin.enabled ? tr('Aktiv') : tr('Inaktiv')}</span><span className="adminBadge">v{plugin.version ?? '?'}</span><span className="adminBadge">{plugin.author ?? tr('Unbekannt')}</span>{plugin.loadError ? <span className="adminBadge dangerBadge">{plugin.loadError}</span> : null}</span><p>{plugin.description}</p><section className="pluginSlotAdminSection"><strong>{tr('Slot-Sichtbarkeit')}</strong><div className="pluginSlotList">{(pluginSlotsByPlugin.get(plugin.id) ?? []).length ? (pluginSlotsByPlugin.get(plugin.id) ?? []).map((slotItem) => <span className="adminBadge pluginSlotBadge" key={`${slotItem.pluginId}-${slotItem.slot}-${slotItem.actionName ?? slotItem.label}`}>{slotItem.slot}: {slotItem.label || slotItem.title || slotItem.actionName || tr('Slot')}</span>) : <span className="adminBadge">{tr('Keine Slots')}</span>}</div></section></div><div className="adminRowActions"><button onClick={() => toggleInstalledPlugin(plugin)}>{plugin.enabled ? tr('Deaktivieren') : tr('Aktivieren')}</button><button onClick={() => setAdminStatus(tr(`Logs: ${plugin.name}`))}>{tr('Logs')}</button><button disabled={!plugin.enabled} onClick={() => setAdminStatus(tr(`Befehle: ${plugin.name}`))}>{tr('Befehle')}</button><button disabled={!plugin.enabled} onClick={() => setAdminStatus(tr(`Einstellungen: ${plugin.name}`))}>{tr('Einstellungen')}</button><button className="danger" onClick={() => deleteInstalledPlugin(plugin)}>{tr('Entfernen')}</button></div></div>) : <div className="adminEmptyState">{tr('Keine installierten Plugins oder keine Berechtigung.')}</div>}</div> : <div className="adminList">{filteredMarketplacePlugins.length ? filteredMarketplacePlugins.map((entry) => { const installed = installedPluginIds.has(entry.plugin.id); return <div className="adminListRow pluginRow" key={entry.plugin.id}><div className="adminRowMain"><strong>{entry.plugin.name}</strong><span><span className="adminBadge">v{pluginVersion(entry)}</span><span className="adminBadge">{entry.plugin.author}</span>{entry.plugin.verified ? <span className="adminBadge success">{tr('Verifiziert')}</span> : null}{installed ? <span className="adminBadge success">{tr('Installiert')}</span> : null}</span><p>{entry.plugin.description}</p></div><div className="adminRowActions">{installed ? <button onClick={() => updateInstalledPlugin(entry)}>{tr('Aktualisieren')}</button> : <button onClick={() => installMarketplacePlugin(entry)}>{tr('Installieren')}</button>}</div></div>; }) : <div className="adminEmptyState">{tr('Marketplace leer oder nicht erreichbar.')}</div>}</div>}</div> : null}
    {pendingRoleAction ? <RoleActionDialog action={pendingRoleAction} onCancel={() => setPendingRoleAction(null)} onConfirm={confirmRoleAction} /> : null}
    {adminUserInfo ? <AdminUserInfoModal info={adminUserInfo} baseUrl={connection.baseUrl} onClose={() => setAdminUserInfoState(null)} onDeleteFile={(file) => void deleteAdminUserFile(file)} /> : null}
    {inviteDialogOpen ? <CreateInviteDialog draft={inviteDraft} setDraft={setInviteDraft} roles={roles} status={adminStatus} onCancel={() => setInviteDialogOpen(false)} onSubmit={submitInvite} /> : null}
  </section>;
}

function RoleActionDialog({ action, onCancel, onConfirm }: { action: RoleAction; onCancel: () => void; onConfirm: (action: RoleAction) => void }) {
  const [name, setName] = useState(action.kind === 'edit' ? action.name : action.role.name);
  const [color, setColor] = useState(action.kind === 'edit' ? action.color : action.role.color || '#99aab5');
  const isDelete = action.kind === 'delete';
  const title = isDelete ? tr('Rolle löschen') : tr('Rolle bearbeiten');
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    onConfirm(action.kind === 'edit' ? { ...action, name, color } : action);
  };
  return <div className="modalBackdrop" onMouseDown={onCancel}><form className="confirmDialog adminConfirmDialog" onSubmit={submit} onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={title}>
    <h2>{title}</h2>
    {isDelete ? <p>{tr('Rolle löschen')}: <strong>{action.role.name}</strong>. {tr('Diese Aktion kann nicht über den Desktop rückgängig gemacht werden.')}</p> : <><label className="adminConfirmField">{tr('Rollenname')}<input autoFocus value={name} onChange={(event) => setName(event.target.value)} /></label><label className="adminConfirmField">{tr('Farbe')}<input type="color" value={color || '#99aab5'} onChange={(event) => setColor(event.target.value)} /></label></>}
    <div className="modalActions"><button type="button" className="secondary" onClick={onCancel}>{tr('Abbrechen')}</button><button type="submit" className={isDelete ? 'dangerAction' : 'primaryAction'}>{isDelete ? tr('Rolle löschen') : tr('Speichern')}</button></div>
  </form></div>;
}

function AdminUserInfoModal({ info, baseUrl, onClose, onDeleteFile }: { info: SharkordUserInfo; baseUrl: string; onClose: () => void; onDeleteFile: (file: SharkordFile) => void }) {
  const user = info.user;
  const messages = info.messages ?? [];
  const files = info.files ?? [];
  const links = messages.filter((message) => /https?:\/\//i.test(textFromHtml(message.content)));
  const logins = info.logins ?? [];
  const usedStorageLabel = info.storage ? formatFileSize(info.storage.usedStorage) : '0 B';
  const quotaLabel = info.storage?.quota ? formatFileSize(info.storage.quota) : tr('unbegrenzt');
  const name = displayUserName(user);
  return <div className="modalBackdrop adminUserInfoBackdrop" onMouseDown={onClose}><section className="adminUserInfoModal" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={tr('Benutzerdetails')}>
    <header><div><h2>{name}</h2><p>{user.identity ? `@${user.identity}` : `ID ${user.id}`} · {t('profile.popover.memberSince')} {formatShortDate(user.createdAt)}</p></div><button type="button" onClick={onClose} aria-label={tr('Schließen')}>×</button></header>
    <div className="serverActivityCards">
      <article><Users size={18} /><span>{tr('Logins')}</span><strong>{logins.length}</strong></article>
      <article><Search size={18} /><span>{tr('Nachrichten')}</span><strong>{messages.length}</strong></article>
      <article><HardDrive size={18} /><span>{tr('Dateien')}</span><strong>{files.length}</strong></article>
      <article><AtSign size={18} /><span>{tr('Speicher')}</span><strong>{usedStorageLabel}</strong></article>
    </div>
    <div className="adminUserInfoGrid">
      <section className="adminUserMessages"><h3>{tr('Server-Aktivität / Nachrichten')}</h3>{messages.length ? messages.slice(0, 8).map((message) => <article key={message.id}><strong>#{message.channelId} · {formatTimestamp(message.createdAt)}</strong><p>{textFromHtml(message.content) || tr('Leere Nachricht')}</p></article>) : <p>{tr('Keine Nachrichten gefunden.')}</p>}</section>
      <section className="adminUserFiles"><h3>{tr('Dateien')}</h3>{files.length ? files.slice(0, 8).map((file) => <article key={file.id}><a href={fileUrl(baseUrl, file)} target="_blank" rel="noreferrer">{file.originalName || file.name}</a><span>{formatFileSize(file.size)} · {formatTimestamp(file.createdAt)}</span><button type="button" className="danger" onClick={() => onDeleteFile(file)}>{tr('Löschen')}</button></article>) : <p>{tr('Keine Dateien gefunden.')}</p>}</section>
      <section className="adminUserLinks"><h3>{tr('Links')}</h3>{links.length ? links.slice(0, 6).map((message) => <article key={message.id}><strong>{formatTimestamp(message.createdAt)}</strong><p>{textFromHtml(message.content)}</p></article>) : <p>{tr('Keine Links gefunden.')}</p>}</section>
      <section className="adminUserStorage"><h3>{tr('Speicher')}</h3><p>{tr('Dateien')}: {info.storage?.fileCount ?? files.length}</p><p>{tr('Verwendet')}: {usedStorageLabel}</p><p>{tr('Kontingent')}: {quotaLabel}</p></section>
    </div>
  </section></div>;
}

function AdminContextMenu({ menu, usersById, roles, connection, voiceMap, categories, activeServer, userVolumes, setUserVolume, setMenu, setStatus, refreshRoles, openServerSettings, createServerChannel, createServerCategory, createServerInvite, editContextChannel, deleteContextChannel, copyContextChannelLink, openChannelLinkTarget, openVoiceTextChat, editContextCategory, deleteContextCategory, moderateContextUser, disconnectContextVoiceUser, stopContextUserVoiceMedia, toggleUserRole }: { menu: ContextMenuState; usersById: Map<number, SharkordUser>; roles: SharkordRole[]; connection: SharkordConnection | null; voiceMap: VoiceMap; categories: SharkordCategory[]; activeServer: SharkordServer | null; userVolumes: UserVolumeSettings; setUserVolume: (serverId: string, remoteId: number, volume: number) => void; setMenu: (menu: ContextMenuState) => void; setStatus: (value: string) => void; refreshRoles: () => void; openServerSettings: () => void; createServerChannel: (type?: 'TEXT' | 'VOICE') => void; createServerCategory: () => void; createServerInvite: () => void; editContextChannel: (channel: SharkordChannel) => void; deleteContextChannel: (channel: SharkordChannel) => void; copyContextChannelLink: (channel: SharkordChannel) => void; openChannelLinkTarget: (channel: SharkordChannel) => void; openVoiceTextChat: (channel: SharkordChannel) => void; editContextCategory: (category: SharkordCategory) => void; deleteContextCategory: (category: SharkordCategory, channelCount: number) => void; moderateContextUser: (user: SharkordUser, action: 'kick' | 'ban' | 'unban' | 'delete') => void; disconnectContextVoiceUser: (user: SharkordUser) => void; stopContextUserVoiceMedia: (user: SharkordUser, kind: 'video' | 'screen' | 'screen_audio') => void; toggleUserRole: (user: SharkordUser, role: SharkordRole) => void }) {
  useEffect(() => {
    if (!menu) return undefined;
    const close = () => setMenu(null);
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') setMenu(null); };
    const timer = window.setTimeout(() => {
      window.addEventListener('click', close);
      window.addEventListener('keydown', closeOnEscape);
    }, 0);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('click', close);
      window.removeEventListener('keydown', closeOnEscape);
    };
  }, [menu, setMenu]);
  if (!menu) return null;
  const currentMenuUser = menu?.kind === 'user' ? usersById.get(menu.user.id) ?? menu.user : null;
  const contextMenuMargin = 12;
  const contextMenuWidth = menu.kind === 'user' ? 300 : 240;
  const contextMenuHeight = menu.kind === 'user' ? 420 : 280;
  const style = {
    left: Math.max(contextMenuMargin, Math.min(menu.x, window.innerWidth - contextMenuWidth - contextMenuMargin)),
    top: Math.max(contextMenuMargin, Math.min(menu.y, window.innerHeight - contextMenuHeight - contextMenuMargin)),
    maxHeight: 'calc(100vh - 24px)',
    overflowY: 'auto'
  } as React.CSSProperties;
  const menuVoiceState = menu.kind === 'user' && currentMenuUser ? Object.values(voiceMap).map(normalizeVoiceChannelState).find((state) => !!state.users?.[currentMenuUser.id])?.users?.[currentMenuUser.id] : undefined;
  const userInVoice = !!menuVoiceState;
  const canManageTargetVoice = userInVoice && !!connection && !!currentMenuUser && currentMenuUser.id !== connection.join.ownUserId;
  return <div className="discordContextMenu adminContextMenu" style={style} onClick={(event) => event.stopPropagation()} onContextMenu={(event) => event.stopPropagation()}>
    {menu.kind === 'channel' ? <><strong>#{menu.channel.name}</strong>{connection?.serverCapabilities.channelLinks ? <><button onClick={() => void copyContextChannelLink(menu.channel)}>{tr('Channel-Link kopieren')}</button><button onClick={() => void openChannelLinkTarget(menu.channel)}>{tr('Channel-Link öffnen')}</button><div className="contextMenuDivider" /></> : null}{isVoiceChannel(menu.channel) && connection?.serverCapabilities.voiceTextChatCoupling ? <button onClick={() => void openVoiceTextChat(menu.channel)}>{tr('Textchat öffnen')}</button> : null}<button onClick={() => void editContextChannel(menu.channel)}>{tr('Channel bearbeiten')}</button><button className="danger" onClick={() => void deleteContextChannel(menu.channel)}>{tr('Channel löschen')}</button></> : null}
    {menu.kind === 'category' ? <><strong>{menu.category.name}</strong><button onClick={() => void editContextCategory(menu.category)}>{tr('Kategorie bearbeiten')}</button><button className="danger" onClick={() => void deleteContextCategory(menu.category, menu.channelCount)}>{tr('Kategorie löschen')}</button><small>{menu.channelCount} {tr('Channels enthalten')}</small></> : null}
    {menu.kind === 'user' && currentMenuUser ? <><strong>{currentMenuUser.name || currentMenuUser.identity || `User ${currentMenuUser.id}`}</strong>{activeServer && userInVoice ? <div className="userVolumeControl"><div><small>{tr('Benutzerlautstärke')}</small><strong>{userVolumes[userVolumeKey(activeServer.id, currentMenuUser.id)] ?? 100}%</strong></div><input className="userVolumeSlider" type="range" min={0} max={200} step={1} value={userVolumes[userVolumeKey(activeServer.id, currentMenuUser.id)] ?? 100} onChange={(event) => setUserVolume(activeServer.id, currentMenuUser.id, Number(event.target.value))} /></div> : null}<div className="contextMenuDivider" />{connection?.serverCapabilities.voiceUserMediaModeration && canManageTargetVoice && menuVoiceState?.webcamEnabled ? <button className="danger" onClick={() => stopContextUserVoiceMedia(currentMenuUser, 'video')}>{tr('Webcam stoppen')}</button> : null}{connection?.serverCapabilities.voiceUserMediaModeration && canManageTargetVoice && menuVoiceState?.sharingScreen ? <button className="danger" onClick={() => stopContextUserVoiceMedia(currentMenuUser, 'screen')}>{tr('Screenshare stoppen')}</button> : null}{connection?.serverCapabilities.voiceUserDisconnect && canManageTargetVoice ? <button className="danger" onClick={() => disconnectContextVoiceUser(currentMenuUser)}><PhoneOff size={14} />{tr('Aus Voice trennen')}</button> : null}<button onClick={() => moderateContextUser(currentMenuUser, 'kick')}>{tr('Kick')}</button><button onClick={() => moderateContextUser(currentMenuUser, 'ban')}>{tr('Ban')}</button><button onClick={() => moderateContextUser(currentMenuUser, 'unban')}>{tr('Unban')}</button><button className="danger" onClick={() => moderateContextUser(currentMenuUser, 'delete')}>{tr('User löschen')}</button><div className="contextMenuDivider" /><small>{tr('Rollen')}</small>{roles.length ? roles.map((role) => { const active = (currentMenuUser.roleIds ?? []).includes(role.id); return <button key={role.id} className={`roleMenuItem ${active ? 'selected' : ''}`} onClick={() => toggleUserRole(currentMenuUser, role)}><span className="roleDot" style={{ background: role.color || '#99aab5' }} />{active ? '✓ ' : ''}{role.name}</button>; }) : <button onClick={() => refreshRoles()}>{tr('Rollen laden')}</button>}</> : null}
  </div>;
}


type InviteDraft = { code: string; maxUses: string; expiresAt: string; roleId: string };
function createInviteDraft(): InviteDraft {
  return { code: randomInviteCode(), maxUses: '0', expiresAt: '', roleId: 'default' };
}
function randomInviteCode(): string {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let code = '';
  const cryptoObj = typeof crypto !== 'undefined' ? crypto : undefined;
  const bytes = cryptoObj?.getRandomValues ? cryptoObj.getRandomValues(new Uint8Array(24)) : null;
  for (let i = 0; i < 24; i += 1) code += alphabet[(bytes ? bytes[i] : Math.floor(Math.random() * alphabet.length)) % alphabet.length];
  return code;
}
function CreateInviteDialog({ draft, setDraft, roles, status, onCancel, onSubmit }: { draft: InviteDraft; setDraft: (draft: InviteDraft) => void; roles: SharkordRole[]; status: string; onCancel: () => void; onSubmit: (event: FormEvent<HTMLFormElement>) => void }) {
  return <div className="modalBackdrop" onMouseDown={onCancel}><form className="inviteCreateDialog" onSubmit={onSubmit} onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={tr('Server-Invite erstellen')}><div className="inviteCreateHeader"><div><h2>{tr('Server-Invite erstellen')}</h2><p>{tr('Erstelle einen neuen Einladungslink, damit Benutzer dem Server beitreten können.')}</p></div><button type="button" onClick={onCancel} aria-label={tr('Schließen')}>×</button></div><label>{tr('Code')}<input autoFocus value={draft.code} onChange={(event) => setDraft({ ...draft, code: event.target.value })} minLength={4} maxLength={64} /></label><label>{tr('Maximale Nutzungen')}<small>{tr('0 bedeutet unbegrenzt.')}</small><input type="number" min={0} max={100} step={1} value={draft.maxUses} onChange={(event) => setDraft({ ...draft, maxUses: event.target.value })} /></label><label>{tr('Läuft ab')}<small>{tr('Leer lassen für kein Ablaufdatum.')}</small><input type="date" value={draft.expiresAt} onChange={(event) => setDraft({ ...draft, expiresAt: event.target.value })} /></label><label>{tr('Rolle zuweisen')}<small>{tr('Beitretende Benutzer erhalten diese Rolle.')}</small><select value={draft.roleId} onChange={(event) => setDraft({ ...draft, roleId: event.target.value })}><option value="default">{tr('Standard')}</option>{roles.map((role) => <option key={role.id} value={role.id}>{role.name}</option>)}</select></label><p className="adminStatus">{status}</p><div className="inviteCreateActions"><button type="button" className="secondary" onClick={onCancel}>{tr('Abbrechen')}</button><button type="submit" className="primaryAction">{tr('Invite erstellen')}</button></div></form></div>;
}

function AdminWorkbenchModal({ children, onClose }: { children: ReactNode; onClose: () => void }) {
  return <div className="modalBackdrop adminWorkbenchBackdrop" onMouseDown={onClose}><div className="adminWorkbenchModal" onMouseDown={(event) => event.stopPropagation()}><div className="adminWorkbenchModalHeader"><strong>{tr('Server-Einstellungen')}</strong><button type="button" onClick={onClose} aria-label={tr('Server-Einstellungen schließen')}>×</button></div>{children}</div></div>;
}


function ConfirmDirectMessageDeleteDialog({ entry, status, onCancel, onConfirm }: { entry: DirectMessageEntry; status: string; onCancel: () => void; onConfirm: () => void }) {
  const label = displayUserName(entry.user);
  return <div className="modalBackdrop" onMouseDown={onCancel}><div className="confirmDialog" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={tr('Direktnachricht wirklich ausblenden')}><h2>{tr('Direktnachricht wirklich ausblenden?')}</h2><p>{tr('Die Direktnachricht mit')} <strong>{label}</strong> {tr('wird aus deiner Liste ausgeblendet. Nachrichten bleiben auf dem Server; die Unterhaltung erscheint wieder bei einer neuen Gegen-Nachricht.')}</p><p className="adminStatus">{tr(status)}</p><div className="modalActions"><button type="button" className="secondary" onClick={onCancel}>{tr('Abbrechen')}</button><button type="button" className="dangerAction" onClick={onConfirm}>{tr('Direktnachricht ausblenden')}</button></div></div></div>;
}

function UnsupportedDirectMessageDeleteDialog({ entry, onClose }: { entry: DirectMessageEntry; onClose: () => void }) {
  const label = displayUserName(entry.user);
  return <div className="modalBackdrop" onMouseDown={onClose}><div className="confirmDialog" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={tr('Direktnachricht ausblenden nicht unterstützt')}><h2>{tr('Direktnachricht ausblenden nicht unterstützt')}</h2><p>{tr('Diese Funktion wird von diesem Server nicht unterstützt.')} <strong>{entry.server.name}</strong> {tr('kann die Direktnachricht mit')} <strong>{label}</strong> {tr('nicht über die Desktop-App aus der Liste ausblenden.')}</p><div className="modalActions"><button type="button" className="primaryAction" onClick={onClose}>{tr('OK')}</button></div></div></div>;
}

function AdminActionConfirmDialog({ action, onCancel, onConfirm }: { action: AdminConfirmAction; onCancel: () => void; onConfirm: (action: AdminConfirmAction) => void }) {
  const [reason, setReason] = useState(action.kind === 'moderate-user' ? action.reason : '');
  const [wipe, setWipe] = useState(action.kind === 'moderate-user' ? action.wipe : false);
  const userLabel = displayUserName(action.user);
  const isModeration = action.kind === 'moderate-user';
  const title = action.kind === 'disconnect-voice-user'
    ? tr('Voice-Verbindung trennen?')
    : action.action === 'delete'
      ? tr('Benutzer wirklich löschen?')
      : tr(`Benutzer ${action.action}?`);
  const body = action.kind === 'disconnect-voice-user'
    ? tr('Der Benutzer wird aus dem aktuellen Voice-Channel getrennt. Er kann später erneut beitreten, wenn Berechtigungen passen.')
    : action.action === 'unban'
      ? tr('Der Benutzer wird entbannt und kann wieder beitreten.')
      : tr('Diese Moderationsaktion wird direkt auf dem Server ausgeführt.');
  const nextAction = isModeration ? { ...action, reason, wipe } : action;
  return <div className="modalBackdrop" onMouseDown={onCancel}><div className="confirmDialog adminConfirmDialog" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={title}>
    <h2>{title}</h2>
    <p><strong>{userLabel}</strong> · {body}</p>
    {isModeration && action.action !== 'unban' ? <label className="adminConfirmField">{tr('Grund optional')}<textarea value={reason} onChange={(event) => setReason(event.target.value)} rows={3} placeholder={tr('Grund für Audit/Moderation')} autoFocus /></label> : null}
    {isModeration && action.action === 'delete' ? <label className="checkboxRow adminConfirmCheck"><input type="checkbox" checked={wipe} onChange={(event) => setWipe(event.target.checked)} />{tr('Benutzer-Daten endgültig löschen (Wipe)')}</label> : null}
    <div className="modalActions"><button type="button" className="secondary" onClick={onCancel}>{tr('Abbrechen')}</button><button type="button" className="dangerAction" onClick={() => onConfirm(nextAction)}>{action.kind === 'disconnect-voice-user' ? tr('Voice trennen') : tr('Bestätigen')}</button></div>
  </div></div>;
}

function ConfirmChannelDeleteDialog({ channel, status, onCancel, onConfirm }: { channel: SharkordChannel; status: string; onCancel: () => void; onConfirm: () => void }) {
  return <div className="modalBackdrop" onMouseDown={onCancel}><div className="confirmDialog" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={tr('Channel wirklich löschen')}><h2>{tr('Channel wirklich löschen?')}</h2><p>#{channel.name} {tr('wird gelöscht. Diese Aktion kann nicht über den Desktop rückgängig gemacht werden.')}</p><p className="adminStatus">{tr(status)}</p><div className="modalActions"><button type="button" className="secondary" onClick={onCancel}>{tr('Abbrechen')}</button><button type="button" className="dangerAction" onClick={onConfirm}>{tr('Channel löschen')}</button></div></div></div>;
}
function ConfirmServerRemovalDialog({ server, status, onCancel, onConfirm }: { server: SharkordServer; status: string; onCancel: () => void; onConfirm: () => void }) {
  return <div className="modalBackdrop" onMouseDown={onCancel}><div className="confirmDialog" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={tr('Server wirklich entfernen')}><h2>{tr('Server wirklich entfernen?')}</h2><p><strong>{server.name}</strong> {tr('wird aus dieser Desktop-App entfernt. Der Server selbst und seine Daten bleiben online.')}</p><p className="adminStatus">{tr(status)}</p><div className="modalActions"><button type="button" className="secondary" onClick={onCancel}>{tr('Abbrechen')}</button><button type="button" className="dangerAction" onClick={onConfirm}>{tr('Server entfernen')}</button></div></div></div>;
}
function ConfirmCategoryDeleteDialog({ category, channelCount, status, onCancel, onConfirm }: { category: SharkordCategory; channelCount: number; status: string; onCancel: () => void; onConfirm: () => void }) {
  return <div className="modalBackdrop" onMouseDown={onCancel}><div className="confirmDialog" onMouseDown={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-label={tr('Kategorie wirklich löschen')}><h2>{tr('Kategorie wirklich löschen?')}</h2><p>{tr('Diese Kategorie und alle enthaltenen Channels werden gelöscht:')} <strong>{category.name}</strong>{channelCount ? ` · ${channelCount} Channels` : ''}. {tr('Diese Aktion kann nicht über den Desktop rückgängig gemacht werden.')}</p><p className="adminStatus">{tr(status)}</p><div className="modalActions"><button type="button" className="secondary" onClick={onCancel}>{tr('Abbrechen')}</button><button type="button" className="dangerAction" onClick={onConfirm}>{tr('Kategorie löschen')}</button></div></div></div>;
}

function AddServerModal({ name, setName, url, setUrl, autoConnectChecked, setAutoConnectChecked, newCreds, setNewCreds, error, onClose, onSubmit }: { name: string; setName: (value: string) => void; url: string; setUrl: (value: string) => void; autoConnectChecked: boolean; setAutoConnectChecked: (value: boolean) => void; newCreds: AuthState; setNewCreds: (value: AuthState) => void; error: string; onClose: () => void; onSubmit: (event: FormEvent<HTMLFormElement>) => void }) {
  return <div className="modalBackdrop" onMouseDown={onClose}><form className="serverModal" onSubmit={onSubmit} onMouseDown={(event) => event.stopPropagation()} noValidate>
    <h2>{tr('Sharkord-Server hinzufügen')}</h2>
    <label>{tr('Anzeigename')}<input autoFocus value={name} onChange={(event) => setName(event.target.value)} placeholder={tr('Mein Sharkord')} /></label>
    <label>{tr('Server-URL')}<input value={url} onChange={(event) => setUrl(event.target.value)} placeholder="https://sharkord.example.tld" />{error ? <span className="formError inlineFormError">{error}</span> : null}</label>
    <label className="checkboxRow"><input type="checkbox" checked={autoConnectChecked} onChange={(event) => setAutoConnectChecked(event.target.checked)} />{tr('Verbindung automatisch herstellen, wenn gespeicherte Credentials vorhanden sind')}</label>
    <div className="modalDivider">{tr('Login verschlüsselt speichern')}</div>
    <label>Identity<input value={newCreds.identity} onChange={(event) => setNewCreds({ ...newCreds, identity: event.target.value })} autoComplete="username" /></label>
    <label>{tr('Passwort')}<input type="password" value={newCreds.password} onChange={(event) => setNewCreds({ ...newCreds, password: event.target.value })} autoComplete="current-password" /></label>
    <label>{tr('Invite-Code optional')}<input value={newCreds.invite} onChange={(event) => setNewCreds({ ...newCreds, invite: normalizeInviteInput(event.target.value) || event.target.value })} placeholder={tr('Invite-Code oder Invite-Link')} autoComplete="off" /></label>
    <label>{tr('Server-Passwort optional')}<input type="password" value={newCreds.serverPassword} onChange={(event) => setNewCreds({ ...newCreds, serverPassword: event.target.value })} /></label>
    <div className="modalActions"><button type="button" className="secondary" onClick={onClose}>{tr('Abbrechen')}</button><button type="submit">{tr('Hinzufügen')}</button></div>
  </form></div>;
}

function reorderIds(ids: number[], sourceId: number, targetId: number): number[] {
  const next = ids.filter((id) => id !== sourceId);
  const targetIndex = next.indexOf(targetId);
  if (targetIndex === -1) return ids;
  next.splice(targetIndex, 0, sourceId);
  return next;
}

function buildChannelGroups(channels: SharkordChannel[], categories: SharkordCategory[]): ChannelGroup[] {
  const groups = categories.map((category) => ({ id: category.id, name: category.name, channels: [] as SharkordChannel[] }));
  const byId = new Map(groups.map((group) => [group.id, group]));
  const uncategorized: ChannelGroup = { id: null, name: 'CHANNELS', channels: [] };
  for (const channel of [...channels].sort(byPosition)) {
    if (channel.categoryId != null && byId.has(channel.categoryId)) byId.get(channel.categoryId)?.channels.push(channel);
    else uncategorized.channels.push(channel);
  }
  const ordered = groups.map((group) => ({ ...group, channels: group.channels.sort(byPosition) }));
  return uncategorized.channels.length ? [uncategorized, ...ordered] : ordered;
}
function buildVoiceUsersByChannelId(voiceMap: VoiceMap, usersById: Map<number, SharkordUser>): Map<number, VoiceUser[]> {
  const result = new Map<number, VoiceUser[]>();
  Object.entries(voiceMap).forEach(([channelId, voiceState]) => {
    const channelUsers = Object.entries(normalizeVoiceChannelState(voiceState).users).map(([userId, state]) => {
      const user = usersById.get(Number(userId));
      return user && !isDeletedUserPlaceholder(user) ? { ...user, state: normalizeVoiceState(state) } : null;
    }).filter((user): user is VoiceUser => !!user);
    result.set(Number(channelId), channelUsers.sort((a, b) => (a.name || '').localeCompare(b.name || '')));
  });
  return result;
}
function findVoiceChannelIdForUser(voiceMap: VoiceMap, userId: number): number | null {
  const entry = Object.entries(voiceMap).find(([, state]) => !!normalizeVoiceChannelState(state).users?.[userId]);
  return entry ? Number(entry[0]) : null;
}
function upsertById<T extends { id: number }>(setter: React.Dispatch<React.SetStateAction<T[]>>, item: T) { setter((current) => [...current.filter((entry) => entry.id !== item.id), item]); }
function upsertListById<T extends { id: number }>(items: T[], item: T): T[] { return [...items.filter((entry) => entry.id !== item.id), item]; }
function markUserOnline(user: SharkordUser): SharkordUser { return { ...user, status: 'online' }; }
function mergeUserPreservingPresence(existing: SharkordUser, incoming: SharkordUser): SharkordUser {
  const incomingStatus = String(incoming.status ?? '').trim().toLowerCase();
  const preserveExistingStatus = memberPresenceStatus(existing) !== 'offline' && (!incomingStatus || incomingStatus === 'offline');
  return { ...existing, ...incoming, status: preserveExistingStatus ? existing.status : incoming.status ?? existing.status };
}
function upsertUserListPreservingPresence(items: SharkordUser[], incoming: SharkordUser): SharkordUser[] {
  const existing = items.find((item) => item.id === incoming.id);
  const nextUser = existing ? mergeUserPreservingPresence(existing, incoming) : incoming;
  return [...items.filter((entry) => entry.id !== incoming.id), nextUser];
}
function updateReplyCountInMessages(messages: SharkordMessage[], messageId: number, replyCount: number): SharkordMessage[] { return messages.map((message) => message.id === messageId ? { ...message, replyCount } : message.parentMessage?.id === messageId ? { ...message, parentMessage: { ...message.parentMessage, replyCount } } : message); }
function channelIdFromPermissionsEvent(payload: unknown): number | null {
  if (!payload || typeof payload !== 'object') return null;
  const record = payload as Record<string, unknown>;
  const direct = Number(record.channelId ?? record.id);
  if (Number.isFinite(direct) && direct > 0) return direct;
  const numericKey = Object.keys(record).find((key) => /^\d+$/.test(key));
  return numericKey ? Number(numericKey) : null;
}
type ServerCredentialsWithInvite = ServerCredentials & { invite?: string; appPassword?: string };
function memberPresenceStatus(user: SharkordUser, ownUserId?: number): string {
  const status = String(user.status ?? '').trim().toLowerCase();
  if (status) return status === 'offline' ? 'offline' : status;
  return user.id === ownUserId ? 'online' : 'offline';
}
function adminAccountStatusLabel(user: SharkordUser): string { return user.banned ? tr('Gebannt') : tr('Aktiv'); }
function normalizeRoleWeight(value: unknown, roleId?: number): number {
  const numeric = Number(value);
  if (Number.isFinite(numeric) && numeric >= 0) return Math.round(numeric);
  return roleId === 1 ? 0 : 100;
}

function normalizeRoleForSave(role: SharkordRole): SharkordRole {
  return {
    ...role,
    name: role.name.trim() || role.name,
    color: role.color || '#99aab5',
    permissions: role.permissions ?? [],
    storageSpaceQuota: Number(role.storageSpaceQuota ?? 0),
    weight: normalizeRoleWeight(role.weight, role.id)
  };
}

function roleSortWeight(role: SharkordRole | undefined): number {
  if (!role) return 900;
  if (role.id === 1) return 0;
  const weight = Number(role.weight);
  return Number.isFinite(weight) && weight >= 0 ? weight : role.isDefault ? 100 : 100;
}
function singleMemberGroup(users: SharkordUser[]): { key: string; title: string; weight: number; users: SharkordUser[] } {
  return { key: 'members', title: 'Members', weight: 0, users: [...users].sort((a, b) => displayUserName(a).localeCompare(displayUserName(b), undefined, { sensitivity: 'base' })) };
}
function groupMembersByAssignedRole(users: SharkordUser[], roles: SharkordRole[]): Array<{ key: string; title: string; weight: number; users: SharkordUser[] }> {
  if (!users.length) return [];
  if (!roles.length) return [singleMemberGroup(users)];
  const sortedRoles = [...roles].sort((a, b) => roleSortWeight(a) - roleSortWeight(b) || (a.isDefault === b.isDefault ? a.name.localeCompare(b.name) : a.isDefault ? 1 : -1));
  const roleById = new Map(sortedRoles.map((role) => [role.id, role]));
  const defaultRole = sortedRoles.find((role) => role.isDefault);
  const hasAnyKnownRoleAssignment = users.some((user) => (user.roleIds ?? []).some((id) => roleById.has(id)));
  if (!defaultRole && !hasAnyKnownRoleAssignment) return [singleMemberGroup(users)];
  const buckets = new Map<string, { key: string; title: string; weight: number; users: SharkordUser[] }>();
  for (const user of users) {
    const assigned = (user.roleIds ?? []).map((id) => roleById.get(id)).filter((role): role is SharkordRole => !!role && !role.isDefault).sort((a, b) => roleSortWeight(a) - roleSortWeight(b) || a.name.localeCompare(b.name))[0] ?? defaultRole;
    const key = assigned ? `role:${assigned.id}` : 'role:none';
    const title = assigned?.name ?? tr('Ohne Rolle');
    if (!buckets.has(key)) buckets.set(key, { key, title, weight: roleSortWeight(assigned), users: [] });
    buckets.get(key)?.users.push(user);
  }
  return [...buckets.values()].map((group) => ({ ...group, users: group.users.sort((a, b) => displayUserName(a).localeCompare(displayUserName(b), undefined, { sensitivity: 'base' })) })).sort((a, b) => a.weight - b.weight || a.title.localeCompare(b.title));
}
function groupMembersByPresenceAndRole(users: SharkordUser[], roles: SharkordRole[], ownUserId?: number): Array<{ key: string; title: string; weight: number; presenceRank: number; users: SharkordUser[] }> {
  const onlineUsers = users.filter((user) => memberPresenceStatus(user, ownUserId) !== 'offline');
  const offlineUsers = users.filter((user) => memberPresenceStatus(user, ownUserId) === 'offline');
  const onlineGroups = groupMembersByAssignedRole(onlineUsers, roles).map((group) => ({
    ...group,
    key: `online:${group.key}`,
    title: `${tr('Online')} — ${group.title}`,
    presenceRank: 0
  }));
  const offlineGroup = offlineUsers.length ? [{
    key: 'offline',
    title: tr('Offline'),
    weight: 0,
    presenceRank: 1,
    users: offlineUsers
  }] : [];
  return [...onlineGroups, ...offlineGroup].sort((a, b) => a.presenceRank - b.presenceRank || a.weight - b.weight || a.title.localeCompare(b.title));
}
function credsToAuth(creds: ServerCredentials): AuthState { const stored = creds as ServerCredentialsWithInvite; return { identity: creds.identity || '', password: creds.password || '', totpCode: '', appPassword: stored.appPassword || '', serverPassword: creds.serverPassword || '', invite: stored.invite || '' }; }
function authToCreds(auth: AuthState): ServerCredentials { return { identity: auth.identity, password: auth.password, appPassword: auth.appPassword, serverPassword: auth.serverPassword, invite: normalizeInviteInput(auth.invite) } as ServerCredentialsWithInvite; }
function displayUserName(user?: SharkordUser | null): string { return user?.name || user?.identity || (user?.id ? `User ${user.id}` : 'User'); }
function groupPluginSlots(rows: SharkordPluginSlotRender[]): PluginSlotMap {
  const grouped = emptyPluginSlots();
  for (const item of rows) {
    if (PLUGIN_SLOT_IDS.includes(item.slot) && item.enabled !== false) grouped[item.slot].push(item);
  }
  for (const slot of PLUGIN_SLOT_IDS) grouped[slot].sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || (a.label || a.title || a.actionName || '').localeCompare(b.label || b.title || b.actionName || ''));
  return grouped;
}
function cleanError(err: unknown): string { const raw = err instanceof Error ? err.message : String(err); return tr(raw.replace(/^Error:\s*/, '')); }
function isTotpRequiredError(message: string): boolean { return /totp|two-factor|2fa|two factor|mfa|one-time|one time|authenticator/i.test(message); }
function isAuthenticationError(message: string): boolean { return /must be authenticated|unauthorized|unauthenticated|not authenticated|nicht authentifiziert|nicht angemeldet/i.test(message); }
function formatReleaseChangelog(changelog?: string): string {
  const raw = changelog?.trim() ?? '';
  if (!raw) return tr('Kein Changelog im Release.');
  const withoutInternalSections = raw.replace(/\n##\s*(Verification|Verifikation|QA|Tests?|Build)[\s\S]*$/i, '').trim();
  const withoutInternalBullets = withoutInternalSections
    .split('\n')
    .filter((line) => !/^[-*]\s*(Frontend tests?|Frontend production build|npm audit|Go tests?|Linux and Windows artifacts|macOS Apple Silicon artifact|SHA256 checks?|Stable and Beta update feeds|Source commit|Build host)\b/i.test(line.trim()))
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  return withoutInternalBullets || tr('Kein Changelog im Release.');
}
function formatFileSize(bytes?: number): string {
  const value = Number(bytes ?? 0);
  if (!Number.isFinite(value) || value <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const index = Math.min(units.length - 1, Math.floor(Math.log(value) / Math.log(1024)));
  return `${(value / (1024 ** index)).toFixed(index === 0 ? 0 : 1)} ${units[index]}`;
}
function formatTimestamp(value?: number | null): string {
  if (!value) return tr('Unbekannt');
  const ms = value > 1_000_000_000_000 ? value : value * 1000;
  return new Date(ms).toLocaleString(getLocale() === 'en' ? 'en-US' : 'de-DE', { dateStyle: 'short', timeStyle: 'short' });
}
function isRateLimitError(message: string): boolean { return message.includes('Too many requests') || message.includes('TOO_MANY_REQUESTS'); }
