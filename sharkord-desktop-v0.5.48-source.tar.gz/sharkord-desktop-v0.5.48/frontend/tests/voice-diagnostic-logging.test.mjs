import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFileSync } from 'node:fs';

const appSource = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const liveDebugSource = readFileSync(new URL('../src/liveDebug.ts', import.meta.url), 'utf8');
const clientSource = readFileSync(new URL('../src/sharkordClient.ts', import.meta.url), 'utf8');

test('desktop voice diagnostics keeps local redacted log support behind global opt-in setting', () => {
  assert.doesNotMatch(appSource, /const emitLiveDebug = \(_event: string, _data: Record<string, unknown> = \{}, _level = 'info', _message = ''\) => undefined/);
  assert.match(liveDebugSource, /AppendDiagnosticLog/);
  assert.match(liveDebugSource, /GetDiagnosticLogInfo/);
  assert.match(appSource, /voice\.diagnostics\.ready/);
  assert.match(appSource, /voice\.diagnostics\.writeFailed/);
  assert.match(appSource, /diagnosticLoggingEnabled: false/);
  assert.match(appSource, /if \(!uiSettings\.diagnosticLoggingEnabled\) return/);
  assert.match(appSource, /checked=\{uiSettings\.diagnosticLoggingEnabled\}/);
  assert.match(appSource, /updateUiSetting\(\{ diagnosticLoggingEnabled: event\.target\.checked \}\)/);
  assert.match(appSource, /Lokale Diagnose-Logs schreiben/);
});

test('desktop voice diagnostics records realtime boundary events around remote users and producers', () => {
  for (const eventName of [
    'voice.realtime.join',
    'voice.realtime.leave',
    'voice.realtime.updateState',
    'voice.realtime.newProducer',
    'voice.realtime.producerClosed',
    'voice.render.snapshot'
  ]) {
    assert.match(appSource, new RegExp(eventName.replaceAll('.', '\\.'), 'g'));
  }
});

test('diagnostic logging never records auth fields or message bodies from the frontend', () => {
  assert.doesNotMatch(appSource, /emitLiveDebug\([^\n]*message\.content/);
  assert.doesNotMatch(appSource, /emitLiveDebug\([^\n]*(password|serverPassword|appPassword|token|authorization)/i);
  assert.doesNotMatch(clientSource, /diagnostic.*password/i);
});
