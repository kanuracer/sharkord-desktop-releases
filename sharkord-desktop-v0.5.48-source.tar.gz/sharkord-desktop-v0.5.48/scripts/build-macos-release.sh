#!/usr/bin/env bash
set -euo pipefail

VERSION="${1:-${SHARKORD_VERSION:-0.5.48}}"
OUTDIR="${2:-$HOME}"
ARCH="${SHARKORD_ARCH:-arm64}"
APP_NAME="Sharkord Desktop"
BUNDLE_ID="eu.kanuracer.sharkord-desktop"
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$HOME/go/bin"

WORK="${WORK:-$HOME/sharkord-desktop-macos-build-v${VERSION}}"
ARCHIVE="${ARCHIVE:-$HOME/sharkord-desktop-v${VERSION}.tar.gz}"
APP="${APP:-$OUTDIR/sharkord-desktop-${VERSION}-darwin-${ARCH}.app}"
ASSET="${ASSET:-$OUTDIR/sharkord-desktop-${VERSION}-darwin-${ARCH}.zip}"

rm -rf "$WORK" "$APP" "$ASSET"
mkdir -p "$WORK" "$OUTDIR"
tar -xzf "$ARCHIVE" -C "$WORK" --strip-components 1
cd "$WORK"

npm --prefix frontend install
npm --prefix frontend test
wails3 generate bindings -ts ./...
npm --prefix frontend run build
go test -buildvcs=false ./...
go build -buildvcs=false ./...
wails3 generate icons -input build/appicon.png -macfilename build/darwin/icons.icns

mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
go build -tags production -trimpath -buildvcs=false -ldflags="-w -s -X main.appVersion=${VERSION}" -o "$APP/Contents/MacOS/sharkord-desktop"
cp build/darwin/icons.icns "$APP/Contents/Resources/Sharkord.icns"
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleExecutable</key><string>sharkord-desktop</string>
  <key>CFBundleIdentifier</key><string>${BUNDLE_ID}</string>
  <key>CFBundleName</key><string>${APP_NAME}</string>
  <key>CFBundleDisplayName</key><string>${APP_NAME}</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>${VERSION}</string>
  <key>CFBundleVersion</key><string>${VERSION}</string>
  <key>CFBundleIconFile</key><string>Sharkord</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSMicrophoneUsageDescription</key><string>Sharkord Desktop needs microphone access for voice chat.</string>
  <key>NSCameraUsageDescription</key><string>Sharkord Desktop needs camera access for video in voice chat.</string>
  <key>NSScreenCaptureUsageDescription</key><string>Sharkord Desktop needs screen recording access for screen sharing.</string>
</dict>
</plist>
PLIST

/usr/libexec/PlistBuddy -c 'Print :NSMicrophoneUsageDescription' "$APP/Contents/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c 'Print :NSCameraUsageDescription' "$APP/Contents/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c 'Print :NSScreenCaptureUsageDescription' "$APP/Contents/Info.plist" >/dev/null
codesign --force --deep --sign - "$APP"
codesign --verify --deep --strict "$APP"
/usr/bin/ditto -c -k --keepParent "$APP" "$ASSET"
sha256sum "$ASSET"
file "$APP/Contents/MacOS/sharkord-desktop"
/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$APP/Contents/Info.plist"
echo MACOS_RELEASE_OK VERSION=$VERSION ARCH=$ARCH
