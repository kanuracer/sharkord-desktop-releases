import { createTRPCProxyClient, createWSClient, wsLink } from '@trpc/client';
import { tr } from './i18n';
import type { ChannelPermissionOverride, ChannelPermissionTarget, DirectMessageConversation, JoinServerResult, MessagePage, NativeSharkordSession, PluginSlotId, SharkordCategory, SharkordChannel, SharkordEmoji, SharkordExternalStream, GlobalSearchFilePage, GlobalSearchMessagePage, SharkordFile, SharkordInvite, SharkordMarketplaceEntry, SharkordMessage, SharkordOfficialPluginSlotId, SharkordPluginCommand, SharkordPluginInfo, SharkordPluginLog, SharkordPluginMetadata, SharkordPluginSetting, SharkordPluginSlotRender, SharkordReadState, SharkordRole, SharkordServerInfo, SharkordServerSettings, SharkordStorageSettingsResponse, SharkordTempFile, SharkordUser, SharkordUserInfo, StreamQualitySetting, ThreadInboxResponse, VoiceProducerEvent, VoiceState } from './sharkordTypes';

type TrpcAny = any;
type Unsubscribable = { unsubscribe: () => void };

export type SharkordServerFlavor = 'original' | 'kanuracer' | 'unknown';

export type SharkordServerCapabilities = {
  flavor: SharkordServerFlavor;
  directMessageDelete: boolean;
  directMessageHide: boolean;
  ownerToken: boolean;
  serverSelfUpdate: boolean;
  voiceUserMove: boolean;
  voiceUserDisconnect: boolean;
  voiceUserMediaModeration: boolean;
  channelCrossCategoryMove: boolean;
  incomingWebhooks: boolean;
  retentionPolicies: boolean;
  messageEditAttachments: boolean;
  roleMentions: boolean;
  roleMentionFanout: boolean;
  threadInbox: boolean;
  mfaAppPasswords: boolean;
  mfaReauthHardening: boolean;
  oidcLogin: boolean;
  voiceDeviceHotSwap: boolean;
  webRtcAnnouncedAddress: boolean;
  voiceReactions: boolean;
  voiceTextChatCoupling: boolean;
  customEmojiReactionIds: boolean;
  voiceSoundboard: boolean;
  voiceMediaRecovery: boolean;
  channelLinks: boolean;
  directMessagePinning: boolean;
  channelAccessMembers: boolean;
  customUserStatus: boolean;
  notificationSoundControls: boolean;
  securityIpRules: boolean;
};

export type SharkordConnection = NativeSharkordSession & {
  trpc: TrpcAny;
  serverCapabilities: SharkordServerCapabilities;
  appPassword?: string;
  close: () => void;
  getFreshToken: () => Promise<string>;
};

const TOKEN_REFRESH_AFTER_MS = 8 * 60 * 1000;

export const DEFAULT_ORIGINAL_SERVER_CAPABILITIES: SharkordServerCapabilities = {
  flavor: 'original',
  directMessageDelete: false,
  directMessageHide: false,
  ownerToken: true,
  serverSelfUpdate: true,
  voiceUserMove: false,
  voiceUserDisconnect: false,
  voiceUserMediaModeration: false,
  channelCrossCategoryMove: false,
  incomingWebhooks: false,
  retentionPolicies: false,
  messageEditAttachments: false,
  roleMentions: false,
  roleMentionFanout: false,
  threadInbox: false,
  mfaAppPasswords: false,
  mfaReauthHardening: false,
  oidcLogin: false,
  voiceDeviceHotSwap: false,
  webRtcAnnouncedAddress: false,
  voiceReactions: false,
  voiceTextChatCoupling: false,
  customEmojiReactionIds: false,
  voiceSoundboard: false,
  voiceMediaRecovery: false,
  channelLinks: false,
  directMessagePinning: false,
  channelAccessMembers: false,
  customUserStatus: false,
  notificationSoundControls: false,
  securityIpRules: false
};

export type GetChannelMessagesOptions = { parentMessageId?: number | null };
export type SendChannelMessageOptions = { parentMessageId?: number | null; contentHtml?: string };
export type SharkordServerUpdateInfo = { hasUpdate?: boolean; latestVersion?: string | null; currentVersion?: string | null; canUpdate?: boolean; [key: string]: unknown };

export type LoginInput = {
  serverUrl: string;
  identity: string;
  password: string;
  totpCode?: string;
  appPassword?: string;
  invite?: string;
  serverPassword?: string;
};

export type AppPasswordSummary = {
  id: number;
  name: string;
  createdAt: number;
  lastUsedAt: number | null;
  revokedAt: number | null;
};

export type MfaStatus = { enabled: boolean; recoveryCodesRemaining?: number };
export type TotpSetupResponse = { secret: string; otpauthUrl: string; recoveryCodes?: string[] };
export type IncomingWebhookSummary = { id: number; name: string; channelId: number; createdAt: number; updatedAt?: number | null; lastUsedAt?: number | null };
export type IncomingWebhookCreateResult = { webhook: IncomingWebhookSummary; token: string };
export type RetentionPreview = { enabled: boolean; messageRetentionDays: number; mediaRetentionDays: number; messagesToDelete: number; filesToDelete: number };
export type RetentionRunResult = RetentionPreview & { dryRun: boolean; messagesDeleted: number; filesDeleted: number };
export type SharkordIpSecurityRule = { id: number; kind: 'allowlist' | 'blocklist' | 'allow' | 'block' | string; ipRange: string; reason?: string | null; expiresAt?: number | null; createdBy?: number | null; createdAt?: number };
type SharkordIpSecurityRulesResponse = SharkordIpSecurityRule[] | { allowed?: SharkordIpSecurityRule[]; blocked?: SharkordIpSecurityRule[] };
export type SharkordIpSecurityEvent = { id: number; ip: string; identity?: string | null; event: string; reason?: string | null; metadata?: unknown; createdAt?: number };
export type OidcLoginProvider = { id: string; name: string; issuer: string; clientId: string; authorizationEndpoint: string; scopes: string[] };
export type OidcLoginConfig = { enabled: boolean; providers: OidcLoginProvider[] };

type LoginResult = { token: string; appPassword?: string; appPasswordId?: number };

export type CoreEventHandlers = {
  onVoiceJoin?: (event: { channelId: number; userId: number; state: VoiceState }) => void;
  onVoiceLeave?: (event: { channelId: number; userId: number }) => void;
  onVoiceUpdateState?: (event: { channelId: number; userId: number; state: Partial<VoiceState> }) => void;
  onVoiceNewProducer?: (event: VoiceProducerEvent) => void;
  onVoiceProducerClosed?: (event: VoiceProducerEvent) => void;
  onVoiceAddExternalStream?: (event: { channelId: number; streamId: number; stream: SharkordExternalStream }) => void;
  onVoiceUpdateExternalStream?: (event: { channelId: number; streamId: number; stream: SharkordExternalStream }) => void;
  onVoiceRemoveExternalStream?: (event: { channelId: number; streamId: number }) => void;
  onVoiceReaction?: (event: { channelId: number; userId: number; emoji: string; file?: SharkordFile | null; expiresAt: number }) => void;
  onVoiceSoundboard?: (event: { channelId: number; userId: number; soundId: DesktopSoundboardId; createdAt: number }) => void;
  onMessageNew?: (message: SharkordMessage) => void;
  onMessageUpdate?: (message: SharkordMessage) => void;
  onMessageDelete?: (event: { channelId: number; messageId: number }) => void;
  onMessageTyping?: (event: { channelId: number; userId: number; parentMessageId?: number }) => void;
  onThreadReplyCountUpdate?: (event: { channelId: number; messageId: number; replyCount: number }) => void;
  onDmConversationOpen?: (event: { channelId: number }) => void;
  onUserJoin?: (user: SharkordUser) => void;
  onUserLeave?: (userId: number) => void;
  onUserCreate?: (user: SharkordUser) => void;
  onUserUpdate?: (user: SharkordUser) => void;
  onUserDelete?: (event: { isWipe: boolean; userId: number; deletedUserId: number }) => void;
  onChannelCreate?: (channel: SharkordChannel) => void;
  onChannelUpdate?: (channel: SharkordChannel) => void;
  onChannelDelete?: (channelId: number) => void;
  onChannelPermissionsUpdate?: (event: unknown) => void;
  onReadStateUpdate?: (event: SharkordReadState) => void;
  onReadStateDelta?: (event: SharkordReadState) => void;
  onPluginLog?: (event: SharkordPluginLog) => void;
  onPluginCommandsChange?: (commands: Record<string, SharkordPluginCommand[]>) => void;
  onPluginComponentsChange?: (pluginIds: string[]) => void;
  onPluginMetadataChange?: (metadata: SharkordPluginMetadata[]) => void;
  onRoleCreate?: (role: SharkordRole) => void;
  onRoleUpdate?: (role: SharkordRole) => void;
  onRoleDelete?: (roleId: number) => void;
  onEmojiCreate?: (emoji: SharkordEmoji) => void;
  onEmojiUpdate?: (emoji: SharkordEmoji) => void;
  onEmojiDelete?: (emojiId: number) => void;
  onServerSettingsUpdate?: (settings: Partial<SharkordServerSettings>) => void;
  onCategoryCreate?: (category: SharkordCategory) => void;
  onCategoryUpdate?: (category: SharkordCategory) => void;
  onCategoryDelete?: (categoryId: number) => void;
  onError?: (label: string, error: unknown) => void;
};

export type DesktopSoundType =
  | 'message_received'
  | 'message_sent'
  | 'server_connected'
  | 'server_disconnected'
  | 'own_user_joined_voice_channel'
  | 'own_user_left_voice_channel'
  | 'own_user_muted_mic'
  | 'own_user_unmuted_mic'
  | 'own_user_muted_sound'
  | 'own_user_unmuted_sound'
  | 'remote_user_joined_voice_channel'
  | 'remote_user_left_voice_channel'
  | 'soundboard_pop'
  | 'soundboard_airhorn'
  | 'soundboard_rimshot'
  | 'soundboard_tada'
  | 'soundboard_bonk';
export type DesktopSoundboardId = 'pop' | 'airhorn' | 'rimshot' | 'tada' | 'bonk';

let audioCtx: AudioContext | null = null;

export const DELETED_USER_IDENTITY_AND_NAME = '__deleted_user__';

export function isDeletedUserPlaceholder(user?: Pick<SharkordUser, 'name' | 'identity'> | null): boolean {
  return user?.name === DELETED_USER_IDENTITY_AND_NAME || user?.identity === DELETED_USER_IDENTITY_AND_NAME;
}

function cleanClientError(error: unknown): string {
  return error instanceof Error ? error.message.replace(/^Error:\s*/, '') : String(error);
}

function isMissingTrpcProcedureError(error: unknown, path: string): boolean {
  const message = cleanClientError(error);
  const commaPath = path.replace('.', ',');
  return message.includes(`No "query"-procedure on path "${path}"`)
    || message.includes(`No "mutation"-procedure on path "${path}"`)
    || message.includes(`No procedure found on path "${path}"`)
    || message.includes(`No "query"-procedure on path "${commaPath}"`)
    || message.includes(`No "mutation"-procedure on path "${commaPath}"`)
    || message.includes(`No procedure found on path "${commaPath}"`);
}

function copyOriginalServerCapabilities(): SharkordServerCapabilities {
  return { ...DEFAULT_ORIGINAL_SERVER_CAPABILITIES };
}

function normalizeServerFlavor(value: unknown): SharkordServerFlavor {
  return value === 'original' || value === 'kanuracer' || value === 'unknown' ? value : 'unknown';
}

function capabilityEnabled(...values: unknown[]): boolean {
  return values.some((value) => value === true);
}

function normalizeIpSecurityRule(rule: SharkordIpSecurityRule): SharkordIpSecurityRule {
  if (rule.kind === 'allow') return { ...rule, kind: 'allowlist' };
  if (rule.kind === 'block') return { ...rule, kind: 'blocklist' };
  return rule;
}

function normalizeIpSecurityRulesResponse(raw: SharkordIpSecurityRulesResponse): SharkordIpSecurityRule[] {
  const rules = Array.isArray(raw) ? raw : [...(raw.allowed ?? []), ...(raw.blocked ?? [])];
  return rules.map(normalizeIpSecurityRule);
}

async function probeIpSecurityCapability(trpc: any): Promise<boolean> {
  try {
    await trpc.security.getIpRules.query();
    return true;
  } catch (error) {
    return !isMissingTrpcProcedureError(error, 'security.getIpRules')
      && !isMissingTrpcProcedureError(error, 'security,getIpRules')
      && cleanClientError(error).toLowerCase().includes('forbidden');
  }
}

export function parseCustomEmojiReactionValue(value: string): { id: number; name: string } | null {
  const match = value.match(/^custom:(\d+):([a-zA-Z0-9_-]{1,64})$/);
  if (!match) return null;
  const id = Number(match[1]);
  return Number.isInteger(id) && id > 0 ? { id, name: match[2]! } : null;
}

export function customEmojiReactionName(value: string): string {
  return parseCustomEmojiReactionValue(value)?.name ?? value;
}

export function customEmojiReactionValue(emoji: string | { id?: number; customId?: number; name?: string; shortcodes?: string[]; emoji?: string }): string {
  if (typeof emoji === 'string') return emoji;
  const customId = Number(emoji.customId ?? emoji.id);
  const name = (emoji.name || emoji.shortcodes?.[0] || '').trim();
  if (Number.isInteger(customId) && customId > 0 && name) return `custom:${customId}:${name}`;
  return emoji.emoji || emoji.shortcodes?.[0] || name;
}

function normalizeServerCapabilities(raw: unknown): SharkordServerCapabilities {
  if (!raw || typeof raw !== 'object') return { ...copyOriginalServerCapabilities(), flavor: 'unknown' };
  const payload = raw as Record<string, unknown>;
  const nested = payload.capabilities && typeof payload.capabilities === 'object' && !Array.isArray(payload.capabilities)
    ? payload.capabilities as Record<string, unknown>
    : payload;
  const flavor = normalizeServerFlavor(payload.flavor ?? payload.serverFlavor ?? nested.flavor);
  return {
    flavor,
    directMessageDelete: capabilityEnabled(nested.directMessageDelete, nested.dmDelete, nested.directMessagesDelete),
    directMessageHide: capabilityEnabled(nested.directMessageHide, nested.dmHide, nested.hideDirectMessage),
    ownerToken: capabilityEnabled(nested.ownerToken, nested.serverOwnerToken),
    serverSelfUpdate: capabilityEnabled(nested.serverSelfUpdate, nested.selfUpdate, nested.serverUpdate),
    voiceUserMove: capabilityEnabled(nested.voiceUserMove, nested.voiceMoveUser, nested.moveVoiceUser),
    voiceUserDisconnect: capabilityEnabled(nested.voiceUserDisconnect, nested.voiceDisconnectUser, nested.disconnectVoiceUser),
    voiceUserMediaModeration: capabilityEnabled(nested.voiceUserMediaModeration, nested.voiceMediaModeration, nested.stopUserVoiceMedia),
    channelCrossCategoryMove: capabilityEnabled(nested.channelCrossCategoryMove, nested.channelCrossCategoryReorder, nested.crossCategoryChannelMove, nested.crossCategoryChannelReorder),
    incomingWebhooks: capabilityEnabled(nested.incomingWebhooks, nested.webhooks, nested.incomingWebhook),
    retentionPolicies: capabilityEnabled(nested.retentionPolicies, nested.messageRetention, nested.mediaRetention),
    messageEditAttachments: capabilityEnabled(nested.messageEditAttachments, nested.editMessageAttachments, nested.messageAttachmentEdit),
    roleMentions: capabilityEnabled(nested.roleMentions, nested.roleMentionSuggestions, nested.roleMention),
    roleMentionFanout: capabilityEnabled(nested.roleMentionFanout, nested.roleMentionNotifications, nested.mentionFanout),
    threadInbox: capabilityEnabled(nested.threadInbox, nested.threadUnreadAggregation, nested.threadAggregation),
    mfaAppPasswords: flavor === 'kanuracer' || capabilityEnabled(nested.mfaAppPasswords, nested.accountSecurity, nested.totp, nested.totpMfa, nested.appPasswords),
    mfaReauthHardening: capabilityEnabled(nested.mfaReauthHardening, nested.mfaHardening, nested.accountSecurityAudit),
    oidcLogin: capabilityEnabled(nested.oidcLogin, nested.ssoLogin, nested.oidc),
    voiceDeviceHotSwap: capabilityEnabled(nested.voiceDeviceHotSwap, nested.voiceHotSwap, nested.deviceHotSwap),
    webRtcAnnouncedAddress: capabilityEnabled(nested.webRtcAnnouncedAddress, nested.webrtcAnnouncedAddress, nested.voiceAnnouncedAddress),
    voiceReactions: capabilityEnabled(nested.voiceReactions, nested.voiceReaction, nested.voiceEmojiReactions),
    voiceTextChatCoupling: capabilityEnabled(nested.voiceTextChatCoupling, nested.voiceTextChat, nested.voiceChatCoupling),
    customEmojiReactionIds: capabilityEnabled(nested.customEmojiReactionIds, nested.customEmojiReactionId, nested.customReactionIds),
    voiceSoundboard: capabilityEnabled(nested.voiceSoundboard, nested.soundboard, nested.voiceSoundBoard),
    voiceMediaRecovery: capabilityEnabled(nested.voiceMediaRecovery, nested.voiceRecovery, nested.mediaRecovery),
    channelLinks: capabilityEnabled(nested.channelLinks, nested.channelDeepLinks, nested.deepLinks),
    directMessagePinning: capabilityEnabled(nested.directMessagePinning, nested.dmPinning, nested.pinDirectMessages),
    channelAccessMembers: capabilityEnabled(nested.channelAccessMembers, nested.accessibleMembers, nested.channelMemberAccess),
    customUserStatus: capabilityEnabled(nested.customUserStatus, nested.customStatus, nested.userStatusMessage),
    notificationSoundControls: capabilityEnabled(nested.notificationSoundControls, nested.notificationSounds, nested.muteNotificationSounds),
    securityIpRules: capabilityEnabled(nested.securityIpRules, nested.ipSecurityRules, nested.ipAllowlist)
  };
}

export async function detectServerCapabilities(trpc: any): Promise<SharkordServerCapabilities> {
  try {
    const capabilities = normalizeServerCapabilities(await trpc.desktop.capabilities.query());
    if (!capabilities.securityIpRules && await probeIpSecurityCapability(trpc)) {
      return { ...capabilities, securityIpRules: true };
    }
    return capabilities;
  } catch (error) {
    const fallback = isMissingTrpcProcedureError(error, 'desktop.capabilities')
      ? copyOriginalServerCapabilities()
      : { ...copyOriginalServerCapabilities(), flavor: 'unknown' as const };
    return await probeIpSecurityCapability(trpc)
      ? { ...fallback, securityIpRules: true }
      : fallback;
  }
}

export function normalizeServerUrl(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) throw new Error(tr('Server-URL fehlt'));
  const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  const parsed = new URL(withProtocol);
  parsed.hash = '';
  parsed.search = '';
  return parsed.toString().replace(/\/$/, '');
}

export function hostFromServerUrl(serverUrl: string): string {
  return new URL(normalizeServerUrl(serverUrl)).host;
}

export function websocketUrlFromServerUrl(serverUrl: string): string {
  const parsed = new URL(normalizeServerUrl(serverUrl));
  return `${parsed.protocol === 'https:' ? 'wss' : 'ws'}://${parsed.host}`;
}

export function normalizeInviteInput(raw?: string | null): string {
  const trimmed = String(raw ?? '').trim();
  if (!trimmed) return '';

  const parseCandidate = (value: string): URL | null => {
    try { return new URL(value); }
    catch {
      if (/^[\w.-]+\.[a-z]{2,}(?:[/:?#]|$)/i.test(value)) {
        try { return new URL(`https://${value}`); }
        catch { return null; }
      }
      return null;
    }
  };

  const parsed = parseCandidate(trimmed);
  if (parsed) {
    const queryInvite = parsed.searchParams.get('invite') || parsed.searchParams.get('code');
    if (queryInvite) return decodeURIComponent(queryInvite).trim();

    if (parsed.protocol === 'sharkord:' && parsed.hostname.toLowerCase() === 'invite') {
      return decodeURIComponent(parsed.pathname.split('/').filter(Boolean)[0] ?? '').trim();
    }

    const parts = parsed.pathname.split('/').filter(Boolean);
    const inviteIndex = parts.findIndex((part) => ['invite', 'invites', 'join'].includes(part.toLowerCase()));
    if (inviteIndex >= 0 && parts[inviteIndex + 1]) return decodeURIComponent(parts[inviteIndex + 1]).trim();
    return '';
  }

  return trimmed.replace(/^#/, '');
}

export async function fetchServerInfo(serverUrl: string): Promise<SharkordServerInfo> {
  const baseUrl = normalizeServerUrl(serverUrl);
  const response = await fetch(`${baseUrl}/info`);
  if (!response.ok) throw new Error(tr(`Server-Info fehlgeschlagen (${response.status})`));
  return response.json() as Promise<SharkordServerInfo>;
}


export async function fetchOidcLoginConfig(serverUrl: string): Promise<OidcLoginConfig> {
  const baseUrl = normalizeServerUrl(serverUrl);
  const response = await fetch(`${baseUrl}/auth/oidc/config`);
  if (response.status === 404) return { enabled: false, providers: [] };
  if (!response.ok) throw new Error(tr(`OIDC-Konfiguration fehlgeschlagen (${response.status})`));
  const data = await response.json().catch(() => ({}));
  return { enabled: data?.enabled === true, providers: Array.isArray(data?.providers) ? data.providers : [] };
}

export function buildOidcAuthorizationUrl(serverUrl: string, provider: OidcLoginProvider, redirectUri: string, state: string): string {
  const url = new URL(provider.authorizationEndpoint);
  url.searchParams.set('client_id', provider.clientId);
  url.searchParams.set('redirect_uri', redirectUri);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope', (provider.scopes?.length ? provider.scopes : ['openid', 'profile', 'email']).join(' '));
  url.searchParams.set('state', state || hostFromServerUrl(serverUrl));
  return url.toString();
}

export async function loginWithOidcCode(serverUrl: string, provider: string, code: string, redirectUri: string): Promise<LoginResult> {
  const baseUrl = normalizeServerUrl(serverUrl);
  const response = await fetch(`${baseUrl}/login/oidc`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ provider, code, redirectUri })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const errors = data?.errors ? Object.values(data.errors).join(', ') : '';
    throw new Error(errors || data?.error || tr(`OIDC Login fehlgeschlagen (${response.status})`));
  }
  if (!data?.token) throw new Error(tr('OIDC Login-Antwort enthält keinen Token'));
  return { token: data.token as string };
}

async function login(input: LoginInput): Promise<LoginResult> {
  const baseUrl = normalizeServerUrl(input.serverUrl);
  const invite = normalizeInviteInput(input.invite);
  const response = await fetch(`${baseUrl}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identity: input.identity, password: input.password, totpCode: input.totpCode || undefined, appPassword: input.appPassword || undefined, rememberDevice: !!input.totpCode, deviceName: 'Sharkord Desktop', invite: invite || undefined })
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const errors = data?.errors ? Object.values(data.errors).join(', ') : '';
    throw new Error(errors || data?.error || tr(`Login fehlgeschlagen (${response.status})`));
  }
  if (!data?.token) throw new Error(tr('Login-Antwort enthält keinen Token'));
  return { token: data.token as string, appPassword: data.appPassword as string | undefined, appPasswordId: data.appPasswordId as number | undefined };
}

async function connectWithToken(input: LoginInput, loginResult: LoginResult, refreshToken?: () => Promise<string>): Promise<SharkordConnection> {
  const baseUrl = normalizeServerUrl(input.serverUrl);
  let token = loginResult.token;
  const websocketToken = token;
  let tokenIssuedAt = Date.now();

  async function refreshAuthTokenIfStale(force = false): Promise<string> {
    if (!refreshToken) return token;
    if (!force && Date.now() - tokenIssuedAt < TOKEN_REFRESH_AFTER_MS) return token;
    token = await refreshToken();
    tokenIssuedAt = Date.now();
    return token;
  }

  const wsClient = createWSClient({
    url: websocketUrlFromServerUrl(baseUrl),
    connectionParams: () => ({ token: websocketToken }),
    keepAlive: { enabled: true, intervalMs: 30_000, pongTimeoutMs: 5_000 }
  });
  const trpc = createTRPCProxyClient<TrpcAny>({ links: [wsLink({ client: wsClient })] }) as any;

  try {
    const handshake = await trpc.others.handshake.query();
    if (handshake.hasPassword && !input.serverPassword) {
      throw new Error(tr('Server-Passwort nötig'));
    }
    const join = await trpc.others.joinServer.query({
      handshakeHash: handshake.handshakeHash,
      password: input.serverPassword || undefined
    }) as JoinServerResult;
    return {
      baseUrl,
      get token() { return token; },
      join,
      trpc,
      appPassword: loginResult.appPassword,
      serverCapabilities: await detectServerCapabilities(trpc),
      close: () => wsClient.close(),
      getFreshToken: () => refreshAuthTokenIfStale()
    };
  } catch (error) {
    wsClient.close();
    throw error;
  }
}

export async function loginAndJoin(input: LoginInput): Promise<SharkordConnection> {
  const baseUrl = normalizeServerUrl(input.serverUrl);
  const loginInput: LoginInput = { ...input, serverUrl: baseUrl };
  const loginResult = await login(loginInput);
  if (loginResult.appPassword) {
    loginInput.appPassword = loginResult.appPassword;
    loginInput.totpCode = undefined;
  }
  return connectWithToken(loginInput, loginResult, async () => (await login(loginInput)).token);
}

export async function loginWithOidcCodeAndJoin(input: { serverUrl: string; provider: string; code: string; redirectUri: string; serverPassword?: string }): Promise<SharkordConnection> {
  const baseUrl = normalizeServerUrl(input.serverUrl);
  const loginResult = await loginWithOidcCode(baseUrl, input.provider, input.code, input.redirectUri);
  return connectWithToken({ serverUrl: baseUrl, identity: '', password: '', serverPassword: input.serverPassword ?? '' }, loginResult);
}

export function subscribeToCoreEvents(connection: SharkordConnection, handlers: CoreEventHandlers): () => void {
  const sub = (label: string, factory: () => Unsubscribable): Unsubscribable | null => {
    try { return factory(); } catch (error) { handlers.onError?.(label, error); return null; }
  };
  const subs = [
    sub('voice.onJoin', () => connection.trpc.voice.onJoin.subscribe(undefined, { onData: handlers.onVoiceJoin, onError: (error: unknown) => handlers.onError?.('voice.onJoin', error) })),
    sub('voice.onLeave', () => connection.trpc.voice.onLeave.subscribe(undefined, { onData: handlers.onVoiceLeave, onError: (error: unknown) => handlers.onError?.('voice.onLeave', error) })),
    sub('voice.onUpdateState', () => connection.trpc.voice.onUpdateState.subscribe(undefined, { onData: handlers.onVoiceUpdateState, onError: (error: unknown) => handlers.onError?.('voice.onUpdateState', error) })),
    sub('voice.onNewProducer', () => connection.trpc.voice.onNewProducer.subscribe(undefined, { onData: handlers.onVoiceNewProducer, onError: (error: unknown) => handlers.onError?.('voice.onNewProducer', error) })),
    sub('voice.onProducerClosed', () => connection.trpc.voice.onProducerClosed.subscribe(undefined, { onData: handlers.onVoiceProducerClosed, onError: (error: unknown) => handlers.onError?.('voice.onProducerClosed', error) })),
    sub('voice.onAddExternalStream', () => connection.trpc.voice.onAddExternalStream.subscribe(undefined, { onData: handlers.onVoiceAddExternalStream, onError: (error: unknown) => handlers.onError?.('voice.onAddExternalStream', error) })),
    sub('voice.onUpdateExternalStream', () => connection.trpc.voice.onUpdateExternalStream.subscribe(undefined, { onData: handlers.onVoiceUpdateExternalStream, onError: (error: unknown) => handlers.onError?.('voice.onUpdateExternalStream', error) })),
    sub('voice.onRemoveExternalStream', () => connection.trpc.voice.onRemoveExternalStream.subscribe(undefined, { onData: handlers.onVoiceRemoveExternalStream, onError: (error: unknown) => handlers.onError?.('voice.onRemoveExternalStream', error) })),
    ...(connection.serverCapabilities.voiceReactions ? [sub('voice.onReaction', () => connection.trpc.voice.onReaction.subscribe(undefined, { onData: handlers.onVoiceReaction, onError: (error: unknown) => handlers.onError?.('voice.onReaction', error) }))] : []),
    ...(connection.serverCapabilities.voiceSoundboard ? [sub('voice.onSoundboard', () => connection.trpc.voice.onSoundboard.subscribe(undefined, { onData: handlers.onVoiceSoundboard, onError: (error: unknown) => handlers.onError?.('voice.onSoundboard', error) }))] : []),
    sub('messages.onNew', () => connection.trpc.messages.onNew.subscribe(undefined, { onData: handlers.onMessageNew, onError: (error: unknown) => handlers.onError?.('messages.onNew', error) })),
    sub('messages.onUpdate', () => connection.trpc.messages.onUpdate.subscribe(undefined, { onData: handlers.onMessageUpdate, onError: (error: unknown) => handlers.onError?.('messages.onUpdate', error) })),
    sub('messages.onDelete', () => connection.trpc.messages.onDelete.subscribe(undefined, { onData: handlers.onMessageDelete, onError: (error: unknown) => handlers.onError?.('messages.onDelete', error) })),
    sub('messages.onTyping', () => connection.trpc.messages.onTyping.subscribe(undefined, { onData: handlers.onMessageTyping, onError: (error: unknown) => handlers.onError?.('messages.onTyping', error) })),
    sub('messages.onThreadReplyCountUpdate', () => connection.trpc.messages.onThreadReplyCountUpdate.subscribe(undefined, { onData: handlers.onThreadReplyCountUpdate, onError: (error: unknown) => handlers.onError?.('messages.onThreadReplyCountUpdate', error) })),
    sub('dms.onConversationOpen', () => connection.trpc.dms.onConversationOpen.subscribe(undefined, { onData: handlers.onDmConversationOpen, onError: (error: unknown) => handlers.onError?.('dms.onConversationOpen', error) })),
    sub('others.onServerSettingsUpdate', () => connection.trpc.others.onServerSettingsUpdate.subscribe(undefined, { onData: handlers.onServerSettingsUpdate, onError: (error: unknown) => handlers.onError?.('others.onServerSettingsUpdate', error) })),
    sub('channels.onReadStateUpdate', () => connection.trpc.channels.onReadStateUpdate.subscribe(undefined, { onData: handlers.onReadStateUpdate, onError: (error: unknown) => handlers.onError?.('channels.onReadStateUpdate', error) })),
    sub('channels.onReadStateDelta', () => connection.trpc.channels.onReadStateDelta.subscribe(undefined, { onData: handlers.onReadStateDelta, onError: (error: unknown) => handlers.onError?.('channels.onReadStateDelta', error) })),
    sub('plugins.onLog', () => connection.trpc.plugins.onLog.subscribe(undefined, { onData: handlers.onPluginLog, onError: (error: unknown) => handlers.onError?.('plugins.onLog', error) })),
    sub('plugins.onCommandsChange', () => connection.trpc.plugins.onCommandsChange.subscribe(undefined, { onData: (data: unknown) => handlers.onPluginCommandsChange?.(normalizePluginCommands(data)), onError: (error: unknown) => handlers.onError?.('plugins.onCommandsChange', error) })),
    sub('plugins.onComponentsChange', () => connection.trpc.plugins.onComponentsChange.subscribe(undefined, { onData: (data: unknown) => handlers.onPluginComponentsChange?.(normalizePluginComponentIds(data)), onError: (error: unknown) => handlers.onError?.('plugins.onComponentsChange', error) })),
    sub('plugins.onMetadataChange', () => connection.trpc.plugins.onMetadataChange.subscribe(undefined, { onData: handlers.onPluginMetadataChange, onError: (error: unknown) => handlers.onError?.('plugins.onMetadataChange', error) })),
    sub('users.onJoin', () => connection.trpc.users.onJoin.subscribe(undefined, { onData: handlers.onUserJoin, onError: (error: unknown) => handlers.onError?.('users.onJoin', error) })),
    sub('users.onLeave', () => connection.trpc.users.onLeave.subscribe(undefined, { onData: handlers.onUserLeave, onError: (error: unknown) => handlers.onError?.('users.onLeave', error) })),
    sub('users.onCreate', () => connection.trpc.users.onCreate.subscribe(undefined, { onData: handlers.onUserCreate, onError: (error: unknown) => handlers.onError?.('users.onCreate', error) })),
    sub('users.onUpdate', () => connection.trpc.users.onUpdate.subscribe(undefined, { onData: handlers.onUserUpdate, onError: (error: unknown) => handlers.onError?.('users.onUpdate', error) })),
    sub('users.onDelete', () => connection.trpc.users.onDelete.subscribe(undefined, { onData: handlers.onUserDelete, onError: (error: unknown) => handlers.onError?.('users.onDelete', error) })),
    sub('channels.onCreate', () => connection.trpc.channels.onCreate.subscribe(undefined, { onData: handlers.onChannelCreate, onError: (error: unknown) => handlers.onError?.('channels.onCreate', error) })),
    sub('channels.onUpdate', () => connection.trpc.channels.onUpdate.subscribe(undefined, { onData: handlers.onChannelUpdate, onError: (error: unknown) => handlers.onError?.('channels.onUpdate', error) })),
    sub('channels.onDelete', () => connection.trpc.channels.onDelete.subscribe(undefined, { onData: handlers.onChannelDelete, onError: (error: unknown) => handlers.onError?.('channels.onDelete', error) })),
    sub('channels.onPermissionsUpdate', () => connection.trpc.channels.onPermissionsUpdate.subscribe(undefined, { onData: handlers.onChannelPermissionsUpdate, onError: (error: unknown) => handlers.onError?.('channels.onPermissionsUpdate', error) })),
    sub('roles.onCreate', () => connection.trpc.roles.onCreate.subscribe(undefined, { onData: handlers.onRoleCreate, onError: (error: unknown) => handlers.onError?.('roles.onCreate', error) })),
    sub('roles.onUpdate', () => connection.trpc.roles.onUpdate.subscribe(undefined, { onData: handlers.onRoleUpdate, onError: (error: unknown) => handlers.onError?.('roles.onUpdate', error) })),
    sub('roles.onDelete', () => connection.trpc.roles.onDelete.subscribe(undefined, { onData: handlers.onRoleDelete, onError: (error: unknown) => handlers.onError?.('roles.onDelete', error) })),
    sub('emojis.onCreate', () => connection.trpc.emojis.onCreate.subscribe(undefined, { onData: handlers.onEmojiCreate, onError: (error: unknown) => handlers.onError?.('emojis.onCreate', error) })),
    sub('emojis.onUpdate', () => connection.trpc.emojis.onUpdate.subscribe(undefined, { onData: handlers.onEmojiUpdate, onError: (error: unknown) => handlers.onError?.('emojis.onUpdate', error) })),
    sub('emojis.onDelete', () => connection.trpc.emojis.onDelete.subscribe(undefined, { onData: handlers.onEmojiDelete, onError: (error: unknown) => handlers.onError?.('emojis.onDelete', error) })),
    sub('categories.onCreate', () => connection.trpc.categories.onCreate.subscribe(undefined, { onData: handlers.onCategoryCreate, onError: (error: unknown) => handlers.onError?.('categories.onCreate', error) })),
    sub('categories.onUpdate', () => connection.trpc.categories.onUpdate.subscribe(undefined, { onData: handlers.onCategoryUpdate, onError: (error: unknown) => handlers.onError?.('categories.onUpdate', error) })),
    sub('categories.onDelete', () => connection.trpc.categories.onDelete.subscribe(undefined, { onData: handlers.onCategoryDelete, onError: (error: unknown) => handlers.onError?.('categories.onDelete', error) }))
  ].filter(Boolean) as Unsubscribable[];
  return () => subs.forEach((subscription) => subscription.unsubscribe());
}

export async function getChannelMessages(connection: SharkordConnection, channelId: number, limit = 50, options: GetChannelMessagesOptions = {}): Promise<MessagePage> {
  try {
    return await connection.trpc.messages.get.query({ channelId, limit, parentMessageId: options.parentMessageId ?? undefined }) as MessagePage;
  } catch (error) {
    if (options.parentMessageId == null) throw error;
    return connection.trpc.messages.get.query({ channelId, limit }) as Promise<MessagePage>;
  }
}

export async function getThreadInbox(connection: SharkordConnection, limit = 50): Promise<ThreadInboxResponse> {
  if (!connection.serverCapabilities.threadInbox) throw new Error(tr('Dieser Server unterstützt Thread Inbox nicht.'));
  return connection.trpc.messages.getThreadInbox.query({ limit }) as Promise<ThreadInboxResponse>;
}

export async function getUnreadThreads(connection: SharkordConnection, limit = 50): Promise<ThreadInboxResponse> {
  return getThreadInbox(connection, limit);
}

export async function getThreadMessages(connection: SharkordConnection, channelId: number, parentMessageId: number, limit = 50): Promise<MessagePage> {
  const input = { channelId, parentMessageId, limit };
  try {
    return await connection.trpc.messages.getThread.query(input) as MessagePage;
  } catch (error) {
    if (!isMissingTrpcProcedureError(error, 'messages.getThread')) throw error;
    return getChannelMessages(connection, channelId, limit, { parentMessageId });
  }
}

// Legacy source guard: export async function sendChannelMessage(connection: SharkordConnection, channelId: number, plainText: string, files: SharkordTempFile[] = [])
export async function sendChannelMessage(connection: SharkordConnection, channelId: number, plainText: string, files: SharkordTempFile[] = [], options: SendChannelMessageOptions = {}): Promise<void> {
  const content = options.contentHtml ? richTextToSafeHtml(options.contentHtml) : plainTextToHtml(plainText);
  const payload = { channelId, content, files: files.map((file) => file.id), parentMessageId: options.parentMessageId ?? undefined };
  try {
    await connection.trpc.messages.send.mutate(payload);
  } catch (error) {
    if (options.parentMessageId == null) throw error;
    await connection.trpc.messages.send.mutate({ channelId, content, files: files.map((file) => file.id) });
  }
}

export async function signalTyping(connection: SharkordConnection, channelId: number): Promise<void>;
export async function signalTyping(connection: SharkordConnection, channelId: number, parentMessageId: number | null): Promise<void>;
export async function signalTyping(connection: SharkordConnection, channelId: number, parentMessageId?: number | null): Promise<void> {
  if (parentMessageId == null) {
    await connection.trpc.messages.signalTyping.mutate({ channelId });
    return;
  }
  try {
    await connection.trpc.messages.signalTyping.mutate({ channelId, parentMessageId: parentMessageId ?? undefined });
  } catch {
    await connection.trpc.messages.signalTyping.mutate({ channelId });
  }
}

export async function editMessage(connection: SharkordConnection, messageId: number, plainText: string, files: SharkordTempFile[] = []): Promise<void> {
  const payload: { messageId: number; content: string; files?: string[] } = { messageId, content: plainTextToHtml(plainText) };
  if (files.length > 0) {
    if (!connection.serverCapabilities.messageEditAttachments) throw new Error(tr('Server unterstützt Anhänge beim Bearbeiten nicht.'));
    payload.files = files.map((file) => String(file.id));
  }
  await connection.trpc.messages.edit.mutate(payload);
}

export async function deleteMessage(connection: SharkordConnection, messageId: number): Promise<void> {
  await connection.trpc.messages.delete.mutate({ messageId });
}

export async function getOwnStorageFiles(connection: SharkordConnection): Promise<SharkordFile[]> {
  const info = await connection.trpc.users.getInfo.query({ userId: connection.join.ownUserId }) as { files?: SharkordFile[] };
  return info.files ?? [];
}

export async function deleteStoredFile(connection: SharkordConnection, fileId: number): Promise<void> {
  await connection.trpc.files.delete.mutate({ fileId });
}

export async function toggleMessagePin(connection: SharkordConnection, messageId: number): Promise<void> {
  await connection.trpc.messages.togglePin.mutate({ messageId });
}

export async function toggleReaction(connection: SharkordConnection, messageId: number, emoji = '👍'): Promise<void> {
  await connection.trpc.messages.toggleReaction.mutate({ messageId, emoji });
}

export async function joinVoiceChannel(connection: SharkordConnection, channelId: number, state: VoiceState) {
  return connection.trpc.voice.join.mutate({ channelId, state });
}

export async function leaveVoiceChannel(connection: SharkordConnection): Promise<void> {
  await connection.trpc.voice.leave.mutate();
}

export async function updateVoiceState(connection: SharkordConnection, state: Partial<VoiceState>): Promise<void> {
  await connection.trpc.voice.updateState.mutate(state);
}

export async function reactVoice(connection: SharkordConnection, emoji: string): Promise<void> {
  if (!connection.serverCapabilities.voiceReactions) throw new Error(tr('Server unterstützt Voice-Reactions nicht.'));
  try {
    await connection.trpc.voice.react.mutate({ emoji });
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'voice.react')) throw new Error(tr('Server unterstützt Voice-Reactions nicht.'));
    throw error;
  }
}

export async function playVoiceSoundboard(connection: SharkordConnection, soundId: DesktopSoundboardId): Promise<void> {
  if (!connection.serverCapabilities.voiceSoundboard) throw new Error(tr('Server unterstützt Soundboard nicht.'));
  try {
    await connection.trpc.voice.playSoundboard.mutate({ soundId });
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'voice.playSoundboard')) throw new Error(tr('Server unterstützt Soundboard nicht.'));
    throw error;
  }
}

export async function recoverVoiceMedia(connection: SharkordConnection): Promise<{ recoveredKinds: string[]; consumerTransportReset?: boolean }> {
  if (!connection.serverCapabilities.voiceMediaRecovery) throw new Error(tr('Server unterstützt Voice-Recovery nicht.'));
  try {
    return await connection.trpc.voice.recoverMedia.mutate() as { recoveredKinds: string[]; consumerTransportReset?: boolean };
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'voice.recoverMedia')) throw new Error(tr('Server unterstützt Voice-Recovery nicht.'));
    throw error;
  }
}

export async function moveVoiceUser(connection: SharkordConnection, userId: number, destinationChannelId: number): Promise<void> {
  if (!connection.serverCapabilities.voiceUserMove) throw new Error(tr('Server unterstützt Voice-User verschieben nicht.'));
  try {
    await connection.trpc.voice.moveUser.mutate({ userId, destinationChannelId });
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'voice.moveUser')) throw new Error(tr('Server unterstützt Voice-User verschieben nicht.'));
    throw error;
  }
}

export async function disconnectVoiceUser(connection: SharkordConnection, userId: number): Promise<void> {
  if (!connection.serverCapabilities.voiceUserDisconnect) throw new Error(tr('Server unterstützt Voice-Disconnect nicht.'));
  try {
    await connection.trpc.voice.disconnectUser.mutate({ userId });
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'voice.disconnectUser')) throw new Error(tr('Server unterstützt Voice-Disconnect nicht.'));
    throw error;
  }
}


export type ChannelLinkTarget = {
  channelId: number;
  id?: number;
  name: string;
  type: 'TEXT' | 'VOICE';
  categoryId?: number | null;
};

export async function stopUserVoiceMedia(connection: SharkordConnection, userId: number, kind: 'video' | 'screen' | 'screen_audio'): Promise<{ closedKinds: string[] }> {
  if (!connection.serverCapabilities.voiceUserMediaModeration) throw new Error(tr('Server unterstützt Voice-Medien-Moderation nicht.'));
  try {
    return await connection.trpc.voice.closeUserProducer.mutate({ userId, kind }) as { closedKinds: string[] };
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'voice.closeUserProducer')) throw new Error(tr('Server unterstützt Voice-Medien-Moderation nicht.'));
    throw error;
  }
}

export async function resolveChannelLink(connection: SharkordConnection, channelId: number): Promise<ChannelLinkTarget> {
  if (!connection.serverCapabilities.channelLinks) throw new Error(tr('Server unterstützt Channel-Links nicht.'));
  try {
    return await connection.trpc.channels.resolveLink.query({ channelId }) as ChannelLinkTarget;
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'channels.resolveLink')) throw new Error(tr('Server unterstützt Channel-Links nicht.'));
    throw error;
  }
}

export async function getServerSettings(connection: SharkordConnection): Promise<SharkordServerSettings> {
  return connection.trpc.others.getSettings.query() as Promise<SharkordServerSettings>;
}

export async function saveServerSettings(connection: SharkordConnection, settings: Partial<SharkordServerSettings>): Promise<void> {
  await connection.trpc.others.updateSettings.mutate(settings);
}

export async function getStorageSettings(connection: SharkordConnection): Promise<SharkordStorageSettingsResponse> {
  return connection.trpc.others.getStorageSettings.query() as Promise<SharkordStorageSettingsResponse>;
}

export async function listIncomingWebhooks(connection: SharkordConnection): Promise<IncomingWebhookSummary[]> {
  if (!connection.serverCapabilities.incomingWebhooks) throw new Error(tr('Dieser Server unterstützt Incoming Webhooks nicht.'));
  return connection.trpc.webhooks.list.query() as Promise<IncomingWebhookSummary[]>;
}

export async function createIncomingWebhook(connection: SharkordConnection, input: { name: string; channelId: number }): Promise<IncomingWebhookCreateResult> {
  if (!connection.serverCapabilities.incomingWebhooks) throw new Error(tr('Dieser Server unterstützt Incoming Webhooks nicht.'));
  return connection.trpc.webhooks.create.mutate(input) as Promise<IncomingWebhookCreateResult>;
}

export async function deleteIncomingWebhook(connection: SharkordConnection, webhookId: number): Promise<void> {
  if (!connection.serverCapabilities.incomingWebhooks) throw new Error(tr('Dieser Server unterstützt Incoming Webhooks nicht.'));
  await connection.trpc.webhooks.delete.mutate({ webhookId });
}

export async function previewRetention(connection: SharkordConnection): Promise<RetentionPreview> {
  if (!connection.serverCapabilities.retentionPolicies) throw new Error(tr('Dieser Server unterstützt Retention Policies nicht.'));
  return connection.trpc.retention.preview.query() as Promise<RetentionPreview>;
}

export async function runRetentionCleanup(connection: SharkordConnection, dryRun = true): Promise<RetentionRunResult> {
  if (!connection.serverCapabilities.retentionPolicies) throw new Error(tr('Dieser Server unterstützt Retention Policies nicht.'));
  return connection.trpc.retention.run.mutate({ dryRun }) as Promise<RetentionRunResult>;
}

export async function getIpSecurityRules(connection: SharkordConnection): Promise<SharkordIpSecurityRule[]> {
  if (!connection.serverCapabilities.securityIpRules) throw new Error(tr('Dieser Server unterstützt IP-Sicherheit nicht.'));
  return normalizeIpSecurityRulesResponse(await connection.trpc.security.getIpRules.query() as SharkordIpSecurityRulesResponse);
}

export async function getIpSecurityEvents(connection: SharkordConnection): Promise<SharkordIpSecurityEvent[]> {
  if (!connection.serverCapabilities.securityIpRules) throw new Error(tr('Dieser Server unterstützt IP-Sicherheit nicht.'));
  try {
    return await connection.trpc.security.getSecurityEvents.query() as Promise<SharkordIpSecurityEvent[]>;
  } catch (error) {
    if (!isMissingTrpcProcedureError(error, 'security.getSecurityEvents')
      && !isMissingTrpcProcedureError(error, 'security,getSecurityEvents')) throw error;
    return connection.trpc.security.getIpSecurityEvents.query() as Promise<SharkordIpSecurityEvent[]>;
  }
}

export async function addIpAllowlist(connection: SharkordConnection, input: { ipRange: string; reason?: string; expiresAt?: number | null }): Promise<void> {
  if (!connection.serverCapabilities.securityIpRules) throw new Error(tr('Dieser Server unterstützt IP-Sicherheit nicht.'));
  await connection.trpc.security.addIpAllowlist.mutate(input);
}

export async function addIpBlock(connection: SharkordConnection, input: { ipRange: string; reason?: string; expiresAt?: number | null }): Promise<void> {
  if (!connection.serverCapabilities.securityIpRules) throw new Error(tr('Dieser Server unterstützt IP-Sicherheit nicht.'));
  await connection.trpc.security.addIpBlock.mutate(input);
}

export async function removeIpSecurityRule(connection: SharkordConnection, ruleId: number): Promise<void> {
  if (!connection.serverCapabilities.securityIpRules) throw new Error(tr('Dieser Server unterstützt IP-Sicherheit nicht.'));
  await connection.trpc.security.removeIpRule.mutate({ ruleId });
}

export async function unblockIp(connection: SharkordConnection, ipRange: string): Promise<void> {
  if (!connection.serverCapabilities.securityIpRules) throw new Error(tr('Dieser Server unterstützt IP-Sicherheit nicht.'));
  try {
    await connection.trpc.security.unblockIp.mutate({ ip: ipRange });
  } catch (error) {
    if (!cleanClientError(error).includes('Required')) throw error;
    await connection.trpc.security.unblockIp.mutate({ ipRange });
  }
}

export async function useSecretToken(connection: SharkordConnection, token: string): Promise<void> {
  try {
    await connection.trpc.others.useSecretToken.mutate({ token });
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'others.useSecretToken')) throw new Error(tr('Server unterstützt Owner-Token nicht.'));
    throw error;
  }
}

export async function getServerUpdate(connection: SharkordConnection): Promise<SharkordServerUpdateInfo> {
  try {
    return await connection.trpc.others.getUpdate.query() as SharkordServerUpdateInfo;
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'others.getUpdate')) throw new Error(tr('Server unterstützt Update-Prüfung nicht.'));
    throw error;
  }
}

export async function updateServer(connection: SharkordConnection): Promise<void> {
  try {
    await connection.trpc.others.updateServer.mutate();
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'others.updateServer')) throw new Error(tr('Server unterstützt Inplace-Updates nicht.'));
    throw error;
  }
}

export async function createCategory(connection: SharkordConnection, name: string): Promise<number> {
  return connection.trpc.categories.add.mutate({ name }) as Promise<number>;
}

export async function getCategoryDetail(connection: SharkordConnection, categoryId: number): Promise<SharkordCategory> {
  return connection.trpc.categories.get.query({ categoryId }) as Promise<SharkordCategory>;
}

export async function updateCategory(connection: SharkordConnection, categoryId: number, name: string): Promise<void> {
  await connection.trpc.categories.update.mutate({ categoryId, name });
}

export async function deleteCategory(connection: SharkordConnection, categoryId: number): Promise<void> {
  await connection.trpc.categories.delete.mutate({ categoryId });
}

export async function createChannel(connection: SharkordConnection, input: { name: string; type: string; categoryId: number }): Promise<number> {
  return connection.trpc.channels.add.mutate(input) as Promise<number>;
}

export async function getChannelDetail(connection: SharkordConnection, channelId: number): Promise<SharkordChannel> {
  return connection.trpc.channels.get.query({ channelId }) as Promise<SharkordChannel>;
}

export async function updateChannel(connection: SharkordConnection, input: { channelId: number; name: string; topic?: string | null; private?: boolean }): Promise<void> {
  await connection.trpc.channels.update.mutate(input);
}

type ChannelPermissionRow = {
  channelId?: number;
  roleId?: number;
  userId?: number;
  permission?: string;
  allow?: boolean;
};

type ChannelPermissionResponsePayload = {
  overrides?: ChannelPermissionOverride[];
  rolePermissions?: ChannelPermissionRow[];
  userPermissions?: ChannelPermissionRow[];
};

type ChannelPermissionResponse = ChannelPermissionOverride[] | ChannelPermissionResponsePayload;

function normalizeChannelPermissionNames(permissions: string[]): string[] {
  return [...new Set(permissions.filter((permission) => typeof permission === 'string' && permission.trim()).map((permission) => permission.trim()))];
}

function channelPermissionTargetPayload(targetType: ChannelPermissionTarget, targetId: number): { roleId: number } | { userId: number } {
  return targetType === 'user' ? { userId: targetId } : { roleId: targetId };
}

function pushChannelPermissionRow(groups: Map<string, ChannelPermissionOverride>, targetType: ChannelPermissionTarget, targetId: number | undefined, row: ChannelPermissionRow) {
  if (!Number.isFinite(targetId) || typeof row.permission !== 'string' || !row.permission.trim()) return;
  const key = `${targetType}:${targetId}`;
  const override = groups.get(key) ?? { targetType, targetId: targetId!, allow: [], deny: [] };
  const permission = row.permission.trim();
  if (row.allow) {
    if (!override.allow.includes(permission)) override.allow.push(permission);
  } else if (!override.deny.includes(permission)) {
    override.deny.push(permission);
  }
  groups.set(key, override);
}

export function normalizeChannelPermissionOverrides(raw: ChannelPermissionResponse | unknown): ChannelPermissionOverride[] {
  if (Array.isArray(raw)) {
    const groups = new Map<string, ChannelPermissionOverride>();
    const legacyOverrides: ChannelPermissionOverride[] = [];
    for (const item of raw) {
      if (!item || typeof item !== 'object') continue;
      const row = item as Partial<ChannelPermissionOverride> & ChannelPermissionRow;
      if ((row.targetType === 'role' || row.targetType === 'user') && Number.isFinite(row.targetId)) {
        legacyOverrides.push({ targetType: row.targetType, targetId: row.targetId!, allow: normalizeChannelPermissionNames(row.allow ?? []), deny: normalizeChannelPermissionNames(row.deny ?? []) });
      } else if (Number.isFinite(row.roleId)) {
        pushChannelPermissionRow(groups, 'role', row.roleId, row);
      } else if (Number.isFinite(row.userId)) {
        pushChannelPermissionRow(groups, 'user', row.userId, row);
      }
    }
    return legacyOverrides.length ? legacyOverrides : [...groups.values()];
  }

  if (!raw || typeof raw !== 'object') return [];
  const payload = raw as ChannelPermissionResponsePayload;
  if (Array.isArray(payload.overrides)) return normalizeChannelPermissionOverrides(payload.overrides);

  const groups = new Map<string, ChannelPermissionOverride>();
  for (const row of payload.rolePermissions ?? []) pushChannelPermissionRow(groups, 'role', row.roleId, row);
  for (const row of payload.userPermissions ?? []) pushChannelPermissionRow(groups, 'user', row.userId, row);
  return [...groups.values()];
}

export async function getChannelPermissions(connection: SharkordConnection, channelId: number): Promise<ChannelPermissionOverride[]> {
  try {
    return normalizeChannelPermissionOverrides(await connection.trpc.channels.getPermissions.mutate({ channelId }));
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'channels.getPermissions')) return [];
    throw new Error(`${tr('Channel-Berechtigungen laden fehlgeschlagen')}: ${cleanClientError(error)}`);
  }
}

export async function updateChannelPermissions(connection: SharkordConnection, channelId: number, targetType: ChannelPermissionTarget, targetId: number, allow: string[], deny: string[]): Promise<void> {
  try {
    const targetPayload = channelPermissionTargetPayload(targetType, targetId);
    await connection.trpc.channels.updatePermissions.mutate({ channelId, ...targetPayload, permissions: normalizeChannelPermissionNames(allow) });
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'channels.updatePermissions')) throw new Error(tr('Server unterstützt Channel-Berechtigungs-Overrides noch nicht.'));
    throw new Error(`${tr('Channel-Berechtigungen speichern fehlgeschlagen')}: ${cleanClientError(error)}`);
  }
}

export async function deleteChannelPermissions(connection: SharkordConnection, channelId: number, targetType: ChannelPermissionTarget, targetId: number): Promise<void> {
  try {
    const targetPayload = channelPermissionTargetPayload(targetType, targetId);
    await connection.trpc.channels.deletePermissions.mutate({ channelId, ...targetPayload });
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'channels.deletePermissions')) throw new Error(tr('Server unterstützt Channel-Berechtigungs-Overrides noch nicht.'));
    throw new Error(`${tr('Channel-Berechtigungen löschen fehlgeschlagen')}: ${cleanClientError(error)}`);
  }
}

export async function deleteChannel(connection: SharkordConnection, channelId: number): Promise<void> {
  await connection.trpc.channels.delete.mutate({ channelId });
}

export async function reorderChannels(connection: SharkordConnection, categoryId: number, channelIds: number[]): Promise<void> {
  await connection.trpc.channels.reorder.mutate({ categoryId, channelIds });
}

export async function reorderCategories(connection: SharkordConnection, categoryIds: number[]): Promise<void> {
  await connection.trpc.categories.reorder.mutate({ categoryIds });
}

function normalizedRoleWeight(role: SharkordRole): number {
  const weight = Number(role.weight ?? (role.id === 1 ? 0 : 100));
  return Number.isFinite(weight) && weight >= 0 ? Math.round(weight) : role.id === 1 ? 0 : 100;
}

export async function getRoles(connection: SharkordConnection): Promise<SharkordRole[]> {
  return connection.trpc.roles.getAll.query() as Promise<SharkordRole[]>;
}

export async function createRole(connection: SharkordConnection): Promise<number> {
  return connection.trpc.roles.add.mutate() as Promise<number>;
}

export async function updateRole(connection: SharkordConnection, role: SharkordRole): Promise<void> {
  await connection.trpc.roles.update.mutate({ roleId: role.id, name: role.name, color: role.color, permissions: role.permissions ?? [], mentionable: !!role.mentionable, storageQuotaOverrideEnabled: !!role.storageQuotaOverrideEnabled, storageSpaceQuota: Number(role.storageSpaceQuota ?? 0), weight: normalizedRoleWeight(role) });
}

export async function deleteRole(connection: SharkordConnection, roleId: number): Promise<void> {
  await connection.trpc.roles.delete.mutate({ roleId });
}

export async function setDefaultRole(connection: SharkordConnection, roleId: number): Promise<void> {
  await connection.trpc.roles.setDefault.mutate({ roleId });
}

export async function getAdminUsers(connection: SharkordConnection): Promise<SharkordUser[]> {
  const users = await connection.trpc.users.getAll.query() as SharkordUser[];
  return users.filter((user) => !isDeletedUserPlaceholder(user));
}

export async function getAccessibleMembers(connection: SharkordConnection, channelId: number, includeAll = false): Promise<SharkordUser[]> {
  if (!connection.serverCapabilities.channelAccessMembers) return connection.join.users.filter((user) => !isDeletedUserPlaceholder(user));
  try {
    const users = await connection.trpc.channels.getAccessibleMembers.query({ channelId, includeAll }) as SharkordUser[];
    return users.filter((user) => !isDeletedUserPlaceholder(user));
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'channels.getAccessibleMembers')) return connection.join.users.filter((user) => !isDeletedUserPlaceholder(user));
    throw error;
  }
}

export async function getUserInfo(connection: SharkordConnection, userId: number): Promise<SharkordUserInfo> {
  return connection.trpc.users.getInfo.query({ userId }) as Promise<SharkordUserInfo>;
}

export async function getDirectMessages(connection: SharkordConnection): Promise<DirectMessageConversation[]> {
  try {
    return await connection.trpc.dms.get.query() as DirectMessageConversation[];
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'dms.get')) return [];
    throw error;
  }
}

export async function deleteDirectMessage(connection: SharkordConnection, channelId: number): Promise<void> {
  try {
    await connection.trpc.dms.delete.mutate({ channelId });
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'dms.delete')) throw new Error(tr('Server unterstützt DM-Löschen noch nicht.'));
    throw error;
  }
}

export async function hideDirectMessage(connection: SharkordConnection, channelId: number): Promise<void> {
  if (!connection.serverCapabilities.directMessageHide) throw new Error(tr('Server unterstützt DM-Ausblenden noch nicht.'));
  try {
    await connection.trpc.dms.hide.mutate({ channelId });
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'dms.hide')) throw new Error(tr('Server unterstützt DM-Ausblenden noch nicht.'));
    throw error;
  }
}

export async function openDirectMessage(connection: SharkordConnection, userId: number): Promise<{ channelId: number }> {
  try {
    return await connection.trpc.dms.open.mutate({ userId }) as { channelId: number };
  } catch (error) {
    if (isMissingTrpcProcedureError(error, 'dms.open')) throw new Error(tr('Server unterstützt Direktnachrichten noch nicht.'));
    throw error;
  }
}

export async function moderateUser(connection: SharkordConnection, action: 'kick' | 'ban' | 'unban' | 'delete', userId: number, options: { reason?: string; wipe?: boolean } = {}): Promise<void> {
  if (action === 'kick') await connection.trpc.users.kick.mutate({ userId, reason: options.reason });
  if (action === 'ban') await connection.trpc.users.ban.mutate({ userId, reason: options.reason });
  if (action === 'unban') await connection.trpc.users.unban.mutate({ userId });
  if (action === 'delete') await connection.trpc.users.delete.mutate({ userId, wipe: !!options.wipe });
}

export async function addRoleToUser(connection: SharkordConnection, userId: number, roleId: number): Promise<void> {
  await connection.trpc.users.addRole.mutate({ userId, roleId });
}

export async function removeRoleFromUser(connection: SharkordConnection, userId: number, roleId: number): Promise<void> {
  await connection.trpc.users.removeRole.mutate({ userId, roleId });
}

export async function getInvites(connection: SharkordConnection): Promise<SharkordInvite[]> {
  return connection.trpc.invites.getAll.query() as Promise<SharkordInvite[]>;
}

export async function createInvite(connection: SharkordConnection, input: { code?: string; maxUses?: number; expiresAt?: number | null; roleId?: number }): Promise<SharkordInvite> {
  return connection.trpc.invites.add.mutate(input) as Promise<SharkordInvite>;
}

export async function deleteInvite(connection: SharkordConnection, inviteId: number): Promise<void> {
  await connection.trpc.invites.delete.mutate({ inviteId });
}


export const SHARKORD_MARKETPLACE_REGISTRY_URL = 'https://raw.githubusercontent.com/Sharkord/plugins/refs/heads/main/plugins.json?raw=true';

export async function uploadTemporaryFile(connection: SharkordConnection, file: File): Promise<SharkordTempFile> {
  const safeName = file.name.trim().normalize('NFKD').replace(/[^\x00-\x7F]/g, '_') || 'upload.bin';
  const response = await fetch(`${connection.baseUrl}/upload`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/octet-stream',
      'x-file-type': file.type || 'application/octet-stream',
      'x-file-name': safeName,
      'x-token': await connection.getFreshToken()
    },
    body: file
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.error || tr(`Upload fehlgeschlagen (${response.status})`));
  return data as SharkordTempFile;
}

export async function deleteTemporaryFile(connection: SharkordConnection, fileId: SharkordTempFile['id']): Promise<void> {
  await connection.trpc.files.deleteTemporary.mutate({ fileId: String(fileId) });
}

export async function uploadEmoji(connection: SharkordConnection, file: File, name: string): Promise<void> {
  if (!file.type.startsWith('image/')) throw new Error(tr('Nur Bilddateien erlaubt'));
  const tempFile = await uploadTemporaryFile(connection, file);
  const fileId = tempFile.id == null ? undefined : String(tempFile.id);
  if (!fileId) throw new Error(tr('Upload lieferte keine File-ID'));
  const cleanName = name.trim().replace(/\.[^.]+$/, '').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 32) || 'emoji';
  await connection.trpc.emojis.add.mutate([{ fileId, name: cleanName }]);
}

export async function getPlugins(connection: SharkordConnection): Promise<SharkordPluginInfo[]> {
  const result = await connection.trpc.plugins.get.query() as { plugins?: SharkordPluginInfo[] };
  return result.plugins ?? [];
}

export async function togglePlugin(connection: SharkordConnection, pluginId: string, enabled: boolean): Promise<void> {
  await connection.trpc.plugins.toggle.mutate({ pluginId, enabled });
}

export async function removePlugin(connection: SharkordConnection, pluginId: string): Promise<void> {
  await connection.trpc.plugins.remove.mutate({ pluginId });
}

export async function installPlugin(connection: SharkordConnection, pluginId: string, version: string): Promise<void> {
  await connection.trpc.plugins.install.mutate({ pluginId, version });
}

export async function updatePlugin(connection: SharkordConnection, pluginId: string, version: string): Promise<void> {
  await connection.trpc.plugins.update.mutate({ pluginId, version });
}

export async function getMarketplacePlugins(): Promise<SharkordMarketplaceEntry[]> {
  const response = await fetch(SHARKORD_MARKETPLACE_REGISTRY_URL);
  if (!response.ok) throw new Error(tr(`Marketplace fehlgeschlagen (${response.status})`));
  const entries = await response.json() as SharkordMarketplaceEntry[];
  return [...entries].map((entry) => ({ ...entry, versions: [...(entry.versions ?? [])].sort((a, b) => (b.timestamp ?? 0) - (a.timestamp ?? 0)) })).sort((a, b) => ((b.versions?.[0]?.timestamp ?? 0) - (a.versions?.[0]?.timestamp ?? 0)));
}

export async function getEmojis(connection: SharkordConnection): Promise<SharkordEmoji[]> {
  return connection.trpc.emojis.getAll.query() as Promise<SharkordEmoji[]>;
}

export async function updateEmoji(connection: SharkordConnection, emojiId: number, name: string): Promise<void> {
  await connection.trpc.emojis.update.mutate({ emojiId, name });
}

export async function deleteEmoji(connection: SharkordConnection, emojiId: number): Promise<void> {
  await connection.trpc.emojis.delete.mutate({ emojiId });
}


export async function getPinnedMessages(connection: SharkordConnection, channelId: number): Promise<SharkordMessage[]> {
  return connection.trpc.messages.getPinned.query({ channelId }) as Promise<SharkordMessage[]>;
}

export async function getMessage(connection: SharkordConnection, messageId: number): Promise<SharkordMessage> {
  return connection.trpc.messages.getOne.query({ messageId }) as Promise<SharkordMessage>;
}

export async function getMessagePageAround(connection: SharkordConnection, channelId: number, messageId: number, limit = 50): Promise<MessagePage> {
  return connection.trpc.messages.get.query({ channelId, targetMessageId: messageId, cursor: null, limit }) as Promise<MessagePage>;
}

type GlobalSearchInput = { query: string; cursor?: number | string | null; limit?: number };
type MessageSearchResponse = Partial<GlobalSearchMessagePage & GlobalSearchFilePage> & {
  results?: GlobalSearchMessagePage['messages'];
  items?: GlobalSearchMessagePage['messages'];
  fileResults?: GlobalSearchFilePage['files'];
  fileItems?: GlobalSearchFilePage['files'];
};

async function queryGlobalSearch(connection: SharkordConnection, input: GlobalSearchInput): Promise<GlobalSearchMessagePage & GlobalSearchFilePage> {
  const result = await connection.trpc.messages.search.query({ query: input.query, cursor: input.cursor ?? null, limit: input.limit ?? 25 }) as MessageSearchResponse | GlobalSearchMessagePage['messages'];
  if (Array.isArray(result)) return { messages: result, files: [], nextCursor: null };
  return {
    messages: result.messages ?? result.results ?? result.items ?? [],
    files: result.files ?? result.fileResults ?? result.fileItems ?? [],
    nextCursor: result.nextCursor ?? null
  };
}

export async function globalSearchMessages(connection: SharkordConnection, input: GlobalSearchInput): Promise<GlobalSearchMessagePage> {
  return queryGlobalSearch(connection, input);
}

export async function globalSearchFiles(connection: SharkordConnection, input: GlobalSearchInput): Promise<GlobalSearchFilePage> {
  const result = await queryGlobalSearch(connection, input);
  return { files: result.files, nextCursor: result.nextCursor };
}

export async function markChannelAsRead(connection: SharkordConnection, channelId: number): Promise<void> {
  await connection.trpc.channels.markAsRead.mutate({ channelId });
}

export async function changeServerLogo(connection: SharkordConnection, file?: File): Promise<void> {
  const tempFile = file ? await uploadTemporaryFile(connection, file) : undefined;
  await connection.trpc.others.changeLogo.mutate({ fileId: tempFile ? String(tempFile.id) : undefined });
}

export async function updateOwnProfile(connection: SharkordConnection, input: { name: string; bannerColor: string; bio?: string; statusOverride?: string | null; statusMessage?: string | null }): Promise<void> {
  const payload = connection.serverCapabilities.customUserStatus ? input : { name: input.name, bannerColor: input.bannerColor, bio: input.bio };
  await connection.trpc.users.update.mutate(payload);
}

export async function changeOwnAvatar(connection: SharkordConnection, file?: File): Promise<void> {
  const tempFile = file ? await uploadTemporaryFile(connection, file) : undefined;
  await connection.trpc.users.changeAvatar.mutate({ fileId: tempFile ? String(tempFile.id) : undefined });
}

export async function changeOwnBanner(connection: SharkordConnection, file?: File): Promise<void> {
  const tempFile = file ? await uploadTemporaryFile(connection, file) : undefined;
  await connection.trpc.users.changeBanner.mutate({ fileId: tempFile ? String(tempFile.id) : undefined });
}

export async function updateOwnPassword(connection: SharkordConnection, input: { currentPassword: string; newPassword: string; confirmNewPassword: string }): Promise<void> {
  await connection.trpc.users.updatePassword.mutate(input);
}

export async function getOwnMfaStatus(connection: SharkordConnection): Promise<MfaStatus> {
  return connection.trpc.users.mfa.status.query() as Promise<MfaStatus>;
}

export async function startOwnTotpSetup(connection: SharkordConnection): Promise<TotpSetupResponse> {
  return connection.trpc.users.mfa.start.mutate() as Promise<TotpSetupResponse>;
}

export async function enableOwnTotp(connection: SharkordConnection, code: string): Promise<{ enabled: boolean; recoveryCodes?: string[] }> {
  return connection.trpc.users.mfa.enable.mutate({ code }) as Promise<{ enabled: boolean; recoveryCodes?: string[] }>;
}

export async function disableOwnTotp(connection: SharkordConnection, input: { password: string; code?: string }): Promise<void> {
  await connection.trpc.users.mfa.disable.mutate(input);
}

export async function regenerateOwnRecoveryCodes(connection: SharkordConnection, input: { password: string; code?: string }): Promise<string[]> {
  return connection.trpc.users.mfa.regenerateRecoveryCodes.mutate(input) as Promise<string[]>;
}

export async function getOwnAppPasswords(connection: SharkordConnection): Promise<AppPasswordSummary[]> {
  return connection.trpc.users.mfa.appPasswords.query() as Promise<AppPasswordSummary[]>;
}

export async function revokeOwnAppPassword(connection: SharkordConnection, id: number): Promise<void> {
  await connection.trpc.users.mfa.revokeAppPassword.mutate({ id });
}

export async function requestDesktopNotificationPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (typeof Notification === 'undefined') return 'unsupported';
  if (Notification.permission === 'default') return Notification.requestPermission();
  return Notification.permission;
}

export async function getPluginCommands(connection: SharkordConnection, pluginId?: string): Promise<Record<string, SharkordPluginCommand[]> | SharkordPluginCommand[]> {
  return connection.trpc.plugins.getCommands.query({ pluginId }) as Promise<Record<string, SharkordPluginCommand[]> | SharkordPluginCommand[]>;
}

function normalizePluginCommands(data: unknown): Record<string, SharkordPluginCommand[]> {
  const value = (data && typeof data === 'object' && !Array.isArray(data) && 'commands' in data)
    ? (data as { commands?: unknown }).commands
    : data;
  const byPlugin: Record<string, SharkordPluginCommand[]> = {};
  const append = (pluginId: string | undefined, commands: unknown) => {
    if (!pluginId || !Array.isArray(commands)) return;
    byPlugin[pluginId] = commands
      .filter((command): command is SharkordPluginCommand => !!command && typeof command === 'object' && typeof (command as SharkordPluginCommand).name === 'string')
      .map((command) => ({ ...command, pluginId: command.pluginId ?? pluginId }));
  };
  if (Array.isArray(value)) {
    value.forEach((command) => {
      if (!command || typeof command !== 'object') return;
      const pluginId = (command as SharkordPluginCommand).pluginId;
      if (!pluginId || typeof (command as SharkordPluginCommand).name !== 'string') return;
      byPlugin[pluginId] = [...(byPlugin[pluginId] ?? []), command as SharkordPluginCommand];
    });
    return byPlugin;
  }
  if (value && typeof value === 'object') {
    Object.entries(value as Record<string, unknown>).forEach(([pluginId, commands]) => append(pluginId, commands));
  }
  return byPlugin;
}

export async function executePluginCommand(connection: SharkordConnection, pluginId: string, commandName: string, args: Record<string, unknown> = {}): Promise<unknown> {
  return connection.trpc.plugins.executeCommand.mutate({ pluginId, commandName, args }) as Promise<unknown>;
}

export async function executePluginAction(connection: SharkordConnection, pluginId: string, actionName: string, payload?: unknown): Promise<unknown> {
  return connection.trpc.plugins.executeAction.mutate({ pluginId, actionName, payload }) as Promise<unknown>;
}

const CLIENT_PLUGIN_ENTRY_FILE = 'client/index.js';
const DESKTOP_PLUGIN_SLOT_BY_SERVER_SLOT: Record<SharkordOfficialPluginSlotId, PluginSlotId> = {
  connect_screen: 'connect',
  home_screen: 'content-wrapper',
  chat_actions: 'chat-actions',
  topbar_right: 'topbar',
  full_screen: 'content-wrapper'
};
const SERVER_PLUGIN_SLOT_LABELS: Record<SharkordOfficialPluginSlotId, string> = {
  connect_screen: 'Connect',
  home_screen: 'Home',
  chat_actions: 'Chat actions',
  topbar_right: 'Topbar',
  full_screen: 'Fullscreen'
};

function normalizePluginComponentIds(data: unknown): string[] {
  const value = (data && typeof data === 'object' && !Array.isArray(data))
    ? ((data as { pluginIdsWithComponents?: unknown; pluginIds?: unknown; components?: unknown }).pluginIdsWithComponents
      ?? (data as { pluginIds?: unknown }).pluginIds
      ?? (data as { components?: unknown }).components)
    : data;
  return Array.isArray(value) ? [...new Set(value.filter((pluginId): pluginId is string => typeof pluginId === 'string' && pluginId.trim().length > 0))] : [];
}

function isRenderablePluginComponent(component: unknown): component is NonNullable<SharkordPluginSlotRender['component']> {
  return typeof component === 'function' || (!!component && typeof component === 'object');
}

export async function processPluginComponents(connection: SharkordConnection, pluginIdsInput: unknown, metadata: SharkordPluginMetadata[] = []): Promise<SharkordPluginSlotRender[]> {
  const metadataById = new Map(metadata.map((entry) => [entry.pluginId, entry]));
  const rows: SharkordPluginSlotRender[] = [];
  for (const pluginId of normalizePluginComponentIds(pluginIdsInput)) {
    try {
      const moduleUrl = `${connection.baseUrl}/plugin-bundle/${encodeURIComponent(pluginId)}/${CLIENT_PLUGIN_ENTRY_FILE}`;
      const mod = await import(/* @vite-ignore */ moduleUrl) as { components?: Partial<Record<SharkordOfficialPluginSlotId, unknown>> };
      const pluginMetadata = metadataById.get(pluginId);
      for (const [serverSlot, desktopSlot] of Object.entries(DESKTOP_PLUGIN_SLOT_BY_SERVER_SLOT) as Array<[SharkordOfficialPluginSlotId, PluginSlotId]>) {
        const slotComponents = mod.components?.[serverSlot];
        const components = Array.isArray(slotComponents) ? slotComponents : slotComponents ? [slotComponents] : [];
        components.forEach((component, componentIndex) => {
          if (!isRenderablePluginComponent(component)) return;
          const slotLabel = SERVER_PLUGIN_SLOT_LABELS[serverSlot];
          rows.push({
            pluginId,
            slot: desktopSlot,
            label: pluginMetadata?.name ?? pluginId,
            title: `${pluginMetadata?.name ?? pluginId} · ${slotLabel}`,
            description: pluginMetadata?.description,
            enabled: true,
            order: componentIndex,
            component,
            componentSlot: serverSlot,
            componentIndex
          });
        });
      }
    } catch {
      // Match the webclient model: one broken plugin component bundle should not block other plugin UI.
    }
  }
  return rows;
}

export async function executePluginSlotAction(connection: SharkordConnection, slotItem: SharkordPluginSlotRender, context: Record<string, unknown> = {}): Promise<unknown> {
  if (!slotItem.pluginId || !slotItem.actionName) throw new Error(tr('Plugin-Slot ohne Action'));
  return connection.trpc.plugins.executeAction.mutate({
    pluginId: slotItem.pluginId,
    actionName: slotItem.actionName,
    payload: { slot: slotItem.slot, context, payload: slotItem.payload }
  }) as Promise<unknown>;
}

export async function getPluginLogs(connection: SharkordConnection, pluginId: string): Promise<SharkordPluginLog[]> {
  return connection.trpc.plugins.getLogs.query({ pluginId }) as Promise<SharkordPluginLog[]>;
}

export async function getPluginSettings(connection: SharkordConnection, pluginId: string): Promise<SharkordPluginSetting[]> {
  return connection.trpc.plugins.getSettings.query({ pluginId }) as Promise<SharkordPluginSetting[]>;
}

export async function updatePluginSetting(connection: SharkordConnection, pluginId: string, key: string, value: string | number | boolean): Promise<void> {
  await connection.trpc.plugins.updateSetting.mutate({ pluginId, key, value });
}

export async function setConsumerQuality(connection: SharkordConnection, remoteId: number, kind: 'video' | 'screen' | 'external_video', quality: StreamQualitySetting): Promise<void> {
  await connection.trpc.voice.setConsumerQuality.mutate({ remoteId, kind, quality });
}

export function playDesktopSound(type: DesktopSoundType) {
  if (typeof window === 'undefined') return;
  const AudioContextCtor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextCtor) return;
  audioCtx ??= new AudioContextCtor();
  if (audioCtx.state === 'suspended') void audioCtx.resume();
  const palette: Record<DesktopSoundType, [number, number, number]> = {
    message_received: [660, 0.045, 0.055],
    message_sent: [760, 0.035, 0.045],
    server_connected: [523, 0.055, 0.07],
    server_disconnected: [220, 0.08, 0.12],
    own_user_joined_voice_channel: [440, 0.06, 0.08],
    own_user_left_voice_channel: [294, 0.06, 0.09],
    own_user_muted_mic: [196, 0.05, 0.08],
    own_user_unmuted_mic: [494, 0.045, 0.065],
    own_user_muted_sound: [165, 0.055, 0.1],
    own_user_unmuted_sound: [587, 0.045, 0.07],
    remote_user_joined_voice_channel: [392, 0.04, 0.07],
    remote_user_left_voice_channel: [247, 0.04, 0.08],
    soundboard_pop: [880, 0.05, 0.05],
    soundboard_airhorn: [220, 0.08, 0.14],
    soundboard_rimshot: [330, 0.055, 0.08],
    soundboard_tada: [660, 0.055, 0.11],
    soundboard_bonk: [180, 0.07, 0.12]
  };
  const [freq, gainValue, length] = palette[type];
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  const now = audioCtx.currentTime;
  osc.type = type.includes('disconnected') || type.includes('muted') ? 'triangle' : 'sine';
  osc.frequency.setValueAtTime(freq, now);
  gain.gain.setValueAtTime(gainValue, now);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + length);
  osc.connect(gain).connect(audioCtx.destination);
  osc.start(now);
  osc.stop(now + length);
}

export function fileUrl(baseUrl: string, file?: SharkordFile | null): string {
  if (!file?.name) return '';
  let url = `${normalizeServerUrl(baseUrl)}/public/${file.name}`;
  if (file._accessToken) {
    url += `?accessToken=${file._accessToken}`;
    if (file._accessTokenExpiresAt) url += `&expires=${file._accessTokenExpiresAt}`;
  }
  return encodeURI(url);
}

export function textFromHtml(html = ''): string {
  const decodeEntities = (value: string) => {
    if (typeof document !== 'undefined') {
      const node = document.createElement('textarea');
      node.innerHTML = value;
      return node.value;
    }
    return value
      .replace(/&#(\d+);/g, (_match, code) => String.fromCodePoint(Number(code)))
      .replace(/&#x([0-9a-f]+);/gi, (_match, code) => String.fromCodePoint(parseInt(code, 16)))
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'")
      .replace(/&nbsp;/g, ' ');
  };
  const attrValue = (tag: string, attr: string) => {
    const match = tag.match(new RegExp(`${attr}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s>]+))`, 'i'));
    return decodeEntities(match?.[2] ?? match?.[3] ?? match?.[4] ?? '').trim();
  };
  const stripInlineTags = (value: string) => value.replace(/<[^>]+>/g, ' ');
  const withRichLabels = html
    .replace(/<\s*(script|style)[^>]*>[\s\S]*?<\s*\/\s*\1\s*>/gi, '')
    .replace(/<\s*a\b([^>]*)>([\s\S]*?)<\s*\/\s*a\s*>/gi, (match, _attrs, body) => {
      const href = attrValue(match, 'href');
      const label = decodeEntities(stripInlineTags(String(body))).replace(/\s+/g, ' ').trim();
      if (!href) return label;
      if (!label || label === href) return href;
      return `${label} (${href})`;
    })
    .replace(/<\s*(img|video|audio|source)\b[^>]*>/gi, (match) => {
      const label = attrValue(match, 'alt') || attrValue(match, 'title') || attrValue(match, 'aria-label');
      const src = attrValue(match, 'src');
      if (label && src) return `${label} (${src})`;
      return label || src || '';
    });
  const normalized = withRichLabels
    .replace(/<\s*br\s*\/?>/gi, '\n')
    .replace(/<\s*\/\s*(p|div|li|h[1-6]|blockquote|pre|tr)\s*>/gi, '\n')
    .replace(/<\s*(p|div|li|h[1-6]|blockquote|pre|tr)[^>]*>/gi, '')
    .replace(/<[^>]+>/g, ' ');
  return decodeEntities(normalized)
    .replace(/[ \t\f\v]+/g, ' ')
    .replace(/ *\n+ */g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

export function richTextToSafeHtml(text: string): string {
  const formatted = escapeHtml(text)
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|\s)\*([^*]+)\*/g, '$1<em>$2</em>');
  const withLinks = replaceOutsideTags(formatted, /https?:\/\/[^\s<]+/g, (url) => `<a href="${url}" target="_blank" rel="noreferrer">${url}</a>`);
  const withRoleMentions = replaceOutsideTags(withLinks, /(^|[\s(])@&([A-Za-z0-9_. -]{1,80})/g, (_match, prefix, name) => `${prefix}<span class="roleMention">@&${name.trim()}</span>`);
  const withMentions = replaceOutsideTags(withRoleMentions, /(^|[\s(])@([A-Za-z0-9_.-]{1,80})/g, (_match, prefix, name) => `${prefix}<span class="mention">@${name}</span>`);
  return `<p>${withMentions.replace(/\n/g, '<br>')}</p>`;
}

function plainTextToHtml(text: string): string {
  return richTextToSafeHtml(text);
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function replaceOutsideTags(html: string, pattern: RegExp, replacer: (...args: string[]) => string): string {
  return html.split(/(<[^>]+>)/g).map((part) => part.startsWith('<') ? part : part.replace(pattern, replacer as never)).join('');
}
